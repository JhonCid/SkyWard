# SkyWard — Documento de Arquitetura Técnica

## 1. Visão Geral da Arquitetura

O SkyWard utiliza uma arquitetura baseada em **módulos de domínio desacoplados**, permitindo desenvolvimento independente e testes automatizados, com um pipeline de compilação que gera um executável web autônomo em arquivo único (`SkyWard.html`).

```
projeto/
├── SkyWard.html             # Artefato final de produção (Single-file, zero dependências)
├── GAME_DESIGN.md           # Especificação viva das regras, controles e mecânicas
├── ARCHITECTURE.md          # Especificação técnica dos subsistemas e APIs
├── ROADMAP.md               # Planejamento de sprints e futuras expansões
├── build.js                 # Pipeline de empacotamento rápido (< 100ms)
├── src/                     # Código-fonte modular por subsistema
│   ├── core/                # Loop, entradas, constantes e sincronização de estado
│   ├── camera/              # Dinâmica procedural em 1ª e 3ª pessoa, zoom e tremores
│   ├── ship/                # Física de voo, propulsores, inclinação e trens de pouso
│   ├── player/              # Biomecânica esquelética, animação e posturas de armas
│   ├── world/               # Geração procedural planetária, relevo, cidades e arcos
│   ├── combat/              # Armas, sintetizador procedural de áudio e IA
│   └── ui/                  # HUD, consoles MFD e menus
└── tests/                   # Bateria automatizada de testes de regressão (CI)
    ├── run_all_tests.js     # Executor mestre de testes automatizados
```

---

## 2. Subsistemas Principais

### 2.1. Sistema de Trens de Pouso (`src/ship/landing_gear.js`)
* **Hierarquia de 4 módulos:** Frontal Esquerdo/Direito e Traseiro Esquerdo/Direito.
* **Componentes:**
  * `bay`: Nicho embutido no casco (`Y = -0.22`).
  * `strutGroup`: Cilindro hidráulico superior telescópico em titânio (`0x1a222c`).
  * `pistonGroup`: Haste interna em aço cromado espelhado (`0xdde7ee`, metalness 0.92).
  * `scissor1` e `scissor2`: Braços articulados anti-torção que abrem e fecham em losango.
  * `footPad`: Sapata octogonal magnética larga com solado amortecedor e LED indicador.
* **Cinemática:**
  * `shipGearProgress`: Varia entre `0.0` (completamente recolhido no nicho) e `1.0` (totalmente estendido e travado).
  * `shipGearSuspension`: Absorve impacto no toque com o solo e retorna elasticamente.

### 2.2. Sistema de Voo e Inclinação Procedural (`src/ship/flight.js`)
* **Separação Navegação vs. Visual:**
  * `shipNavQuaternion`: Rotação inercial verdadeira de navegação.
  * `shipTiltPitch`, `shipTiltRoll`, `shipTiltYaw`: Ângulos cosméticos de inclinação procedural acionados por Espaço, Ctrl, A, D e giro do mouse.
  * `ship.quaternion = shipNavQuaternion * tiltQuaternion`.
  * Ao soltar as teclas, os ângulos de inclinação retornam elasticamente para zero via `MathUtils.lerp` exponencial.

### 2.3. Transições Contínuas de Câmera (`src/camera/camera_manager.js`)
* Roda do mouse e gestos de pinça modulam o fator de aproximação.
* Ao atingir o limite mínimo em 3ª pessoa (`zoom <= 0.48`), a câmera entra em 1ª pessoa.
* Ao afastar em 1ª pessoa (`factor > 1.04`), a câmera puxa para trás do ombro entrando em 3ª pessoa.

---

## 3. Pipeline de Compilação e Testes
* O script `build.js` reúne todos os módulos do `src/` e injeta na casca do HTML com o Three.js pré-carregado.
* O executor `node tests/run_all_tests.js` carrega o ambiente simulado no Node.js com WebGL mock e executa em < 1 segundo todos os testes essenciais.

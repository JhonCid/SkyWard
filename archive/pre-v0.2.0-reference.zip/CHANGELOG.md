# v0.1.41 — Atlas v3 integrada

- Atlas_v3.glb incorporada ao HTML, sem downloads externos; nave padrão da frota.
- Escala uniforme 2×, jogador de 1,8 m e rampa de 6,4 m de largura.
- Seis portas com painéis originais, colisão triangular e abertura deslizante.
- Rampa ventral articulada em sua dobradiça original, fechamento no plano do porão.
- Dois pistões telescópicos com ancoragens fixas e móveis; retração contínua ao fechar.
- Rover acompanha a rampa, entra e sai dirigindo e permanece vinculado à nave no voo.
- Três trens de pouso originais, botões amarelos, comandos do cockpit e faróis.
- Rampas curtas de acesso ao cockpit, marcadores de assento e saída adaptados ao modelo.
- Sondas de pouso e detecção de obstáculos ajustadas ao tamanho da nave.
- 12 verificações de geometria/interação e 6 verificações com o mundo carregado aprovadas.

## [v0.1.40] — 2026-09-20 (Pouso Suave do Piloto Automático sem Trepidação, Visibilidade Real dos Planetas no Céu & Oclusão Completa do Brilho Solar)
### Corrigido & Aprimorado
* **Pouso Suave do Piloto Automático (Sem Parar no Ar nem Tremer):**
  * **Eliminação da Trepidação:** Sincronizado o quaternion de navegação (`shipNavQuaternion`) com o quaternion da nave durante toda a aproximação final e bloqueada a sobreposição de inclinação manual quando o piloto automático está ativo (`if (!auto)`), eliminando o conflito que fazia a nave vibrar/tremer rapidamente.
  * **Descida Vertical Contínua:** Removida a parada brusca no ar (`landWp.copy(ship.position)`), permitindo que a nave continue descendo de forma suave e controlada em direção à pista de pouso enquanto alinha suas sapatas com a normal da superfície.
  * **Toque Suave e Amortecido:** Ajustada a tolerância de toque final para 1,2 m de altitude e 4,6° de desvio angular, garantindo acionamento fluido dos amortecedores e trem de pouso sem congelamento no ar.
* **Visibilidade Nítida dos Outros Planetas no Céu (Superfície e Nuvens):**
  * **Desativação do Nebulizador Oclusivo (`fog = false`):** Explicitamente desativado o efeito de neblina de cena sobre a malha dos planetas e da água, impedindo que a atmosfera local oculte corpos celestes distantes a mais de 3.500 m.
  * **Calibração do Haze Atmosférico:** Reduzido o desbotamento artificial (`planetHaze`) de 0,68 para 0,06. Ao olhar para o céu a partir da superfície de qualquer planeta, os outros corpos celestes aparecem de forma nítida, com seus relevos, continentes e biomas visíveis sob os desenhos translúcidos das suas nuvens.
* **Oclusão Completa do Brilho Solar pela Nave e pelo Rover (Zero Sangramento):**
  * **Oclusão Física da Cabine da Nave:** O brilho solar (lens flare / coroa radiante) agora é bloqueado de forma estrita pela estrutura física da nave. Na cadeira do piloto, o sol só é visível através das janelas de vidro do canopy frontal; ao olhar para cima no teto de metal, para trás na divisória ou para baixo no piso, o brilho solar é 100% ocluído.
  * **Oclusão da Cabine do Rover:** Ao dirigir o rover em primeira pessoa, o teto metálico maciço, a blindagem traseira e o chassi bloqueiam totalmente o brilho do sol.
  * **Oclusão Externa via Raycast:** Em terceira pessoa ou a pé do lado de fora, caso a nave ou o rover estejam posicionados entre a câmera e o sol, o raio de oclusão detecta as malhas opacas e desativa o flare imediatamente.

---

## [v0.1.39] — 2026-09-20 (Correção do Piloto Automático Interplanetário & Restauração Universal das Cidades e Vilarejos)
### Corrigido & Aprimorado
* **Restauração Universal das Cidades e Vilarejos em Todos os Planetas:**
  * Corrigido o problema onde cidades e vilarejos secundários não eram gerados nos outros planetas (Rhodos, Cristalis, etc.): todas as cidades e vilarejos de todos os planetas do sistema agora são gerados e indexados de forma persistente logo no carregamento do sistema.
  * O streaming de superfície não descarta mais as cidades ao se afastar do planeta, garantindo que assentamentos, pistas de pouso, hangares, lojas e habitantes permaneçam sempre existentes e visíveis.
  * **Identificação Clara no Mapa Planetário 3D:** No globo 3D, cada pino agora exibe o rótulo do assentamento específico (ex: `Cidade 1`, `Cidade 2`, `Vilarejo 1`, `Vilarejo 2`) em vez de repetir o nome do planeta.
  * **Correção da Visibilidade Polar no Globo:** Calibrada a inclinação do globo 3D para que locais no polo norte e hemisfério setentrional (incluindo o porto principal e Cidade 1) fiquem frontalmente visíveis ao jogador.
* **Correção do Piloto Automático Interplanetário (Sem Ficar Preso no Espaço):**
  * **Cálculo de Linha de Visada Real (`hasDirectLineOfSight`):** Corrigida a validação de horizonte planetário para viagens interplanetárias. O teste de horizonte de curvatura agora é restrito exclusivamente ao corpo celeste onde o alvo de pouso se encontra, evitando que a partida de um planeta considere falsamente que o destino externo está bloqueado.
  * **Transição Limpa para o Vácuo:** Ao decolar para outro planeta, a nave sobe desobstruída para fora da atmosfera, alinha a trajetória diretamente através do espaço profundo e acelera em linha reta até a velocidade de cruzeiro espacial (até 3000 m/s), sem ficar parada ou oscilando de um lado para o outro.
  * **Chegada e Órbita Segura no Destino:** Caso a cidade de destino no planeta alvo esteja no lado oposto, a nave entra diretamente na órbita de aproximação segura do planeta de destino, faz a curva ao redor dele até obter linha de visada desobstruída com a pista e, então, executa o cone de descida controlado para o pouso.

---

## [v0.1.38] — 2026-09-20 (Remoção de Toasts, Círculo Único por Planeta no Mapa, Globo 3D Sem Listas & Piloto Automático com Órbita Inteligente)
### Adicionado & Aprimorado
* **Organização no Google Drive:**
  * Todos os 133 arquivos de compilações HTML, pacotes ZIP e documentação foram organizados diretamente dentro da pasta `- SkyWard - (html)`.
  * Todas as novas versões e entregáveis passam a ser salvos diretamente dentro da pasta dedicada.
* **Remoção de Notificações de Meio de Tela (Imersão Visual Completa):**
  * As notificações flutuantes na tela (`#toast`) foram completamente desativadas e ocultadas.
  * Mensagens como "Porta aberta", "Rampa aberta", "Piloto automático ativo" e afins não aparecem mais no meio da visão do jogador, garantindo imersão cinematográfica total através da observação direta do mundo e das animações.
* **Mapa do Sistema (Círculo Único por Planeta):**
  * O mapa 2D do sistema agora renderiza estritamente **um único círculo por planeta/lua**, eliminando a poluição de múltiplos círculos para diferentes vilarejos no mesmo corpo celeste.
  * **Clique simples no planeta:** Marca o núcleo do planeta no HUD (`[PLANETA] · NÚCLEO`) como guia de navegação de longa distância. O marcador desativa-se automaticamente assim que a nave atinge a atmosfera do planeta (`alt <= ATMOSPHERE`).
  * **Duplo clique no planeta:** Abre instantaneamente o Mapa Planetário 3D daquele planeta.
* **Mapa Planetário 3D Redesenhado (Sem Listas, Interação Direta no Globo):**
  * Removida completamente a coluna lateral de listas/cards de locais.
  * O mapa agora é composto exclusivamente por um globo 3D amplo e interativo do planeta no centro da tela.
  * Suporta rotação horizontal suave por arrasto do mouse/toque ao redor do eixo polar.
  * Todos os assentamentos, cidades e portos são representados como pontos/pinos táteis diretamente sobre a superfície visível da esfera 3D:
    * **Clique simples no pino:** Marca/desmarca o local como alvo no HUD de navegação.
    * **Duplo clique no pino:** Aciona o piloto automático para voar diretamente até o local.
* **Piloto Automático Inteligente com Órbita e Desvio de Terreno:**
  * Corrigida a colisão com o solo quando o destino está no lado oposto do planeta: a nave não tenta mais atravessar o relevo em linha reta.
  * **Circunavegação Orbital no Mesmo Planeta:** Se o alvo estiver na face oposta ou oculto pelo horizonte, o piloto automático ascende à órbita segura ($R_{orbit} = 	ext{raio} + 	ext{atmosfera} + 900	ext{ m}$), orbita o planeta ao longo do grande círculo até obter linha de visada direta com a zona de pouso, e somente então inicia o cone de descida controlado.
  * **Desvio Perpendicular de Planetas:** Se o objetivo estiver em outro planeta/arco e o planeta atual bloquear a trajetória, o piloto automático navega em direção perpendicular ao trajeto direto ao redor do planeta atual até desobstruir a linha de visada, segue em linha reta pelo espaço profundo e, ao chegar ao planeta de destino, executa a circunavegação orbital até a linha de visada do ponto de pouso estar livre antes de descer.

---

## [v0.1.37] — 2026-09-20 (Colisor Esférico de Granadas, Punhos Ocultos em Repouso & Calibração da Direção do Rover)
### Adicionado & Aprimorado
* **Colisor Físico Esférico de Granadas (Sem Ricochetes Aleatórios):**
  * O colisor físico da granada no chão e em superfícies foi completamente reformulado para uma esfera perfeita de raio 0.12 m ($R = 12	ext{ cm}$).
  * A detecção de contato contra terreno planetário e geometrias estáticas (plataformas, edifícios, rampas, calçadas) agora utiliza cálculo esférico analítico (`spherePush`), obtendo a normal exata de colisão da superfície.
  * A reflexão física decompõe o vetor de velocidade em componente normal elástica ($e = 0.52$) e tangencial com atrito de rolamento ($f = 0.78$), preservando o impulso para frente e eliminando completamente os estalos e ricochetes para lados aleatórios.
  * O modelo 3D da granada foi atualizado para uma carcaça esférica aerodinâmica de plasma com anel equatorial brilhante e pino de segurança.
  * A linha de previsão de trajetória balística (`updateGrenadeTrajectory`) foi sincronizada com a física do colisor esférico.
* **Punhos Desarmados em 1ª Pessoa Ocultos/Abaixados em Repouso:**
  * Em visão de primeira pessoa desarmada, as mãos agora iniciam e permanecem abaixadas fora do campo de visão durante a exploração normal, mantendo a tela limpa e imersiva.
  * Ao desferir um golpe (botão esquerdo / ataque corporal) ou ao mirar, as mãos erguem-se rapidamente em postura de guarda e desferem os socos alternados.
  * Ao cessar os ataques por aproximadamente 2 segundos, as mãos abaixam de volta suavemente ao repouso na altura do quadril, desaparecendo do campo visual.
* **Calibração da Direção do Veículo Rover:**
  * **Teclas A e D mais Rápidas e Ágeis:** A taxa de esterçamento do chassi foi mais do que duplicada (de 1.10 rad/s para 2.50 rad/s, aproximadamente $143^\circ/	ext{s}$), com torque de virada aprimorado mesmo em baixa velocidade para facilitar manobras entre rochas e caminhos estreitos.
  * **Direção por Mouse Suave e Estável:** Eliminada a rotação excessiva e repentina do chassi em movimentos rápidos de mouse através de limitação angular por evento e recentralização progressiva rápida do volante, proporcionando controle fino sem chicotadas involuntárias do veículo.

---

## [v0.1.36] — 2026-09-20 (Mapa Planetário Interativo 3D, Correção de Portal de Chegada, Lens Flare Solar Suave & Correções Técnicas)
### Adicionado & Aprimorado
* **Tela de Mapa Planetário Interativo 3D (Planet Map View):**
  * Ao dar clique duplo em um planeta no Mapa do Sistema (ou acionar pelo tooltip), abre-se a tela dedicada de cartografia planetária.
  * Globo 3D interativo com sombreamento esfumado dos biomas primário e secundário do planeta, anéis de latitude/meridianos e brilho atmosférico, permitindo rotação livre por arrasto com mouse ou toque.
  * Marcadores luminosos projetados dinamicamente na superfície visível do globo indicando todas as cidades e vilarejos secundários.
  * Painel lateral listando os assentamentos disponíveis com botões de acionamento imediato do piloto automático (`auto`) ou fixação de waypoint no HUD.
  * Vilarejos e cidades secundárias agora são gerados e registrados corretamente em `destinations` via `finishSettlements()`.
* **Correção da Saída de Portal Hiperespacial (Sem Flip de 180°):**
  * Corrigida a descontinuidade na chegada de saltos interestelares: a nave agora mantém a trajetória para a frente (`arrivalDir`), emergindo suavemente do arco e adentrando o sistema estelar a 450 m/s em direção aos planetas internos, eliminando o estalo que invertia a orientação de costas para o sistema.
* **Efeito Óptico de Lens Flare Suave:**
  * Adicionado brilho suave e cinematográfico de lente ao olhar em direção à estrela central do sistema.
  * Composto por corona quente, feixe anamórfico horizontal e anéis ópticos de difração ao longo do eixo visual.
  * Inclui teste de oclusão por esferas planetárias e compartimentos internos da nave, com atenuação exponencial suave.
* **Correções Técnicas Adicionais do Relatório:**
  * *Missões de Resgate:* O índice de planeta agora é limitado com segurança à quantidade real de corpos celestes do sistema, evitando referências fora de limite (`rescueSites`).
  * *Contratos de Carga:* Ponto de entrega seleciona exclusivamente portos planetários ou estações civis válidas, impedindo que portais hiperespaciais no vácuo sejam escolhidos como destino.
  * *Piso Rígido de Colisão de Voo:* Adicionada trava de segurança de elevação mínima em `06_flight_physics.js`, impedindo que a nave atravesse o relevo ou penetre no interior do planeta ao planar ou descer em baixa velocidade.
  * *Desembarque da Cama:* Desembarcar (`exitShip`) agora limpa adequadamente o estado de descanso (`resting = null`), evitando descompasso de câmera.
  * *HUD de Espaço Profundo:* Nome do sistema estelar atual é exibido dinamicamente no HUD a partir de `currentSystem.name`.
  * *Tooltip de Portais:* Corrigida a propriedade de nome do sistema de destino (`targetName`).
  * *Inicialização do Áudio:* `initAudio()` é chamada no clique síncrono dos botões de inicialização, evitando bloqueios de autoplay pelos navegadores.
  * *Clarão de Disparo (Muzzle Flash):* Ativada a invocação de `f.update()` no loop de efeitos visuais.
  * *Gerenciamento de Memória:* Descarte adequado da geometria do halo solar (`s.halo.geometry.dispose()`) ao descarregar sistemas.
  * *Contratos de Combate:* Prevenida a duplicação de entradas ao reinicializar tarefas.

---

## [v0.1.35] — 2026-09-20 (Remoção de Mineração/Commodities, Mapeamento Estrito L/F e Correções Gerais do Relatório)
### Alterado & Aprimorado
* **Remoção de Mineração e Commodities:**
  * Coleta e fratura de minérios (`ores`) removidas da ferramenta de campo; a ferramenta agora realiza estritamente varredura científica e catalogação de fauna.
  * Geração de depósitos de minério na superfície dos planetas desativada.
  * Porão de carga desvinculado de pallets de commodities, eliminando qualquer dependência de `commodityDefs`.
  * Contratos e diálogos de mineração substituídos por missões de pesquisa e exploração.
  * Opções de mercado e refinaria removidas da interface e barra de ações.
* **Mapeamento Estrito de Teclas:**
  * **Tecla L:** Exclusiva para alternância dos faróis da nave (`toggleHeadlights`), sem disparar rotina de pouso acidental.
  * **Tecla F:** Tecla primária de pouso no modo piloto (`land()`) e uso da ferramenta de campo/interação no modo a pé.
* **Correções de Bugs do Relatório:**
  * *NPCs:* Corrigida a função `redecorateShop` para verificar a existência do atendente antes de usar `splice`, evitando a deleção do último NPC gerado no mundo.
  * *Web Audio API:* Corrigido agendamento de envelopes em `tone()` com tempo de ataque dinâmico proporcional à duração, eliminando o erro `InvalidStateError` em sons de curtíssima duração.
  * *Escopeta (Shotgun):* Incluída no inventário persistente do `localStorage` e na rotina de compra das lojas de armas.
  * *Menu da Frota & Troca de Naves:* Restaurada a funcionalidade de `changeShip`, permitindo selecionar e pilotar Atlas, Hermes e Titan a partir do painel da frota.
  * *Desembarque do Rover:* Tecla `R` para sair do assento agora retorna imediatamente, sem acionar recarga de arma involuntária no mesmo clique.
  * *Notificações Toast:* Removido o filtro restritivo de expressões regulares; todas as mensagens informativas (faróis, câmera, pouso, zoom, saúde) agora aparecem normalmente no HUD.
  * *Barra Contextual:* Adicionada a ação de faróis (`headlights: cycleHeadlightMode`).
  * *Relevo Aquático:* Adicionado clamp `[-1, 1]` em `Math.asin` na função `waterCarve`, prevenindo anomalias de `NaN` nos polos de planetas oceânicos.
  * *Natação:* Verificação de submersão agora se baseia na coordenada vertical do avatar e não na câmera.

---

## [v0.1.34] — 2026-09-20 (Desarmado Padrão, Posturas Autênticas de Armas, Ciclo de Granada & Câmera Livre em 3ª Pessoa a Pé)
### Adicionado & Aprimorado
* **Opção Desarmado como Padrão:**
  * O equipamento inicial padrão do jogador agora é oficialmente *Desarmado* (`equipped = 'unarmed'`), iniciando o jogo com os punhos prontos para combate corporal.
* **Posturas Autênticas de Empunhadura em Terceira Pessoa:**
  * **Pistola:** Em postura de combate e mira, o personagem empunha a pistola com as duas mãos praticamente unidas e cotovelos flexionados junto ao peito, simulando uma empunhadura tática moderna e compacta (*high compressed ready*).
  * **Fuzil / Metralhadora e Escopeta:** A mão direita segura firmemente o cabo/empunhadura e a coronha encaixada junto ao ombro direito, enquanto a mão esquerda estende-se à frente sustentando o cano e o guarda-mão da arma de fogo.
  * **Armas de Uma Mão (Ferramenta, Lâmina e Sabre):** A mão esquerda nunca é levantada, mantendo o braço esquerdo relaxado ao lado do corpo com balanço natural durante o movimento.
  * **Ciclo Cinematográfico da Granada:**
    1. *Preparação:* Ao mirar, o braço direito ergue-se e arma-se para trás do ombro enquanto o braço esquerdo aponta para a frente em direção à trajetória prevista.
    2. *Arremesso:* Ao disparar, o braço direito chicoteia à frente desferindo o arremesso explosivo, e a granada se desvincula fisicamente da mão do personagem.
    3. *Busca no Cinto:* Logo após o arremesso, a mão direita desce até o cinto de utilidades na cintura para buscar outra granada se disponível no inventário, retornando à mão para prontidão. Caso esgotem as granadas, o personagem retorna ao estado desarmado.
* **Locomoção Desacoplada e Câmera Independente em 3ª Pessoa a Pé (Modo Câmera):**
  * No modo de câmera livre em terceira pessoa (`footFreeCam`), mover o mouse para orbitar e observar ao redor não mais desvia ou força a direção de caminhada/corrida do jogador.
  * Mudar a direção do personagem andando com as teclas de movimento (`W`, `A`, `S`, `D` ou analógico) rotaciona o avatar para a direção da passada sem arrastar ou virar a câmera junto. A câmera permanece orientada exclusivamente pela rotação do jogador via mouse/toque, sem molas de alinhamento forçado.

---

## [v0.1.33] — 2026-09-20 (Câmera Livre em 1ª Pessoa na Nave & Filtro Estrito de Corrida Automática a Pé)
### Corrigido & Aprimorado
* **Alternância para Câmera Livre em Primeira Pessoa na Nave (Duplo Toque na Direita):**
  * Implementado rastreamento direto e instantâneo de duplo toque na metade direita da tela (`mode === 'pilot' && side === 'right'`), permitindo alternar instantaneamente entre o modo de Direção de Voo e Câmera Livre (`shipLookOnly`), tanto em voo quanto na nave pousada.
  * O duplo toque não é mais interceptado ou bloqueado por botões do painel do cockpit (`targetedCockpitButton`), permitindo alternar livremente para olhar instrumentos e interagir com um único toque ou retornar centralizando a visão para pilotagem.
* **Filtro Estrito de Lado para Corrida Automática a Pé (Auto-Forward):**
  * Corrigido o disparo acidental de corrida automática (`autoForward`) ao clicar ou tocar repetidamente na parte direita da tela enquanto a pé (`mode === 'foot'`).
  * A tela foi estritamente delimitada para que a zona de locomoção e corrida automática pertença exclusivamente à metade esquerda (`clientX < innerWidth * 0.45`). Qualquer clique, toque rápido de combate (socos/tiros) ou interação na metade direita (`clientX >= innerWidth * 0.45`) é estritamente isolado para ações ofensivas e interativas, nunca acionando `autoForward`.
  * Ao tocar na parte direita, qualquer toque pendente da esquerda é imediatamente invalidado, impedindo que toques anteriores do polegar esquerdo no joystick virtual se combinem com toques do polegar direito.

---

## [v0.1.32] — 2026-09-20 (Combate Desarmado com Socos Alternados e Aleatórios)
### Adicionado & Aprimorado
* **Opção Permanente de Combate Desarmado (Punhos):**
  * Ficar desarmado agora é oficialmente uma opção permanente e sempre disponível de equipamento (`id: 'unarmed'`, nome: *Desarmado*), acessível no seletor de armas, inventário, alternância cíclica (`cycleWeapon`) e atalhos de teclado (teclas `8` e `0`). Não requer compra ou munição.
* **Mecânica de Socos com Seleção Aleatória de Mãos:**
  * Ao desferir ataques desarmado (`firePlayer()`), cada golpe aciona socos de combate corporal com alcance de 2,3 metros e 24 pontos de dano contundente.
  * A cada soco acionado, o sistema sorteia aleatoriamente uma das mãos (esquerda ou direita) para golpear (`punchHand = Math.random() < 0.5 ? 0 : 1`), garantindo alternância dinâmica e orgânica entre jabs e diretos.
* **Animações em 1ª e 3ª Pessoa:**
  * **Primeira Pessoa (Fists View):** O modelo visual em 1ª pessoa exibe ambos os punhos cerrados com luvas táticas em guarda marcial. Quando um soco é disparado, o punho sorteado projeta-se velozmente à frente com rotação de impacto e retorna à guarda, enquanto a outra mão mantém a proteção defensiva.
  * **Terceira Pessoa (Biomecânica de Boxe do Avatar):** O braço sorteado para o soco estende-se em linha reta com projeção do cotovelo e torção do tronco, enquanto o braço oposto recolhe-se junto à lateral da mandíbula/queixo em postura de guarda. Fora de combate, os braços relaxam ao lado do corpo com balanço natural de caminhada.
* **Áudio Procedural de Impacto:**
  * Adicionado sintetizador acústico de impacto contundente e deslocamento de ar (`playWeaponSound('unarmed')`), produzindo estalo e baque pesado para os socos sem emitir sons sintéticos ou beeps.

---

## [v0.1.31] — 2026-09-20 (Correção da Inclinação da Rampa do Rover, Posturas de Armas em 3ª Pessoa, Granada Saindo da Mão e Direção do Rover Suave com Mouse)
### Corrigido & Aprimorado
* **Física e Inclinação da Rampa do Veículo:**
  * **Sentido Físico Correto na Rampa:** Corrigido o sinal do cálculo angular de inclinação (`rampPitch = -fwdLocal.dot(layout().normal) * 0.22`). Agora, ao descer a rampa traseira da nave, o rover inclina o nariz para baixo em direção ao solo acompanhando a declividade da rampa em vez de empinar para cima.
* **Biomecânica e Posturas de Armas em Terceira Pessoa:**
  * **Pistola (Empunhadura Compacta com Duas Mãos):** Ao mirar, o personagem agora une as duas mãos praticamente juntas em frente ao peito (`arm.rotation.y = ±0.32`, cotovelos dobrados em postura tática compacta), sem esticar os braços excessivamente para a frente.
  * **Metralhadora / Fuzil e Escopeta:** O personagem agora apoia a coronha e o cabo com a mão direita junto ao ombro direito (`rElbow = 1.25`), enquanto a mão esquerda alcança à frente sob o cano/guarda-mão (`leftArmX = 1.25`, `lElbow = 0.70`), criando a postura de tiro longa e realista.
  * **Armas de Uma Mão (Ferramenta Ruptor, Lâmina e Sabre):** A mão esquerda permanece sempre abaixada junto ao corpo com balanço natural de caminhada (`leftArm.rotation.x ≈ 0`), sem nunca ser levantada desnecessariamente.
  * **Granada (Postura de Arremesso):** Ao preparar o arremesso, o personagem adota uma postura atlética de engatilhamento: braço direito armado para trás e para cima junto à cabeça/ombro (`rotX = 1.65`, cotovelo flexionado `rotX = 1.40`) e braço esquerdo estendido à frente apontando para o alvo como guia de equilíbrio.
* **Origem e Balística da Granada:**
  * **Arremesso Direto da Mão:** A origem do projétil e do arco de trajetória agora é calculada diretamente a partir da posição global da mão direita do avatar (`avatarWeapon.getWorldPosition` / `rightElbow.localToWorld`), eliminando o spawn da granada no meio do ar.
* **Controle de Direção do Rover em 3ª Pessoa (Fim das Viradas Abruptas):**
  * **Direção Suave e Amortecida com Mouse:** Eliminada a rotação dupla e instantânea que provocava solavancos e giros abruptos. O movimento do mouse agora deflete suavemente o volante e as rodas dianteiras com sensibilidade calibrada e amortecimento progressivo em altas velocidades (`speedDamping`), além de recentralização gradual, proporcionando uma condução automotiva estável, refinada e previsível.

---

## [v0.1.30] — 2026-09-20 (Iluminação Suave no Pôr do Sol, Noite e Espaço Mais Claros, e Portas Internas Herméticas Sem Frestas)
### Corrigido & Aprimorado
* **Iluminação Planetária & Ciclo Dia/Noite:**
  * **Pôr do Sol Suave e Gradual (Fim do Breu Repentino):** Corrigida a curva de espalhamento crepuscular. Durante o pôr do sol (quando a elevação solar atinge o horizonte e desce gradualmente), a atmosfera não escurece repentinamente; em vez disso, ganha um brilho quente âmbar e violeta crepuscular com luz solar difusa e suave (`intensity ~ 1.0`), mantendo o relevo, árvores e cidades visíveis sob iluminação dourada e alaranjada.
  * **Noites Mais Claras e Agradáveis:** O piso de iluminação noturna planetária foi elevado (`HemisphereLight` base de `0.42` com céu noturno estelar e solo `0x182432`), eliminando o breu total e permitindo enxergar a topografia do terreno, flora e estruturas sob a luz das estrelas.
  * **Espaço Profundo Mais Claro e Atmosférico:** O fundo do vácuo espacial foi calibrado de preto absoluto esmagado para um azul cósmico profundo (`#070e1a`), e a luz hemisférica no espaço foi aumentada para `0.82`, permitindo que as faces de sombra da nave Atlas, satélites e estações espaciais permaneçam nítidas e visíveis.
* **Portas Internas da Nave (Vedação Hermética Sem Frestas):**
  * **Eliminação Total da Fresta Central:** A largura dos painéis deslizantes foi recalculada com sobreposição hermética no centro (`width/2 + 0.024m`), eliminando a fresta de 4,5 cm que existia enquanto as portas estavam fechadas.
  * **Friso Divisório Central e Gaxeta de Borracha:** Quando fechados, os dois painéis se unem de forma contínua com uma linha divisória iluminada ciano (`userData.centerSeam`) e vedação de compressão escura ao longo da emenda vertical, restaurando a estética de antepara reforçada e garantindo passagem livre e desobstruída quando abertas.

---

## [v0.1.29] — 2026-09-20 (HUD de Marcador Minimalista, Marcação da Própria Nave no Mapa, Piloto Automático Exclusivo na Nave, Entregáveis Versionados e Física de Esterço Realista do Rover)
### Corrigido & Aprimorado
* **HUD do Marcador de Destino / Waypoint:**
  * **Design Minimalista e Limpo:** Removida a poluição visual, caixas pesadas e textos redundantes ("DESTINO · ", " · atrás de você"). O marcador agora exibe estritamente o ícone/seta direcional, o nome do local em caixa alta e a distância formatada (ex: `ARCO NYX
28.9km` ou `450m`).
  * **Desobstrução da Mira Central:** Quando o destino estiver alinhado com o centro da tela, o marcador é posicionado ligeiramente abaixo da retícula de mira (offset vertical suave), impedindo que ele fique em cima da mira do jogador.
* **Navegação & Marcação da Própria Nave:**
  * **Marcação do Cargueiro Atlas no Mapa 2D:** O marcador da nave no mapa orbital interativo agora é clicável. Ao clicar na própria nave, ela é definida como o alvo de navegação ativo no HUD (`SUA NAVE (ATLAS)`), permitindo que o jogador encontre facilmente o caminho de volta para a nave enquanto explora planetas a pé ou no Rover.
* **Segurança do Piloto Automático:**
  * **Bloqueio Fora da Nave:** O piloto automático agora só pode ser ativado se o jogador estiver sentado no comando da nave (`mode === 'pilot'`). Tentativas de ativar o piloto automático a pé ou no Rover exibem aviso orientativo e são bloqueadas.
* **Física e Animações de Esterço do Rover (1ª e 3ª Pessoa):**
  * **Sensibilidade Suave e Controlável:** A sensibilidade excessiva e abrupta do mouse foi reduzida e amortecida, proporcionando curvas graduais e estáveis.
  * **Física Ackermann (Sem Giro Parado):** O chassi do veículo agora só rotaciona se houver velocidade linear (avanço ou ré). Com o veículo parado, o chassi permanece estático e não gira mais no próprio eixo.
  * **Animação do Volante e dos Pneus via Mouse:** O movimento do mouse agora aciona diretamente o volante (yoke) e os mancais das rodas dianteiras (pneus) em tempo real, visíveis tanto na visão interna em 1ª pessoa quanto na câmera externa em 3ª pessoa.
* **Entregáveis de Download Versionados:**
  * Os arquivos HTML compilados e disponibilizados para download passam a conter a versão explícita no final do nome (`SkyWard-v0.1.29.html`).

---

## [v0.1.28] — 2026-09-20 (Frota Exclusiva Atlas & Rover, Remoção Total de Outros Modelos e Correção do Teletransporte do Rover ao Reembarcar na Nave)
### Corrigido & Aprimorado
* **Frota e Garagem Exclusivas (Atlas e Rover):**
  * **Remoção de Todas as Outras Naves:** Os modelos Kestrel e Mole foram completamente deletados do jogo, dos estaleiros, das lojas, da lista de naves e do terminal de hangar. O cargueiro pesado **Atlas** é agora a única nave estelar do jogo.
  * **Remoção de Todos os Outros Veículos:** Os modelos Scout, Hauler, Skiff e Cutter foram completamente deletados do jogo, das garagens, das lojas e dos seletores de veículos. O **Rover** de exploração planetária é agora o único veículo terrestre do jogo.
  * **Interface Limpa no Terminal de Hangar e Frotas:** As interfaces de hangar e frota foram simplificadas para exibir com clareza o Atlas como nave oficial na plataforma e o Rover como veículo operacional embarcado na garagem.
* **Correção Crítica de Física e Reembarque do Rover (Fim do Teletransporte para o Espaço):**
  * **Bug de Coordenadas Globais vs Locais Resolvido:** Ao dirigir o Rover de volta para dentro da nave pela rampa de popa, a função de acoplamento (`dockRoverToShip`) transferia a hierarquia para a nave (`ship.attach`), mas o loop de física daquele mesmo frame continuava executando a rotina de terreno planetário usando as novas coordenadas locais do Rover como se fossem globais. Isso calculava uma projeção planetária no centro do sistema solar e forçava a posição do veículo a milhões de metros de distância na órbita da nave.
  * **Transição Limpa e Interrupção Imediata do Loop de Solo:** Ao cruzar o limiar da rampa aberta para a garagem (`rampD < 0.5`), o veículo é acoplado instantaneamente, suas coordenadas locais são travadas no deque da garagem (`y = 0.33`), os limites físicos da garagem são respeitados e a execução do loop de solo naquele frame é interrompida imediatamente.
  * **Inércia e Orientação Contínuas no Deque:** O ângulo de aproximação (`yaw`) do jogador é preservado sem invertê-lo bruscamente em 180°, permitindo que o jogador manobre, estacione ou saia do veículo em solo seguro dentro do porão de carga.

---

## [v0.1.27] — 2026-09-20 (Afastamento e Redesign High-Tech do Terminal de Hangar, Remoção da Placa Flutuante, Órbita de Câmera Travada no Rover, Direção via Mouse e Aceleração Progressiva do Rover)
### Corrigido & Aprimorado
* **Terminal de Hangar & Infraestrutura de Pouso:**
  * **Afastamento da Pista de Pouso:** O terminal de hangar foi reposicionado para 29,5 m de distância do centro da plataforma de pouso (fora da área de 42x42 m), garantindo que as asas e fuselagens das maiores naves (como Atlas e Kestrel) nunca fiquem sobre o terminal.
  * **Remoção da Placa Flutuante Gigante:** Removido o letreiro 3D gigante suspenso ("E · TERMINAL DE HANGAR") das cidades planetárias e da estação orbital, proporcionando um visual limpo e imersivo.
  * **Redesign Arquitetônico High-Tech:** O quiosque de hangar agora possui uma base hexagonal com meio-fio de segurança industrial, coluna metálica reforçada com aletas de resfriamento térmico, console tático em dois níveis (painel de operações de voo holográfico ciano e visor superior de telemetria), mastro de antena com sinalizador estroboscópico de aviação e balizadores perimetrais com anéis de luz magnética.
* **Câmera do Rover em Alta Velocidade:**
  * **Fixação do Ponto Focal no Chassi (Lag Horizontal Zero):** Corrigido o cálculo de rastreamento da câmera em terceira pessoa. A coordenada horizontal do ponto de órbita (`smoothRoverCamTarget`) agora permanece 100% ancorada no centro do rover, sem arrasto para trás em altas velocidades (lag horizontal reduzido de 54 m para 0,00 m a 70 m/s). Ao girar a câmera em 360° em alta velocidade, o rover permanece perfeitamente enquadrado no centro da tela.
  * **Amortecimento Vertical Preservado:** Apenas as ondulações verticais do terreno são amortecidas suavemente ao longo do vetor normal do planeta, absorvendo solavancos e rampas sem desvios horizontais.
* **Modos de Controle do Rover (Direção vs Câmera Livre):**
  * **Modo de Direção (Ativo por Padrão):** O movimento horizontal do mouse para a esquerda e direita agora esterça diretamente as rodas e a carroceria do veículo. Em primeira pessoa, o cockpit gira acompanhando a curva; em terceira pessoa, a câmera segue suavemente atrás do sentido de deslocamento do rover.
  * **Modo de Câmera Livre (Alternado via Duplo Toque ou Botão do Meio):** O mouse orbita a câmera livremente em 360° (ou permite olhar ao redor da cabine em 1ª pessoa) sem alterar a rotação ou a trajetória do veículo.
* **Física de Aceleração e Tração do Rover:**
  * **Curva Progressiva de Torque:** Eliminada a arrancada súbita e excessivamente agressiva. O veículo agora acelera com inércia progressiva realista (arrancada suave a ~1,5 m/s no primeiro instante, ganhando velocidade de forma contínua ao longo de vários segundos até atingir a velocidade máxima), conferindo peso e autenticidade ao veículo de exploração.

---

## [v0.1.26] — 2026-09-19 (Re-acoplamento do Rover na Garagem, Projeção Real da Carta Estelar 2D, Transição Gradual de Atmosfera nas Nuvens e Ciclo Dia/Noite Alinhado ao Sol Central)
### Corrigido & Aprimorado
* **Veículos & Garagem da Nave:**
  * **Re-acoplamento e Fixação Automática do Rover:** Ao dirigir o rover de volta para dentro da nave (ou subir a rampa até a garagem), o veículo agora se fixa automaticamente ao convés da nave (`isRoverOnShipDeck()`).
  * **Sincronização de Decolagem e Voo:** Ao desembarcar do rover dentro do porão (`leaveSeatGesture`) ou acionar a decolagem da nave, o rover é rigidamente acoplado ao sistema de coordenadas local da nave (`y = 0.33`). Agora o rover viaja junto com a nave durante todo o voo espacial, manobras atmosféricas e saltos interestelares, sem ficar perdido para trás no planeta.
* **Personagem & Carta Estelar 2D (Mapa do Sistema):**
  * **Projeção Ortográfica Realista 1:1:** O mapa 2D do sistema agora é uma projeção ortográfica direta e autêntica do espaço 3D real no plano orbital X-Z.
  * **Órbitas Planetárias Concêntricas ao Redor do Sol Central:** Os planetas orbitam a estrela central do sistema `(0, 0, 0)` em distâncias reais e ângulos verdadeiros, com órbitas circulares desenhadas no mapa que correspondem exatamente às suas posições físicas no espaço.
  * **Marcador do Jogador ("VOCÊ") Preciso:** A posição do marcador da embarcação do jogador agora projeta as coordenadas mundiais reais de voo e pouso (`ship.position * MAP_SCALE`). Quando a nave está pousada em Vérdea, o marcador repousa exatamente sobre o planeta Vérdea; ao voar pelo espaço, desloca-se em tempo real ao longo da trajetória real.
* **Planetas & Transição Atmosférica:**
  * **Gradiente Atmosférico Suave:** A transição de cor do céu ao entrar na atmosfera foi reformulada para ser extremamente gradual entre 450 m e 105 m de altitude.
  * **100% de Cor ao Atravessar o Teto de Nuvens:** A cor do céu atinge 100% da saturação atmosférica exatamente ao cruzar a camada de nuvens (105 m). Abaixo das nuvens até o solo, o céu permanece 100% atmosférico.
  * **Dissipação Rápida ao Sair do Planeta:** Ao subir em direção ao espaço, assim que a nave ultrapassa 450 m de altitude, a atmosfera e a névoa dissipam-se completamente, revelando o vácuo espacial negro com estrelas cristalinas e densidade zero ("VÁCUO · SEM ARRASTO").
* **Iluminação Planetária & Ciclo Dia/Noite:**
  * **Alinhamento com a Estrela Central:** Eliminada a rotação artificial que desincronizava a luz solar da estrela visual no céu. A luz direcional (`sunlight`), a iluminação das nuvens (`cloudMat.uniforms.sunDir`), a dispersão atmosférica e o cálculo de `daylight()` agora convergem 100% para a posição real da estrela do sistema em `(0, 1200, 0)`.
  * **Correção da Inversão Dia/Noite:** O hemisfério do planeta voltado para a estrela agora é plenamente iluminado pelo Sol (dia), enquanto o hemisfério oposto fica imerso na sombra natural da noite com céu estrelado, corrigindo o erro em que a face iluminada ficava escura e vice-versa.

---

## [v0.1.25] — 2026-09-19 (Elevação do Teto do Hover/Rover, Empunhadura de Armas com Duas Mãos, Trajetória Unificada da Granada, Ferramenta Silenciosa, Terminal na Cidade Inicial e Câmeras Terrestres Estabilizadas)
### Corrigido & Aprimorado
* **Veículos & Teto Elevado:**
  * **Elevação da Cabine e Teto do Rover:** O teto da cabine foi elevado para 1,64 m (com painel solar a 1,66 m), reconfigurando o para-brisa frontal, janelas panorâmicas laterais, janela traseira e barras estruturais da gaiola de proteção. O capacete do piloto (a 1,29 m no assento rebaixado) agora possui mais de 30 cm de folga, eliminando totalmente o corte da cabeça pelo teto.
* **Armas & Equipamentos:**
  * **Empunhadura com Duas Mãos em Terceira Pessoa:** O personagem agora empunha todas as armas e ferramentas com ambas as mãos em 3ª pessoa, tanto em repouso/patrulha quanto ao mirar:
    * Pistola: empunhadura tática isósceles com a mão esquerda envolvendo a mão direita ao mirar, e suporte duplo próximo ao corpo em descanso.
    * Fuzil, Escopeta e Ferramenta de Campo: a mão esquerda segura e apoia firmemente o guarda-mão/cano em ambas as situações.
  * **Unificação Fiel da Trajetória da Granada:** Criada a função unificada `getGrenadeOriginAndVelocity()`, compartilhada integralmente entre o arco pontilhado de mira e o disparo real (`firePlayer`). O ponto de lançamento na mão do personagem, a gravidade e o vetor de velocidade inicial são 100% idênticos, garantindo que a granada viaje exatamente pela trajetória desenhada na mira.
  * **Ferramenta de Campo 100% Limpa/Silenciosa Visualmente:** Removido qualquer feixe (`scannerBeamFX`), traçador ou partícula projetada no ponto de mira. A ferramenta cumpre suas funções de aquecimento de minério e escaneamento biológico com retorno de áudio e coleta de créditos, sem fazer surgir nenhum objeto ou efeito visual na tela.
* **Geral & Interface:**
  * **Sincronização do Número de Versão no HUD:** O rótulo de versão no canto superior esquerdo da tela agora é sincronizado dinamicamente com a versão real do arquivo (`VERSION = '0.1.25'`), eliminando o valor estático defasado.
  * **Terminal de Hangar na Cidade Inicial e Assentamentos Planetários:** Instalado o terminal físico interativo de hangar e estaleiro (`E · TERMINAL DE HANGAR`) ao lado de cada pista de pouso central das cidades planetárias (a 16,5 m do centro da pista). Permite trocar a nave pousada e definir qual veículo da frota está preparado na garagem interna da nave.
* **Câmera:**
  * **Câmera Orbital Livre a Pé (Alternância via Botão do Meio ou Toque com 2 Dedos na Esquerda):** Permite alternar entre o modo padrão direcional e a órbita livre. No modo livre, virar o personagem não rotaciona a câmera. Ao caminhar continuamente por 3 segundos sem mover a câmera, ela se realinha suavemente atrás do personagem; mover a câmera cancela o alinhamento e reseta o contador. Se parado, o contador permanece zerado.
  * **Câmera de Veículos Estabilizada no Planeta e sem Rotação por A/D:**
    * Em veículos terrestres, a câmera fica alinhada com o vetor normal do planeta (`planetUp`), eliminando os balanços e inclinações abruptas do chassi em terrenos acidentados.
    * O rastreamento vertical e de foco possui amortecimento suave (`smoothRoverCamTarget.lerp`), tornando subidas e descidas de colinas suaves e cinematográficas.
    * No modo de câmera livre do veículo, pressionar `A` ou `D` esterça o veículo sem rotacionar a câmera. Ao dirigir sem mexer na câmera por 3 segundos, ela se realinha suavemente atrás do veículo.

---

## [v0.1.24] — 2026-09-19 (Restauração da Nave Original, Correção de Postura na Cama em 3ª Pessoa e Câmera Livre Orbital / 1ª Pessoa sem Clipping)
### Corrigido & Aprimorado
* **Aparência da Nave Restaurada:**
  * Revertida completamente a estrutura externa da nave para o modelo aerodinâmico original autêntico (`aeroHull`), com fuselagem loftada elegante, canópios panorâmicos integrados, naceles de propulsão com anéis de plasma ciano e revestimento perfeitamente selado, eliminando de forma definitiva a estrutura aberta em formato de caixa/caçamba com placas cortadas.
* **Mecânica de Descanso na Cama & Postura do Personagem:**
  * **Postura Supina em Terceira Pessoa (Barriga para Cima):** Corrigida a orientação do rig anatômico na cama (`rotX: Math.PI / 2`, rotação compensada de 180° no eixo Y): o personagem agora deita com as costas confortavelmente apoiadas sobre o colchão, o peito e o rosto voltados para cima (teto da cabine), a nuca perfeitamente encaixada sobre o travesseiro e as pernas estendidas sob o lençol, eliminando o bug em que o personagem deitava de barriga para baixo.
  * **Câmera Livre Orbital em Terceira Pessoa:** Na cama, a câmera em 3ª pessoa agora orbita livremente em 360° ao redor do leito e do avatar sem qualquer trava de guinada (`yaw`).
  * **Câmera em Primeira Pessoa sem Clipping no Travesseiro:** Elevado o ponto de visão dos olhos para cima do travesseiro, evitando que a geometria do travesseiro oclua a visão do jogador ao deitar.
  * **Limitação Correta em Primeira Pessoa na Cama:** A câmera em 1ª pessoa agora possui limitação estrita para trás (`yaw` delimitado em `Math.PI ± 1.25`, impedindo que o pescoço atravesse a cabeceira da cama) e limitação para baixo (`pitch >= -0.35`, impedindo a visão de afundar no próprio tórax ou no colchão), liberando amplitude ampla e desimpedida para olhar para cima em direção ao teto e luminárias (`pitch` até `+1.35`).

---

## [v0.1.23] — 2026-09-19 (Correções nos Veículos, Áudio Balístico Autêntico, Lore no Inventário, Terminal de Hangar, Câmera Orbital com Auto-Alinhamento e Alinhamento Visual/Colisão dos Planetas)
### Corrigido & Aprimorado
* **Veículos e Garagem:**
  * **Postura do Motorista em 3ª Pessoa:** Corrigida a cinemática das pernas e pés do piloto (`thighPose: 1.52`, `kneePose: -0.58`) e o centro de massa do assento, acomodando os pés confortavelmente na pedaleira do assoalho interno e eliminando o vazamento dos pés sob o chassi e placa de proteção.
  * **Rover Nivelado na Garagem da Nave:** Corrigida a elevação vertical do veículo a bordo (`y = 0.33`), fazendo com que os 4 pneus repousem perfeitamente sobre o piso metálico e rampa da nave, eliminando a flutuação anterior de 62 cm.
  * **Física de Direção Terrestre:** Veículos sobre rodas agora obedecem à cinemática de direção real (Ackermann): quando parados (`velocidade = 0`), esterçar as teclas `A`/`D` ou o volante gira as rodas dianteiras e o manche, mas o chassi do veículo não gira como um pião no mesmo lugar; a rotação do corpo do veículo ocorre de forma proporcional ao deslocamento para frente ou para trás.
  * **Cabine Estendida do Rover:** O para-brisa frontal foi esticado para frente (`z = -0.92`), inclinando suavemente até o teto (`z = -0.45`), e os vidros laterais e o teto solar foram prolongados para frente, abrigando completamente o volante de direção, o painel de telemetria MFD e os braços do motorista protegidos dentro da cabine.
* **Armamento & Inventário:**
  * **Síntese de Áudio Balístico Sem Bips Robóticos:** Eliminados todos os osciladores tonais e bips eletrônicos agudos (ondas senoidais, quadradas e dente-de-serra artificiais). Substituídos por síntese acústica puramente balística com explosão concussiva de baixa frequência (estalo de ar e expansão de gases de 140 Hz a 25 Hz) e pulsos de ruído passa-faixa com decaimento exponencial, produzindo tiros secos e viscerais para pistola, fuzil e escopeta.
  * **Feixe Visual da Ferramenta de Campo:** A ferramenta de campo agora utiliza um feixe contínuo de indução e escaneamento térmico (`scannerBeamFX`), eliminando completamente qualquer projétil balístico, centelha cônica ou rastreador incorreto.
  * **Deduplicação de Itens no Inventário:** Corrigida a lista do inventário, garantindo que a ferramenta de campo apareça uma única vez.
  * **Painel de Detalhes Técnicos e Lore do Universo:** Todos os itens e armas agora contam com descrições detalhadas ao passar o mouse ou dar um toque segurado no celular, contendo fabricante oficial, histórico/lore no universo do jogo, estatísticas e instruções práticas de uso (ex.: mineração e pesquisa biológica da ferramenta).
* **Terminal de Hangar da Plataforma de Pouso:**
  * Adicionado um quiosque físico interativo de estaleiro/hangar ao lado de cada plataforma central de pouso (`E · TERMINAL DE HANGAR`).
  * Permite ao jogador, diretamente na pista de pouso, trocar a nave pousada por qualquer outra de sua frota e escolher qual veículo possuído deve ser embarcado na garagem interna da nave.
* **Câmera Livre com Auto-Alinhamento Inteligente (3 Segundos):**
  * **Veículos em 3ª Pessoa (Câmera Livre):** A câmera mantém seu rumo absoluto no mundo enquanto o veículo faz curvas; caso o jogador não mova a câmera por 3 segundos enquanto o veículo estiver em deslocamento, a câmera vira suavemente para a direção para onde o veículo está indo. Se o jogador tocar na câmera, a transição cancela imediatamente e reinicia o contador. Se o veículo estiver parado, o contador permanece zerado.
  * **A Pé em 3ª Pessoa (Câmera Orbital Livre):** Pressionar o botão do meio do mouse (ou tecla de atalho) alterna entre a câmera direcional padrão e a câmera orbital livre. A câmera orbital a pé conta com o mesmo sistema inteligente de 3 segundos: ao caminhar sem mexer na câmera por 3 segundos, ela se realinha suavemente atrás do personagem.
* **Sincronização 100% da Superfície Visual e Colisora dos Planetas:**
  * Resolução geométrica da malha planetária (LOD 3) elevada para `120 x 72` segmentos.
  * O sistema de sondagem de solo (`floorProbe`) agora projeta raios diretamente contra a malha visível da esfera planetária (`p.globe`), garantindo que a superfície onde os pés do personagem e as rodas dos veículos pisam corresponda exatamente ao polígono renderizado, eliminando flutuações e afundamentos no terreno.

---

## [v0.1.22] — 2026-09-19 (Remake Completo da Nave Inicial Atlas & Correção da Animação Corpo a Corpo em 1ª Pessoa)
### Adicionado & Aprimorado
* **Remake Completo da Nave Inicial (ATLAS — Corveta Multipropósito Pesada):**
  * **Modelagem 3D Exterior de Alta Fidelidade:**
    * Chassi aerodinâmico e industrial reforçado de 33 metros de comprimento e 26 metros de envergadura, com blindagem composta chanfrada, placas ventrais de proteção térmica e quilha reforçada.
    * Canópio de ponte multifacetado com colunas estruturais em titânio e vidros aeroespaciais translúcidos com reflexão e visualização interna/externa integrada.
    * Asas delta táticas com aletas verticais (*winglets*) equipadas com luzes de navegação ativas (estroboscópio vermelho a bombordo e verde a boreste).
    * Estabilizadores verticais traseiros duplos com sinalizador de cauda estroboscópico branco.
    * Sistema de propulsão iônica estelar com duas naceles cilíndricas pesadas na popa, bocais de empuxo vetorial, anéis de compressão e núcleos luminosos de plasma ciano/azul (`0x28e5ff`).
    * Canhões táticos de plasma repetidores montados nas ombreiras das asas com canos estriados e aletas de arrefecimento.
    * 4 blocos de micropropulsores RCS (*Reaction Control System*) para controle de atitude tridimensional.
    * 4 trens de pouso articulados pesados com amortecedores hidráulicos para pousos em relevos planetários acidentados.
    * Rampa traseira de carga reforçada com pistões hidráulicos, piso antiderrapante e sinalização de aproximação.
  * **Modelagem 3D Interior Completa e Funcional (Três Zonas Distintas):**
    * **Ponte de Comando:** Plataforma elevada com assento de comando ergonômico do piloto, manche de voo e acelerador nos apoios de braço, estação de salto do copiloto/navegador, consoles laterais e integração total com o painel 3D físico interativo (telas MFD de energia, radar, pouso, iluminação e controle de rampa).
    * **Módulo Habitacional:** Cabine de descanso com beliches cápsula acolchoados, iluminação de leitura individual, armário pessoal de suprimentos com interface de transferência de itens, refeitório com bancada de cozinha em aço inox, pia, torneira, sintetizador de alimentos, mesa de refeições e banco fixo.
    * **Engenharia & Reator de Fusão Quântico:** Reator central com câmara cilíndrica de confinamento magnético, núcleo pulsante de plasma quântico ciano (`0x22f5d2`) e tubulações criogênicas conectadas à propulsão traseira.
    * **Hangar de Veículos & Porão de Carga:** Hangar espaçoso dimensionado para acomodar o Rover de exploração, com faixas de demarcação de perigo amarelas e pretas no piso, travas magnéticas, prateleiras de contêineres de carga modulares e trilho de guindaste industrial no teto.
    * Portas herméticas deslizantes automatizadas com sensores biométricos interligando todas as seções da nave.
* **Correção da Animação de Armas Brancas em Primeira Pessoa:**
  * Corrigida a inversão dos eixos de rotação e translação das armas corpo a corpo (faca tática/tanto e sabre de plasma).
  * O ponto de apoio da empunhadura (cabo) agora permanece fixo e ancorado na mão do jogador no quadrante inferior direito, enquanto a lâmina descreve um arco cinético dinâmico e letal através do campo de visão:
    * **Combo 0:** Golpe diagonal de cima para baixo (do canto superior direito para o inferior esquerdo), com recuo de preparação e corte fluido.
    * **Combo 1:** Golpe horizontal transversal em corte de revés, varrendo a tela da esquerda para a direita mantendo o punho firme.

---

## [v0.1.21] — 2026-09-19 (Disparo em Mira [ADS], Áudio Balístico Realista das Armas, Efeitos na Ferramenta de Campo e Fim da Corrida Descontrolada)
### Corrigido & Aprimorado
* **Disparo com Mira [ADS] via Clique Simultâneo (Botão Direito + Botão Esquerdo):**
  * Corrigida a limitação da API de ponteiro (`pointerdown`) que não disparava eventos para cliques acordados (pressionar o botão esquerdo enquanto o botão direito já está pressionado).
  * Adicionado suporte direto a eventos de mouse (`mousedown`/`mouseup`) integrados ao canvas, permitindo mirar livremente com o botão direito e atirar continuamente ou com disparos únicos usando o botão esquerdo sem soltar a mira.
* **Síntese Sonora Realista das Armas de Fogo:**
  * **Pistola:** Removida a onda triangular abafada que soava como "batida na madeira". Substituída por uma síntese acústica balística completa de 9 mm, combinando estalo supersônico de alta frequência (*noise burst* passa-faixa), decaimento acentuado de dente-de-serra (*bark* mecânico de 360 Hz a 55 Hz), soco sub-grave de 58 Hz e clique metálico do ferrolho.
  * **Fuzil e Escopeta:** Aprimorados com detonação de câmara encorpada, estrondo de choque de alta energia e impacto sub-grave visceral.
* **Áudio e Feixe Visual na Ferramenta de Campo:**
  * A ferramenta de campo (`tool`) agora conta com efeito sonoro de pulso de escaneamento ressonante sci-fi em todos os usos, acompanhado por um feixe de varredura visual (`traceFX`) na direção da mira.
  * A ferramenta atua como um escâner e extrator multifuncional: ao mirar em depósitos minerais, emite aquecimento térmico fraturador para coletar minério (+55 CR e reputação CMI); ao mirar em fauna ou terreno aberto, cataloga as espécies biológicas do ecossistema planetário.
* **Eliminação da Corrida Automática Descontrolada por Cliques Repetidos no Mouse:**
  * Corrigido o bug que ativava a corrida automática (`autoForward`) e fazia o personagem andar sozinho sem parar após cliques rápidos do botão esquerdo para atirar.
  * O clique duplo nativo (`dblclick`) agora ignora completamente o modo a pé, garantindo que o combate com cliques rápidos nunca inicie corrida automática involuntária.
  * Pressionar qualquer tecla de movimentação (`W`, `S`, `A`, `D`) agora cancela instantaneamente qualquer estado de avanço automático residual.

---

## [v0.1.20] — 2026-09-19 (Debounce no Toque Duplo do Rover, Desambiguação de Porta/Cama por Linha de Visão e Alinhamento Ergonômico do Travesseiro)
### Corrigido & Aprimorado
* **Eliminação da Alternância Dupla e Repentina do Modo de Câmera Livre no Rover:**
  * Identificada a causa da alternância instantânea de ida e volta: o evento de segundo toque disparava a troca e, em seguida, eventos subsequentes (como o `dblclick` sintetizado nativamente pelo navegador) disparavam uma segunda alternância cerca de 25 ms depois, cancelando o modo imediatamente.
  * Centralizada a lógica na função `toggleRoverLookMode` com janela de debounce de 240 ms e remoção dos gatilhos duplicados. Ao dar o duplo toque na metade direita da tela, a transição entre **Modo Direção** e **Modo Câmera Livre Orbital (360°)** ocorre uma única vez de forma estável e garantida.
* **Desambiguação Inteligente entre Porta do Quarto e Cama por Linha de Visão:**
  * Corrigido o bug que fazia o jogador deitar na cama involuntariamente ao tentar abrir a porta da cabine de descanso para sair.
  * O seletor de interação (`switchCandidate`) agora leva em conta a direção para onde a câmera/olhar do jogador está apontando (`dot product` com a linha de visão) e aplica um limite de alcance mais realista para a cama (1,35 m, em vez dos 2,5 m genéricos).
  * Ao olhar para a porta para sair do quarto, a cama fica fora do cone de visão e é descartada, garantindo que o comando de interação acione exclusivamente a abertura ou fechamento da porta.
* **Posicionamento Ergonômico do Jogador e da Visão ao Deitar na Cama:**
  * Corrigida a postura e a altura do avatar: a cabeça agora repousa com precisão sobre o travesseiro (`z = -1.0` local da cama / `z = -4.70` na nave), o corpo fica estendido horizontalmente sobre o colchão (`y = 0.92`) e os membros relaxados sob as cobertas, eliminando a antiga pose em que o personagem parecia sentado e atravessado no meio do móvel.
  * A câmera em primeira pessoa agora se posiciona exatamente nos olhos do personagem sobre o travesseiro (`y = 1.40`, `z = -4.70`), orientada naturalmente ao longo do comprimento da cama em direção aos pés e ao quarto (`yaw = π`, `pitch = -0.15`), permitindo olhar confortavelmente pelo cômodo e teto antes de se levantar.

---

## [v0.1.19] — 2026-09-19 (Remoção de Botões na Condução do Rover, Toque Duplo Instantâneo na Metade Direita e Remoção dos "Óculos" do Personagem Principal)
### Corrigido & Aprimorado
* **Remoção Completa do Botão no Lado Direito da Tela no Rover:**
  * O botão de ação rápida (`quickWeapon`) no canto inferior direito agora é estritamente ocultado (`hidden`) durante a condução do veículo terrestre.
  * A tela fica completamente desimpedida e limpa, eliminando qualquer botão sobreposto e restaurando a visão panorâmica da condução. Ao desembarcar para o modo a pé, o seletor de equipamento é reexibido automaticamente.
* **Toque Duplo Instantâneo em Qualquer Ponto da Metade Direita da Tela:**
  * Corrigida a falha na detecção de toque duplo em telas sensíveis ao toque: eliminada a dependência de temporizadores rígidos de segurar (`SECOND_HOLD_MS = 170ms`) e restrições excessivas de arrasto de pixel (`DRAG_PX = 10px`), que descartavam toques naturais com leve contato de ponta de dedo.
  * Implementada detecção direta com disparo imediato no segundo contato (`touchDown`): tocar duas vezes em qualquer lugar da metade direita da tela alterna instantaneamente entre o **Modo de Direção** e o **Modo de Câmera Livre Orbital (360°)** com resposta tátil e aviso visual no HUD.
  * O duplo toque na metade esquerda da tela continua reservado exclusivamente para ativar a aceleração automática contínua (`autoForward`).
* **Remoção dos "Óculos" / Viseira Saliente da Cara do Personagem Principal:**
  * Removido o conjunto poligonal saliente da viseira (`panelMesh`) e os módulos ópticos laterais (`ellipsoid` e `SphereGeometry`) que ficavam projetados na altura dos olhos e conferiam uma aparência volumosa de "óculos" ou lentes no rosto do avatar.
  * O capacete do traje espacial agora possui acabamento limpo, contínuo e aerodinâmico, sem acessórios ou armações artificiais na frente da face.
* **Controle por Mouse no Computador:**
  * No PC, a alternância entre direção e câmera livre orbital permanece no botão do meio do mouse (scroll wheel click), operando de forma imediata e sincronizada.

---

## [v0.1.18] — 2026-09-19 (Correção Definitiva da Sensibilidade de Toque/Clique para Alternância de Câmera Livre e Direção do Veículo)
### Corrigido & Aprimorado
* **Detecção Ultrarrobusta de Toque Duplo no Lado Direito:**
  * Corrigido o descarte indevido de toques na tela sensível ao toque: o limite anterior de microdeslocamento (10 pixels) descartava toques naturais com leve arrasto do dedo ao encostar ou levantar. A tolerância de toque foi ampliada para 32 pixels e a janela de duplo toque para 450 ms.
  * Implementado rastreador dedicado de toques para o veículo (`lastRightTapTime`), imune a toques simultâneos no lado esquerdo (joystick) e sem dependência de eventos nativos instáveis de navegadores móveis.
* **Detecção Precisa de Duplo Clique no Mouse/Desktop:**
  * Implementado rastreador nativo direto via `pointerdown` para cliques com o mouse na metade direita da tela, garantindo alternância instantânea mesmo se o cursor se mover ligeiramente entre os cliques.
* **Botão Direto de Ação no Canto Inferior Direito:**
  * Quando no rover, o botão do canto inferior direito agora se transforma em um seletor visual direto de modo: **`[ 🔄 Direção ]`** / **`[ 🔄 Câmera livre ]`**.
  * Além do toque duplo em qualquer ponto da metade direita da tela, um clique simples diretamente nesse botão alterna instantaneamente o modo, sem risco de interferência de seleção de armas (as armas ficam desabilitadas na condução).

---

## [v0.1.17] — 2026-09-19 (Física Suave de Aceleração e Inércia do Rover, Correção Biomecânica dos Braços ao Esterçar e Roteamento Estrito de Toque Duplo)
### Corrigido & Aprimorado
* **Física Real de Aceleração Gradual e Inércia ao Desacelerar (Coasting):**
  * Substituída a movimentação instantânea em bloco por um modelo inercial contínuo (`roverLinearSpeed`).
  * Ao pressionar o acelerador (`W` ou joystick para frente), o veículo ganha velocidade suave e progressivamente com curva exponencial até atingir a velocidade máxima, transmitindo peso físico e potência real do motor.
  * Ao soltar o acelerador, o rover não trava bruscamente: ele desacelera gradualmente por atrito de rolagem e inércia antes de parar por completo.
  * Pressionar ré enquanto o veículo está em movimento para a frente aciona frenagem firme e progressiva antes de inverter o sentido.
  * A rotação das rodas e o velocímetro do HUD acompanham em tempo real a velocidade física real do veículo.
* **Biomecânica Natural dos Braços ao Virar o Volante:**
  * Corrigida a cinemática inversa dos membros superiores ao pilotar o veículo.
  * Ao esterçar para a **direita**, o braço esquerdo agora avança e sobe acompanhando o movimento horário do manche, enquanto o braço direito recua e desce ergonomicamente em direção ao corpo.
  * Ao esterçar para a **esquerda**, o movimento se inverte com precisão (braço direito avança e braço esquerdo recua), sincronizando perfeitamente a rotação do manche, a posição das mãos e a direção das rodas dianteiras.
* **Roteamento Estrito de Toque Duplo na Tela:**
  * **Parte Esquerda da Tela:** O duplo clique/toque duplo na metade esquerda aciona **estritamente** a aceleração automática do veículo (`autoForward`), sem jamais afetar ou alternar a câmera e a direção.
  * **Parte Direita da Tela:** O duplo clique/toque duplo na metade direita é o **único responsável** por alternar entre o modo de Direção na Tela e o modo de Câmera Livre Orbital (360°).

---

## [v0.1.16] — 2026-09-19 (Acomodação Correta na Cabine do Rover, Direção Vertical das Rodas, Câmera Orbital 360°, Alta Velocidade e Alternância de Direção/Câmera por Toque Duplo)
### Corrigido & Aprimorado
* **Acomodação Correta do Piloto no Interior da Cabine:**
  * Corrigida a altura e o ponto de ancoragem do avatar sentado dentro do veículo (`y = -0.32, z = 0.12`). A cabeça, capacete e tronco do piloto agora ficam totalmente abrigados sob a canópia de vidro aeroespacial (com 11 cm de folga segura abaixo do teto), eliminando de vez o problema visual do personagem atravessar a estrutura da cobertura.
* **Correção da Rotação e Direção das Rodas Dianteiras:**
  * Removido o conflito legado que aplicava rotação de rolagem no eixo X sobre os montantes de direção (`steerKnuckles`).
  * As mangas de direção dianteiras agora mantêm rotação estritamente nula nos eixos de cambagem e inclinação (`rotX = 0`, `rotZ = 0`) e giram exclusivamente no eixo vertical Y (`rotY`), virando as rodas de forma limpa, precisa e vertical para a direção exata da curva.
  * O giro de rolagem dos pneus em solo permanece desacoplado e contínuo nos cilindros internos (`wheelRollers`).
* **Câmera em Terceira Pessoa Livre e Orbital (360°):**
  * Removido o bloqueio angular da câmera em 3ª pessoa no veículo: a câmera agora orbita livremente em todos os 360 graus horizontais ao redor do rover sem travas laterais, além de contar com amplitude vertical completa (de vista aérea superior até rente aos pneus).
* **Aumento da Velocidade Máxima e Agilidade de Curva:**
  * Velocidade máxima do rover terrestre em superfície planetária aumentada de 32 m/s para **75 m/s** (~270 km/h) no modelo padrão, com pico de **105 m/s** (~378 km/h) sob impulso/corrida (`Shift` ou toque duplo frontal). O modelo explorador (scout) atinge até 126 m/s.
  * Taxa de esterçamento e manobrabilidade aumentada em 63% (taxa de 2.2) para curvas rápidas e firmes.
* **Segurança no Toque e Saída Padronizada com Dois Dedos:**
  * Clicar ou tocar na tela não ejeta mais o jogador do veículo (o clique agora é inerte enquanto no veículo).
  * O desembarque segue rigorosamente o mesmo padrão da nave: gesto de deslizar dois dedos para cima no canto esquerdo da tela (ou tecla `R` / `B` no teclado).
* **Alternância por Clique Duplo (Direção na Tela vs Câmera Livre):**
  * Um duplo clique (ou toque duplo na parte direita da tela) alterna dinamicamente o comportamento de deslizamento:
    1. **Modo Direção (Padrão):** Deslizar o dedo horizontalmente pela metade direita da tela manobra o veículo diretamente para a esquerda e para a direita.
    2. **Modo Câmera Livre:** Deslizar pela metade direita da tela move a câmera livremente em órbita 360° ao redor do veículo, sem desviar a trajetória das rodas.
  * Os controles do lado esquerdo (joystick analógico para aceleração/ré e gesto de saída) permanecem 100% ativos e intocados em ambos os modos.

---

## [v0.1.15] — 2026-09-19 (Cabine Envolvente do Rover, Visão em 1ª Pessoa com Manche, Física Real de Inclinação em Encostas e Menu 'Iniciar')
### Corrigido & Aprimorado
* **Cabine Espacial Fechada & Fim da Cadeira Gigante Externa:**
  * Removida completamente a estrutura desproporcional de assento genérico externo (`makeSeat`).
  * O rover agora possui uma cabine aeroespacial completa, espaçosa e protegida: assento concha anatômico integrado rebaixado no piso da banheira, painel de instrumentos em rampa com 3 visores MFD coloridos e uma canópia panorâmica translúcida em vidro aeroespacial com reforço tubular de santantônio.
  * O piloto fica acomodado naturalmente no interior do habitáculo em escala 1.0, com postura ergonômica e mãos firmes no manche.
* **Visão em Primeira Pessoa com Manche Funcional:**
  * A câmera em primeira pessoa dentro do veículo foi calibrada para a altura exata dos olhos do condutor dentro do habitáculo (`y = 1.20, z = 0.10`).
  * Ao pilotar em 1ª pessoa, o jogador enxerga o manche esportivo e o painel de instrumentos no campo de visão inferior, e observa o manche girar fluidamente em resposta aos comandos de direção enquanto olha através do para-brisa para o horizonte.
* **Física Real de Inclinação do Veículo (Rampa e Relevo Planetário):**
  * **Descida da Rampa da Nave:** Ao descer a rampa física da nave em direção ao solo, o veículo agora inclina o bico para baixo (`rotX = -0.26 rad` / ~15°) acompanhando o declive da plataforma e desce suavemente até tocar a terra, sem saltos abruptos ou levitação horizontal.
  * **Simulação de Terreno Multieixo:** O veículo agora calcula a inclinação real do relevo planetário por meio de amostragem de 4 pontos de contato no solo sob as rodas, derivando uma base ortonormal com amortecimento de suspensão. O chassi inclina em aclives, declives e depressões de terreno de forma contínua e realista.
* **Ajuste de Textos no Menu Principal:**
  * O botão de início foi simplificado de "INICIAR AVENTURA" estritamente para **"Iniciar"**.
  * A opção inferior de sandbox foi ajustada para **"Modo Sandbox"**.

---

## [v0.1.14] — 2026-09-19 (Novo Rover Espacial, Animação de Rodas e Volante, Saída Segura da Rampa, Mira Reta Deslocada e Armas Liberadas nas Cidades)
### Corrigido & Aprimorado
* **Reformulação Completa do Rover Planetário (Design Espacial Autêntico):**
  * O modelo do veículo foi recriado do zero com proporções realistas adequadas à escala do piloto (1,5 m de largura total por 2,7 m de comprimento e 1,4 m de altura).
  * O avatar do piloto não é mais reduzido artificialmente, sentado em escala 1.0 em um assento concha anatômico com cockpit aberto e exoesqueleto tubular aeroespacial.
  * Adicionados componentes espaciais autênticos: geradores de célula de íons duplos com núcleos energéticos turquesa, mastro de comunicação de alto ganho com antena parabólica, visores HUD transparentes e faróis duplos LED integrados no capô chanfrado.
* **Animações Dinâmicas de Condução e Direção Realistas:**
  * **Giro das Rodas:** Todas as 4 rodas agora giram dinamicamente ao redor do seu eixo de rotação em conformidade exata com a velocidade e direção de condução (para frente e ré).
  * **Mangas de Eixo Frontais:** As rodas dianteiras viram fisicamente para a esquerda ou direita ao manobrar o veículo.
  * **Volante/Manche Aeroespacial:** O manche de controle futurista no painel gira suavemente acompanhando a entrada de direção do piloto.
* **Postura Biomecânica dos Braços do Piloto:**
  * Corrigida a postura dos braços e cotovelos do piloto enquanto sentado ou conduzindo o veículo: os braços estendem-se para a frente em direção ao volante com flexão anatômica de 52° dos cotovelos, eliminando a torção invertida para trás do corpo.
  * As mãos acompanham dinamicamente o giro do manche durante as curvas.
* **Fim da Catapultagem do Rover ao Sair da Nave:**
  * O rover agora desce toda a extensão da rampa física (7,2 m) até tocar o solo antes de ser desacoplado para a cena.
  * O sistema de sondagem de solo (`floorProbe`) foi corrigido para ignorar o próprio rover, eliminando o auto-raio colisional que empurrava o veículo exponencialmente em direção ao espaço.
  * Velocidade e gravidade zeradas/aterradas com segurança ao tocar o solo planetário.
* **Alinhamento da Mira das Armas (ADS Reta e Deslocada à Direita):**
  * Ajuste na postura de mira em primeira pessoa: a arma permanece perfeitamente reta no eixo vertical (`rotZ = 0`), sem inclinação para a esquerda, e é posicionada ligeiramente à direita da linha central da tela (`posX = 0.065`), garantindo conforto de visada e alinhamento com a retícula.
* **Liberação Completa de Armas nas Cidades:**
  * Removido o bloqueio que desativava o armamento ao entrar em áreas civis e cidades (`safeZone`). O jogador agora pode sacar, mirar e disparar armas livremente dentro de qualquer cidade ou assentamento.

---

## [v0.1.13] — 2026-09-19 (Farol Frontal Inferior, Trajetória e Física Real de Granadas, Alinhamento Coaxial de Lâminas, Fim da Queda no Limbo, Gravidade Interna em Voo e UI Unificada)
### Corrigido & Aprimorado
* **Farol Frontal Inferior & Fim das Luzes na Fuselagem:**
  * Remoção completa de todas as bolinhas de luz e sinalizadores externos que haviam sido adicionados pela fuselagem, asas e cauda.
  * Substituição dos faróis do cockpit por um único projetor de alta potência montado na parte de baixo da frente da nave (queixo ventral da proa), com feixe de 950 metros e sem qualquer vazamento de luz no interior da cabine.
* **Física e Dinâmica Real de Granadas com Previsão de Trajetória:**
  * O objeto arremessado passa a ser o modelo tridimensional idêntico ao que o jogador segura na mão.
  * Lançamento em arco balístico com gravidade, colisão firme contra o solo, quique amortecido e rolamento, impedindo que atravesse o chão.
  * Espoleta com temporizador de 3,0 segundos após o arremesso para detonação em explosão expansiva de alto impacto.
  * Exibição de arco de trajetória previsto na tela ao mirar segurando a granada.
  * Saque automático da próxima granada para a mão após lançar a anterior.
* **Armamento & Mecânica de Tiro:**
  * Áudio da pistola Apex-9 aprimorado: remoção do bip robótico residual, mantendo apenas o estalo seco da detonação inicial e o grave profundo de recuo.
  * Habilitado o disparo de armas enquanto o jogador está mirando (ADS) com resposta imediata.
  * Ajuste do braço do personagem em 3ª pessoa para apontar para cima ou para baixo acompanhando a inclinação vertical da câmera e a linha de tiro.
  * Correção das armas brancas (Tanto e Sabre de Plasma): a lâmina foi perfeitamente alinhada em linha reta com o cabo, eliminando a torção de 90°.
* **Fim da Queda no Limbo ao Pisar na Grama:**
  * Ajuste no cálculo de colisão do terreno e introdução de piso de sustentação absoluto que impede o personagem de afundar no terreno rumo ao centro do planeta.
* **Gravidade Artificial em Voo & Locomoção na Nave:**
  * Gravidade artificial interna mantida ativa durante o voo, mantendo a referência do jogador estritamente dentro da nave (eliminando animação de andar involuntária ao voar e impedindo o jogador de ser arremessado contra paredes em curvas).
  * A gravidade artificial só é desabilitada quando a nave estiver pousada/estacionada.
* **Oclusão Celestial de Estrelas:**
  * Correção no teste de profundidade e ordenação da camada de estrelas de fundo, garantindo que nenhum planeta permita ver estrelas através do seu relevo.
* **Identidade Visual e Limpeza de Marca:**
  * Remoção do subtítulo "Fronteiras Ilimitadas" / "Fronteiras Infinitas" de todos os textos e do título da página (`<title>SkyWard</title>`).
  * Botão de Sandbox ajustado estritamente para o texto "Sandbox".
  * Unificação de toda a interface do jogo (painéis, abas, cartões, botões e toasts) com o design escuro translúcido moderno do menu inicial.

---

## [v0.1.12] — 2026-09-19 (Mira como Cursor no Painel Mobile, Inclinação Natural da Arma ao Mirar, Remoção de Mercado e Refinaria, Mapa 2D Centrado no Sol com Elementos Maiores e Sem Sobreposição)
### Corrigido & Aprimorado
* **Controle de Versão Estrito (Terceiro Dígito):**
  * Correção e consolidação da numeração de versões recentes para seguir estritamente o incremento automático apenas do terceiro dígito (patch `0.1.X`), reclassificando as versões anteriores para `v0.1.10` e `v0.1.11`, e estabelecendo a regra de que alterações nos dígitos maior ou menor exigem proposta prévia e aprovação explícita do usuário.
* **Painel da Nave no Mobile com Mira Central como Cursor:**
  * O centro da mira (crosshair central da tela) agora atua como cursor exclusivo para interação com o painel 3D e botões do cockpit em dispositivos móveis/toque.
  * O toque do jogador em qualquer ponto da tela não aciona mais o local tocado pelo dedo, mas aciona única e exclusivamente o botão ou instrumento que estiver sob o centro da mira.
* **Inclinação Natural da Arma ao Mirar (ADS):**
  * Ao mirar com a arma (fuzil, pistola, escopeta), a arma fica perfeitamente centralizada na visão e suavemente inclinada para a esquerda (+rotZ / sentido anti-horário), refletindo a postura ergonômica real de empunhadura com a mão direita trazendo a visada ao olho do operador.
* **Remoção Completa dos Sistemas de Mercado e Refinaria:**
  * Removidas todas as abas e botões de Mercado e Refinaria do painel HUD e do cockpit.
  * Removidos do código de tempo de execução os manipuladores de compra/venda de commodities, cálculo de preços de mercado, usina de refino e paletes de carga físicos.
* **Mapa 2D do Sistema Centrado no Sol com Elementos Maiores e Sem Sobreposição:**
  * O centro absoluto do mapa do sistema agora é a estrela/Sol (`(0, 0)`), eliminando o posicionamento anterior que sobrepunha o planeta Ferrum ao centro solar.
  * As dimensões visuais de todos os corpos celestes e marcos espaciais foram significativamente aumentadas (planetas, gigantes gasosos, estações orbitais e portais de salto).
  * Implementado algoritmo de distribuição orbital e relaxação anti-colisão que garante matematicamente espaçamento mínimo entre todos os nós e em relação ao Sol, impedindo 100% qualquer sobreposição de corpos e rótulos na carta estelar.

---

# Changelog — SkyWard

Todas as notas de versão e histórico de evolução do projeto SkyWard.

O projeto segue estritamente a convenção de versionamento semântico **`vX.Y.Z`**:
* **`Z` (Dígito da Direita / Patch):** Incrementado automaticamente a cada novo ciclo ou pedido de implementações/correções.
* **`Y` (Dígito Central / Minor):** Reservado para marcos maiores de jogabilidade e sistemas integrados. Alterado mediante declaração e aprovação do usuário.
* **`X` (Dígito da Esquerda / Major):** Reservado para o lançamento oficial estável da versão 1.0 (Gold Master).

---

## [v0.1.11] — 2026-09-19 (Câmera Estável em 3ª Pessoa, Controle da Nave em 3ª Pessoa, Faróis Potentes e Luzes Externas Sincronizadas)
### Corrigido & Aprimorado
* **Câmera Estável Sem Inclinação em 3ª Pessoa a Pé:**
  * O vetor de orientação vertical da câmera em terceira pessoa a pé permanece rigorosamente perpendicular ao solo e alinhado à gravidade local, eliminando qualquer inclinação, rotação lateral ou balanço durante deslocamentos, curvas ou corridas.
* **Controle Direto da Nave na Câmera em 3ª Pessoa:**
  * O direcionamento da nave pelo mouse foi ativado na visão em 3ª pessoa durante o voo, permitindo pilotar, manobrar e guiar a espaçonave com total precisão tanto em primeira quanto em terceira pessoa.
* **Faróis Potentes Sem Vazamento no Interior da Nave:**
  * Reposicionamento dos faróis principais para o bico frontal externo da nave, estritamente à frente do cockpit e do canópio, eliminando qualquer iluminação residual indesejada na cabine.
  * Remoção de refletores duplicados obsoletos que estavam posicionados no interior do cockpit.
  * Projetores de longo alcance aumentados para alcance de 850 metros (intensidade 16,0, feixe amplo) com lentes de alta luminescência no exterior da proa.
* **Luzes Externas de Navegação e Sinalização Sincronizadas:**
  * Instalação de luzes externas sutis em pontos-chave da fuselagem: balizas de navegação nas pontas das asas (bombordo vermelho, boreste verde), sinalizador dorsal no topo da fuselagem, luzes de posição nos motores traseiros e marcador ventral.
  * Todas as luzes externas e os faróis principais ligam e desligam de forma perfeitamente sincronizada de acordo com o estado do sistema de iluminação (modo auto, ligado ou desligado).

---

## [v0.1.10] — 2026-09-19 (Gravidade Real do Solo, Rampa Física com Inclinação, Ações Diretas por Verbos, Acesso Sandbox no Menu e Remoção da Estrela de 3 Pontas)
### Corrigido & Aprimorado
* **Gravidade do Terreno e Bloqueio de Voo Espacial em Solo:**
  * Desativação da gravidade artificial da nave enquanto estiver pousada: o jogador e a câmera seguem unicamente o vetor gravitacional do planeta ou da estação espacial, tanto dentro quanto fora da nave.
  * O modo de voo em gravidade zero (EVA) é completamente desativado em planetas e estações (`eva = false`), eliminando o problema em que o personagem ficava flutuando e planando como se estivesse no espaço sideral ao sair da nave.
  * O modo de pilotagem de voo só pode ser acionado quando sentado no assento do piloto com intenção deliberada de decolagem.
* **Rampa Física com Colisão e Inclinação Natural:**
  * O deque da rampa (`deck`) agora possui colisão física sólida integrada ao sistema de sondagem de solo (`floorProbe`), permitindo caminhar e dirigir respeitando a sua inclinação angular real de 11,5° ao longo de seus 7,2 metros de comprimento.
  * Remoção completa de teletransportes artificiais, solavancos para o chão ou queda através da geometria da rampa. A transição entre o interior da nave e o solo ocorre de maneira fluida e contínua.
* **Prompts de Interação Limpos com Verbo + Objeto:**
  * Eliminadas todas as instruções de "clique duplo", "clique normal" ou nomes de teclas nas mensagens de interação.
  * Mensagens diretas e contextuais: *Sentar na cadeira do piloto*, *Levantar da cadeira*, *Deitar na cama*, *Levantar da cama*, *Abrir rampa*, *Fechar rampa*, *Descer rampa*, *Subir rampa da nave*, *Abrir porta*, *Fechar porta*, *Abrir armário*, *Iniciar conversa*, *Realizar compras*, *Acariciar animal*, *Embarcar no veículo*, *Sair do veículo*, *Apertar botão: Frear nave*, entre outros.
  * Adicionada ação de acariciar a fauna dócil encontrada na superfície dos planetas.
* **Acesso Direto ao Modo Sandbox no Menu Inicial:**
  * Adicionado o botão "MODO SANDBOX (RECURSOS ILIMITADOS)" no menu inicial, viabilizando iniciar imediatamente a sessão com créditos, combustível, jetpack e equipamentos ilimitados.
* **Remoção da Estrela de 3 Pontas:**
  * Removido integralmente o símbolo de estrela de 3 pontas do menu principal.

---

## [v0.1.9] — 2026-09-19 (Cidades Secas Elevadas, Friso Divisório de Portas e Mapa 2D Estático Ampliado)
### Corrigido & Aprimorado
* **Cidades e Portos em Terra Firme Sem Glitches de Geração:**
  * Corrigida a cota altimétrica das cidades em planetas com água (incluindo Vérdea), garantindo elevação segura de $18	ext{ m}$ acima da lâmina d'água (`seaRadius`).
  * Supressão automática de bacias e canais de erosão hídrica (`waterCarve`) em um raio de segurança em torno de qualquer assentamento, eliminando cidades submersas ou terrenos cortados por água.
  * O estado de nado (`isWater`) é estritamente bloqueado dentro das áreas urbanas e portos planetários.
  * O spawn inicial e o retorno da nave posicionam a nave pousada com precisão no porto de Vérdea em terra seca.
* **Linha Divisória Vertical e Relevo nas Portas Internas da Nave:**
  * As portas corrediças da cabine agora possuem um friso mecânico vertical proeminente em tom escuro (`0x111922`), além de painéis chanfrados em rebaixo e indicadores LED.
  * A porta fechada agora apresenta uma divisão visual evidente entre as duas metades que deslizam, eliminando o aspecto de parede contínua.
* **Carta Estelar 2D Fixa e Itens com Escala Aumentada:**
  * Removidos os controles de arraste (pan) e zoom da Carta Estelar 2D para proporcionar uma visão estável e sem desvios de enquadramento; cursor definido como padrão.
  * Todos os elementos visuais tiveram seu tamanho substancialmente ampliado: estrela central ($r=42$), planetas terrestres ($r=20$), gigantes gasosos ($r=28$), luas ($r=11$) e estações ($r=16$).
  * Tipografia dos nomes dos corpos celestes ampliada para $13	ext{ px}$ com negrito e contorno de alto contraste para máxima legibilidade contra o radar orbital.
  * Ícone da nave do jogador ("VOCÊ") ampliado e estilizado em ciano brilhante.

---

## [v0.1.8] — 2026-09-19 (Desembarque Contínuo pela Rampa e Direção do Veículo Aderente ao Solo)
### Corrigido & Aprimorado
* **Descida Contínua e Fluida pela Rampa da Nave:**
  * O jogador agora pode descer a pé toda a extensão de 7,2 metros da rampa até alcançar o solo, com física de contato contínua.
  * Removido o teletransporte repentino e a inversão abrupta de 180° da câmera ao descer a rampa. A direção do olhar e o movimento para a frente são integralmente preservados ao tocar o chão do planeta.
  * Suporte a reembarque suave ao caminhar de volta do terreno subindo a rampa em direção à porta da nave.
* **Física de Direção do Veículo Terrestre Aderente ao Solo:**
  * O rover agora roda com os 4 pneus firmemente apoiados na superfície do terreno (+0,29 m), corrigindo o defeito onde o veículo perdia contato com o solo e ficava flutuando/voando no ar em declives.
  * Alinhamento da suspensão e inclinação contínua em relação ao relevo planetário e pisos das colônias.

---

## [v0.1.7] — 2026-09-19 (Transição Suave do Céu sem Bolha, Portas Perfeitamente Seladas, Surgimento Frontal nos Portais e Cinemática Realista de Pulo e Corrida)
### Aprimorado & Corrigido
* **Ocultamento da Bolha de Atmosfera e Gradiente Contínuo do Céu:**
  * A malha esférica da atmosfera foi desativada da renderização visual.
  * O céu agora transita suave e naturalmente do vácuo negro do espaço profundo para o tom atmosférico do planeta através de uma curva exponencial contínua baseada na altitude da nave, sem bordas artificiais ou saltos bruscos de cor.
* **Selamento Completo das Portas Internas da Nave:**
  * Corrigida a folga central de 4,5 cm entre as folhas das portas automáticas corrediças quando fechadas. As folhas agora se sobrepõem perfeitamente no fechamento, vedando a passagem sem frestas.
* **Surgimento Frontal nos Portais de Salto:**
  * A nave e os marcadores de navegação dos arcos interestelares agora se posicionam a 400–450 m à frente da estrutura do portal, alinhados à sua trajetória, evitando qualquer surgimento ou colisão dentro dos anéis da passagem.
* **Cinemática Realista de Pulo e Corrida do Personagem:**
  * *Pulo em Três Fases:* Impulsão explosiva na decolagem com extensão de pernas, encolhimento anatômico de joelhos para limpeza de terreno no ápice do salto e extensão preparatória dos membros inferiores para amortecimento antes do impacto. Os braços erguem-se organicamente para gerar impulso e estabilidade.
  * *Corrida Realista e Atlética:* Cinemática pélvica aprimorada com rotação transversal ativa que impulsiona o quadril no avanço da perna, contra-rotação dos ombros e tórax para equilíbrio dinâmico, inclinação corporal de 9° e ciclo fluido de flexão pendular e absorção de peso na fase de apoio.

---

## [v0.1.6] — 2026-09-19 (Restauração dos Planetas Originais, Cidades Vivas com Tráfego, Ecossistema Completo e Câmera Orbital Firme)
### Restaurado & Aprimorado
* **Restauração Completa dos Planetas Pequenos e Coesos:**
  * Retorno da escala orbital e planetária equilibrada (raios entre 620 m e 800 m: Vérdea 730 m, Ferrum 640 m, Nívea 680 m, Mycelia 800 m, Aurea 620 m, Umbra 750 m).
  * Relevo procedural suave e contínuo com ondulações naturais ($\pm 16$ m), eliminando montanhas pontiagudas excessivas e desníveis entre colisor e malha visual.
  * Superfície física 100% sólida e contínua em toda a extensão do globo.
* **Cidades Vivas, Cidadãos e Tráfego Aéreo:**
  * Restauração integral dos cidadãos (`npcs`) caminhando pelas praças, vias e mercados com diálogos e rotas ativas.
  * Reativação dos carros voadores (`traffic`) circulando pelas vias aéreas da cidade com faróis e lanternas funcionais.
  * Plataformas de pouso, praças comerciais e lojas perfeitamente niveladas e integradas ao solo.
* **Ecossistema Planetário Nativo (Fauna, Flora e Minérios):**
  * Reintrodução dos animais quadrúpedes animados (`animals`) pastando e se movimentando nos campos e colinas fora da cidade.
  * Geração nativa de 190 elementos de cenário (`scenery`) por planeta: árvores, cogumelos gigantes, rochas, cactos e cristais.
  * Reativação de 18 depósitos cristalinos de minério (`ores`) escaneáveis e mineráveis por planeta.
* **Câmera em 3ª Pessoa da Nave Ancorada à Fuselagem:**
  * Eliminado o atraso posicional elástico em altas velocidades: a câmera de 3ª pessoa permanece rigorosamente atrelada à nave, orbitando o próprio centro da nave sem derivar para o vazio atrás dela.
* **Câmera em 3ª Pessoa a Pé com Resposta Instantânea:**
  * Removido o delay/esponja ao girar a câmera a pé: a orientação responde de forma imediata aos movimentos do mouse e do toque na tela.

---

## [v0.1.5] — 2026-09-19 (Modo Sandbox, Estrela de 3 Pontas, Mira Mobile Estacionária, Mapa 2D Pan/Zoom, Objetos Geográficos Fixos e Gigantes Gasosos Limpos)
### Corrigido & Aprimorado
* **Prevenção Absoluta de Seleção de Texto:**
  * Implementada diretiva CSS universal `*, *::before, *::after { user-select: none !important; }` garantindo que nenhum texto da interface, HUD, canvas ou menus possa ser selecionado por clique ou arraste.
* **Estrela de 3 Pontas no Menu Inicial:**
  * Substituído o glifo de 4 pontas no cabeçalho por um vetor SVG tridimensional estilizado com 3 pontas, com o vértice superior perfeitamente apontado para cima.
* **Controles Mobile Refinados (Mira Estacionária e Voo em 3ª Pessoa):**
  * Desacoplado o controle de mira do movimento de câmera: deslizar o dedo na metade direita da tela move unicamente a câmera.
  * A mira telescópica/combate agora só é ativada quando o jogador mantém o dedo imóvel na parte direita por pelo menos 350 ms.
  * O controle de voo em 3ª pessoa da nave no mobile agora responde com precisão ao deslize de dedo na tela para pilotar e manobrar.
* **Remoção do Alinhamento Automático de Terreno:**
  * Removido integralmente o torque de alinhamento de barriga na atmosfera, restaurando a liberdade total do piloto de manobrar e mergulhar em direção à superfície.
* **Animação de Corrida Humana e Natural:**
  * Redesenhada a cinemática de corrida para padrões anatômicos humanos: postura atlética com inclinação suave de 7° a 8°, elevação moderada de joelhos (flexão confortável de 42° para desobstrução do solo) e passada ritmada sem movimentos cartunescos.
* **Correção das Cidades e Superfícies dos Planetas:**
  * Desativada a malha sobreposta de terreno que entrava em conflito e cobria as cidades. As cidades e vilarejos repousam perfeitamente alinhados e nivelados sobre o chão planetário.
  * Implementada a geração geográfica determinística baseada em latitude e longitude (espiral esférica de Fibonacci com semente planetária fixa): árvores, rochas, cactos e minérios existem em coordenadas permanentes no planeta e nunca se movem ou reaparecem ao redor do jogador.
* **Gigantes Gasosos Limpos, Majestosos e Atmosfera Profunda:**
  * Removidas as camadas aramadas sobrepostas; o planeta gasoso volta a ter a forma clássica de uma bola colossal de gás nítida e contínua.
  * Atmosfera profunda expandida para 14.000 m de altitude, permitindo descer longas distâncias antes de adentrar as camadas inferiores mais densas, tempestades e o pequeno núcleo interno.
* **Carta Estelar 2D Interativa com Pan e Zoom:**
  * Removidos textos redundantes de instrução, mantendo apenas o título limpo.
  * O mapa ocupa toda a área útil do painel de navegação sem sobrepor as abas de navegação.
  * Adicionado suporte a arrasto (pan) para navegar pelo sistema estelar e zoom dinâmico via scroll do mouse ou pinça multitoque no celular.

---

## [v0.1.4] — 2026-09-19 (Modo Sandbox, Mapa 2D do Sistema, Piloto Automático Inteligente, Áudio Grave e Animações Expressivas)
### Adicionado & Aprimorado
* **Modo Sandbox no Menu Inicial:**
  * Opção sutil e elegante abaixo do botão "INICIAR" (letras com efeito ciano luminoso no hover, sem formato de caixa de botão).
  * Ao clicar, inicia a expedição com recursos e equipamentos ilimitados: integridade de casco, vida e escudos infinitos, combustível de jetpack inesgotável, 99.999.999 créditos, munição infinita e desbloqueio imediato de todas as naves, veículos (terrestres e aquáticos), trajes e armas.
* **Mapa 2D do Sistema Estelar Interativo:**
  * Substituição completa da lista de caixas de seleção por um radar orbital 2D interativo em SVG vetorial de alta definição.
  * Renderiza a estrela primária com coroa solar, órbitas pontilhadas, planetas com cores de bioma e anéis planetários, luas em órbitas filiais, estações e arcos interestelares.
  * Indicador em tempo real da posição e proa da sua nave (`▲ VOCÊ`).
  * **Interatividade completa:**
    * *Hover ou toque contínuo:* card flutuante com nome, tipo de astro, raio, biomas e distância em km.
    * *Clique simples:* ativa ou desativa o anel pulsante de marcação no HUD para aquele destino.
    * *Duplo clique:* engaja automaticamente o piloto automático rumo ao local selecionado.
* **Física de Voo e Alinhamento Atmosférico com o Terreno:**
  * Implementado torque aerodinâmico que orienta gradualmente a parte inferior (barriga) da nave em direção ao terreno ao voar dentro de atmosferas.
  * A intensidade cresce suavemente à medida que a altitude diminui, oferecendo estabilidade natural para voos rasantes sem solavancos bruscos.
* **Piloto Automático Inteligente com Desvio de Obstáculos:**
  * Algoritmo de desvio de colisão que projeta trajetórias seguras ao redor de planetas, luas e estrelas intermediárias na linha de visada até o destino.
  * Decolagem radial automática para desengajar da atmosfera de origem antes de acelerar e aproximação em arco orbital elevado na descida do planeta de destino.
* **Áudio de Armas Grave e Encorpado:**
  * Removidos todos os bips agudos e ondas quadradas de alta frequência dos disparos.
  * Sintetizadores procedurais reconfigurados com sub-graves profundos (30Hz - 60Hz), estalo de culatra mecânica e canhões navais com estrondo reverberante de baixa frequência.
* **Biomecânica e Novas Animações do Personagem:**
  * **Corrida (Sprint):** inclinação atlética do tronco (32° para frente), passadas largas, elevação acentuada dos joelhos e bombeamento enérgico dos braços com rotação contrária do tórax.
  * **Pulo:** impulso atlético na subida, retração das pernas em suspensão com braços abertos para estabilidade aerodinâmica e amortecimento de impacto na aterrissagem.
  * **Nado:** postura horizontal na água com cabeça erguida para respirar, braçadas alternadas de nado crawl e pernadas contínuas.
  * **Jetpack:** pernas estendidas e relaxadas com mãos firmes nos controles de empuxo integrados ao peitoral.
* **Transição Suave de Câmera por Limite de Zoom e Órbita 360°:**
  * Alternância entre 1ª e 3ª pessoa acontece por empurrão além do limite de zoom: o zoom para na extremidade e continuar rolando ativa a transição suave e contínua.
  * Zoom de 1ª pessoa no cockpit com maior aproximação (FOV até 28°) para visualização e acionamento nítido de todos os botões do painel.
  * Câmera de 3ª pessoa da nave com rotação orbital livre de 360° em todas as direções via mouse.
  * Limites de rotação na cabine sentada ampliados (165° laterais e 75° para baixo), eliminando restrições ao interagir com o console.
* **Superfícies Planetárias Suaves e Vida Abundante:**
  * Relevo reformulado: o relevo agora é predominantemente suave, formado por vastas planícies navegáveis e colinas; montanhas íngremes ocorrem apenas em cordilheiras orográficas localizadas (~18% da área).
  * Oceanos, lagos e rios visíveis preenchendo as bacias e terras baixas nos mundos úmidos.
  * Rede de cidades e vilarejos povoados ativamente distribuídos por cada planeta, com portos comerciais e cidadãos em circulação.
  * Esferas de nuvens dos gigantes gasosos trancadas no sistema de coordenadas locais do astro, com alinhamento concêntrico perfeito e sem tracking de câmera.

---

## [v0.1.3] — 2026-09-19 (Correção de Colisor de Solo, Detalhamento de Biomas, Nuvens em Camadas de Gigantes Gasosos e Câmera Roll)
### Corrigido & Aprimorado
* **Sincronização Perfeita do Colisor com a Superfície Visível:**
  * Corrigido o problema em que o colisor ficava muito abaixo das superfícies visíveis: a rotação planetária (`spinAngle`) fazia com que as montanhas visuais girassem enquanto o cálculo de colisão avaliava as coordenadas mundiais desatualizadas.
  * Implementada a função `planetLocalNormal(p, worldN)` que desrotaciona o vetor normal do jogador antes de calcular `radius(p, n)`, garantindo paridade absoluta entre a malha gráfica rotativa e o cálculo físico de altura.
  * Implementada a **Malha de Terreno Local de Alta Resolução (`localGroundMesh`)** que se projeta dinamicamente sob o jogador/nave em um raio de até 1.400 m (grade densa de 36x36 vértices avaliada com a função exata de elevação e sombreamento plano), eliminando qualquer diferença perceptível entre o chão visual e o ponto de toque dos pés.
* **Detalhamento Denso e Rico do Solo ao Redor do Jogador:**
  * Substituída a distribuição esparsa global pelo **Sistema de Proximidade de Detalhes de Terreno (`refreshProximityFlora`)**, que popula continuamente de 85 a 120 elementos ricos em um raio de 220 m ao redor do jogador.
  * Vegetação, rochas e elementos geológicos autênticos para cada bioma de latitude:
    * **Tropical / Equatorial:** Palmeiras curvas com grandes folhagens, samambaias densas, cogumelos bioluminescentes e rochas cobertas de musgo.
    * **Savana:** Acácias com copas tabulares, touceiras de capim dourado e rochedos de granito.
    * **Deserto Cálido:** Cactos colunares nervurados com braços laterais, espirais de arenito e arbustos ressequidos.
    * **Taiga / Boreal:** Pinheiros coníferos em camadas com agulhas escuras, troncos caídos e seixos frios.
    * **Polar / Glacial:** Cristais pontiagudos de gelo cintilante e espículas glaciais translúcidas.
    * **Vulcânico:** Colunas de basalto negro hexagonal, respiradouros de magma incandescente e cracas de obsidiana.
    * **Temperado / Pradarias:** Árvores decíduas frondosas, arbustos com flores silvestres e rochas de campina.
* **Gigantes Gasosos (Atmosfera Totalmente Preenchida, Várias Camadas, Névoas e Raios):**
  * O topo da atmosfera do gigante gasoso agora conta com um manto de nuvens contínuo e denso (96% a 98% de cobertura) sem vazios visíveis do espaço.
  * **Múltiplos Conveses Concêntricos de Nuvens:** Quatro camadas de nuvens esféricas em altitudes distintas (*Upper Stratosphere, Mid Troposphere, Deep Storm Deck, Supercritical Base*).
  * **Preenchimento Progressivo ao Descer:** As camadas inferiores iniciam com aberturas e vão se preenchendo de nuvens densas conforme a nave desce, virando paredes sólidas de tempestade.
  * **Névoa Volumétrica Pesada:** Ao entrar na atmosfera, o alcance da névoa fecha drasticamente (*near* 8 m, *far* 95 m) com tonalidades escuras e opacas de gás hiperbárico.
  * **Tempestades Frequentes de Raios e Trovões:** Arcos elétricos ramificados em 3D piscam no interior das nuvens com emissão luminosa vibrante e estrondos sonoros de trovão em baixa frequência.
* **Alinhamento Suave da Câmera com a Rotação da Nave (Roll / Q e E):**
  * Corrigido o bug que fazia a câmera ficar permanentemente inclinada a 90 graus em relação à nave: o Three.js forçava a orientação baseada em um vetor vertical fixo `(0, 1, 0)` no `lookAt`.
  * Implementado o vetor amortecido `smoothCamUp` que faz a parte superior da câmera acompanhar a rotação da nave de forma suave e contínua (evitando alinhamento rígido que causa solavancos ou travamentos em 90 graus).
  * A câmera agora acompanha naturalmente giros e piruetas com as teclas Q e E sem perder a orientação correta da cabine ou da perseguição em 3ª pessoa.

---

## [v0.1.2] — 2026-09-19 (Planetas Gigantes, Luas, Gigantes Gasosos, Vulcões e Biomas por Latitude)
### Adicionado & Aprimorado
* **Transição Atmosférica Suave e Contínua:**
  * Removido o corte nítido e a borda dura esférica das atmosferas planetárias.
  * Implementado shader volumétrico com decaimento exponencial de densidade e dispersão rim suave (`pow(1.0 - abs(dot(n, v)), 4.2)`), fundindo perfeitamente as cores do céu ao negro estrelado do espaço.
* **Escala Planetária Muito Maior:**
  * Planetas agora possuem dimensões colossais (raios de 5.600m a 8.200m para mundos rochosos e até 24.000m para gigantes gasosos, um aumento de mais de 10x na área e volume explorável).
* **Rotação e Translação Orbital em Tempo Real:**
  * Planetas giram dinamicamente em torno do seu próprio eixo polar (`rotSpeed`), com deslocamento relativo das camadas de nuvens.
  * Translação orbital de cada planeta em torno da estrela primária ao longo do tempo estelar.
* **Sistema de Luas Naturais:**
  * Luas com órbitas elípticas ao redor dos planetas principais (*Selene* em Vérdea, *Ígnea* em Ferrum, *Têmis* em Tifão, *Lúmen* em Mycelia).
  * Luas com relevo de crateras de impacto, gravidade própria e referências completas de navegação e pouso.
* **Gigantes Gasosos (Tifão no Sistema Éos e Boreas no Sistema Nyx):**
  * Mundos gasosos maciços (22.000m a 24.000m de raio) com faixas zonais animadas e atmosfera hiperbárica de 9.000m.
  * **Mecânica de Descida:** Quanto mais fundo a nave desce, menor a visibilidade (névoa progressivamente opaca e escura), maior o amortecimento de descida (a descida fica cada vez mais lenta pela densidade, enquanto a subida preserva potência plena).
  * **Turbulência Violenta:** Ventos laterais e jatos de gás sacodem e desestabilizam o controle da nave (*buffeting*).
  * **Núcleo em Duas Camadas:** Camada externa de oceano supercrítico de água líquida e camada interna de manto rochoso e solo metálico.
  * **Tempestades Elétricas e Dano:** Relâmpagos violentos frequentes e dano contínuo por pressão extrema e descargas de plasma ao se aproximar do núcleo.
* **Relevo com Montanhas Multi-Escala e Vulcões:**
  * Elevação procedural combinando colinas suaves (15m), cordilheiras médias (55m), picos pontiagudos (260m) e montanhas colossais (420m+).
  * Cones vulcânicos com caldeiras centrais e lagos de lava incandescente.
  * Biomas vulcânicos em mundos tectônicos (*Ferrum* e *Umbra*) com rochas de basalto negro, cinzas e fissuras ativas de lava.
* **Biomas Realistas por Latitude (0° a 90°):**
  * Geração fiel aos parâmetros geográficos planetários:
    * **0° a 10° (Equatorial):** Floresta Tropical e Equatorial exuberante de alta umidade.
    * **10° a 20° (Tropical):** Savanas e vegetação de gramíneas com árvores esparsas.
    * **15° a 30° (Subtropical):** Desertos Cálidos com dunas de areia alaranjada.
    * **30° a 45° (Temperada Baixa):** Campos e Pradarias.
    * **40° a 60° (Temperada Alta):** Floresta Temperada com tons verdes e outonais.
    * **60° a 70° (Boreal):** Taiga e Floresta de Coníferas.
    * **70° a 80° (Polar Baixa):** Tundra fria com permafrost.
    * **80° a 90° (Polar Alta):** Calotas Polares com gelo perpétuo e geleiras azuis.
  * Quantidade de biomas adaptada ao porte do corpo celeste: planetas grandes (até 5 biomas), médios (até 3 biomas) e pequenos/luas (1 a 2 biomas), com transições suaves e graduais.

---

## [v0.1.1] — 2026-09-19 (Ajustes de Câmera, Teclas e Modos de Luz)
### Adicionado & Aprimorado
* **Inversão de Teclas de Pilotagem:**
  * Tecla **`R`**: Levantar do assento de pilotagem (e do banco/cama).
  * Tecla **`F`**: Executar sequência de pouso da nave. (A pé, `R` recarrega armas e `F` usa a ferramenta/scan).
* **Faróis do Cockpit com 3 Modos (Auto / Ligado / Desligado):**
  * O botão 3D superior direito do console do cockpit agora controla os faróis externos da nave, substituindo o botão de câmera.
  * Modos disponíveis: **Automático** (padrão — liga no escuro/noite/sombras e desliga em luz diurna plena), **Ligado** e **Desligado**. O visor MFD do botão atualiza em tempo real `LIGHTS [AUTO / ON / OFF]`.
* **Câmera Livre Automática no Pouso:**
  * Ao pousar em primeira pessoa, a visão entra automaticamente em câmera livre (`shipLookOnly = true`), permitindo olhar a cabine e os arredores sem mover a nave.
  * Enquanto pousado, o modo de controle de voo pelo mouse/toque direito fica bloqueado.
  * Ao decolar, o controle de voo é reativado automaticamente e centralizado.
* **Zoom Suave e Sensibilidade Calibrada da Roda do Mouse:**
  * Sensibilidade do scroll reduzida em ~60%, eliminando o salto direto entre zoom alto e terceira pessoa.
  * Transição contínua e suave entre primeira e terceira pessoa sem cortes abruptos.
* **Atraso Cinemático (Camera Lag / Spring Follow) em 3ª Pessoa:**
  * A câmera externa agora acompanha a nave, veículo ou personagem com uma interpolação elástica orgânica, transmitindo peso e dinamismo em manobras e curvas.
* **Limites Suaves de Rotação de Câmera Sentado:**
  * Ao pilotar ou sentar em cadeiras/veículos, a câmera permite olhar amplamente para trás (até ~135°), mas desacelera progressivamente e com amortecimento suave até parar, evitando girar 180° ou olhar excessivamente para baixo no assento.

---

## [v0.1.0] — 2026-09-18 (Marco Maior: Economia, Comércio e Exploração Noturna)
### Adicionado & Aprimorado
* **Bolsa de Commodities e Comércio Interestelar (Trading Loop):**
  * 8 commodities comerciais autênticas: Minério Bruto (`ore_raw`), Ligas Metálicas (`metals_refined`), Bioprodutos (`bioproducts`), Água Potável (`water_fresh`), Células de Combustível (`fuel_cells`), Cristais de Hiper-Dobra (`hyper_crystals`), Maquinário Pesado (`machinery`) e Kits Cirúrgicos (`medical_supplies`).
  * Economia regional viva com oferta, demanda e multiplicadores de preço dedicados por planeta e estações orbitais (ex.: Ferrum produz minério e ligas baratas, mas compra água e alimentos a preços altos; Vérdea produz água e bioprodutos baratos, mas demanda maquinário e cristais).
  * Painel de Mercado interativo (`menu('market')` / tecla `M`) para compra e venda direta nos portos e estações com cálculo de capacidade de porão.
* **Carga Física Paletizada no Porão da Nave:**
  * Todas as mercadorias adquiridas ou extraídas aparecem renderizadas como paletes de carga tridimensionais com tinturas exclusivas, travas metálicas e etiquetas holográficas na câmara de carga da Atlas, Kestrel e Mole.
* **Mineração com Laser Térmico Fraturante:**
  * O disparo da ferramenta de campo (`equipped === 'tool'`) em depósitos minerais agora projeta um feixe de plasma concentrado contínuo com som pulsante e faíscas.
  * O depósito acumula estresse térmico até que uma **fratura sísmica** ocorre, explodindo a rocha em partículas brilhantes e coletando 2x Minério Bruto no porão, +55 CR e reputação com o Consórcio Mineiro.
* **Terminal de Refino Industrial:**
  * Terminal acessível em portos e nativamente a bordo da nave mineradora Mole (`menu('refinery')`), permitindo fundir 2x Minério Bruto em 1x Liga Metálica (+8 Rep CMI), agregando alto valor comercial.
* **Facções e Reputação Dinâmica (CMI, GCU, SNYX):**
  * Introdução de 3 facções galácticas com níveis de reputação salvos: *Consórcio Mineiro Independente* (CMI), *Guarda Colonial Unida* (GCU) e *Sindicato de Saqueadores de Nyx* (SNYX).
* **Ciclo Solar e Dia/Noite Planetário Dinâmico:**
  * Movimentação orbital suave da estrela primária em tempo real (`updateSunOrbit`), proporcionando amanhecer dourado, meio-dia claro, entardecer com dispersão atmosférica avermelhada e noites escuras estreladas.
* **Faróis e Holofotes de Navegação Noturna (Tecla `L`):**
  * Projetores de alta intensidade montados na proa da nave e do veículo terrestre (`toggleHeadlights()`), iluminando o relevo e estruturas até 280 metros à frente.
* **Suíte de Testes Expandida para 39 Testes:** Cobertura automatizada completa de todos os sistemas novos e regressões.

---

## [v0.0.11] — Ajustes de Voo, Trens de Pouso e Feixes 3D
* Modularização da arquitetura em 17 módulos desacoplados com pipeline de compilação em 100 ms.
* Correção do recolhimento dos trens de pouso na decolagem com tolerância de subida.
* Correção dos eixos de inclinação lateral (A inclina para esquerda, D para direita) e amortecimento suave progressivo com limites ampliados.
* Feixes tridimensionais de partículas correndo pelo exterior da fuselagem durante saltos de dobra em portais.

---

## [v0.0.10] — Gestos e Opções de Desempenho
* Zoom por pinça touch e gesto de dois dedos para levantar.
* Menu de opções avançadas de renderização (LOD, escala 50-100%, modo econômico).

---

## [v0.0.9] — Controles, Câmera e Pouso
* Volume de segurança contra colisão de câmera e aproximação suave de pouso.

---

## [v0.0.8] — Traje, Interiores e Quedas
* Traje espacial com capacete fechado e interiores habitáveis.

---

## [v0.0.7] — Recursos Ambientais e Exploração Aquática
* Cidades orgânicas, oceanos, natação e embarcações jogáveis.

---

## [v0.0.1 a v0.0.6] — Fundações do Protótipo
* Naves Atlas, Kestrel e Mole; contratos de trabalho, arcos e sistemas Éos e Nyx.

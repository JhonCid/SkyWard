# SkyWard — Documento de Design do Jogo (GDD)

**Versão do Projeto:** 0.11
**Gênero:** Space Sim / Exploração Espacial Procedural / Ação e Sobrevivência
**Plataforma Alvo:** Web (Navegador Desktop & Mobile), zero instalação
**Motor Gráfico:** Three.js (WebGL com aceleração por hardware)

---

## 1. Visão Geral e Pilares Fundamentais

SkyWard é um simulador espacial imersivo sem telas de carregamento (*seamless*), onde o jogador pode:
1. **Transitar sem cortes:** Voar no vácuo espacial profundo, cruzar atmosferas planetárias com arrasto e aquecimento aerodinâmico e pousar diretamente na superfície de planetas vivos.
2. **Explorar a pé e em veículos:** Desembarcar da nave, andar pelo interior dos compartimentos habitáveis, pilotar rovers e lanchas anfíbias, coletar recursos e interagir com habitantes.
3. **Sistemas mecânicos táteis:** Cabines com consoles 3D interativos, trens de pouso articulados e amortecidos, combate procedural de armas de fogo e lâminas com movimentação corporal realista.

---

## 2. Mapa Completo de Controles

### A. Pilotagem da Nave (Modo Piloto)
| Ação | Teclado / Mouse | Descrição |
| :--- | :--- | :--- |
| **Acelerar / Marcha a ré** | `W` / `S` | Empuxo longitudinal principal. |
| **Deslocamento Lateral (*Strafe*)** | `A` / `D` | Propulsores laterais velozes (85 m/s) com inclinação visual (*roll bank*). |
| **Subir / Descer (*Lift / Dive*)** | `Espaço` / `Ctrl` | Empuxo vertical (90 m/s). Espaço empina o nariz para cima; Ctrl inclina para baixo. |
| **Rolar (*Roll*)** | `Q` / `E` | `Q` inclina para a esquerda; `E` inclina para a direita. |
| **Arfagem e Guinada (*Pitch / Yaw*)** | `Mouse` / `Setas` | Rotação direcional nos eixos X e Y. Virar o mouse gera inclinação lateral dinâmica. |
| **Pousar** | `R` (ou `L`) | Inicia sequência automática de pouso com desvio de obstáculos e amortecimento. |
| **Levantar do Banco de Piloto** | `F` | Sai dos controles e retorna para o modo a pé dentro da nave. |
| **Desembarcar da Nave** | `B` | Sai diretamente para a superfície se estiver próximo à rampa/solo. |
| **Câmera Livre na Cabine** | `Z` / `Alt` / `Botão do Meio` | Desvincula a visão dos controles de voo para olhar livremente pela cabine. |
| **Frear Nave** | `X` | Corta acelerações e zera a velocidade de cruzeiro. |
| **Piloto Manual / Cancelar Auto** | `P` | Cancela trajetórias de piloto automático. |
| **Alternar Rampa de Carga** | `O` | Abre ou fecha a rampa traseira/lateral da nave. |

### B. Modo a Pé (Exploração e Combate Terrestre)
| Ação | Teclado / Mouse | Descrição |
| :--- | :--- | :--- |
| **Movimentação** | `W`, `A`, `S`, `D` | Caminhada e corrida com cinemática biomecânica realista e passos orgânicos. |
| **Correr (*Sprint*)** | `Shift` (segurar) | Corrida rápida atlética com inclinação do tronco para frente. |
| **Pular / Jetpack** | `Espaço` | Toque rápido pula; segurar no ar ativa os propulsores de plasma do jetpack. |
| **Interagir** | `E` | Opera portas internas, deita em camas, senta em bancos, abre armários e fala com NPCs. |
| **Levantar de Camas/Bancos** | `F` ou `Espaço` | Retorna o personagem à posição de pé. |
| **Ferramenta de Campo / Scanner** | `F` | Faz varredura geológica de minérios ou catalogação de fauna a até 65 m. |
| **Atacar / Disparar** | `Clique Esquerdo` | Desfere corte corpo a corpo fluido ou dispara a arma selecionada. |
| **Mirar Arma** | `Clique Direito` (segurar) | Postura tática de combate com cotovelos dobrados (apenas armas de fogo). |
| **Recarregar Arma** | `R` | Sequência tática de ejeção, inserção e trava do ferrolho com física de câmera. |
| **Usar Kit Médico** | `C` | Restaura 55 pontos de integridade física. |
| **Selecionar Armas** | Teclas `1` a `7` | 1: Pistola · 2: Faca · 3: Fuzil · 4: Escopeta · 5: Sabre · 6: Granadas · 7: Scanner. |
| **Alternar 1ª e 3ª Pessoa** | `V` | Alterna instantaneamente a visão da câmera. |

### C. Controles de Câmera e Zoom
* **Zoom Suave e Alternância Automática:**
  * **Em 1ª pessoa:** Rolar o mouse para trás (afastando o zoom) transita de forma fluida para a **3ª pessoa**.
  * **Em 3ª pessoa:** Rolar o mouse para a frente (aproximando) até o limite mínimo transita de volta para a **1ª pessoa**.
* **Movimentação Procedural de Câmera em 1ª Pessoa:**
  * Oscilação orgânica (*head bob*) nos passos ao andar e correr.
  * Amortecimento elástico de compressão ao pousar no chão após um salto ou queda.
  * Tremor sutil contínuo ao ligar o jetpack.
  * Reação física da visão durante as etapas de recarga e avanço cinético em golpes corpo a corpo.

---

## 3. Frota e Especificações das Naves

| Nave | Modelo | Cor Padrão | Velocidade | Capacidade | Características |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **ATLAS** | Cargueiro Pesado | Azul Naval (`#1e5282`) | 190 m/s | 18 Caixas | Asa integrada, rampa traseira ampla, ponte, dormitório e garagem. |
| **KESTREL**| Exploradora Ágil | Azul Cobalto (`#225d94`)| 280 m/s | 8 Caixas | Asa voadora furtiva, velocidade supersônica, entrada lateral. |
| **MOLE** | Mineradora Industrial| Azul Aço (`#1d4a75`) | 155 m/s | 26 Caixas | Casco duplo blindado, oficina interna, doca reforçada para rover. |

*Todas as naves contam com acabamentos exteriores elegantes em preto carbono nos motores, bordas e sapatas de pouso, mantendo os cômodos internos limpos e desobstruídos.*

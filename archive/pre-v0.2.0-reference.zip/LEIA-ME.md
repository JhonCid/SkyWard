# SkyWard v0.1.41 — Atlas v3

Abra **SkyWard.html** ou **SkyWard-v0.1.41.html** em um navegador de computador com WebGL. A nave está incorporada ao HTML; o arquivo não precisa de servidor ou de acesso à internet para carregar o modelo.

## Controles

- **WASD**: caminhar ou dirigir. **Mouse**: olhar.
- **E** perto de um painel: abrir/fechar a porta ou rampa. Perto da cadeira: pilotar. Perto do rover: entrar.
- **O**: acionar a rampa; também há os botões amarelos do modelo e o comando no cockpit.
- **R** ou **B** enquanto pilota/dirige: levantar/sair do assento.
- **T**: retornar ao cockpit. **F**, pilotando: pousar. **L**: faróis. **V**: câmera.

O rover começa sobre a rampa. Ele acompanha a inclinação durante o fechamento. Afaste o jogador da rampa antes de fechar; o bloqueio de ocupação evita fechar sobre o personagem. Para desembarcar com o rover, abra totalmente a rampa e dirija até a extremidade. Para embarcar, alinhe-o com a rampa e suba.

## Projeto

- `assets/Atlas_v3.glb`: modelo fornecido, preservado.
- `src/modules/16a_atlas_asset.js`: geometria incorporada com transformações aplicadas.
- `src/modules/16b_atlas_integration.js`: rampa, pistões, portas, cockpit e colisões.
- `python build.py`: gera os dois HTMLs a partir dos módulos.
- `python import_atlas.py`: reconverte o GLB (requer NumPy e SciPy); dispensável para compilar as alterações de lógica.
- `node tests/run_all_tests.js`: executa as 18 verificações atuais.

## Validação

As 18 verificações atuais passaram: portas, apoio na rampa, acesso ao cockpit, retração dos pistões, ausência de interseções amostradas em 61 posições da rampa, folga do rover, trens de pouso, carregamento do mundo, condução para fora/para dentro e transporte do rover junto da nave.

A suíte histórica `legacy_v0.1.40_tests.js` foi preservada para referência. Ela usa posições, dimensões, quatro trens de pouso e elementos procedurais da nave anterior, portanto não é uma verificação de aprovação para a Atlas v3. Executada durante a adaptação, registrou 381 aprovações e 69 falhas, incluindo expectativas da versão e da geometria anteriores.

Os testes atuais simulam o jogo com o renderizador substituído. A inspeção geométrica foi feita separadamente; não foi possível executar uma sessão WebGL em navegador neste ambiente. Desempenho gráfico e aparência final devem ser conferidos ao abrir o HTML.

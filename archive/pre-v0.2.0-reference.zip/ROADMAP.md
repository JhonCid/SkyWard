# SkyWard — Roadmap de Desenvolvimento

## Milestone 1: Fundação Espacial e Voo (v0.0.1 a v0.0.6 — Concluído)
- [x] Universo contínuo sem telas de carregamento entre sistemas estelares e planetas.
- [x] Simulação de atmosfera, arrasto, reentrada aerodinâmica e gravidade esférica.
- [x] Rede de arcos hiperespaciais para trânsito interestelar com feixes 3D.
- [x] Três modelos de nave com interiores habitáveis detalhados.

## Milestone 2: Exploração Terrestre e Biomecânica (v0.0.7 a v0.0.10 — Concluído)
- [x] Locomoção humana com cinemática nas pernas e amortecimento de joelhos.
- [x] Câmera em primeira/terceira pessoa conectada fluidamente pelo zoom.
- [x] Postura de armas em terceira pessoa com guarda fechada e cotovelo flexionado.
- [x] Mares globais, natação, embarcações aquáticas e opções gráficas avançadas.

## Milestone 3: Sistemas da Nave e Pouso de Precisão (v0.0.11 — Concluído)
- [x] Trens de pouso articulados e retráteis automáticos com suspensão mecânica.
- [x] Sequência cinemática de pouso com desvio inteligente de obstáculos.
- [x] Inclinação visual suave com retorno automático (Espaço, Ctrl, A, D, mouse).
- [x] Arquitetura modular desacoplada com pipeline de compilação em 100 ms.

## Milestone 4: Economia, Mineração e Comércio (v0.1.0 — Marco Atual Concluído)
- [x] Bolsa de 8 commodities comerciais com flutuação regional por planeta e estações.
- [x] Carga física paletizada renderizada tridimensionalmente no porão das naves.
- [x] Mineração contínua com feixe de laser térmico e fratura sísmica de depósitos.
- [x] Terminal de refino industrial para fundição de minério bruto em ligas metálicas.
- [x] Facções galácticas (CMI, GCU, SNYX) e reputação dinâmica progressiva.
- [x] Ciclo solar dia/noite em tempo real e sistema de faróis de alta potência (Tecla L).

## Milestone 5: Atmosfera Volumétrica, Esquadrões e Combate Avançado (Próximos Passos)
- [ ] IA de combate com formação em esquadrão para naves inimigas.
- [ ] Módulos de armas e escudos customizáveis em docas de estaleiro.
- [ ] Shaders volumétricos de névoa e nuvens densas nos vales planetários.

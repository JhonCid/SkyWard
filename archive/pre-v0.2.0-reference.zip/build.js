#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

function build() {
  const startTime = Date.now();
  const baseDir = __dirname;
  const srcDir = path.join(baseDir, 'src');
  const shellDir = path.join(srcDir, 'shell');
  const modulesDir = path.join(srcDir, 'modules');
  const manifestPath = path.join(srcDir, 'modules_manifest.json');
  const outHtml = path.join(baseDir, 'SkyWard.html');

  const head = fs.readFileSync(path.join(shellDir, 'head.html'), 'utf8');
  const three = fs.readFileSync(path.join(shellDir, 'three.min.js'), 'utf8');
  const tail = fs.readFileSync(path.join(shellDir, 'tail.html'), 'utf8');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

  const chunks = manifest.map(fn => fs.readFileSync(path.join(modulesDir, fn), 'utf8'));
  const gameCode = chunks.join('');

  const finalHtml = head + '<script>' + three + '</script>\n<script>' + gameCode + '</script>' + tail;
  fs.writeFileSync(outHtml, finalHtml, 'utf8');

  const elapsed = Date.now() - startTime;
  const sizeKb = (Buffer.byteLength(finalHtml, 'utf8') / 1024).toFixed(1);
  console.log(`✓ SkyWard compiled successfully in ${elapsed}ms! Size: ${sizeKb} KB -> ${outHtml}`);
}

build();

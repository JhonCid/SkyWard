#!/usr/bin/env python3
import os, time, json

def build():
    start_time = time.time()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.join(base_dir, 'src')
    shell_dir = os.path.join(src_dir, 'shell')
    modules_dir = os.path.join(src_dir, 'modules')
    manifest_path = os.path.join(src_dir, 'modules_manifest.json')
    out_html = os.path.join(base_dir, 'SkyWard.html')

    with open(os.path.join(shell_dir, 'head.html'), 'r', encoding='utf-8') as f:
        head = f.read()
    with open(os.path.join(shell_dir, 'three.min.js'), 'r', encoding='utf-8') as f:
        three = f.read()
    with open(os.path.join(shell_dir, 'tail.html'), 'r', encoding='utf-8') as f:
        tail = f.read()
    with open(manifest_path, 'r', encoding='utf-8') as f:
        manifest = json.load(f)

    chunks = []
    for fn in manifest:
        file_path = os.path.join(modules_dir, fn)
        with open(file_path, 'r', encoding='utf-8') as f:
            chunks.append(f.read())

    game_code = "".join(chunks)

    # Assemble standalone HTML
    final_html = head + '<script>' + three + '</script>\n<script>' + game_code + '</script>' + tail

    with open(out_html, 'w', encoding='utf-8') as f:
        f.write(final_html)

    # Also export version-tagged HTML deliverable
    import re
    ver_match = re.search(r"const VERSION='([^']+)'", game_code)
    version = ver_match.group(1) if ver_match else '0.1.29'
    versioned_html = os.path.join(base_dir, f'SkyWard-v{version}.html')
    with open(versioned_html, 'w', encoding='utf-8') as f:
        f.write(final_html)

    elapsed = (time.time() - start_time) * 1000
    size_kb = len(final_html) / 1024
    print(f"✓ SkyWard compiled successfully in {elapsed:.1f}ms! Size: {size_kb:.1f} KB -> {out_html} and {versioned_html}")

if __name__ == '__main__':
    build()

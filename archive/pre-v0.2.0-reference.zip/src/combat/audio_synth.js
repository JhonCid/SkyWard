function playWeaponSound(id) {
  if (!audioContext) return;
  const t = audioContext.currentTime;

  if (id === 'pistol') {
    // Sharp supersonic crack + low chamber punch + slide cycle
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(260, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.08);
    g.gain.setValueAtTime(0.40, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.10);

    tone(720, t, 0.025, 0.28, fxBus, 'square'); // high snap
    tone(180, t + 0.04, 0.05, 0.14, fxBus, 'triangle'); // mechanical slide click

  } else if (id === 'rifle') {
    // Heavy military bullpup rifle crack
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(310, t);
    osc.frequency.exponentialRampToValueAtTime(50, t + 0.10);
    g.gain.setValueAtTime(0.42, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.12);

    tone(850, t, 0.02, 0.30, fxBus, 'square'); // supersonic snap
    tone(140, t + 0.045, 0.06, 0.18, fxBus, 'sawtooth'); // bolt cycle

  } else if (id === 'shotgun') {
    // Thunderous plasma scattergun blast + pump rack
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(26, t + 0.22);
    g.gain.setValueAtTime(0.75, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.25);

    tone(460, t, 0.05, 0.38, fxBus, 'square');
    tone(200, t + 0.02, 0.10, 0.32, fxBus, 'sawtooth');

    // Mechanical pump action rack "CLACK-CHUCK" 0.35s later
    tone(240, t + 0.34, 0.05, 0.18, fxBus, 'square');
    tone(150, t + 0.40, 0.07, 0.20, fxBus, 'sawtooth');

  } else if (id === 'blade') {
    tone(480, t, 0.09, 0.18, fxBus, 'sawtooth');
    tone(240, t + 0.02, 0.08, 0.14, fxBus, 'triangle');

  } else if (id === 'sabre') {
    tone(110, t, 0.16, 0.26, fxBus, 'sawtooth');
    tone(360, t + 0.02, 0.12, 0.20, fxBus, 'sine');
    tone(580, t + 0.04, 0.08, 0.18, fxBus, 'triangle');

  } else if (id === 'tool') {
    tone(160, t, 0.18, 0.18, fxBus, 'sawtooth');
    tone(320, t + 0.05, 0.12, 0.14, fxBus, 'triangle');

  } else {
    tone(110, t, 0.10, 0.15, fxBus, 'square');
  }
}
window.playWeaponSound = playWeaponSound;

let reloadActive = false, reloadDuration = 1.6, reloadStartTime = 0;
let meleeActive = false, meleeDuration = 0.38, meleeStartTime = 0, meleeCombo = 0;


'use strict';
const performancePrefs={resolution:1,distance:1,planetDetail:3,characterDistance:1,shadows:true,clouds:true,rain:true};
let performanceReady=false;
function applyPerformance(){renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='low'?1:quality==='medium'?1.3:1.8)*performancePrefs.resolution);renderer.shadowMap.enabled=performancePrefs.shadows;renderer.shadowMap.needsUpdate=true;lodTimer=0;if(performanceReady){updateLOD(0,true);updateCityBatches(true);}for(const p of planets)if(p.cloud)p.cloud.visible=performancePrefs.clouds&&p.globe.visible;if(rainLines&&!performancePrefs.rain)rainLines.visible=false;}
function setPerformance(key,value){if(['shadows','clouds','rain'].includes(key))performancePrefs[key]=!!value;else if(['resolution','distance','planetDetail','characterDistance'].includes(key)){const n=Number(value);if(!Number.isFinite(n))return;performancePrefs[key]=key==='planetDetail'?Math.round(THREE.MathUtils.clamp(n,1,3)):THREE.MathUtils.clamp(n,key==='resolution'?.5:.35,1);}else if(key==='particles')particlesEnabled=!!value;else return;applyPerformance();if(performanceReady)save();}
function applyQuality(value){if(!['low','medium','high','economy'].includes(value))return;quality=value==='economy'?'low':value;Object.assign(performancePrefs,value==='economy'?{resolution:.6,distance:.4,planetDetail:1,characterDistance:.4,shadows:false,clouds:false,rain:false}:value==='low'?{resolution:1,distance:.7,planetDetail:2,characterDistance:.65,shadows:false,clouds:true,rain:true}:value==='medium'?{resolution:1,distance:.85,planetDetail:2,characterDistance:.85,shadows:false,clouds:true,rain:true}:{resolution:1,distance:1,planetDetail:3,characterDistance:1,shadows:true,clouds:true,rain:true});particlesEnabled=value!=='economy';applyPerformance();$('qualityLabel').textContent=value==='economy'?'Econômico':{low:'Leve',medium:'Equilibrado',high:'Detalhado'}[quality];if(performanceReady)save();}
function loadPerformance(){try{const saved=JSON.parse(localStorage.getItem('horizonte-v1'))?.skyward?.performance;if(saved){if(['low','medium','high'].includes(saved.quality))quality=saved.quality;for(const key of Object.keys(performancePrefs))if(typeof saved[key]===typeof performancePrefs[key])setPerformance(key,saved[key]);if(typeof saved.particles==='boolean')particlesEnabled=saved.particles;}}catch{}performanceReady=true;applyPerformance();}
function performanceSettings(){const select=(key,label,values)=>`<label>${label}<select aria-label="${label}" onchange="setPerformance('${key}',this.value)">${values.map(([value,name])=>`<option value="${value}" ${performancePrefs[key]===value?'selected':''}>${name}</option>`).join('')}</select></label>`;const check=(key,label)=>`<label><input type="checkbox" ${performancePrefs[key]?'checked':''} onchange="setPerformance('${key}',this.checked)">${label}</label>`;return `<section><h3>Desempenho avançado</h3><button onclick="applyQuality('economy');renderPanel('settings')">Aplicar modo econômico</button>${select('resolution','Resolução de renderização',[[.5,'50%'],[.6,'60%'],[.75,'75%'],[1,'100%']])}${select('distance','Distância dos detalhes',[[.4,'Curta'],[.7,'Média'],[.85,'Longa'],[1,'Completa']])}${select('planetDetail','Detalhe de planetas distantes',[[1,'Baixo'],[2,'Médio'],[3,'Alto']])}${select('characterDistance','Detalhe de personagens',[[.4,'Próximos'],[.65,'Médio'],[.85,'Alto'],[1,'Completo']])}${check('shadows','Sombras dinâmicas')}${check('clouds','Nuvens')}${check('rain','Efeito visual de chuva/neve')}<p>Resolução menor deixa a imagem menos nítida. Distâncias menores simplificam detalhes mais cedo. O modo econômico também desliga partículas. Os ajustes ficam salvos e entram em vigor imediatamente.</p></section>`;}
function leaveSeatGesture(){if(mode==='pilot'){mode='foot';inside=true;resetFootMotion();foot.copy(layout().seat).add(V(0,.08,1.8));yaw=pitch=0;}else if(mode==='rover'){mode='foot';inside=rover.parent===ship;eva=!inside&&roverAir;if(inside){foot.copy(layout().spawn);eva=false;}else{player.copy(safeExit(rover.getWorldPosition(V()),rover,station?null:groundPlanet));if(eva){evaFrame.copy(rover.quaternion);evaVelocity.copy(roverVelocity);}}resetFootMotion();}else if(resting){standUp();}else return;autoForward=false;touchX=touchY=touchRoll=touchLift=0;steerPixels.set(0,0,0);haptic();}
function pinchDown(){if(touches.size!==2)return;const pair=[...touches.values()];if(pair[0].side!==pair[1].side)return;const side=pair[0].side;pinchGesture={ids:pair.map(t=>t.id),kind:side==='right'?'zoom':'seat',distance:Math.hypot(pair[0].lastX-pair[1].lastX,pair[0].lastY-pair[1].lastY),active:false,blocked:false,context:gestureContext()};for(const t of pair){t.pinched=true;t.moved=true;}pendingTaps.left=pendingTaps.right=null;aiming=false;aimOwner=null;if(jumpOwner!==null)keys.Space=false;jumpOwner=null;mobileJumpHeld=mobileJumpBoost=false;if(side==='left')touchX=touchY=0;else touchRoll=touchLift=0;}
function pinchMove(e){if(!pinchGesture)return false;const g=pinchGesture,pair=g.ids.map(id=>touches.get(id)),moving=touches.get(e.pointerId);if(pair.some(t=>!t)||!moving)return false;moving.lastX=e.clientX;moving.lastY=e.clientY;const correctHalf=t=>g.kind==='zoom'?t.lastX>=innerWidth/2:t.lastX<innerWidth/2;if(!pair.every(correctHalf)||g.context!==gestureContext())g.blocked=true;if(g.blocked)return true;if(g.kind==='seat'){const movement=pair.map(t=>({up:t.y-t.lastY,side:Math.abs(t.lastX-t.x)}));if(!g.active&&movement.every(d=>d.up>=48&&d.side<d.up*.7)){g.active=true;leaveSeatGesture();}return true;}
const distance=Math.hypot(pair[0].lastX-pair[1].lastX,pair[0].lastY-pair[1].lastY);if(!g.active&&Math.abs(distance-g.distance)>12)g.active=true;if(g.active){zoomCamera(g.distance/Math.max(20,distance));g.distance=distance;}return true;}

// SkyWard 0.9: persistent controls and independent camera zoom per vehicle.
const controlPrefs={camera:1.65,ship:1.6};
const cameraZoom={foot:1,rover:1,pilot:1};
window.resetCameraZoom = function() {
  cameraZoom.foot = 1;
  cameraZoom.rover = 1;
  cameraZoom.pilot = 1;
  camera.fov = 70;
  camera.updateProjectionMatrix();
  toast('Zoom da câmera redefinido.');
};

let pinchGesture=null;
function setSensitivity(kind,value){if(!(kind in controlPrefs))return;const n=Number(value);if(!Number.isFinite(n))return;controlPrefs[kind]=THREE.MathUtils.clamp(n,.25,4);save();}
function loadControls(){try{const data=JSON.parse(localStorage.getItem('horizonte-v1'))?.skyward?.controls;for(const k of ['camera','ship'])if(Number.isFinite(data?.[k]))controlPrefs[k]=THREE.MathUtils.clamp(data[k],.25,4);}catch{}}
function toggleShipLook(){if(mode!=='pilot'||!started||!$('panel').classList.contains('hidden'))return;shipLookOnly=!shipLookOnly;steerPixels.set(0,0,0);angularVelocity.x=angularVelocity.y=0;}
function zoomCamera(factor){
  if(!started||!$('panel').classList.contains('hidden')||!Number.isFinite(factor))return;
  if(!thirdPerson){
    // In First Person: scrolling back (factor > 1.04) seamlessly transitions to Third Person!
    if(factor > 1.04){
      thirdPerson = true;
      cameraZoom[mode] = 0.55;
      toast('Câmera em terceira pessoa.');
      return;
    }
  } else {
    // In Third Person: scrolling in towards minimum distance seamlessly transitions to First Person!
    const newZoom = cameraZoom[mode] * factor;
    if(newZoom <= 0.48 && factor < 0.98){
      thirdPerson = false;
      cameraZoom[mode] = 0.55;
      toast('Câmera em primeira pessoa.');
      return;
    }
    cameraZoom[mode] = THREE.MathUtils.clamp(newZoom, 0.48, 3.2);
  }
}
window.zoomCamera = zoomCamera;

'use strict';
const performancePrefs={resolution:1,distance:1,planetDetail:3,characterDistance:1,shadows:true,clouds:true,rain:true};
let performanceReady=false;
function applyPerformance(){renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='low'?1:quality==='medium'?1.3:1.8)*performancePrefs.resolution);renderer.shadowMap.enabled=performancePrefs.shadows;renderer.shadowMap.needsUpdate=true;lodTimer=0;if(performanceReady){updateLOD(0,true);updateCityBatches(true);}for(const p of planets)if(p.cloud)p.cloud.visible=performancePrefs.clouds&&p.globe.visible;if(rainLines&&!performancePrefs.rain)rainLines.visible=false;}
function setPerformance(key,value){if(['shadows','clouds','rain'].includes(key))performancePrefs[key]=!!value;else if(['resolution','distance','planetDetail','characterDistance'].includes(key)){const n=Number(value);if(!Number.isFinite(n))return;performancePrefs[key]=key==='planetDetail'?Math.round(THREE.MathUtils.clamp(n,1,3)):THREE.MathUtils.clamp(n,key==='resolution'?.5:.35,1);}else if(key==='particles')particlesEnabled=!!value;else return;applyPerformance();if(performanceReady)save();}
function applyQuality(value){if(!['low','medium','high','economy'].includes(value))return;quality=value==='economy'?'low':value;Object.assign(performancePrefs,value==='economy'?{resolution:.6,distance:.4,planetDetail:1,characterDistance:.4,shadows:false,clouds:false,rain:false}:value==='low'?{resolution:1,distance:.7,planetDetail:2,characterDistance:.65,shadows:false,clouds:true,rain:true}:value==='medium'?{resolution:1,distance:.85,planetDetail:2,characterDistance:.85,shadows:false,clouds:true,rain:true}:{resolution:1,distance:1,planetDetail:3,characterDistance:1,shadows:true,clouds:true,rain:true});particlesEnabled=value!=='economy';applyPerformance();$('qualityLabel').textContent=value==='economy'?'Econômico':{low:'Leve',medium:'Equilibrado',high:'Detalhado'}[quality];if(performanceReady)save();}
function loadPerformance(){try{const saved=JSON.parse(localStorage.getItem('horizonte-v1'))?.skyward?.performance;if(saved){if(['low','medium','high'].includes(saved.quality))quality=saved.quality;for(const key of Object.keys(performancePrefs))if(typeof saved[key]===typeof performancePrefs[key])setPerformance(key,saved[key]);if(typeof saved.particles==='boolean')particlesEnabled=saved.particles;}}catch{}performanceReady=true;applyPerformance();}
function performanceSettings(){const select=(key,label,values)=>`<label>${label}<select aria-label="${label}" onchange="setPerformance('${key}',this.value)">${values.map(([value,name])=>`<option value="${value}" ${performancePrefs[key]===value?'selected':''}>${name}</option>`).join('')}</select></label>`;const check=(key,label)=>`<label><input type="checkbox" ${performancePrefs[key]?'checked':''} onchange="setPerformance('${key}',this.checked)">${label}</label>`;return `<section><h3>Desempenho avançado</h3><button onclick="applyQuality('economy');renderPanel('settings')">Aplicar modo econômico</button>${select('resolution','Resolução de renderização',[[.5,'50%'],[.6,'60%'],[.75,'75%'],[1,'100%']])}${select('distance','Distância dos detalhes',[[.4,'Curta'],[.7,'Média'],[.85,'Longa'],[1,'Completa']])}${select('planetDetail','Detalhe de planetas distantes',[[1,'Baixo'],[2,'Médio'],[3,'Alto']])}${select('characterDistance','Detalhe de personagens',[[.4,'Próximos'],[.65,'Médio'],[.85,'Alto'],[1,'Completo']])}${check('shadows','Sombras dinâmicas')}${check('clouds','Nuvens')}${check('rain','Efeito visual de chuva/neve')}<p>Resolução menor deixa a imagem menos nítida. Distâncias menores simplificam detalhes mais cedo. O modo econômico também desliga partículas. Os ajustes ficam salvos e entram em vigor imediatamente.</p></section>`;}
function leaveSeatGesture(){if(mode==='pilot'){mode='foot';inside=true;resetFootMotion();foot.copy(layout().seat).add(V(0,.08,1.8));yaw=pitch=0;}else if(mode==='rover'){mode='foot';inside=rover.parent===ship;eva=!inside&&roverAir;if(inside){foot.copy(layout().spawn);eva=false;}else{player.copy(safeExit(rover.getWorldPosition(V()),rover,station?null:groundPlanet));if(eva){evaFrame.copy(rover.quaternion);evaVelocity.copy(roverVelocity);}}resetFootMotion();}else if(resting){standUp();}else return;autoForward=false;touchX=touchY=touchRoll=touchLift=0;steerPixels.set(0,0,0);haptic();}
function pinchDown(){if(touches.size!==2)return;const pair=[...touches.values()];if(pair[0].side!==pair[1].side)return;const side=pair[0].side;pinchGesture={ids:pair.map(t=>t.id),kind:side==='right'?'zoom':'seat',distance:Math.hypot(pair[0].lastX-pair[1].lastX,pair[0].lastY-pair[1].lastY),active:false,blocked:false,context:gestureContext()};for(const t of pair){t.pinched=true;t.moved=true;}pendingTaps.left=pendingTaps.right=null;aiming=false;aimOwner=null;if(jumpOwner!==null)keys.Space=false;jumpOwner=null;mobileJumpHeld=mobileJumpBoost=false;if(side==='left')touchX=touchY=0;else touchRoll=touchLift=0;}
function pinchMove(e){if(!pinchGesture)return false;const g=pinchGesture,pair=g.ids.map(id=>touches.get(id)),moving=touches.get(e.pointerId);if(pair.some(t=>!t)||!moving)return false;moving.lastX=e.clientX;moving.lastY=e.clientY;const correctHalf=t=>g.kind==='zoom'?t.lastX>=innerWidth/2:t.lastX<innerWidth/2;if(!pair.every(correctHalf)||g.context!==gestureContext())g.blocked=true;if(g.blocked)return true;if(g.kind==='seat'){const movement=pair.map(t=>({up:t.y-t.lastY,side:Math.abs(t.lastX-t.x)}));if(!g.active&&movement.every(d=>d.up>=48&&d.side<d.up*.7)){g.active=true;leaveSeatGesture();}return true;}
const distance=Math.hypot(pair[0].lastX-pair[1].lastX,pair[0].lastY-pair[1].lastY);if(!g.active&&Math.abs(distance-g.distance)>12)g.active=true;if(g.active){zoomCamera(g.distance/Math.max(20,distance));g.distance=distance;}return true;}

// SkyWard 0.9: persistent controls and independent camera zoom per vehicle.
const controlPrefs={camera:1.65,ship:1.6};
const cameraZoom={foot:1,rover:1,pilot:1};
window.resetCameraZoom = function() {
  cameraZoom.foot = 1;
  cameraZoom.rover = 1;
  cameraZoom.pilot = 1;
  camera.fov = 70;
  camera.updateProjectionMatrix();
  toast('Zoom da câmera redefinido.');
};

let pinchGesture=null;
function setSensitivity(kind,value){if(!(kind in controlPrefs))return;const n=Number(value);if(!Number.isFinite(n))return;controlPrefs[kind]=THREE.MathUtils.clamp(n,.25,4);save();}
function loadControls(){try{const data=JSON.parse(localStorage.getItem('horizonte-v1'))?.skyward?.controls;for(const k of ['camera','ship'])if(Number.isFinite(data?.[k]))controlPrefs[k]=THREE.MathUtils.clamp(data[k],.25,4);}catch{}}
function toggleShipLook(){if(mode!=='pilot'||!started||!$('panel').classList.contains('hidden'))return;shipLookOnly=!shipLookOnly;steerPixels.set(0,0,0);angularVelocity.x=angularVelocity.y=0;}
function zoomCamera(factor){
  if(!started||!$('panel').classList.contains('hidden')||!Number.isFinite(factor))return;
  if(!thirdPerson){
    // In First Person: scrolling back (factor > 1.04) seamlessly transitions to Third Person!
    if(factor > 1.04){
      thirdPerson = true;
      cameraZoom[mode] = 0.55;
      toast('Câmera em terceira pessoa.');
      return;
    }
  } else {
    // In Third Person: scrolling in towards minimum distance seamlessly transitions to First Person!
    const newZoom = cameraZoom[mode] * factor;
    if(newZoom <= 0.48 && factor < 0.98){
      thirdPerson = false;
      cameraZoom[mode] = 0.55;
      toast('Câmera em primeira pessoa.');
      return;
    }
    cameraZoom[mode] = THREE.MathUtils.clamp(newZoom, 0.48, 3.2);
  }
}
window.zoomCamera = zoomCamera;
function terrainCameraClearance(point){const p=nearest(point),n=planetUp(point,p),r=point.distanceTo(p.center),surface=Math.max(radius(p,n),wetPlanet(p)?seaRadius(p):-Infinity)+1.2;if(r<surface)point.copy(p.center).addScaledVector(n,surface);return point;}
function shipCameraOutside(point){const local=localPoint(point),bounds=new THREE.Box3(V(-26,-4,-29),V(26,13,23));if(bounds.containsPoint(local)){const direction=local.sub(V(0,2,0));if(direction.lengthSq()<.01)direction.set(0,1,1);direction.normalize();const origin=V(0,2,0);let exit=Infinity;for(const k of ['x','y','z'])if(Math.abs(direction[k])>1e-6)exit=Math.min(exit,((direction[k]>0?bounds.max[k]:bounds.min[k])-origin[k])/direction[k]);point.copy(shipPoint(origin.addScaledVector(direction,exit+1)));}return point;}
function safeChaseCamera(focus,offset,ignore,aboard){const wanted=focus.clone().add(offset);const dist=obstacleDistance(focus,wanted,ignore);let point=Number.isFinite(dist)?focus.clone().addScaledVector(offset.clone().normalize(),Math.max(.4,dist-.6)):wanted;
if(aboard){shipCameraOutside(point);terrainCameraClearance(point);shipCameraOutside(point);
// If a wall blocks the short follow position, lift above the ship instead of
// shortening the ray through its hull. Keep the planet-facing side clear.
if(Number.isFinite(dist)&&focus.distanceTo(point)>dist){point=shipPoint(V(0,Math.max(25,offset.length()*.55),8));terrainCameraClearance(point);shipCameraOutside(point);}}
else if(!inside&&!station)terrainCameraClearance(point);return point;}
function landingProbes(){const l=layout(),points=[];for(const x of [-l.halfX+1,l.halfX-1])for(const z of [-l.halfZ+3,l.halfZ-3])points.push(V(x,-1.73,z));const wings=shipType===0?[[24,6.75],[17,-1],[7,15]]:shipType===1?[[21.5,-4.95],[8.5,0],[5.5,11]]:[[20,0],[10,-10],[10,10]];for(const [x,z]of wings)for(const side of [-1,1])points.push(V(side*x,-.25,z));points.push(V(0,-.25,shipType===2?-17:-25));return points;}
function landingPose(pos,p){if(!p)return {pos:pos.clone().add(V(0,1.9,0)),q:new THREE.Quaternion()};const radial=planetUp(pos,p),base=frameAt(pos,p.center),center=p.center.clone().addScaledVector(radial,Math.max(radius(p,radial),wetPlanet(p)?seaRadius(p):-Infinity));const sample=(x,z)=>{const n=planetUp(center.clone().add(V(x,0,z).applyQuaternion(base)),p);return p.center.clone().addScaledVector(n,Math.max(radius(p,n),wetPlanet(p)?seaRadius(p):-Infinity));};const right=sample(9,0).sub(sample(-9,0)).normalize(),back=sample(0,9).sub(sample(0,-9)).normalize(),normal=back.clone().cross(right).normalize();if(normal.dot(radial)<0)normal.negate();const q=new THREE.Quaternion().setFromUnitVectors(radial,normal).multiply(base);const result=center.clone().addScaledVector(radial,2);
for(let iteration=0;iteration<3;iteration++){let correction=0;for(const probe of landingProbes()){const world=probe.clone().applyQuaternion(q).add(result),n=planetUp(world,p),floor=Math.max(radius(p,n),wetPlanet(p)?seaRadius(p):-Infinity);correction=Math.max(correction,floor+.13-world.distanceTo(p.center));}result.addScaledVector(radial,correction+.005);}return{pos:result,q};}
// === ARTICULATED LANDING GEARS & PROCEDURAL SHIP TILT ===
const landingGears = [];
let shipGearProgress = 1.0; // 1.0 = deployed (on ground), 0.0 = retracted (in flight)
let shipGearSuspension = 0.0; // Touchdown compression bounce
let shipTiltPitch = 0, shipTiltRoll = 0, shipTiltYaw = 0;
const shipNavQuaternion = new THREE.Quaternion();
let landingSequence = null;
window.landingGears = landingGears;
window.getShipGearProgress = () => shipGearProgress;
window.getShipTilt = () => ({ pitch: shipTiltPitch, roll: shipTiltRoll, yaw: shipTiltYaw });
window.getLandingSequence = () => landingSequence;

function finishLanding(pose,p,st){ship.position.copy(pose.pos);ship.quaternion.copy(pose.q);shipNavQuaternion.copy(pose.q);shipTiltPitch=shipTiltRoll=shipTiltYaw=0;landed=true;landingSequence=null;auto=null;flightSpeed=0;shipVelocity.set(0,0,0);manualVelocity.set(0,0,0);angularVelocity.set(0,0,0);thrustAcceleration=sideSpeed=liftSpeed=0;manualWasActive=false;if(inside||mode==='pilot'){groundPlanet=p||null;station=st||null;}openRamp(true,false);}
function startLandingSequence(targetPose, p, st) {
  landingSequence = {
    active: true,
    targetPose,
    p,
    st,
    startPos: ship.position.clone(),
    startQ: ship.quaternion.clone(),
    elapsed: 0,
    duration: 3.0
  };
  auto = null;
  flightSpeed = 0;
  thrustAcceleration = 0;
  toast('Sequência de pouso iniciada · Trens de pouso estendendo…');
}

function land() {
  if (mode !== 'pilot' || boost || (landingSequence && landingSequence.active)) return;
  const p = nearest(ship.position);
  const n = planetUp(ship.position, p);
  const h = ship.position.distanceTo(p.center) - radius(p, n);
  const st = destinations.find(d => d.station && ship.position.distanceTo(d.pos) < 150);

  if (st) {
    const targetPose = landingPose(st.pos, null);
    startLandingSequence(targetPose, null, st.station);
    return;
  }

  if (h >= 95) {
    toast('Aproxime-se a menos de 90 m da superfície para pousar [R].');
    return;
  }

  // Find clear landing site with intelligent obstacle avoidance
  let targetPose = landingPose(ship.position, p);
  let clearSiteFound = !flightObstacle(ship.position, targetPose.pos);

  if (!clearSiteFound) {
    // Spiral search for nearest unobstructed, level landing zone
    toast('Detectada estrutura/obstrução no solo. Desviando para zona livre…');
    const base = frameAt(ship.position, p.center);
    const searchRadii = [18, 32, 50, 70];
    const searchAngles = [0, Math.PI / 3, (2 * Math.PI) / 3, Math.PI, (4 * Math.PI) / 3, (5 * Math.PI) / 3];

    for (const r of searchRadii) {
      if (clearSiteFound) break;
      for (const a of searchAngles) {
        const offset = V(Math.cos(a) * r, 0, Math.sin(a) * r).applyQuaternion(base);
        const candPos = ship.position.clone().add(offset);
        const candPose = landingPose(candPos, p);
        if (!flightObstacle(ship.position, candPose.pos)) {
          targetPose = candPose;
          clearSiteFound = true;
          break;
        }
      }
    }
  }

  if (!clearSiteFound) {
    toast('Superfície muito acidentada para pouso seguro. Nivele a nave.');
    return;
  }

  startLandingSequence(targetPose, p, null);
}

const $=id=>document.getElementById(id), V=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z), UP=V(0,1,0), clock=new THREE.Clock();
const mobileDevice=(typeof navigator!=='undefined'&&(/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.maxTouchPoints>1&&innerWidth<1300)))||(typeof matchMedia==='function'&&matchMedia('(pointer: coarse)').matches);
const shops=[],enemies=[],projectiles=[],combatParticles=[];
let touchEnabled=!!mobileDevice,quality=mobileDevice?'low':'high',particlesEnabled=true,touchX=0,touchY=0,firing=false,recoil=0,lastShot=-10,reloadUntil=0,combatTime=0,lastHurt=-100,ambushAt=180,enemySerial=0,damageFlash=0,activeShop=null,threat=null,weaponView=null,ambientDust=null;
let health=100,suitShield=50,hull=320,shipShield=140,vehicleHealth=150,vehicleKind='rover',equipped='pistol';
const equipment={weapons:['pistol','rifle','shotgun','blade','sabre'],ships:[0],vehicles:['rover'],ammo:140,grenades:3,medkits:3};
const magazines={pistol:15,rifle:30,shotgun:8};
const weaponDefs={
  pistol:{name:'Pistola Apex-9',damage:28,rate:.26,range:180,mag:15,recoil:.85,color:0x42f5d7,soundPitch:135},
  rifle:{name:'Fuzil Tempest-X',damage:22,rate:.10,range:280,mag:30,recoil:.65,color:0x38efba,soundPitch:165},
  shotgun:{name:'Escopeta Havoc-12',damage:96,rate:.72,range:55,mag:8,recoil:1.6,color:0xff6b38,soundPitch:75,pellets:6},
  blade:{name:'Lâmina Vibro-Edge',damage:54,rate:.42,range:3.5,color:0x64e8ff,soundPitch:220},
  sabre:{name:'Sabre de Plasma Nyx',damage:88,rate:.38,range:4.2,color:0x22f5d2,soundPitch:280},
  grenade:{name:'Granada de Plasma Mk-IV',damage:140,rate:1.0,range:20,color:0xffa338},
  tool:{name:'Ruptor Multi-Tool',damage:15,rate:.5,range:18,color:0x5df5b8}
};
const storeDefs={ranged:{name:'ARMAS DE LONGO ALCANCE',short:'Arsenal',color:0x71a9c0,items:['rifle','shotgun','ammo']},melee:{name:'ARMAS CORPO A CORPO',short:'Lâminas',color:0xbaa0c4,items:['sabre']},explosives:{name:'EXPLOSIVOS',short:'Demolição',color:0xd5aa6a,items:['grenades']},ships:{name:'NAVES',short:'Estaleiro',color:0x87b5bd,items:['ship1','ship2']},vehicles:{name:'VEÍCULOS',short:'Garagem',color:0x9eb77e,items:['scout','hauler','skiff','cutter']},jobs:{name:'CENTRAL DE MISSÕES',short:'Contratos',color:0x94c9ba,items:[]},medical:{name:'CLÍNICA',short:'Clínica',color:0xc2a395,items:['medkits','heal']},supplies:{name:'SUPRIMENTOS E REPAROS',short:'Suprimentos',color:0xaab39b,items:['ammo','medkits','repair']}};
storeDefs.vehicles.items.push('skiff','cutter');
const products={skiff:['Náiade · lancha anfíbia',1100,'26 m/s na água; cabine e rodas para embarque físico.'],cutter:['Pelágico · utilitário aquático',1500,'18 m/s; cabine e rodas de embarque.'],rifle:['Fuzil Tempest-X',650,'Fuzil bullpup automático militar; carregador de 30 tiros.'],shotgun:['Escopeta Havoc-12',780,'Disparo em leque de 6 projéteis de plasma; carregador de 8 tiros.'],ammo:['72 cargas de munição',110,'Reserva compartilhada entre pistola e carabina.'],sabre:['Sabre de energia',450,'Mais alcance e dano em combate próximo.'],grenades:['3 granadas de pulso',180,'Explosão em área; mantenha distância.'],ship1:['Kestrel',3200,'Desbloqueia a nave exploradora.'],ship2:['Mole',4200,'Desbloqueia a nave mineradora.'],scout:['Veículo explorador',950,'Mais leve e rápido: 24 m/s.'],hauler:['Veículo blindado',1450,'Seis rodas, 240 de integridade e 14 m/s.'],medkits:['2 kits médicos',120,'Cada kit recupera 55 pontos de vida.'],heal:['Tratamento completo',80,'Restaura sua vida e o escudo do traje.'],repair:['Reparar nave e veículo',170,'Recupera a integridade e os escudos.']};
const storeSets=[['ranged','melee','jobs','vehicles','medical','supplies'],['explosives','ships','jobs','melee','supplies','vehicles'],['ranged','vehicles','jobs','medical','supplies','melee'],['melee','explosives','jobs','medical','supplies','ranged'],['ships','ranged','jobs','vehicles','supplies','medical'],['ships','explosives','jobs','melee','medical','supplies'],['ships','ranged','jobs','vehicles','medical','supplies'],['ships','explosives','jobs','melee','medical','supplies']];
const combatRng=(()=>{let n=174729;return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296}})();
function controlledPosition(){return mode==='pilot'?ship.position.clone():mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player.clone();}
function axisForward(){return Math.max(-1,Math.min(1,(keys.KeyW?1:0)-(keys.KeyS?1:0)+(touchEnabled&&autoForward?1:0)-touchY));}
function axisStrafe(){return Math.max(-1,Math.min(1,(keys.KeyD?1:0)-(keys.KeyA?1:0)+touchX));}
function hasAncestorFlag(o,flag){while(o){if(o.userData?.[flag])return true;o=o.parent;}return false;}

function discardChildren(g){if(!g||!g.children)return;while(g.children.length){const o=g.children[0];g.remove(o);o.traverse(x=>{if(x.isMesh){x.geometry.dispose();x.material.map?.dispose();x.material.dispose();}});}}

const VERSION='0.10',settlements=[],traffic=[],planetLODs=[],shipInteractables=[],cockpit3DButtons=[];let targetedCockpitButton=null;
const settlementProfiles=[{cities:2,villages:3},{cities:1,villages:1},{cities:0,villages:1},{cities:1,villages:2},{cities:1,villages:2},{cities:0,villages:0}];
let camBobPhase = 0, camLandDip = 0, camWasGrounded = true, camMeleeShake = 0;
let thirdPerson=false,avatar=null,resting=null,jumpVelocity=0,jetFuel=100,jumpHeld=0,jumpWasDown=false,onFootGround=true,jetActive=false,footContext='',activeLocker=null,lodTimer=0;
const outfitColors={explorer:0x78a9b5,ranger:0x879b67,engineer:0xd7a267,arctic:0xd6dfe2,night:0x5d6284};
let outfit='explorer',jetLevel=0,ownedOutfits=['explorer'];
const locker={ammo:0,grenades:0,medkits:0};
const staticGrid=new Map();let gridReady=false;
const statV05={planetTriangles:0,visibleSettlements:0,visibleTraffic:0};
function jetCapacity(){return [100,150,210][jetLevel];}
function planetUp(pos,p){if(!p||!p.center)return V(0,1,0);return pos.clone().sub(p.center).normalize();}
storeDefs.clothes={name:'ROUPAS E TRAJES',short:'Roupas',color:0xb698c7,items:['outfit_ranger','outfit_engineer','outfit_arctic','outfit_night']};
storeDefs.workshop={name:'OFICINA DE NAVES',short:'Oficina',color:0xa7c1cb,items:['repair','jet1','jet2']};
Object.assign(products,{outfit_ranger:['Traje de patrulheiro',180,'Verde, com placas de proteção.'],outfit_engineer:['Traje de engenheiro',180,'Ocre e reforços de trabalho.'],outfit_arctic:['Traje polar',220,'Branco e ombreiras isolantes.'],outfit_night:['Traje noturno',220,'Azul escuro e detalhes discretos.'],jet1:['Jetpack estágio 1',550,'Reservatório de 150 unidades e mais potência.'],jet2:['Jetpack estágio 2',950,'Reservatório de 210 unidades e impulso reforçado.']});

const touches=new Map(),pendingTaps={left:null,right:null};
let inputNow=()=>performance.now(),autoForward=false,shipLookOnly=false,aiming=false,aimOwner=null,aimBlend=0,mobileJumpHeld=false,mobileJumpBoost=false,jumpOwner=null,gestureMode='pilot',weaponPress=null,weaponItemPress=null,weaponInfoHeld=false;
let recentEquipment=['pistol','blade','tool'],cyclingEquipment=false,stripSignature='';
const steerPixels=V(),angularVelocity=V(),manualVelocity=V();
let thrustAcceleration=0,sideSpeed=0,liftSpeed=0,touchRoll=0,touchLift=0,manualWasActive=false;
const DOUBLE_MS=290,HOLD_MS=420,SECOND_HOLD_MS=170,DRAG_PX=10;
weaponDefs.tool={name:'Ferramenta de campo',damage:0,rate:.6,range:65};
function sprinting(){return !!keys.ShiftLeft||touchEnabled&&autoForward;}
function haptic(){try{navigator.vibrate?.(12);}catch{}}
function aimCapable(){return mode==='foot'&&!resting&&['pistol','rifle','shotgun','tool'].includes(equipped);}

const bodyCache=new WeakMap(),cityBatches=[];let cityBatchTime=-1;let humanSerial=0;const environment=[];let rainLines=null,disasterFX=null;
const scene=new THREE.Scene(), camera=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.12,3000000);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;document.body.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xc4e9ff,0x404051,2));const sunlight=new THREE.DirectionalLight(0xffe9cb,2.5);sunlight.position.set(6000,9000,3000);scene.add(sunlight);sunlight.castShadow=true;sunlight.shadow.mapSize.set(1024,1024);Object.assign(sunlight.shadow.camera,{left:-100,right:100,top:100,bottom:-100,near:1,far:400});sunlight.shadow.bias=-.0008;scene.add(sunlight.target);
const mat=(c,e=0)=>new THREE.MeshStandardMaterial({color:c,flatShading:true,roughness:.85,emissive:c,emissiveIntensity:e});
function mesh(g,c,parent=scene,x=0,y=0,z=0){const m=new THREE.Mesh(g,typeof c==='number'?mat(c):c);m.position.set(x,y,z);parent.add(m);return m;}
function box(parent,x,y,z,w,h,d,c){return mesh(new THREE.BoxGeometry(w,h,d),c,parent,x,y,z);}
const staticBodies=[],movingBodies=[];let collisionReady=false;
function belongsTo(obj,root){while(obj){if(obj===root)return true;obj=obj.parent;}return false;}
function makeBody(obj,bounds){if(!bounds){obj.geometry.computeBoundingBox();bounds=obj.geometry.boundingBox.clone();}return {obj,bounds,torus:obj.geometry?.type==='TorusGeometry'?obj.geometry.parameters:null,world:new THREE.Box3(),inv:new THREE.Matrix4(),scale:V(1,1,1)};}
function refreshBody(b){b.obj.updateWorldMatrix(true,false);b.inv.copy(b.obj.matrixWorld).invert();b.world.copy(b.bounds).applyMatrix4(b.obj.matrixWorld);b.obj.getWorldScale(b.scale);b.rotation=(b.rotation||b.obj.getWorldQuaternion(new THREE.Quaternion()));}

function surfacePoint(pos,p,offset=0){const n=pos.clone().sub(p.center).normalize();return p.center.clone().addScaledVector(n,radius(p,n)+offset);}
function upAt(pos){if(inside&&mode!=='pilot')return UP.clone().applyQuaternion(ship.quaternion);if(station&&pos.distanceTo(station.position)<160)return UP.clone();return pos.clone().sub(nearest(pos).center).normalize();}

function groundEye(pos,p,height=1.8){return surfacePoint(pos,p,height+.12);}
function supportEye(pos,up,p,height,bodies){const result=pos.clone(),feet=result.clone().addScaledVector(up,-height),stepUp=.35,stepDown=.30,origin=feet.clone().addScaledVector(up,stepUp);let best=null,bestHeight=-Infinity;const ray=new THREE.Raycaster(origin,up.clone().negate(),0,stepUp+stepDown);ray.layers.enable(31);const candidates=bodies.filter(b=>b.obj.isMesh&&!b.obj.userData.noSupport&&!hasAncestorFlag(b.obj,'actor')&&!hasAncestorFlag(b.obj,'dynamic')&&!b.obj.userData.removed).map(b=>b.obj);for(const hit of ray.intersectObjects(candidates,false)){const normal=hit.face.normal.clone().transformDirection(hit.object.matrixWorld);if(Math.abs(normal.dot(up))<.55)continue;const eye=hit.point.clone().addScaledVector(up,height+.04),difference=eye.clone().sub(result).dot(up);if(difference<=stepUp+.05&&difference>=-stepDown&&difference>bestHeight){best=eye;bestHeight=difference;}}if(p){const terrain=groundEye(result,p,height),difference=terrain.clone().sub(result).dot(up);if(difference<=stepUp&&difference>=-stepDown&&difference>bestHeight)best=terrain;}return best||result;}

function spherePush(center,r,b){if(b.obj.userData.surfaceOnly)return null;if(b.obj.userData.thinPanel)return thinPanelPush(center,r,b);if(b.torus){const local=center.clone().applyMatrix4(b.inv),len=Math.hypot(local.x,local.y),nearest=V(b.torus.radius*(len?local.x/len:1),b.torus.radius*(len?local.y/len:0),0),d=local.clone().sub(nearest),distance=d.length();if(distance>=b.torus.tube+r)return null;if(distance<.001)d.set(0,0,1);else d.divideScalar(distance);return d.multiplyScalar(b.torus.tube+r-distance+.002).applyQuaternion((b.rotation||b.obj.getWorldQuaternion(new THREE.Quaternion())));}const c=center.clone().applyMatrix4(b.inv),rr=V(r/Math.abs(b.scale.x),r/Math.abs(b.scale.y),r/Math.abs(b.scale.z)),closest=c.clone().clamp(b.bounds.min,b.bounds.max),d=c.clone().sub(closest);if(d.lengthSq()>0){const worldD=d.clone().multiply(b.scale),length=worldD.length();if(length>=r)return null;return worldD.normalize().multiplyScalar(r-length+.002).applyQuaternion((b.rotation||b.obj.getWorldQuaternion(new THREE.Quaternion())));}const faces=[['x',b.bounds.max.x-c.x+rr.x,1],['x',c.x-b.bounds.min.x+rr.x,-1],['y',b.bounds.max.y-c.y+rr.y,1],['y',c.y-b.bounds.min.y+rr.y,-1],['z',b.bounds.max.z-c.z+rr.z,1],['z',c.z-b.bounds.min.z+rr.z,-1]].sort((a,z)=>a[1]*Math.abs(b.scale[a[0]])-z[1]*Math.abs(b.scale[z[0]]));const f=faces[0],push=V();push[f[0]]=(f[1]+.002)*f[2]*b.scale[f[0]];return push.applyQuaternion((b.rotation||b.obj.getWorldQuaternion(new THREE.Quaternion())));}
function moveActor(eye,delta,{up=UP,p=null,height=1.8,r=.36,ignore=null,grounded=true}={}){let pos=eye.clone(),steps=Math.max(1,Math.min(800,Math.ceil(delta.length()/.22))),step=delta.clone().divideScalar(steps),bodies=nearbyBodies(eye,delta.length()+height+4,ignore);for(let j=0;j<steps;j++){pos.add(step);if(grounded)pos=supportEye(pos,up,p,height,bodies);for(let pass=0;pass<3;pass++){let changed=false;for(const b of bodies){if(b.world.distanceToPoint(pos)>height+r+1)continue;for(const h of [r,height/2,height-r]){const center=pos.clone().addScaledVector(up,h-height),push=spherePush(center,r,b);if(push){pos.add(push);changed=true;}}}if(!changed)break;}}return pos;}
function moveGround(eye,delta,p,ignore=null,height=1.8,r=.36){const up=station&&eye.distanceTo(station.position)<160?UP.clone():eye.clone().sub(p.center).normalize();return moveActor(eye,delta,{up,p:station&&eye.distanceTo(station.position)<160?null:p,ignore,height,r});}

function safeExit(around,root,p){const q=root.getWorldQuaternion(new THREE.Quaternion());for(const off of [V(3,0,0),V(-3,0,0),V(0,0,5),V(0,0,-5)]){let eye=around.clone().add(off.applyQuaternion(q));eye=placeOnGround(eye,p);const fixed=moveActor(eye,V(),{up:p?eye.clone().sub(p.center).normalize():UP,p,ignore:root});if(fixed.distanceTo(eye)<.3)return fixed;}return placeOnGround(around.clone().add(V(0,0,6)),p);}

function rng(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
// === SISTEMA PROCEDURAL INFINITO COM STREAMING POR APROXIMAÇÃO (SKYWARD 0.11) ===
let currentSystem = { x: 0, y: 0, name: 'ÉOS' };

function hash2D(x, y, seed = 0) {
  let h = (x * 374761393) ^ (y * 668265263) ^ (seed * 1274126177) ^ 0x9E3779B9;
  h = Math.imul(h ^ (h >>> 16), 2246822519);
  h = Math.imul(h ^ (h >>> 13), 3266489917);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function hasVertEdge(x, y) {
  if (x === 0 && y === 0) return true;
  if (x === 1 && y === 0) return true;
  return hash2D(x, y, 77) < 0.5;
}

function getSystemNeighbors(x, y) {
  const neighbors = [];
  neighbors.push({ x: x + 1, y: y, dir: 'Leste' });
  neighbors.push({ x: x - 1, y: y, dir: 'Oeste' });
  if (hasVertEdge(x, y)) {
    neighbors.push({ x: x, y: y + 1, dir: 'Norte' });
  }
  if (hasVertEdge(x, y - 1)) {
    neighbors.push({ x: x, y: y - 1, dir: 'Sul' });
  }
  return neighbors;
}

function getTargetGateIndex(source, dest) {
  const destNbrs = getSystemNeighbors(dest.x, dest.y);
  const idx = destNbrs.findIndex(n => n.x === source.x && n.y === source.y);
  return idx >= 0 ? idx : 0;
}

const sysRoots = [
  'KRONOS', 'SOLARIS', 'VEGA', 'CYGNUS', 'ALTAIR', 'POLARIS', 'BOREAS',
  'THALASSA', 'HYPERION', 'ZENITH', 'ANDROMEDA', 'PROXIMA', 'CENTAURI',
  'SIRIUS', 'ORION', 'DRACO', 'LYRA', 'PHOENIX', 'PEGASUS', 'CASSIOPEIA',
  'ATLAS', 'TITAN', 'VALIS', 'NEBULA', 'TARTARUS', 'AETHER', 'AQUILA',
  'CALYPSO', 'VALHALLA', 'NEXUS', 'VULCANO', 'ARCTURUS', 'ANTARES',
  'RIGEL', 'BETELGEUSE', 'SPICA', 'DENEB', 'ALDEBARAN', 'REGULUS', 'CANOPUS'
];
const sysMods = ['', ' PRIME', ' MAJOR', ' MINOR', ' ALPHA', ' BETA', ' GAMMA', ' DELTA', ' IX', ' VII', ' IV', ' XII'];

function getSystemName(x, y) {
  if (x === 0 && y === 0) return 'ÉOS';
  if (x === 1 && y === 0) return 'NYX';
  const r1 = Math.floor(hash2D(x, y, 101) * sysRoots.length);
  const m1 = Math.floor(hash2D(x, y, 102) * sysMods.length);
  return sysRoots[r1] + sysMods[m1];
}

const starPalettes = [
  { core: [8, 6, 3], color: 0xffefdc, halo1: 'rgba(255,255,225,1)', halo2: 'rgba(255,229,144,.8)', halo3: 'rgba(255,174,77,.25)', halo4: 'rgba(255,154,67,0)', size: 1000 },
  { core: [3, 6, 8], color: 0xaadeff, halo1: 'rgba(225,245,255,1)', halo2: 'rgba(144,210,255,.8)', halo3: 'rgba(77,150,255,.25)', halo4: 'rgba(67,110,255,0)', size: 1200 },
  { core: [8, 2, 1], color: 0xff8a65, halo1: 'rgba(255,230,225,1)', halo2: 'rgba(255,144,110,.8)', halo3: 'rgba(255,90,77,.25)', halo4: 'rgba(255,60,67,0)', size: 900 },
  { core: [8, 8, 8], color: 0xf5f8ff, halo1: 'rgba(255,255,255,1)', halo2: 'rgba(230,240,255,.8)', halo3: 'rgba(180,210,255,.25)', halo4: 'rgba(150,180,255,0)', size: 1100 },
  { core: [8, 4, 1], color: 0xffb74d, halo1: 'rgba(255,245,225,1)', halo2: 'rgba(255,190,110,.8)', halo3: 'rgba(255,130,50,.25)', halo4: 'rgba(255,90,30,0)', size: 1050 },
  { core: [2, 7, 8], color: 0x80deea, halo1: 'rgba(225,255,255,1)', halo2: 'rgba(110,240,255,.8)', halo3: 'rgba(50,200,220,.25)', halo4: 'rgba(30,150,180,0)', size: 1000 }
];

const planetNameList = [
  'KRYOS', 'OBSIDIA', 'PYROS', 'ZEPHYR', 'AQUARIA', 'TARTARUS', 'VERDANTIA',
  'AETHEL', 'KORALIS', 'SYLVIA', 'GLACIES', 'TERRENO', 'VOLCANIS', 'NEBULIS',
  'XANTHOS', 'CYANEA', 'RHODOS', 'CHRONOS', 'BOREALIS', 'AUSTRALIS', 'CALIDUS',
  'LUMINA', 'UMBRALIS', 'ARGENTIA', 'SOLARIA', 'THALASSIS', 'ORPHEUS', 'HESTIA',
  'AURA', 'VANGUARDA', 'OÁSIS', 'MINERVA', 'CRISTALIS', 'NÊMESIS', 'ATENA'
];

const biomePool = [
  { b1: 'Floresta turquesa', b2: 'Pradaria âmbar', c1: 0x287d75, c2: 0xb1a65d, acc: 0x62d6cc, fauna: 'Cervídeo de vela', theme: 0, wet: true },
  { b1: 'Dunas vermelhas', b2: 'Mesetas de obsidiana', c1: 0xb45c40, c2: 0x353849, acc: 0xe49b6e, fauna: 'Escaravelho de pedra', theme: 1, wet: false },
  { b1: 'Geleiras azuis', b2: 'Bosque de cristais', c1: 0xadcddd, c2: 0x64789e, acc: 0x9fd9ff, fauna: 'Raposa de gelo', theme: 2, wet: true },
  { b1: 'Floresta de fungos', b2: 'Pântano violeta', c1: 0x715488, c2: 0x303e64, acc: 0xc69be7, fauna: 'Saltador esporado', theme: 3, wet: true },
  { b1: 'Deserto dourado', b2: 'Cânions coral', c1: 0xcbad61, c2: 0xb35d68, acc: 0xf8d392, fauna: 'Lagarto solar', theme: 4, wet: true },
  { b1: 'Campos de basalto', b2: 'Jardins bioluminescentes', c1: 0x373b49, c2: 0x287377, acc: 0x73ddd9, fauna: 'Aracnídeo de luz', theme: 5, wet: true },
  { b1: 'Savana rubra', b2: 'Lagos de safira', c1: 0x99483b, c2: 0x3e6587, acc: 0x5fa8d3, fauna: 'Antílope da névoa', theme: 0, wet: true },
  { b1: 'Estepes cinzentas', b2: 'Planaltos de enxofre', c1: 0x7a8274, c2: 0xa3984d, acc: 0xd4ca72, fauna: 'Couraçado de quartzo', theme: 1, wet: false },
  { b1: 'Cordilheiras de ferro', b2: 'Vales cristalinos', c1: 0x554d5e, c2: 0x7a6b8a, acc: 0xb6a4cc, fauna: 'Dríade de ametista', theme: 2, wet: false },
  { b1: 'Planícies fósforas', b2: 'Fendas abissais', c1: 0x3b6661, c2: 0x244247, acc: 0x53d6ba, fauna: 'Serpente da areia', theme: 3, wet: true },
  { b1: 'Cânions esmeralda', b2: 'Tundra boreal', c1: 0x3c7e62, c2: 0x588899, acc: 0x7cd1b0, fauna: 'Mastodonte plumado', theme: 4, wet: true },
  { b1: 'Selva prismática', b2: 'Picos nevados', c1: 0x2e7560, c2: 0x8a9faa, acc: 0x65e09f, fauna: 'Gavião auroral', theme: 5, wet: true }
];

const defs=[['VÉRDEA','Floresta turquesa','Pradaria âmbar',0x287d75,0xb1a65d,0x62d6cc,'Cervídeo de vela',730,0,true],['FERRUM','Dunas vermelhas','Mesetas de obsidiana',0xb45c40,0x353849,0xe49b6e,'Escaravelho de pedra',640,1,false],['NÍVEA','Geleiras azuis','Bosque de cristais',0xadcddd,0x64789e,0x9fd9ff,'Raposa de gelo',680,2,true],['MYCELIA','Floresta de fungos','Pântano violeta',0x715488,0x303e64,0xc69be7,'Saltador esporado',800,3,true],['AUREA','Deserto dourado','Cânions coral',0xcbad61,0xb35d68,0xf8d392,'Lagarto solar',620,4,true],['UMBRA','Campos de basalto','Jardins bioluminescentes',0x373b49,0x287377,0x73ddd9,'Aracnídeo de luz',750,5,true]];

function getPlanetDefs(sx, sy) {
  if (sx === 0 && sy === 0) return defs.slice(0, 3);
  if (sx === 1 && sy === 0) return defs.slice(3, 6);
  const count = 3;
  const list = [];
  for (let i = 0; i < count; i++) {
    const nameIdx = Math.floor(hash2D(sx, sy, 310 + i * 17) * planetNameList.length);
    const bIdx = Math.floor(hash2D(sx, sy, 520 + i * 19) * biomePool.length);
    const b = biomePool[bIdx];
    const r = 620 + Math.floor(hash2D(sx, sy, 730 + i * 23) * 160);
    list.push([planetNameList[nameIdx], b.b1, b.b2, b.c1, b.c2, b.acc, b.fauna, r, b.theme, b.wet]);
  }
  return list;
}

const SEP=1200000,ATMOSPHERE=1200,gates=[],suns=[];let boost=null,gateCooldown=0,autoGate=null,heat=0;
function systemOf(pos){return currentSystem.name;}
function nearest(pos){if(!planets||planets.length===0)return {r:1000,center:V(0,-999999,0),def:['ESPAÇO PROFUNDO','Vácuo','Vácuo',0,0,0x62d6cc,'',1000],i:0};return planets.reduce((a,p)=>pos.distanceTo(p.center)-p.r<pos.distanceTo(a.center)-a.r?p:a,planets[0]);}
function atmosphereAt(pos){if(!planets||planets.length===0)return {p:nearest(pos),alt:999999,density:0};const p=nearest(pos),alt=pos.distanceTo(p.center)-radius(p,pos.clone().sub(p.center).normalize());return {p,alt,density:Math.pow(Math.max(0,1-alt/ATMOSPHERE),2)};}

function createSystemSpace(sx, sy) {
  const pal = starPalettes[Math.floor(hash2D(sx, sy, 201) * starPalettes.length)];
  const pos = V(0, 9000, -18000);
  const sun = mesh(new THREE.SphereGeometry(pal.size, 32, 20), new THREE.MeshBasicMaterial({ color: new THREE.Color(pal.core[0], pal.core[1], pal.core[2]), fog: false, toneMapped: false }), scene, ...pos.toArray());
  sun.userData.noCollision = true;
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const cx = c.getContext('2d'), gr = cx.createRadialGradient(128, 128, 2, 128, 128, 128);
  gr.addColorStop(0, pal.halo1);
  gr.addColorStop(.16, pal.halo2);
  gr.addColorStop(.42, pal.halo3);
  gr.addColorStop(1, pal.halo4);
  cx.fillStyle = gr;
  cx.fillRect(0, 0, 256, 256);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, toneMapped: false }));
  halo.position.copy(pos);
  halo.scale.set(6500, 6500, 1);
  scene.add(halo);
  suns.push({ pos, sun, halo });
  sunlight.color.set(pal.color);

  // 2 to 4 Gates per system, each with 10 aligned rings corridor (High Performance InstancedMesh)
  const nbrs = getSystemNeighbors(sx, sy);
  const ringCount = 10;
  const ringSpacing = 48;
  const halfLength = ((ringCount - 1) * ringSpacing) / 2;

  const ringGeo = new THREE.TorusGeometry(150, 7.5, 8, 48);
  const lightGeo = new THREE.TorusGeometry(139, 2.2, 8, 48);
  const pylonGeo = new THREE.BoxGeometry(16, 12, 12);
  const railGeo = new THREE.BoxGeometry(6, 6, halfLength * 2 + 50);

  const ringMat = new THREE.MeshStandardMaterial({ color: 0x678b9d, roughness: 0.8, metalness: 0.2 });
  const lightMat = mat(0x83f5ee, 2.2);
  const pylonMat = new THREE.MeshStandardMaterial({ color: 0x88a9ae, roughness: 0.8 });
  const railMat = new THREE.MeshStandardMaterial({ color: 0x516b77, roughness: 0.8 });

  for (let k = 0; k < nbrs.length; k++) {
    const nbr = nbrs[k];
    const targetName = getSystemName(nbr.x, nbr.y);
    const targetGateIndex = getTargetGateIndex({ x: sx, y: sy }, nbr);
    const angle = (k / nbrs.length) * Math.PI * 2 + 0.35;
    const R = 24000;
    const gPos = V(Math.cos(angle) * R, 3100 + Math.sin(k * 2.2) * 300, Math.sin(angle) * R);
    const normal = gPos.clone().setY(0).normalize();
    const g = new THREE.Group();
    g.position.copy(gPos);
    g.quaternion.setFromUnitVectors(V(0, 0, 1), normal);
    scene.add(g);

    const ringMesh = new THREE.InstancedMesh(ringGeo, ringMat, ringCount);
    ringMesh.userData.noCollision = true;
    const lightMesh = new THREE.InstancedMesh(lightGeo, lightMat, ringCount);
    lightMesh.userData.noCollision = true;
    const pylonMesh = new THREE.InstancedMesh(pylonGeo, pylonMat, ringCount * 8);
    pylonMesh.userData.noCollision = true;

    const m4 = new THREE.Matrix4();
    let pylonIdx = 0;
    for (let r = 0; r < ringCount; r++) {
      const zOff = (r * ringSpacing) - halfLength;
      m4.makeTranslation(0, 0, zOff);
      ringMesh.setMatrixAt(r, m4);
      lightMesh.setMatrixAt(r, m4);

      for (let j = 0; j < 8; j++) {
        const a = j * Math.PI / 4;
        m4.makeTranslation(Math.cos(a) * 155, Math.sin(a) * 155, zOff);
        pylonMesh.setMatrixAt(pylonIdx++, m4);
      }
    }
    ringMesh.instanceMatrix.needsUpdate = true;
    lightMesh.instanceMatrix.needsUpdate = true;
    pylonMesh.instanceMatrix.needsUpdate = true;
    g.add(ringMesh);
    g.add(lightMesh);
    g.add(pylonMesh);

    const railMesh = new THREE.InstancedMesh(railGeo, railMat, 4);
    railMesh.userData.noCollision = true;
    for (let b = 0; b < 4; b++) {
      const ba = b * Math.PI / 2 + Math.PI / 4;
      m4.makeTranslation(Math.cos(ba) * 156, Math.sin(ba) * 156, 0);
      railMesh.setMatrixAt(b, m4);
    }
    railMesh.instanceMatrix.needsUpdate = true;
    g.add(railMesh);

    label3D(g, 'ARCO · ' + targetName, 0, 178, 0, 36);

    gates.push({
      g, pos: gPos, normal, index: k,
      targetCoord: { x: nbr.x, y: nbr.y },
      targetName, targetGateIndex,
      halfLength: halfLength + 60
    });
    destinations.push({
      name: 'ARCO ' + targetName + ' · Impulsionador',
      pos: gPos.clone(), gate: k + 1,
      targetSystemName: targetName,
      gateIndex: k,
      numGates: getSystemNeighbors(nbr.x, nbr.y).length,
      kind: 'gate'
    });
  }
}

function crossesGate(a, b, g) {
  const da = a.clone().sub(g.pos).dot(g.normal);
  const db = b.clone().sub(g.pos).dot(g.normal);
  if ((da <= 0 && db >= 0) || (da >= 0 && db <= 0)) {
    const denom = da - db;
    const t = Math.abs(denom) > 1e-6 ? da / denom : 0.5;
    const p = a.clone().add(b.clone().sub(a).multiplyScalar(THREE.MathUtils.clamp(t, 0, 1)));
    const latSq = p.clone().sub(g.pos).addScaledVector(g.normal, -p.clone().sub(g.pos).dot(g.normal)).lengthSq();
    if (latSq <= 145 * 145) return true;
  }
  const mid = a.clone().add(b).multiplyScalar(0.5);
  const along = mid.clone().sub(g.pos).dot(g.normal);
  if (Math.abs(along) < (g.halfLength || 250)) {
    const latSq = mid.clone().sub(g.pos).addScaledVector(g.normal, -along).lengthSq();
    if (latSq <= 140 * 140) return true;
  }
  return false;
}

function triggerBoost(g) {
  landed = false;
  openRamp(false,false);
  if (auto?.gate) auto = null;
  autoGate = null;
  gateCooldown = 18;
  if (rover.parent !== ship) {
    ship.attach(rover);
    rover.position.copy(layout().rover);
    rover.rotation.set(0, layout().roverYaw, 0);
    inside = true;
    roverAir = false;
  }
  const warpDir = g.normal.clone().normalize();
  const ly = (3.4 + hash2D(g.targetCoord.x, g.targetCoord.y, 42) * 4.8).toFixed(1);
  boost = {
    startGate: g,
    targetCoord: g.targetCoord,
    targetName: g.targetName,
    targetGateIndex: g.targetGateIndex,
    elapsed: 0,
    duration: 13.5,
    warpDir,
    startPos: ship.position.clone(),
    tunnelPos: g.pos.clone().addScaledVector(warpDir, 8000),
    lightYears: parseFloat(ly),
    loaded: false,
    loadedAt: 0,
    unloadedOld: false,
    approachStart: null,
    approachEnd: null,
    arrivalDir: null
  };
  ship.quaternion.setFromUnitVectors(V(0, 0, -1), warpDir);
  toast('ARCO ATIVADO · Salto Interestelar para ' + g.targetName + ' (' + ly + ' AL)');
  if (audioContext) [110, 220, 440, 880].forEach((f, i) => tone(f, audioContext.currentTime + i * .1, 2.2, .14, fxBus, 'triangle'));
}

function updateSky(dt) {
  if (boost || !planets || planets.length === 0) {
    const bg = new THREE.Color(0x020409);
    scene.background = bg;
    scene.fog = new THREE.Fog(bg, 25000, 4000000);
    starsObj.position.copy(camera.position);
    starsObj.material.opacity = 1;
    camera.fov = THREE.MathUtils.lerp(camera.fov, 104, Math.min(1, dt * 3));
    camera.updateProjectionMatrix();
    return { p: planets[0] || null, alt: 999999, density: 0 };
  }
  const { p, alt, density } = atmosphereAt(camera.position);
  if (!p || !p.def) return { p: null, alt: 999999, density: 0 };
  const inSpace = density < 0.08;
  const sky = inSpace ? new THREE.Color(0x020409) : new THREE.Color(0x030912).lerp(new THREE.Color(p.def[5]).multiplyScalar(.48), Math.sqrt(density));
  scene.background = sky;
  scene.fog = new THREE.Fog(sky, inSpace ? 25000 : (450 + 1000 * (1 - density)), inSpace ? 4000000 : (3500 + 2000000 * (1 - density)));
  for (const world of planets) {
    world.haze.value = inSpace ? 0 : (world === p ? 0 : density * .68);
    world.hazeColor.value.copy(sky);
  }
  starsObj.position.copy(camera.position);
  starsObj.material.opacity = inSpace ? 1 : (1 - density * .98);
  const sol = suns[0] || { pos: V(0, 9000, -18000) },
        lightDir = sol.pos.clone().sub(camera.position).normalize();
  sunlight.position.copy(camera.position).addScaledVector(lightDir, 250);
  sunlight.target.position.copy(camera.position);
  const baseFov = thirdPerson ? 70 : THREE.MathUtils.clamp(70 * cameraZoom[mode], 35, 100);
  const targetFov = boost ? 104 : aiming ? (equipped === 'rifle' ? 44 : equipped === 'tool' ? 46 : 52) : baseFov + heat * 3;
  camera.fov = THREE.MathUtils.lerp(camera.fov, targetFov, Math.min(1, dt * 4));
  camera.updateProjectionMatrix();
  return { p, alt, density };
}
function updateFlightFx() {
  const canvas = $('flightFx');
  if (!canvas) return;
  if (canvas.width !== innerWidth || canvas.height !== innerHeight) {
    canvas.width = innerWidth;
    canvas.height = innerHeight;
  }
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (boost) {
    const cx = canvas.width / 2, cy = canvas.height / 2;
    ctx.strokeStyle = 'rgba(140,225,255,.65)';
    ctx.lineWidth = mobileDevice ? 1.5 : 2;
    const count = mobileDevice ? 28 : 55;
    ctx.beginPath();
    for (let j = 0; j < count; j++) {
      const angle = j * 2.399, phase = (totalTime * 1.8 + j * .137) % 1, r = 80 + phase * canvas.width * .65, len = 60 + phase * 280;
      ctx.moveTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
      ctx.lineTo(cx + Math.cos(angle) * (r + len), cy + Math.sin(angle) * (r + len));
    }
    ctx.stroke();
    ctx.fillStyle = 'rgba(110,185,250,.055)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  if (heat > .03) {
    const grad = ctx.createRadialGradient(canvas.width / 2, canvas.height / 2, canvas.height * .18, canvas.width / 2, canvas.height / 2, canvas.width * .65);
    grad.addColorStop(0, 'rgba(255,130,50,0)');
    grad.addColorStop(1, `rgba(255,96,40,${Math.min(.65, heat * .65)})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
}

function flightObstacle(a, b) {
  const delta = b.clone().sub(a), len = delta.length();
  if (len < .01) return null;
  const candidates = queryStatic(a, len + 25).filter(body => !body.torus && !body.obj.userData.surfaceOnly && body.bounds.getSize(V()).y > 3.5 && body.world.distanceToPoint(a) < len + 25),
        ray = new THREE.Ray(a.clone(), delta.clone().normalize());
  let nearestHit = null, best = len;
  for (const body of candidates) {
    const expanded = body.world.clone().expandByScalar(shipType === 2 ? 6 : 4), point = ray.intersectBox(expanded, V());
    if (point) {
      const dist = a.distanceTo(point);
      if (dist < best && dist > .05) {
        best = dist;
        nearestHit = point.addScaledVector(ray.direction, -1);
      }
    }
  }
  return nearestHit;
}

function autoDestination() {
  if (!auto) return null;
  if (auto.gate) {
    autoGate = gates[auto.gate - 1] || null;
    return auto;
  }
  autoGate = null;
  return auto;
}

function flyShip(dt) {
  updateLandingGears(dt);
  if (auto || boost) {
    manualWasActive = false;
    angularVelocity.set(0, 0, 0);
    steerPixels.set(0, 0, 0);
  }
  const prev = ship.position.clone();
  gateCooldown = Math.max(0, gateCooldown - dt);

  // Majestic Interstellar Hyper-Jump (13.5s 3-phase journey across deep void)
  if (boost) {
    boost.elapsed += dt;

    // Phase 1: Departure gate acceleration (0s to 2.5s)
    if (boost.elapsed < 2.5) {
      flightSpeed = THREE.MathUtils.lerp(flightSpeed, 4500, dt * 2.5);
      ship.position.addScaledVector(boost.warpDir, flightSpeed * dt);
      $('airState').textContent = 'SALTO INTERESTELAR · HIPERESPAÇO';
      $('gestureState').textContent = 'ACELERAÇÃO DE PARTIDA · ENTRANDO NO VÁCUO';
    }
    // Phase 2: True Interstellar Void Cruise (2.5s to 8.5s)
    else if (boost.elapsed < 8.5) {
      if (!boost.unloadedOld) {
        boost.unloadedOld = true;
        unloadCurrentSystem();
      }
      flightSpeed = 6500;
      const progress = (boost.elapsed - 2.5) / 6.0;
      const lyRemaining = Math.max(0.1, (1 - progress) * boost.lightYears).toFixed(1);
      $('airState').textContent = 'TRÂNSITO INTERESTELAR · ' + lyRemaining + ' AL · SISTEMA ' + boost.targetName;
      $('gestureState').textContent = 'CRUZEIRO EM HIPERESPAÇO · VELOCIDADE DE DOBRA';
    }
    // Phase 3: Destination system emergence and approach (8.5s to 13.5s)
    else {
      if (!boost.loaded) {
        boost.loaded = true;
        boost.loadedAt = boost.elapsed;
        loadSystemInSpace(boost.targetCoord);
        const destGate = gates[boost.targetGateIndex] || gates[0];
        const arrivalDir = destGate.normal.clone().negate();
        boost.arrivalDir = arrivalDir;
        boost.destGate = destGate;
        // Ship emerges 14,000m out in deep space, flying towards arrival gate
        boost.approachStart = destGate.pos.clone().addScaledVector(arrivalDir, -14000);
        boost.approachEnd = destGate.pos.clone().addScaledVector(arrivalDir, (destGate.halfLength || 250) + 800);
        ship.position.copy(boost.approachStart);
        ship.quaternion.setFromUnitVectors(V(0, 0, -1), arrivalDir);
      }

      const travelRemaining = Math.max(0.001, boost.duration - boost.loadedAt);
      const subT = Math.min(1, Math.max(0, (boost.elapsed - boost.loadedAt) / travelRemaining));
      const ease = subT * (2 - subT);
      ship.position.lerpVectors(boost.approachStart, boost.approachEnd, ease);
      ship.quaternion.setFromUnitVectors(V(0, 0, -1), boost.arrivalDir);
      flightSpeed = THREE.MathUtils.lerp(2200, 450, ease);

      $('airState').textContent = 'APROXIMAÇÃO FINAL · SISTEMA ' + currentSystem.name;
      $('gestureState').textContent = 'DESACELERAÇÃO · CRUZANDO ARCO DE CHEGADA';
    }

    if (boost.elapsed >= boost.duration && boost.loaded) {
      boost = null;
      flightSpeed = 450;
      gateCooldown = 15;
      toast('Chegada ao Sistema ' + currentSystem.name + ' · ' + planets.length + ' planetas · ' + gates.length + ' arcos');
    }
    shipVelocity.copy(ship.position).sub(prev).divideScalar(dt);
    ship.updateMatrixWorld(true);
    heat = 0;
    return;
  }

    // Automated cinematic landing sequence execution
  if (landingSequence && landingSequence.active) {
    landingSequence.elapsed += dt;
    const progress = Math.min(1.0, landingSequence.elapsed / landingSequence.duration);
    const ease = THREE.MathUtils.smoothstep(progress, 0, 1);
    const up = landingSequence.p ? planetUp(landingSequence.targetPose.pos, landingSequence.p) : UP;

    // Soft cushioned descent: starts higher and approaches softly
    const hoverAlt = Math.max(0, (1 - ease) * 14);
    const intermediatePos = landingSequence.targetPose.pos.clone().addScaledVector(up, hoverAlt);

    ship.position.lerpVectors(landingSequence.startPos, intermediatePos, ease);
    ship.quaternion.slerpQuaternions(landingSequence.startQ, landingSequence.targetPose.q, ease);
    shipNavQuaternion.copy(ship.quaternion);
    shipTiltPitch = shipTiltRoll = shipTiltYaw = 0;

    manualVelocity.set(0, 0, 0);
    angularVelocity.set(0, 0, 0);
    sideSpeed = 0;
    liftSpeed = 0;
    flightSpeed = THREE.MathUtils.lerp(flightSpeed, 0, 1 - Math.exp(-dt * 6));

    updateLandingGears(dt);

    $('airState').textContent = 'POUSO AUTOMÁTICO · TRENS DE POUSO ATIVOS';
    $('gestureState').textContent = progress < 0.7 ? 'ALINHANDO E DESVIANDO DE OBSTÁCULOS' : 'TOQUE AMORTECIDO NO SOLO';

    if (progress >= 1.0) {
      shipGearSuspension = 1.0; // Trigger suspension spring compression bounce!
      finishLanding(landingSequence.targetPose, landingSequence.p, landingSequence.st);
      toast('Pouso concluído com sucesso.');
    }
    shipVelocity.copy(ship.position).sub(prev).divideScalar(Math.max(.001, dt));
    ship.updateMatrixWorld(true);
    return;
  }
  const air = atmosphereAt(ship.position);
  if (auto) {
    const d = autoDestination(), p = d.p;
    const pose = d.gate ? null : (d._landing?.type === shipType ? d._landing.pose : (d._landing = { type: shipType, pose: landingPose(d.pos, p) }).pose);

    // Smooth, stable Autopilot for Arcos (10 aligned rings corridor)
    if (d.gate) {
      const gate = gates[d.gate - 1];
      if (gate) {
        const axis = gate.normal.clone().normalize();
        const corridorHalf = gate.halfLength || 250;
        const leadIn = gate.pos.clone().addScaledVector(axis, -corridorHalf - 800);

        if (!auto._gatePhase) auto._gatePhase = 'approach';
        const toShip = ship.position.clone().sub(gate.pos);
        const distAlong = toShip.dot(axis);
        const lateralDist = toShip.clone().addScaledVector(axis, -distAlong).length();

        if (auto._gatePhase === 'approach') {
          if (distAlong > -corridorHalf - 600 || ship.position.distanceTo(leadIn) < 380 || (distAlong < 0 && lateralDist < 250)) {
            auto._gatePhase = 'corridor';
          }
        }

        if (auto._gatePhase === 'corridor') {
          const targetQ = new THREE.Quaternion().setFromUnitVectors(V(0, 0, -1), axis);
          ship.quaternion.slerp(targetQ, 1 - Math.exp(-dt * 4.0));
          flightSpeed = THREE.MathUtils.lerp(flightSpeed, 450, 1 - Math.exp(-dt * 3.0));
          const forward = V(0, 0, -1).applyQuaternion(ship.quaternion);
          ship.position.addScaledVector(forward, flightSpeed * dt);

          // Centering guide
          const lateralOffset = toShip.clone().addScaledVector(axis, -distAlong);
          if (lateralOffset.length() > 0.5) {
            ship.position.addScaledVector(lateralOffset.normalize(), -Math.min(lateralOffset.length(), dt * 25));
          }

          if (Math.abs(distAlong) < 80) {
            triggerBoost(gate);
          }
        } else {
          const toLead = leadIn.clone().sub(ship.position);
          const distToLead = toLead.length();
          const targetQ = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(ship.position, ship.position.clone().add(toLead), UP));
          ship.quaternion.slerp(targetQ, 1 - Math.exp(-dt * 2.5));
          const forward = V(0, 0, -1).applyQuaternion(ship.quaternion);
          const targetSpeed = Math.min(2400, Math.max(80, distToLead * 0.8));
          flightSpeed = THREE.MathUtils.lerp(flightSpeed, targetSpeed, 1 - Math.exp(-dt * 2.5));
          ship.position.addScaledVector(forward, flightSpeed * dt);
        }
      }
    } else {
      let waypoint = d.pos.clone().add(d.p ? planetUp(d.pos, d.p).multiplyScalar(2) : V(0, 2, 0));
      if (p) waypoint = planetApproach(d, air);
      else if (air.alt < ATMOSPHERE + 200) waypoint = air.p.center.clone().addScaledVector(planetUp(ship.position, air.p), air.p.r + ATMOSPHERE + 450);
      if (d.station && Math.hypot(ship.position.x - d.pos.x, ship.position.z - d.pos.z) > 8 && ship.position.distanceTo(d.pos) > 50) waypoint = d.pos.clone().add(V(0, 180, 0));
      const departingStation = destinations.find(x => x.station && ship.position.distanceTo(x.pos) < 130);
      if (departingStation && ship.position.y < departingStation.pos.y + 100 && ship.position.distanceTo(d.pos) > 180) waypoint = ship.position.clone().setY(departingStation.pos.y + 150);

      const targetPos = pose ? pose.pos : waypoint;
      const toTarget = targetPos.clone().sub(ship.position);
      const dist = toTarget.length();
      const finalApproach = !!pose && dist < 180;

      if (finalApproach) {
        const up = p ? planetUp(pose.pos, p) : UP, delta = ship.position.clone().sub(pose.pos), alt = delta.dot(up), lateral = delta.clone().addScaledVector(up, -alt).length();
        let landWp = pose.pos.clone();
        if (lateral > 8) landWp.addScaledVector(up, Math.max(65, alt));
        else if (ship.quaternion.angleTo(pose.q) > .12) landWp.copy(ship.position);
        ship.quaternion.slerp(pose.q, 1 - Math.exp(-dt * 4));
        const landDir = landWp.sub(ship.position);
        const ldd = landDir.length();
        if (ldd > 0.1) {
          flightSpeed = Math.min(12, Math.max(0.35, ldd * 0.65));
          ship.position.addScaledVector(landDir.normalize(), Math.min(ldd, flightSpeed * dt));
        }
        if (dist < 0.6 && ship.quaternion.angleTo(pose.q) < 0.04) {
          finishLanding(pose, p, d.station);
        }
      } else if (dist > 25) {
        const targetQ = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(ship.position, ship.position.clone().add(toTarget), UP));
        ship.quaternion.slerp(targetQ, 1 - Math.exp(-dt * 2.8));
        const forward = V(0, 0, -1).applyQuaternion(ship.quaternion);
        const limit = air.density > .001 ? Math.sqrt(90 / (.004 * air.density)) : 3000;
        const targetSpeed = Math.min(limit, Math.max(25, dist * 0.6));
        flightSpeed = THREE.MathUtils.lerp(flightSpeed, targetSpeed, 1 - Math.exp(-dt * 3));
        ship.position.addScaledVector(forward, flightSpeed * dt);
      } else {
        flightSpeed = THREE.MathUtils.lerp(flightSpeed, 20, 1 - Math.exp(-dt * 3));
        const forward = V(0, 0, -1).applyQuaternion(ship.quaternion);
        ship.position.addScaledVector(forward, flightSpeed * dt);
      }
    }
  } else manualFlight(dt, air);

  if (!landed) {
    const hit = flightObstacle(prev, ship.position);
    if (hit) {
      ship.position.copy(hit);
      manualVelocity.set(0, 0, 0);
      flightSpeed = 0;
      auto = null;
      toast('Obstáculo detectado. Frenagem de emergência.');
    }
    const p = nearest(ship.position), n = ship.position.clone().sub(p.center).normalize();
    if (ship.position.distanceTo(p.center) < radius(p, n) + 2) {
      finishLanding(landingPose(ship.position, p), p, null);
    }
    for (const g of gates) if (gateCooldown === 0 && crossesGate(prev, ship.position, g)) {
      triggerBoost(g);
      break;
    }
  }
  heat = THREE.MathUtils.lerp(heat, Math.min(1, air.density * Math.pow(Math.abs(flightSpeed) / 400, 2)), Math.min(1, dt * 2));
  shipVelocity.copy(ship.position).sub(prev).divideScalar(Math.max(.001, dt));
  ship.updateMatrixWorld(true);
}

const planets=[],destinations=[],npcs=[],animals=[],ores=[],scenery=[];
function biome(n,i){return Math.sin(n.x*4+i)+Math.cos(n.z*3-i)+n.y*.4>0?0:1}
function height(n,i){return 7*Math.sin(n.x*17+i)*Math.cos(n.z*15-i)+6*Math.sin(n.y*23+n.x*11)+3*Math.cos(n.z*39);}

function frameAt(pos,center){return new THREE.Quaternion().setFromUnitVectors(UP,pos.clone().sub(center).normalize())}
function label3D(parent,text,x,y,z,size=8){const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#071b27';ctx.fillRect(0,0,512,128);ctx.fillStyle='#d9eee2';ctx.font='bold 38px Arial';ctx.textAlign='center';ctx.fillText(text,256,77);const tx=new THREE.CanvasTexture(c),m=new THREE.MeshBasicMaterial({map:tx,side:THREE.DoubleSide});const sign=mesh(new THREE.PlaneGeometry(size,size/4),m,parent,x,y,z);sign.userData.noCollision=true;return sign;}
function bodyLoft(parent,rings,color,segments=12){const points=[],indices=[];for(const [y,rx,rz,cz=0] of rings)for(let k=0;k<segments;k++){const a=k/segments*Math.PI*2;points.push(Math.cos(a)*rx,y,cz+Math.sin(a)*rz);}for(let j=0;j<rings.length-1;j++)for(let k=0;k<segments;k++){const a=j*segments+k,b=j*segments+(k+1)%segments,c=b+segments,d=a+segments;indices.push(a,b,d,b,c,d);}for(const end of [0,rings.length-1])for(let k=1;k<segments-1;k++)indices.push(end*segments,end*segments+k,end*segments+k+1);const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(points,3));geo.setIndex(indices);geo.computeVertexNormals();const m=mesh(geo,color,parent);m.material.side=THREE.DoubleSide;return m;}
function person(parent,x,z,c,seed){const random=rng(seed===undefined?++humanSerial*8917:seed),female=random()<.5,fat=random(),muscle=random(),height=1.58+random()*.36,skin=[0xe1b896,0xbf8c66,0x8b5b43,0x593d32,0xd6ac86][Math.floor(random()*5)],hair=[0x211d1b,0x523625,0xa67c42,0xd4b989,0x77716c][Math.floor(random()*5)],style=Math.floor(random()*5),coat=random()<.32,shoulder=(female?.215:.24)+muscle*.04+fat*.025,hip=(female?.19:.16)+fat*.035,waist=.125+fat*.07;const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(height/1.78);g.userData.actor=true;parent.add(g);const pelvis=new THREE.Group();pelvis.position.y=.87;g.add(pelvis);bodyLoft(pelvis,[[-.12,hip*.8,.115],[0,hip,.14],[.15,waist,.12]],0x354451);const torso=new THREE.Group();torso.position.y=.95;g.add(torso);const fabric=new THREE.Color(c).offsetHSL((random()-.5)*.06,(random()-.5)*.15,(random()-.5)*.12).getHex();bodyLoft(torso,[[0,waist,.13],[.12,waist,.115+fat*.045],[.29,shoulder*.87,.14+(female?.025:0)+muscle*.025],[.43,shoulder,.125],[.49,.09,.08]],fabric);if(coat)bodyLoft(pelvis,[[-.18,hip*1.17,.16],[.06,waist*1.16,.15],[.17,waist*1.12,.13]],fabric);bodyLoft(torso,[[.48,.061,.06],[.56,.063,.06]],skin,10);const head=new THREE.Group();head.position.y=1.51;g.add(head);bodyLoft(head,[[0,.055,.065],[.035,.08,.078,-.009],[.10,.095,.086],[.17,.092,.086,.007],[.23,.067,.065,.01],[.255,.008,.01,.01]],skin,16);for(const side of [-1,1])ellipsoid(head,side*.095,.12,.006,.019,.032,.014,skin,1);if(style!==0){const cap=mesh(new THREE.SphereGeometry(1,12,8,0,Math.PI*2,0,Math.PI*.57),hair,head,0,.145,.012);cap.scale.set(.104,.118,.096);if(style>=2)ellipsoid(head,0,.095,.06,.102,.10,.05,hair,2);if(style===3)ellipsoid(head,0,.105,.115,.06,.065,.065,hair,2);if(style===4)ellipsoid(head,0,-.035,.075,.105,.16,.055,hair,2);}
const limbs=[],knees=[],elbows=[];for(const side of [-1,1]){const leg=new THREE.Group();leg.position.set(side*hip*.64,.87,0);g.add(leg);bodyLoft(leg,[[0,.098+fat*.02,.105],[-.16,.09+muscle*.015,.088],[-.38,.061,.065]],0x354451);const knee=new THREE.Group();knee.position.y=-.38;leg.add(knee);bodyLoft(knee,[[0,.062,.068],[-.10,.071+muscle*.012,.072],[-.32,.041,.045],[-.38,.045,.046]],0x354451);ellipsoid(knee,0,-.405,-.055,.065,.055,.14,0x27333d,2);const arm=new THREE.Group();arm.position.set(side*shoulder,1.37,0);g.add(arm);ellipsoid(arm,0,0,0,.09+muscle*.013,.10,.093,fabric,2);bodyLoft(arm,[[0,.072+muscle*.016,.078],[-.13,.071+muscle*.015,.074],[-.28,.049,.047]],fabric);const elbow=new THREE.Group();elbow.position.y=-.28;arm.add(elbow);bodyLoft(elbow,[[0,.048,.048],[-.12,.047,.05],[-.245,.03,.036]],coat?fabric:skin);ellipsoid(elbow,0,-.29,-.01,.039,.061,.026,skin,2);ellipsoid(elbow,side*-.035,-.27,-.015,.017,.035,.02,skin,1);arm.rotation.z=side*.06;limbs.push(leg,arm);knees.push(knee);elbows.push(elbow);}g.userData.limbs=limbs;g.userData.human={seed:seed??humanSerial,female,fat,muscle,height,style,torso,head,pelvis,knees,elbows,phase:random()*6,speed:0,last:null};mergeHumanParts(g);return g;}
function animateHuman(g, dt, seated = false, airborne = false) {
  const r = g.userData.human;
  if (!r) return;

  const pos = g.getWorldPosition(V());
  let speed = r.last ? Math.min(12, pos.distanceTo(r.last) / Math.max(dt, 0.001)) : 0;
  r.last = pos;
  if (speed > 8 && mode !== 'foot') speed = 0;

  r.speed = THREE.MathUtils.lerp(r.speed, speed, 1 - Math.exp(-dt * 8));

  // Dynamic stride frequency scaling with movement speed
  const strideFreq = 3.0 + r.speed * 1.8;
  r.phase += dt * strideFreq;

  const amount = Math.min(1.0, r.speed / 1.8);
  const run = r.speed > 4.5;
  const blend = 1 - Math.exp(-dt * 14);

  // 1. Pelvis Center-of-Mass Dynamics (Vertical bounce, lateral hip sway, and roll)
  if (!seated && !airborne) {
    // Vertical pelvis oscillation (2 cycles per full stride)
    const bounce = -Math.abs(Math.sin(r.phase)) * (run ? 0.045 : 0.028) * amount;
    r.pelvis.position.y = 0.87 + bounce;
    // Lateral sway over the planted foot
    r.pelvis.position.x = Math.sin(r.phase) * (run ? 0.025 : 0.016) * amount;
    // Pelvic roll and yaw into stride
    r.pelvis.rotation.z = Math.sin(r.phase) * 0.035 * amount;
    r.pelvis.rotation.y = Math.cos(r.phase) * 0.05 * amount;
  } else {
    r.pelvis.position.set(0, 0.87, 0);
    r.pelvis.rotation.set(0, 0, 0);
  }

  // 2. Spine & Torso Counter-Dynamics (Rotates opposite to hips for natural balance)
  if (!seated) {
    r.torso.rotation.y = -Math.cos(r.phase) * (run ? 0.11 : 0.07) * amount;
    r.torso.rotation.z = -Math.sin(r.phase) * 0.035 * amount;
    // Athletic forward torso lean during acceleration/sprinting
    const forwardLean = (run ? 0.14 : 0.05) * amount;
    // Natural idle breathing sway when standing still
    const breathe = Math.sin(totalTime * 2.0) * 0.018 * (1 - amount);
    r.torso.rotation.x = forwardLean + breathe;

    // Head stabilizes gaze forward
    r.head.rotation.y = Math.cos(r.phase) * 0.03 * amount + Math.sin(totalTime * 0.8 + r.seed) * 0.025 * (1 - amount);
    r.head.rotation.x = -forwardLean * 0.5;
  } else {
    r.torso.rotation.set(0, 0, 0);
    r.head.rotation.set(0, 0, 0);
  }

  // 3. Biomechanical Leg & Knee Kinematics (Zero backward knee bending!)
  for (let side = 0; side < 2; side++) {
    const legPhase = r.phase + side * Math.PI;
    const swing = Math.sin(legPhase);
    const leg = g.userData.limbs[side * 2];
    const arm = g.userData.limbs[side * 2 + 1];

    let thighPose, kneePose;

    if (seated) {
      // Seated: Thigh extends forward horizontally (+1.35), knee bends 90° down (-1.35)
      thighPose = 1.35;
      kneePose = -1.35;
    } else if (airborne) {
      // Airborne / Jetpack: Legs slightly flexed forward, knees naturally bent backward
      thighPose = 0.28;
      kneePose = -0.52;
    } else {
      // Natural walking/running locomotion:
      const strideAmp = run ? 0.82 : 0.52;
      thighPose = swing * strideAmp * amount;

      // Realistic knee flexion:
      // When leg swings forward (push-off to heel plant, swing < 0 in our phase definition):
      // Knee flexes backward (negative rotX) to lift the boot and clear the floor!
      if (swing < 0) {
        const swingFlex = Math.sin(Math.max(0, -swing) * Math.PI * 0.9) * (run ? 1.40 : 0.88);
        kneePose = -swingFlex * amount;
      } else {
        // Stance phase: boot is planted, knee flexes slightly for shock absorption then straightens
        const stanceFlex = Math.sin(legPhase) * (run ? 0.20 : 0.10);
        kneePose = -Math.max(0, stanceFlex) * amount;
      }
    }

    leg.rotation.x = THREE.MathUtils.lerp(leg.rotation.x, thighPose, blend);
    r.knees[side].rotation.x = THREE.MathUtils.lerp(r.knees[side].rotation.x, kneePose, blend);

    // 4. Natural 3rd Person Weapon Posing & Kinetic Melee Combat
    const isMeleeAttacking = typeof meleeActive !== 'undefined' && meleeActive && (equipped === 'blade' || equipped === 'sabre');
    const isMeleeWeapon = equipped === 'blade' || equipped === 'sabre';
    const isFirearm = ['pistol', 'rifle', 'shotgun', 'tool'].includes(equipped);
    const inCombat = (typeof aiming !== 'undefined' && aiming) ||
                     (typeof firing !== 'undefined' && firing) ||
                     (typeof recoil !== 'undefined' && recoil > 0.05) ||
                     (typeof combatTime !== 'undefined' && typeof lastShot !== 'undefined' && combatTime - lastShot < 1.4);
    const aimPitch = typeof pitch !== 'undefined' ? pitch : 0;

    if (isMeleeAttacking) {
      // FULL-BODY KINETIC MELEE STRIKE ANIMATION IN 3RD PERSON
      const mp = Math.min(1.0, Math.max(0, (combatTime - meleeStartTime) / meleeDuration));
      if (typeof meleeCombo !== 'undefined' && meleeCombo === 0) {
        // Combo 0: Lethal Overhand Diagonal Slash cutting top-right to bottom-left
        if (mp < 0.22) {
          // Windup: Cocking blade high over right shoulder
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, -0.42, blend);
          r.torso.rotation.x = THREE.MathUtils.lerp(r.torso.rotation.x, -0.08, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 1.55, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.48, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 1.30, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, -0.30, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.32, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.50, blend);
          }
        } else if (mp < 0.62) {
          // Heavy Explosive Cut: Lunging forward, twisting hips & shoulders across cut!
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, 0.50, blend);
          r.torso.rotation.x = THREE.MathUtils.lerp(r.torso.rotation.x, 0.18, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.35, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.65, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 0.70, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, -0.45, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.40, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.40, blend);
          }
        } else {
          // Smooth, organic recovery back to melee guard (elbow bends, blade pulls back to chest!)
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, 0, blend);
          r.torso.rotation.x = THREE.MathUtils.lerp(r.torso.rotation.x, 0, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.35, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.20, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 1.20, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.25, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.18, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.65, blend);
          }
        }
      } else {
        // Combo 1: Visceral Horizontal Cleave slicing across torso
        if (mp < 0.22) {
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, 0.38, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.80, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.70, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 1.20, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, -0.25, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.30, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.50, blend);
          }
        } else if (mp < 0.62) {
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, -0.50, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.55, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.75, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 0.60, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, -0.45, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.40, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.40, blend);
          }
        } else {
          // Smooth recovery back to melee guard
          r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, 0, blend);
          r.torso.rotation.x = THREE.MathUtils.lerp(r.torso.rotation.x, 0, blend);
          if (side === 1) {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.35, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.20, blend);
            r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 1.20, blend);
          } else {
            arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.25, blend);
            arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.18, blend);
            r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.65, blend);
          }
        }
      }
    } else if (!seated && !resting && mode === 'foot' && isMeleeWeapon) {
      // NATURAL MARTIAL READY / COMBAT GUARD FOR MELEE WEAPONS:
      // Character holds blade tucked close to body in ready guard, NEVER straight-arm pointing!
      r.torso.rotation.y = THREE.MathUtils.lerp(r.torso.rotation.y, 0, blend);
      r.torso.rotation.x = THREE.MathUtils.lerp(r.torso.rotation.x, 0, blend);
      const walkBob = Math.sin(r.phase) * amount * 0.06;
      if (side === 1) {
        // Right arm holding blade: elbow comfortably bent (~68°), blade held close to chest/waist
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.35 + walkBob, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.20, blend);
        r.elbows[1].rotation.x = THREE.MathUtils.lerp(r.elbows[1].rotation.x, 1.20, blend);
      } else {
        // Left arm off-hand martial ready guard
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.25 - walkBob, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, 0.18, blend);
        r.elbows[0].rotation.x = THREE.MathUtils.lerp(r.elbows[0].rotation.x, 0.65, blend);
      }
    } else if (!seated && !resting && mode === 'foot' && side === 1 && isFirearm) {
      if (inCombat) {
        // NATURAL FIREARM COMBAT AIMING STANCE:
        // Arm is NOT locked straight! Right elbow is comfortably bent at ~42°, tucked close to body
        const targetRotX = 1.05 - aimPitch * 0.80 - (recoil * 0.20);
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, targetRotX, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.18, blend);
        r.elbows[side].rotation.x = THREE.MathUtils.lerp(r.elbows[side].rotation.x, 0.72, blend); // natural elbow bend!
      } else {
        // NATURAL FIREARM LOW-READY / PATROL STANCE:
        const walkBob = Math.sin(r.phase) * amount * 0.08;
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.42 + walkBob, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.16, blend);
        r.elbows[side].rotation.x = THREE.MathUtils.lerp(r.elbows[side].rotation.x, 0.45, blend);
      }
    } else if (!seated && !resting && mode === 'foot' && side === 0 && ['rifle', 'shotgun', 'tool'].includes(equipped)) {
      if (inCombat) {
        // Left arm supporting foregrip naturally with comfortable bend
        const targetRotX = 0.92 - aimPitch * 0.80 - (recoil * 0.16);
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, targetRotX, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.36, blend);
        r.elbows[side].rotation.x = THREE.MathUtils.lerp(r.elbows[side].rotation.x, 1.05, blend); // natural support angle!
      } else {
        // Left arm cradling foregrip across torso in low-ready
        const walkBob = -Math.sin(r.phase) * amount * 0.07;
        arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, 0.36 + walkBob, blend);
        arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, -0.32, blend);
        r.elbows[side].rotation.x = THREE.MathUtils.lerp(r.elbows[side].rotation.x, 0.95, blend);
      }
    } else {
      // Unarmed or seated arm animation
      const armSwing = -swing * amount * (run ? 0.75 : 0.42);
      arm.rotation.x = THREE.MathUtils.lerp(arm.rotation.x, seated ? -0.7 : airborne ? -0.35 : armSwing, blend);
      arm.rotation.y = THREE.MathUtils.lerp(arm.rotation.y, side === 1 ? -0.05 : 0.05, blend);
      r.elbows[side].rotation.x = THREE.MathUtils.lerp(r.elbows[side].rotation.x, seated ? -0.7 : run ? 0.75 : 0.20 + Math.max(0, swing) * amount * 0.30, blend);
    }
  }
}

function mergeHumanParts(root){for(const child of [...root.children])if(!child.isMesh)mergeHumanParts(child);const pieces=root.children.filter(o=>o.isMesh&&!o.material.transparent);if(pieces.length<2)return;const positions=[],normals=[],colors=[];for(const o of pieces){o.updateMatrix();const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(o.matrix);positions.push(...geo.attributes.position.array);normals.push(...geo.attributes.normal.array);const c=o.material.color;for(let j=0;j<geo.attributes.position.count;j++)colors.push(c.r,c.g,c.b);geo.dispose();root.remove(o);o.geometry.dispose();o.material.dispose();}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));const m=mesh(geo,new THREE.MeshStandardMaterial({vertexColors:true,flatShading:true,roughness:.85,side:THREE.DoubleSide}),root);m.castShadow=true;}

function stationCity(parent,p){const tint=p?p.def[5]:0x96c8d5,variation=p?p.i:parent.position.x>SEP/2?7:6;parent.userData.city=true;parent.userData.half=V(80,0,70);box(parent,0,-1.5,0,160,3,140,0x304451);box(parent,0,.05,0,42,.1,125,0x465b64);box(parent,0,.15,0,24,.2,32,0x78938c);for(const side of [-1,1]){box(parent,side*27,.13,0,9,.26,125,0x819394);for(let z=-59;z<=60;z+=7)box(parent,side*12,.12,z,.18,.08,2.3,mat(0xd2c990,.6));}
for(let j=0;j<6;j++)buildStore(parent,p,j,variation);
// Open plaza and canopied market stalls; enough clearance for a rover.
for(let z of [-52,52]){box(parent,0,.15,z,17,.3,13,0x6e8587);for(let x of [-6,6]){mesh(new THREE.CylinderGeometry(.16,.2,4.5,10),0x526c79,parent,x,2.3,z);box(parent,x,1,z,3,1.7,2,0xb79a71);}box(parent,0,4.6,z,17,.25,6,tint);label3D(parent,z<0?'CONTRATOS':'SERVIÇOS',0,3.7,z+3.1,10);}
for(let side of [-1,1])for(let z=-56;z<=56;z+=28){mesh(new THREE.CylinderGeometry(.17,.28,7,10),0x375361,parent,side*21,3.5,z);box(parent,side*21,7,z,3,.2,1,mat(tint,1.8));box(parent,side*31, .55,z+5,4,1,2,0x596d65);mesh(new THREE.IcosahedronGeometry(1.2,1),0x497f6f,parent,side*31,1.7,z+5);}
// Sloped exits connect the flat city deck to the curved terrain.
for(const side of [-1,1]){const ramp=box(parent,0,-2,side*77,22,.4,18,0x5d777c);ramp.rotation.x=side*.21;}
const roles=['Lia · logística','Orion · geólogo','Nara · pesquisadora','Ivo · recuperação','Maia · resgate','Bento · manutenção'];for(let j=0;j<12;j++){const role=j%6,x=j<6?-17:17,z=-45+role*18,g=person(parent,x,z,[0xd3ab73,0xb8bd85,0x78b8af,0x739bbb,0xc18478,0xb2a5c6][role]);const n={g,base:g.position.clone(),name:roles[role],role,phase:j,path:[V(x,.15,z),V(x,.15,z+7),V(x+(j<6?4:-4),.15,z+7),V(x+(j<6?4:-4),.15,z)],way:1,wait:0,city:parent};g.userData.actor=true;npcs.push(n);}
parent.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});}

function talk(n){if(n.shop){openShop(n.shop.id);return;}document.body.classList.add('in-menu');clearInput();document.exitPointerLock?.();$('panel').classList.remove('hidden');const lines=['Suprimentos precisam chegar aos portos. O porão tem espaço?','Os depósitos dourados sustentam nossas oficinas.','Precisamos catalogar a fauna dos mundos vizinhos.','Há equipamentos à deriva perto da estação. Você pode recuperá-los?','Um explorador ficou isolado fora da cidade. Traga-o em segurança.','Três torres precisam de reparo. Leve sua ferramenta de campo.'];$('content').innerHTML=`<div class="eyebrow">${n.city===planets[0].city?'VÉRDEA':'REDE CIVIL'} · HABITANTE</div><h2>${n.name}</h2><p>${lines[n.role]}</p><button class="primary" onclick="accept('${['cargo','mine','scan','salvage','rescue','repair'][n.role]}')">ACEITAR TRABALHO</button> <button onclick="menu('jobs')">VER TODOS OS CONTRATOS</button>`;}

function createSinglePlanet(sx, sy, i) {
  const pDefs = getPlanetDefs(sx, sy);
  if (i >= pDefs.length) return;
  const d = pDefs[i];
  let center;
  if (sx === 0 && sy === 0) {
    center = V((i - 1) * 5700, i === 1 ? 1400 : 0, i === 2 ? -4200 : 0);
  } else if (sx === 1 && sy === 0) {
    center = V((i - 1) * 5700, i === 1 ? 1400 : 0, i === 2 ? -4200 : 0);
  } else {
    const angle = i * (Math.PI * 2 / pDefs.length) + hash2D(sx, sy, 300 + i) * 0.4;
    const dist = 5200 + hash2D(sx, sy, 400 + i) * 2200;
    const Y = -400 + hash2D(sx, sy, 500 + i) * 1800;
    center = V(Math.cos(angle) * dist, Y, Math.sin(angle) * dist);
  }
  const p = {
    def: d, i, r: d[7], center,
    theme: d[8] !== undefined ? d[8] : i % 6,
    wet: d[9] !== undefined ? d[9] : wetPlanet({ i }),
    surfaceLoaded: false,
    city: null, scenery: [], animals: [], ores: [],
    water: null, cloud: null
  };
  planets.push(p);

  // Fast base LOD in space (takes only 4ms)
  createPlanetLOD(p);

  p.globe.material.fog = false;
  p.haze = { value: 0 };
  p.hazeColor = { value: new THREE.Color() };
  p.globe.material.onBeforeCompile = shader => {
    shader.uniforms.planetHaze = p.haze;
    shader.uniforms.planetHazeColor = p.hazeColor;
    shader.fragmentShader = `uniform float planetHaze; uniform vec3 planetHazeColor;\n` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <dithering_fragment>', `gl_FragColor.rgb=mix(gl_FragColor.rgb,planetHazeColor,planetHaze);\n#include <dithering_fragment>`);
  };
  const glow = new THREE.ShaderMaterial({
    uniforms: { tint: { value: new THREE.Color(p.def[5]) } },
    vertexShader: 'varying vec3 n;varying vec3 v;void main(){n=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.0);v=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}',
    fragmentShader: 'uniform vec3 tint;varying vec3 n;varying vec3 v;void main(){float rim=pow(1.0-abs(dot(normalize(n),normalize(v))),3.0);gl_FragColor=vec4(tint,rim*.20);}',
    transparent: true, side: THREE.BackSide, depthWrite: false, blending: THREE.AdditiveBlending
  });
  const shell = mesh(new THREE.SphereGeometry(p.r + ATMOSPHERE, 24, 16), glow, scene, ...p.center.toArray());
  shell.userData.noCollision = true;
  p.atmosphere = shell;

  // Destination port marker in space navigation
  const cityPos = center.clone().add(V(0, 1, 0).multiplyScalar(radius(p, UP) + 1));
  destinations.push({ name: d[0] + ' · Porto', pos: cityPos.clone(), p, kind: 'planet' });
}

// Distance-based streaming: Load planet surface details only when player approaches
function loadPlanetSurface(p) {
  if (p.surfaceLoaded) return;
  p.surfaceLoaded = true;

  const n = V(0, 1, 0), cityPos = p.center.clone().add(n.multiplyScalar(radius(p, UP) + 1));
  p.city = new THREE.Group();
  p.city.position.copy(cityPos);
  scene.add(p.city);
  city(p.city, p);

  // Scenery (trees/rocks)
  const random = rng(182 + (currentSystem.x * 73 + currentSystem.y * 31 + p.i) * 137);
  for (let j = 0; j < 190; j++) {
    let dir = V(random() * 2 - 1, random() * 2 - 1, random() * 2 - 1).normalize();
    if (j < 70) dir = V((random() - .5) * .75, 1, (random() - .5) * .75).normalize();
    if (dir.dot(UP) > .976) continue;
    const g = new THREE.Group();
    g.userData.noCollision = true;
    g.position.copy(p.center).addScaledVector(dir, radius(p, dir));
    g.quaternion.setFromUnitVectors(UP, dir);
    scene.add(g);
    scenery.push(g);
    p.scenery.push(g);
    const b = biome(dir, p.theme);
    if (p.theme === 0) {
      mesh(new THREE.CylinderGeometry(1, 1.3, 9, 9), 0x484637, g, 0, 4, 0);
      mesh(new THREE.ConeGeometry(b ? 4 : 6, b ? 9 : 13, 10), p.def[3 + b], g, 0, 11, 0);
    } else if (p.theme === 3) {
      mesh(new THREE.CylinderGeometry(1, 1.5, 8, 10), 0xaf92ba, g, 0, 4, 0);
      mesh(new THREE.SphereGeometry(7, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2), b ? 0x6767ae : 0xcc8dab, g, 0, 9, 0);
    } else {
      const m = mesh(new THREE.IcosahedronGeometry(3 + random() * 5, 1), p.def[3 + b], g, 0, 3, 0);
      m.scale.y = p.theme === 2 ? 2.7 : .7;
    }
    if (j < 18) {
      const o = mesh(new THREE.OctahedronGeometry(2, 1), mat(0xf2bb67, .25), g, 4, 2, 0);
      ores.push({ g: o, p, taken: false });
      p.ores.push(o);
    }
  }

  // Animals
  for (let j = 0; j < 12; j++) {
    let dir = V((j % 4 - 1.5) * .035, 1, .24 + Math.floor(j / 4) * .035).normalize(), g = new THREE.Group();
    g.position.copy(p.center).addScaledVector(dir, radius(p, dir));
    g.quaternion.setFromUnitVectors(UP, dir);
    scene.add(g);
    box(g, 0, 1.1, 0, 1.4, 1.2, 2.3, p.def[5]);
    mesh(new THREE.IcosahedronGeometry(.7, 1), p.def[5], g, 0, 1.6, -1.4);
    for (let k = 0; k < (p.theme === 5 ? 6 : 4); k++) box(g, k % 2 ? 1 : -1, .4, Math.floor(k / 2) - .7, .22, .8, .22, p.def[3]);
    if (p.theme === 0 || p.theme === 3) mesh(new THREE.ConeGeometry(.8, 2.5, 3), p.def[4], g, 0, 2.6, 0);
    const an = { g, p, origin: g.position.clone(), phase: j };
    animals.push(an);
    p.animals.push(an);
  }

  // Environment (water, clouds)
  if (wetPlanet(p)) {
    const water = mesh(new THREE.SphereGeometry(seaRadius(p), 64, 40), new THREE.MeshStandardMaterial({
      color: [0x1b7384, 0, 0x407caa, 0x514d8d, 0x318c8b, 0x226d6c][p.theme],
      roughness: .25, metalness: .3, transparent: true, opacity: .84, flatShading: true
    }), scene, ...p.center.toArray());
    water.userData.noCollision = true;
    water.material.side = THREE.DoubleSide;
    p.water = water;
  }

  const cloudMat = new THREE.ShaderMaterial({
    uniforms: { sunDir: { value: (suns[0]?.pos || V(0, 9000, -18000)).clone().sub(p.center).normalize() }, tint: { value: new THREE.Color(0xe0e9ec) }, cover: { value: .42 } },
    vertexShader: 'varying vec3 q;void main(){q=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: 'varying vec3 q;uniform vec3 sunDir;uniform vec3 tint;uniform float cover;void main(){vec3 n=normalize(q);float a=sin(n.x*23.+sin(n.z*15.)*2.)*cos(n.y*19.-n.z*6.);float b=sin(n.z*47.+n.y*16.)*sin(n.x*39.);float cloud=smoothstep(cover,cover+.28,a*.7+b*.3);float light=.10+.90*smoothstep(-.1,.4,dot(n,sunDir));gl_FragColor=vec4(tint*light,cloud*.76);}',
    transparent: true, depthWrite: false, side: THREE.DoubleSide
  });
  p.cloud = mesh(new THREE.SphereGeometry(p.r + 105, 32, 20), cloudMat, scene, ...p.center.toArray());
  p.cloud.userData.noCollision = true;

  // Register only this planet's city bodies
  registerBodies();
  buildSpatialIndex();
}

function unloadPlanetSurface(p) {
  if (!p.surfaceLoaded) return;
  p.surfaceLoaded = false;

  if (p.city) { scene.remove(p.city); discardChildren(p.city); p.city = null; }
  for (const g of p.scenery) { scene.remove(g); discardChildren(g); }
  p.scenery.length = 0;
  for (const a of p.animals) { scene.remove(a.g); discardChildren(a.g); }
  p.animals.length = 0;
  for (const o of p.ores) { scene.remove(o.g); discardChildren(o.g); }
  p.ores.length = 0;
  if (p.water) { scene.remove(p.water); p.water.geometry.dispose(); p.water.material.dispose(); p.water = null; }
  if (p.cloud) { scene.remove(p.cloud); p.cloud.geometry.dispose(); p.cloud.material.dispose(); p.cloud = null; }

  registerBodies();
  buildSpatialIndex();
}

function updateSurfaceStreaming(pos) {
  if (boost || !planets || planets.length === 0) return;
  for (const p of planets) {
    const dist = pos.distanceTo(p.center);
    const surfaceDist = dist - p.r;
    if (surfaceDist < 1200 && !p.surfaceLoaded) {
      loadPlanetSurface(p);
    } else if (surfaceDist > 2200 && p.surfaceLoaded && p !== groundPlanet) {
      unloadPlanetSurface(p);
    }
  }
  const stDest = destinations.find(d => d.station);
  if (stDest && stDest.station) {
    const dist = pos.distanceTo(stDest.pos);
    if (dist < 700 && !stDest.station.userData.cityLoaded) {
      loadStationCity(stDest.station);
    }
  }
}

function createSystemPlanets(sx, sy) {
  const pDefs = getPlanetDefs(sx, sy);
  for (let i = 0; i < pDefs.length; i++) {
    createSinglePlanet(sx, sy, i);
  }
}

function createSystemStation(sx, sy) {
  const st = new THREE.Group();
  st.position.set(1800, 2300, 2400);
  scene.add(st);
  const ring = mesh(new THREE.TorusGeometry(65, 4, 12, 72), 0x738c9a, st, 0, 30, 0);
  ring.rotation.x = Math.PI / 2;
  box(st, 0, -7, 0, 30, 14, 35, 0x314655);
  st.userData.cityLoaded = false;
  destinations.push({ name: 'ESTAÇÃO ' + currentSystem.name + ' · Estação', pos: st.position.clone(), station: st, kind: 'station' });
}

function loadStationCity(st) {
  if (st.userData.cityLoaded) return;
  st.userData.cityLoaded = true;
  city(st);
  registerBodies();
  buildSpatialIndex();
}

const stars=new THREE.BufferGeometry(),starArr=[];const sr=rng(99);for(let i=0;i<4500;i++){let v=V(sr()*2-1,sr()*2-1,sr()*2-1).normalize().multiplyScalar(90000);starArr.push(v.x,v.y,v.z)}stars.setAttribute('position',new THREE.Float32BufferAttribute(starArr,3));const starsObj=new THREE.Points(stars,new THREE.PointsMaterial({color:0xc5e3ff,size:55,sizeAttenuation:true,transparent:true,fog:false}));scene.add(starsObj);
const shipTypes=[{name:'ATLAS / cargueiro',color:0x1e5282,speed:190,cap:18},{name:'KESTREL / exploradora',color:0x225d94,speed:280,cap:8},{name:'MOLE / mineradora',color:0x1d4a75,speed:155,cap:26}];
window.shipTypes=shipTypes;const ship=new THREE.Group();scene.add(ship);let shipType=0,rampOpen=true;
const layouts=[{halfX:7,halfZ:15,cockpit:V(0,2.15,-20.7),seat:V(0,2.1,-19.25),entry:V(0,0,15),normal:V(0,0,1),doorHalf:4,spawn:V(0,2.1,12),rover:V(0,.95,5),roverYaw:Math.PI,desc:'Ponte, alojamento e garagem · rampa traseira'},{halfX:5.5,halfZ:11,cockpit:V(0,2.05,-17.4),seat:V(0,2.1,-15.9),entry:V(-5.5,0,4),normal:V(-1,0,0),doorHalf:4,spawn:V(-3.7,2.1,4),rover:V(0,.95,4),roverYaw:Math.PI/2,desc:'Ponte, laboratório/garagem e alojamento · entrada lateral'},{halfX:10,halfZ:10,cockpit:V(5,2.3,-9.5),seat:V(5,2.1,-8.05),entry:V(-5,0,-10),normal:V(0,0,-1),doorHalf:3.5,spawn:V(-5,2.1,-7.2),rover:V(-5,.95,-1),roverYaw:0,desc:'Ponte, oficina e garagem · rampa frontal esquerda'}];
function layout(){return layouts[shipType];}

let transitionUntil=0;
function entryWorld(){return shipPoint(layout().entry);}

function toggleRamp(){if(rampOpen&&doorwayOccupied()){toast('Entrada ocupada.');return;}openRamp(!rampOpen,false);toast('Rampa '+(rampOpen?'aberta.':'fechada.'));}
function boardShip(){resetFootMotion();if(mode==='pilot'){interact();return;}if(mode==='rover'){latch();return;}if(inside){exitShip();return;}if(player.distanceTo(entryWorld())>12){toast('Aproxime-se da entrada da nave. T retorna de qualquer lugar.');return;}openRamp(true);inside=true;eva=false;mode='foot';foot.copy(layout().spawn);yaw=0;pitch=0;transitionUntil=totalTime+.8;toast('Embarque concluído. Siga até o cockpit e pressione E.');}
function exitShip(){resetFootMotion();const l=layout();openRamp(true);inside=false;mode='foot';player.copy(shipPoint(l.entry.clone().addScaledVector(l.normal,5).add(V(0,1.9,0))));eva=!landed;evaFrame.copy(ship.quaternion);evaVelocity.copy(shipVelocity);if(!eva)player.copy(placeOnGround(player,station?null:groundPlanet));yaw=Math.atan2(-l.normal.x,-l.normal.z);pitch=0;transitionUntil=totalTime+.8;toast(eva?'EVA ativo. T retorna ao cockpit.':'Desembarque concluído. B perto da entrada para retornar.');}
function inDoor(local,extra=0){const l=layout(),rel=local.clone().sub(l.entry),across=l.normal.x?rel.z:rel.x;return Math.abs(across)<l.doorHalf-.5+extra;}
function insideMove(delta){const up=UP.clone().applyQuaternion(ship.quaternion),world=shipPoint(foot),m=delta.clone().applyQuaternion(ship.quaternion),next=moveActor(world,m,{up,height:1.8,grounded:true});foot.copy(localPoint(next));const rel=foot.clone().sub(layout().entry);if(rampOpen&&inDoor(foot)&&rel.dot(layout().normal)>.7&&totalTime>transitionUntil)exitShip();}
function interact(){if(mode==='pilot'&&targetedCockpitButton){targetedCockpitButton.userData.execute();return;}if(mode==='foot'&&inside&&!resting&&foot.distanceTo(layout().seat)<2.6){mode='pilot';yaw=0;pitch=0;return;}if(useShipInterior())return;if(mode==='pilot'){mode='foot';inside=true;resetFootMotion();foot.copy(layout().seat).add(V(0,.08,1.8));yaw=0;pitch=0;toast('Você pode caminhar. B desembarca pela entrada da nave.');return;}if(mode==='rover'){mode='foot';inside=rover.parent===ship;eva=!inside&&roverAir;if(inside){foot.copy(layout().spawn);eva=false;}else{player.copy(safeExit(rover.getWorldPosition(V()),rover,station?null:groundPlanet));if(eva){evaFrame.copy(rover.quaternion);evaVelocity.copy(roverVelocity);}}return;}const pos=inside?shipPoint(foot):player;if(inside&&foot.distanceTo(layout().seat)<2.6){mode='pilot';yaw=0;pitch=0;return;}const roverDist=pos.distanceTo(rover.getWorldPosition(V()));if(roverDist<3.5){mode='rover';eva=false;yaw=0;pitch=0;toast('W avança · S recua · E sai · B/R embarca no porão.');return;}if(!inside&&pos.distanceTo(entryWorld())<10){boardShip();return;}if(inside&&foot.distanceTo(layout().spawn)<3){exitShip();return;}const n=npcs.find(n=>pos.distanceTo(n.g.getWorldPosition(V()))<3.8);if(n){talk(n);return;}if(missionAction())return;toast('Aproxime-se do cockpit, de um habitante, veículo ou entrada. B facilita o embarque.');}
function latch(){if(mode!=='rover')return;if(rover.parent===ship){toast('Dirija para a entrada. W aponta para a saída.');return;}if(rover.getWorldPosition(V()).distanceTo(entryWorld())<15){openRamp(true);ship.attach(rover);rover.position.copy(layout().rover);rover.rotation.set(0,layout().roverYaw,0);inside=true;roverAir=false;toast('Veículo embarcado e preso no porão.');}else toast('Aproxime o veículo da entrada da nave e pressione B ou R.');}
function recall(){resetFootMotion();const port=destinations.find(d=>d.station&&ship.position.distanceTo(d.pos)<160);groundPlanet=port?null:nearest(ship.position);station=port?.station||null;mode='pilot';inside=true;eva=false;evaVelocity.set(0,0,0);yaw=0;pitch=0;foot.copy(layout().seat);closeMenu();toast('Teletransporte concluído. Você está no cockpit.');}

const rover=new THREE.Group();box(rover,0,.7,0,2.8,1,4.2,0xe1ac65);box(rover,0,1.4,-.6,2,1,1.6,0x4b788a);for(let x of [-1.5,1.5])for(let z of [-1.4,1.4]){const wheel=mesh(new THREE.CylinderGeometry(.6,.6,.5,20),0x222e3b,rover,x,.3,z);wheel.rotation.z=Math.PI/2;}
buildShip();if(destinations.length>0)ship.position.copy(destinations[0].pos).add(V(0,2,0));
let mode='foot',started=false,landed=true,inside=true,foot=V(-3.5,1.9,-3.7),player=V(),groundPlanet=planets[0],station=null,yaw=0,pitch=0,flightSpeed=0,auto=null,target=0,credits=1200,cargo=0,mission=null,scanned=new Set(),mined=0,totalTime=0;
try{const save=JSON.parse(localStorage.getItem('horizonte-v1'));if(save){credits=save.credits||1200;scanned=new Set(save.scanned||[])}}catch{}
const keys={};let statusMessage='',messageUntil=0;
function toast(s){statusMessage=s;if(!/inimig|pirata|embosc|perigo|alerta|obstru|insuficient|Pagamento|contrato|missão|compr|adquir|destru|METEOR|tempestade|ciclone|terremoto|não é possível|não pode|Sem munição/i.test(s))return;soundCue(s);messageUntil=totalTime+5;$('toast').textContent=s;}
function save(){try{localStorage.setItem('horizonte-v1',JSON.stringify({credits,scanned:[...scanned],equipment,skyward:{currentSystem:{x:currentSystem.x,y:currentSystem.y},jetLevel,outfit,ownedOutfits,locker,recentEquipment,controls:controlPrefs,performance:{...performancePrefs,quality,particles:particlesEnabled}}}))}catch{}}
function nearest(pos){return planets.reduce((a,p)=>pos.distanceTo(p.center)-p.r<pos.distanceTo(a.center)-a.r?p:a,planets[0])}
function localPoint(world){return ship.worldToLocal(world.clone())}
function shipPoint(v){return ship.localToWorld(v.clone())}
function menu(tab='settings'){closeWeaponPicker();$('actionStrip').classList.add('hidden');clearInput();document.body.classList.add('in-menu');document.exitPointerLock?.();$('panel').classList.remove('hidden');renderPanel(tab)}
function closeMenu(){$('panel').classList.add('hidden');document.body.classList.remove('in-menu');save();}

window.choose=i=>{target=i;renderPanel('map')};
window.engage=()=>{if(mode!=='pilot'){toast('Sente-se no cockpit antes de viajar.');return;}auto=destinations[target];landed=false;openRamp(false,false);flightSpeed=0;closeMenu();toast('Piloto automático ativo. Rotas entre sistemas usam os arcos.');};

window.changeShip=i=>{if(!landed||!atPort()||mode!=='pilot'||mission||rover.parent!==ship){toast('Troque no cockpit, pousado em um porto, sem contrato e com o veículo a bordo.');return;}shipType=i;buildShip();yaw=0;pitch=0;renderPanel('fleet');toast('Nova nave preparada. '+layout().desc);};
function scan(){if(missionAction())return;if(mode==='pilot'){toast('Saia da nave para usar a ferramenta de campo.');return}const pos=mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player;const o=ores.find(o=>!o.taken&&pos.distanceTo(o.g.getWorldPosition(V()))<22);if(o){if(cargo>=shipTypes[shipType].cap){toast('Porão cheio.');return}o.taken=true;o.g.visible=false;mined++;cargo++;credits+=45;save();toast('Minério coletado +45 CR · '+mined+' depósitos');return}const a=animals.find(a=>pos.distanceTo(a.g.position)<65);if(a){scanned.add(a.p.i);if(mission?.type==='scan'&&!mission.seen.includes(a.p.i))mission.seen.push(a.p.i);save();toast('Fauna catalogada: '+a.p.def[6]+' · '+a.p.def[0]);return}const fish=environment.flatMap(e=>e.fish.map(f=>({f,p:e.p}))).find(a=>a.f.g.position.distanceTo(pos)<65);if(fish){scanned.add(fish.p.i);if(mission?.type==='scan'&&!mission.seen.includes(fish.p.i))mission.seen.push(fish.p.i);save();toast('Fauna aquática catalogada · '+fish.p.def[0]);return;}toast('Nenhum depósito a 22 m ou animal a 65 m. Explore além do porto.');}

addEventListener('keydown',e=>{if(['Space','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();keys[e.code]=true;if(e.repeat||!started)return;if(e.code==='Escape'){if($('panel').classList.contains('hidden'))menu('settings');else closeMenu();return;}if(!$('panel').classList.contains('hidden'))return;if(e.code==='KeyB'){if(mode==='pilot'){interact();exitShip();}else boardShip();}if(e.code==='KeyT')recall();if(e.code==='KeyG')toggleGuide();if(e.code==='KeyU')toggleAudio();if(e.code==='KeyE'){
  // Key E: In pilot mode, rolls ship right (handled in manualFlight). On foot, interacts!
  if(mode!=='pilot'){
    interact();
  }
}
if(e.code==='KeyF'){
  // Key F: Stands up from pilot seat or bench/bed. On foot outside seat, activates scan tool!
  if(mode==='pilot'){
    mode='foot';
    inside=true;
    resetFootMotion();
    foot.copy(layout().seat).add(V(0,.08,1.8));
    yaw=0; pitch=0;
    toast('Você levantou do assento [F].');
    return;
  } else if(resting){
    standUp();
    return;
  } else {
    scan();
  }
}
if((e.code==='KeyZ'||e.code==='AltLeft')&&mode==='pilot'){
  toggleCockpitCameraLook(e);
  return;
}if(e.code==='KeyM')menu('map');if(e.code==='KeyJ')menu('jobs');if(e.code==='KeyH')menu('fleet');if(e.code==='KeyO')toggleRamp();
if(e.code==='KeyR'){
  // Key R: In pilot mode, executes landing. On foot, reloads weapon!
  if(mode==='pilot'){
    land();
    return;
  } else if(mode==='foot'){
    reloadWeapon();
  } else {
    latch();
  }
}
if(e.code==='KeyL')land(); // Secondary landing key
if(e.code==='KeyP'){auto=null;toast('Controle manual.')}if(e.code==='KeyX')brakeShip();});addEventListener('keyup',e=>keys[e.code]=false);addEventListener('blur',()=>{Object.keys(keys).forEach(k=>keys[k]=false)});
renderer.domElement.onclick=()=>{if(!touchEnabled&&started&&$('panel').classList.contains('hidden'))renderer.domElement.requestPointerLock?.()};
addEventListener('mousemove',e=>{if(document.pointerLockElement===renderer.domElement)lookInput(e.movementX,e.movementY)});
let eva=false,evaFrame=new THREE.Quaternion(),evaVelocity=V(),shipVelocity=V(),roverAir=false,roverVelocity=V(),guideEnabled=true;

function update(dt){inputTick(dt);totalTime+=dt;if(!started)return;const paused=!$('panel').classList.contains('hidden');if(!paused){tickInteriors(dt,false);flyShip(dt);updateCitizens(dt,false);refreshMovingBodies();if(mode==='foot'){updateFootV05(dt);
}else if(mode==='rover'){const f=axisForward(),turn=(-axisStrafe())*dt*1.25;rover.rotateY(turn);if(roverAir){rover.position.addScaledVector(roverVelocity,dt);const p=nearest(rover.position),n=rover.position.clone().sub(p.center).normalize(),alt=rover.position.distanceTo(p.center)-radius(p,n);if(alt<ATMOSPHERE)roverVelocity.addScaledVector(n,-7*dt);if(alt<1){roverAir=false;groundPlanet=p;station=null;rover.position.copy(placeOnGround(rover.position,p,.3));rover.quaternion.copy(frameAt(rover.position,p.center));}}else{const onboard=rover.parent===ship,p=groundPlanet||nearest(rover.getWorldPosition(V())),up=onboard?UP.clone().applyQuaternion(ship.quaternion):UP.clone().applyQuaternion(walkFrame(rover.getWorldPosition(V()),p)),q=rover.getWorldQuaternion(new THREE.Quaternion()),delta=V(0,0,-f*(aquaticDriveSpeed())*dt).applyQuaternion(q),origin=rover.getWorldPosition(V()),eye=origin.clone().addScaledVector(up,2.2),next=moveActor(eye,delta,{up,p:onboard||station?null:p,height:2.5,r:1.18,ignore:rover}).addScaledVector(up,-2.2);if(onboard){rover.position.copy(localPoint(next));const rel=rover.position.clone().sub(layout().entry);if(rampOpen&&inDoor(rover.position)&&rel.dot(layout().normal)>1){scene.attach(rover);inside=false;roverAir=!landed;roverVelocity.copy(shipVelocity);toast('Veículo fora da nave. B perto da entrada para embarcar.');}}else{rover.position.copy(next);const oldUp=UP.clone().applyQuaternion(rover.quaternion);rover.quaternion.premultiply(new THREE.Quaternion().setFromUnitVectors(oldUp,up));}}}}
updatePlayerCamera(dt);
const {p,alt,density}=updateSky(dt);$('place').textContent=alt<ATMOSPHERE?p.def[0]+' / '+p.def[1+biome(camera.position.clone().sub(p.center).normalize(),p.i)]:systemOf(camera.position)?'SISTEMA NYX':'SISTEMA ÉOS';$('state').textContent=boost?'IMPULSO INTERSISTEMAS':mode==='pilot'?(auto?'PILOTO AUTOMÁTICO':landed?'POUSADO':'VOO MANUAL'):mode==='rover'?(['skiff','cutter'].includes(vehicleKind)?'EMBARCAÇÃO ANFÍBIA':'VEÍCULO TERRESTRE'):inside?'INTERIOR DA NAVE':eva?'EVA':'EXPLORAÇÃO A PÉ';$('speed').textContent=Math.abs(flightSpeed).toFixed(0);$('alt').textContent=Math.max(0,alt).toFixed(0);$('credits').textContent=credits.toLocaleString('pt-BR');$('objective').textContent=mission?mission.label+(mission.type==='mine'?' · '+Math.min(3,mined-mission.startMined)+'/3':mission.type==='scan'?' · '+mission.seen.length+'/2':mission.type==='repair'||mission.type==='salvage'?' · '+mission.done.length+'/'+(mission.type==='repair'?3:2):''):'';$('shipname').textContent=shipTypes[shipType].name;$('cargo').textContent=cargo+'/'+shipTypes[shipType].cap+' · '+(rover.parent===ship?'VEÍCULO A BORDO':'VEÍCULO EM SOLO');$('toast').style.opacity=totalTime<messageUntil?1:0;$('airState').textContent=boost?'TRÂNSITO · '+Math.max(0,6-boost.elapsed).toFixed(1)+' s':density>.005?'ATMOSFERA · DENSIDADE '+Math.round(density*100)+'% · ARRASTO ATIVO':'VÁCUO · SEM ARRASTO';const dist=(inside?shipPoint(foot):player).distanceTo(entryWorld());$('boardHint').textContent=mode==='pilot'?'F · LEVANTAR   B · SAIR':inside?'B · SAIR PELA ENTRADA':dist<12?'B · EMBARCAR':'T · VOLTAR AO COCKPIT';updateGuide();updateCockpitRaycast();updateAudio(dt,paused);updateFlightFx();for(const a of animals)a.g.visible=camera.position.distanceTo(a.g.position)<3500;v04Tick(dt,paused);v05Tick(dt,paused);updateSurfaceStreaming(controlledPosition());inputAfterTick();environmentTick(dt,paused);if(paused)tickInteriors(0,true);}


const jobDefs=[['cargo','Carga','Leve quatro caixas ao porto indicado.',1400],['mine','Mineração','Colete três depósitos e retorne a um porto.',1100],['scan','Pesquisa','Catalogue fauna em dois planetas.',1800],['salvage','Recuperação orbital','Saia em EVA e recupere dois módulos à deriva.',2100],['rescue','Resgate','Busque um explorador isolado e traga-o ao porto de origem.',2400],['repair','Manutenção','Conserte três torres de comunicação com sua ferramenta.',1300]];
const repairSites=[],rescueSites=[],salvageSites=[];
function initJobs() {
  repairSites.length = 0;
  rescueSites.length = 0;
  salvageSites.length = 0;
  for (let i = 0; i < planets.length; i++) {
    const p = planets[i];
    for (let j = 0; j < 3; j++) {
      const g = new THREE.Group();
      g.position.copy(p.center).add(V(j === 0 ? -14 : 14, p.r + 2, j === 2 ? 38 : -32 + j * 20));
      scene.add(g);
      box(g, 0, 1, 0, 1.6, 2, 1.6, 0x617a85);
      mesh(new THREE.CylinderGeometry(.17, .23, 5, 10), 0x8a9a9d, g, 0, 3.7, 0);
      const bulb = mesh(new THREE.SphereGeometry(.4, 12, 8), mat(0xe6a16c, 1), g, 0, 6.4, 0);
      repairSites.push({ g, p, bulb, index: j });
    }
    const normal = V(.19, 1, .15).normalize(), pos = p.center.clone().addScaledVector(normal, radius(p, normal) + .1), g = new THREE.Group();
    g.position.copy(pos);
    g.quaternion.copy(frameAt(pos, p.center));
    scene.add(g);
    const survivor = person(g, 0, 0, 0xe89e79);
    box(g, 3, 1, 0, 2, 2, 3, 0x79785f);
    rescueSites.push({ g, p, survivor });
  }
  const stDest = destinations.find(d => d.station);
  const stPos = stDest ? stDest.pos : V(1800, 2300, 2400);
  for (let j = 0; j < 2; j++) {
    const g = new THREE.Group();
    g.position.copy(stPos).add(V(-25 + j * 50, 110 + j * 20, 160));
    scene.add(g);
    box(g, 0, 0, 0, 3, 2, 3, 0xa48b67);
    box(g, 0, 1.2, 0, 2.2, .3, 2.2, mat(0x89cedc, .8));
    salvageSites.push({ g, index: j });
  }
}
function clearMissionCargo(){ship.children.filter(c=>c.name==='cargo'||c.name==='passenger').forEach(c=>{ship.remove(c);c.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.map?.dispose();o.material.dispose();}});});}
function acceptJob(type){if(['hunt','bounty','patrol'].includes(type))return acceptCombat(type);if(mission){toast('Conclua ou cancele o contrato atual.');return;}const port=atPort(),def=jobDefs.find(j=>j[0]===type);if(!port||!def){toast('Aceite um contrato perto de um porto.');return;}const origin=destinations.indexOf(port),planetIndex=port.p?port.p.i:port.pos.x>SEP/2?3:0;mission={type,origin,to:(planetIndex+1)%6,startMined:mined,seen:[],done:[],planetIndex,picked:false,label:def[1],reward:def[3]};if(type==='cargo'){cargo=4;const l=layout();for(let j=0;j<4;j++){const c=box(ship,l.rover.x+(shipType===2?0:0),1,shipType===2?5+j*1.7:shipType===1?8:-3+j*1.7,1.3,1.3,1.3,0xd8af73);if(shipType===1)c.position.x=-3+j*1.6;if(shipType===2)c.position.set(-5+(j%2?1:-1),1,5+Math.floor(j/2)*2.2);c.name='cargo';}mission.label='Carga → '+destinations[mission.to].name;}if(type==='rescue')mission.label='Resgate → '+planets[planetIndex].def[0];if(type==='repair')mission.label='Manutenção · três torres';if(type==='salvage'){mission.system=port.pos.x>SEP/2?1:0;salvageSites.filter(x=>x.system===mission.system).forEach(x=>{x.g.visible=true;x.g.traverse(o=>o.userData.removed=false)});}refreshMovingBodies();toast('Contrato aceito. G mostra o objetivo.');renderPanel('jobs');}
function missionAction(){if(!mission||mode==='pilot'&&!(mission.type==='rescue'&&mission.picked&&!mission.boarded))return false;const pos=mode==='pilot'?ship.position:mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player;if(mission.type==='repair'){const site=repairSites.find(x=>x.p.i===mission.planetIndex&&!mission.done.includes(x.index)&&pos.distanceTo(x.g.position)<5);if(site){mission.done.push(site.index);site.bulb.material=mat(0x8fe8ba,1);toast('Torre reparada · '+mission.done.length+'/3.');return true;}}
if(mission.type==='salvage'){const site=salvageSites.find(x=>x.system===mission.system&&!mission.done.includes(x.index)&&pos.distanceTo(x.g.position)<7);if(site){mission.done.push(site.index);site.g.visible=false;site.g.traverse(o=>o.userData.removed=true);toast('Módulo recuperado · '+mission.done.length+'/2.');return true;}}
if(mission.type==='rescue'&&!mission.picked){const site=rescueSites[mission.planetIndex];if(pos.distanceTo(site.g.position)<6){mission.picked=true;toast('Explorador localizado. Leve a nave a até 80 m e pressione F para embarcá-lo.');return true;}}
if(mission.type==='rescue'&&mission.picked&&!mission.boarded){const site=rescueSites[mission.planetIndex];if(landed&&ship.position.distanceTo(site.g.position)<80){mission.boarded=true;site.survivor.visible=false;site.survivor.traverse(o=>o.userData.removed=true);const passenger=person(ship,shipType===2?4:shipType===1?1.6:3,shipType===2?3:-5,0xe89e79);passenger.name='passenger';mission.label='Resgate · retornar a '+destinations[mission.origin].name;refreshMovingBodies();toast('Explorador a bordo. Retorne ao porto de origem.');return true;}toast('Aproxime e pouse a nave a até 80 m do local do resgate.');return true;}return false;}
function completeJob(){if(!mission)return;if(mission.combat)return completeCombat();const port=atPort();if(!port){toast('Retorne a um porto para entregar.');return;}const m=mission,ok=m.type==='cargo'?port===destinations[m.to]:m.type==='mine'?mined-m.startMined>=3:m.type==='scan'?m.seen.length>=2:m.type==='repair'?m.done.length>=3:m.type==='salvage'?m.done.length>=2:m.boarded&&port===destinations[m.origin];if(!ok){toast('Os objetivos ainda não foram concluídos.');return;}credits+=m.reward;resetJobObjects(m);mission=null;cargo=0;clearMissionCargo();refreshMovingBodies();save();toast('Contrato concluído. Pagamento recebido!');renderPanel('jobs');}
function resetJobObjects(m){if(m.type==='rescue'){const s=rescueSites[m.planetIndex].survivor;s.visible=true;s.traverse(o=>o.userData.removed=false);}if(m.type==='repair')repairSites.filter(s=>s.p.i===m.planetIndex).forEach(s=>s.bulb.material=mat(0xe6a16c,1));}
function cancelJob(){clearCombatMission();if(mission)resetJobObjects(mission);mission=null;cargo=0;clearMissionCargo();refreshMovingBodies();toast('Contrato cancelado.');renderPanel('jobs');}
function currentGoal(){if(mission?.combat&&!boost)return combatGoal();const from=mode==='pilot'?ship.position:mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player,closest=list=>list.reduce((a,b)=>!a||from.distanceTo(b.pos)<from.distanceTo(a.pos)?b:a,null);if(boost)return {pos:boost.approachEnd||boost.tunnelPos||ship.position,label:'IMPULSO · SISTEMA '+(boost.targetName||'DESTINO').toUpperCase()};if(autoGate&&!boost)return {pos:autoGate.pos,label:'ATRAVESSAR ARCO · '+(autoGate.targetName||'DESTINO').toUpperCase()};if(!mission)return {pos:destinations[target].pos,label:'DESTINO · '+destinations[target].name};const m=mission;if(m.type==='cargo')return {pos:destinations[m.to].pos,label:'ENTREGA · '+destinations[m.to].name};if(m.type==='mine'&&mined-m.startMined<3)return closest(ores.filter(o=>!o.taken).map(o=>({pos:o.g.getWorldPosition(V()),label:'MINÉRIO · '+o.p.def[0]})));if(m.type==='scan'&&m.seen.length<2)return closest(animals.filter(a=>!m.seen.includes(a.p.i)).map(a=>({pos:a.g.position,label:'FAUNA · '+a.p.def[0]})));if(m.type==='repair'&&m.done.length<3)return closest(repairSites.filter(x=>x.p.i===m.planetIndex&&!m.done.includes(x.index)).map(x=>({pos:x.g.position,label:'REPARAR TORRE · F'})));if(m.type==='salvage'&&m.done.length<2)return closest(salvageSites.filter(x=>x.system===m.system&&!m.done.includes(x.index)).map(x=>({pos:x.g.position,label:'RECUPERAR MÓDULO · EVA + F'})));if(m.type==='rescue'){if(!m.boarded)return {pos:rescueSites[m.planetIndex].g.position,label:m.picked?'POUSE A NAVE PERTO DO EXPLORADOR · F':'LOCALIZAR EXPLORADOR · F'};return {pos:destinations[m.origin].pos,label:'RESGATE · RETORNAR À ORIGEM'};}return closest(destinations.filter(d=>!d.gate&&d.kind!=='water').map(d=>({pos:d.pos,label:'RECEBER PAGAMENTO · '+d.name})));}

window.accept=acceptJob;window.finishJob=completeJob;window.cancelJob=cancelJob;

function toggleGuide(){guideEnabled=!guideEnabled;$('guideToggle').textContent='G · OBJETIVO '+(guideEnabled?'ON':'OFF');toast('HUD de objetivo '+(guideEnabled?'ativado.':'desativado.'));}
function updateGuide(){const goal=currentGoal(),marker=$('waypoint');marker.style.display=guideEnabled&&goal?'block':'none';if(!guideEnabled||!goal)return;camera.updateMatrixWorld();const rel=goal.pos.clone().sub(camera.position).applyQuaternion(camera.quaternion.clone().invert()),distance=rel.length(),ndc=goal.pos.clone().project(camera);let x=(ndc.x*.5+.5)*innerWidth,y=(-ndc.y*.5+.5)*innerHeight;const off=rel.z>=0||x<90||x>innerWidth-90||y<90||y>innerHeight-180;let angle=0;if(off){let dx=rel.x,dy=-rel.y;if(Math.abs(dx)+Math.abs(dy)<.001){dx=0;dy=1;}const factor=Math.min((innerWidth/2-90)/Math.max(.001,Math.abs(dx)),(innerHeight/2-170)/Math.max(.001,Math.abs(dy)));x=innerWidth/2+dx*factor;y=innerHeight/2+dy*factor;angle=Math.atan2(dy,dx)*180/Math.PI+90;}$('wayArrow').textContent=off?'▲':'◇';$('wayArrow').style.transform=`rotate(${off?angle:0}deg)`;$('wayLabel').textContent=goal.label;$('wayDistance').textContent=(distance>1000?(distance/1000).toFixed(1)+' km':Math.round(distance)+' m')+(rel.z>=0?' · atrás de você':'');marker.style.left=x+'px';marker.style.top=y+'px';}
let audioContext=null,musicBus,fxBus,masterBus,engineGain,engineOsc,engineFilter,windGain,audioMuted=false,nextChord=0,nextMelody=0,musicStep=0,footTimer=0,musicVolume=.35,fxVolume=.6;
function tone(freq,time,duration,gain,bus,type='sine',pan=0){if(!audioContext)return;const o=audioContext.createOscillator(),g=audioContext.createGain(),p=audioContext.createStereoPanner();o.type=type;o.frequency.value=freq;p.pan.value=pan;g.gain.setValueAtTime(0,time);g.gain.linearRampToValueAtTime(gain,time+.06);g.gain.exponentialRampToValueAtTime(.0001,time+duration);o.connect(g).connect(p).connect(bus);o.start(time);o.stop(time+duration+.1);o.onended=()=>{o.disconnect();g.disconnect();p.disconnect()};}
function initAudio(){if(audioContext){audioContext.resume();return;}try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;audioContext=new AC();masterBus=audioContext.createGain();masterBus.gain.value=.7;const limiter=audioContext.createDynamicsCompressor();masterBus.connect(limiter).connect(audioContext.destination);musicBus=audioContext.createGain();musicBus.gain.value=musicVolume;musicBus.connect(masterBus);fxBus=audioContext.createGain();fxBus.gain.value=fxVolume;fxBus.connect(masterBus);
const delay=audioContext.createDelay(2),feedback=audioContext.createGain();delay.delayTime.value=.57;feedback.gain.value=.23;musicBus.connect(delay);delay.connect(feedback);feedback.connect(delay);feedback.connect(masterBus);
engineOsc=audioContext.createOscillator();engineOsc.type='sawtooth';engineFilter=audioContext.createBiquadFilter();engineFilter.type='lowpass';engineFilter.frequency.value=150;engineGain=audioContext.createGain();engineGain.gain.value=0;engineOsc.connect(engineFilter).connect(engineGain).connect(fxBus);engineOsc.start();const buffer=audioContext.createBuffer(1,audioContext.sampleRate*2,audioContext.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;const noise=audioContext.createBufferSource();noise.buffer=buffer;noise.loop=true;const windFilter=audioContext.createBiquadFilter();windFilter.type='lowpass';windFilter.frequency.value=650;windGain=audioContext.createGain();windGain.gain.value=0;noise.connect(windFilter).connect(windGain).connect(fxBus);noise.start();nextChord=audioContext.currentTime+.1;nextMelody=audioContext.currentTime+3;audioContext.resume();}catch(e){if(audioContext)audioContext.close().catch(()=>{});audioContext=null;$('audioStatus').textContent='Áudio indisponível neste navegador';}}
function toggleAudio(){initAudio();audioMuted=!audioMuted;if(masterBus)masterBus.gain.setTargetAtTime(audioMuted?0:.7,audioContext.currentTime,.08);$('audioToggle').textContent='U · ÁUDIO '+(audioMuted?'OFF':'ON');}
function setVolume(type,value){initAudio();const n=Number(value)/100;if(type==='music'){musicVolume=n;if(musicBus)musicBus.gain.setTargetAtTime(n,audioContext.currentTime,.05);}else{fxVolume=n;if(fxBus)fxBus.gain.setTargetAtTime(n,audioContext.currentTime,.05);}}
function soundCue(text){if(!audioContext)return;const t=audioContext.currentTime;if(/Teletransporte/.test(text)){[220,330,440,660,880].forEach((f,i)=>tone(f,t+i*.055,.35,.09,fxBus));}else if(/coletado|catalogada|Pagamento/.test(text)){[523,659,784].forEach((f,i)=>tone(f,t+i*.09,.4,.07,fxBus));}else if(/Rampa|Decolagem|Chegada/.test(text)){tone(110,t,.7,.08,fxBus,'triangle');tone(220,t+.12,.5,.06,fxBus);}else tone(480,t,.13,.025,fxBus);}
function updateAudio(dt,paused){if(!audioContext||audioContext.state!=='running')return;const t=audioContext.currentTime;windGain.gain.setTargetAtTime(paused?0:boost?.16:heat>.1?heat*.12:eva?.016:inside?.002:.028,t,.2);const aboard=inside||mode==='pilot',intensity=landed?.025:Math.min(.15,.04+Math.abs(flightSpeed)/20000);engineGain.gain.setTargetAtTime(paused?0:aboard?intensity:eva?.012:.006,t,.25);engineOsc.frequency.setTargetAtTime(landed?35:45+Math.min(100,Math.abs(flightSpeed)/20),t,.2);engineFilter.frequency.setTargetAtTime(landed?100:200+Math.min(600,Math.abs(flightSpeed)/4),t,.3);
if(t>=nextChord){const chords=[[130.81,164.81,196,246.94],[110,164.81,220,261.63],[87.31,130.81,174.61,220],[98,146.83,196,293.66],[130.81,196,261.63,329.63],[110,164.81,246.94,329.63]];chords[musicStep%chords.length].forEach((f,i)=>tone(f,t+.04*i,9,.04,musicBus,'sine',(i-1.5)*.4));musicStep++;nextChord=t+9+(musicStep%3);}
if(t>=nextMelody){const scale=[261.63,293.66,329.63,392,440,523.25,659.25],index=(musicStep*3+Math.floor(totalTime/4))%scale.length;tone(scale[index],t,2.8,.032,musicBus,'triangle',Math.sin(totalTime)*.5);nextMelody=t+2.5+(musicStep%4)*.8;}
if(!paused&&mode==='foot'&&!eva&&(Math.abs(axisForward())>.05||Math.abs(axisStrafe())>.05)){footTimer-=dt;if(footTimer<=0){tone(inside?100:75,t,.1,.065,fxBus,'triangle');footTimer=keys.ShiftLeft?.27:.43;}}}
window.boardingAction=()=>{if(mode==='pilot'){interact();exitShip();}else boardShip();};window.recall=recall;window.toggleGuide=toggleGuide;window.toggleAudio=toggleAudio;window.setVolume=setVolume;
function ellipsoid(parent,x,y,z,sx,sy,sz,color,detail=1){const m=mesh(new THREE.IcosahedronGeometry(1,detail),color,parent,x,y,z);m.scale.set(sx,sy,sz);return m;}
function bone(parent,a,b,r,color){const d=b.clone().sub(a),m=mesh(new THREE.CylinderGeometry(r*.8,r,d.length(),8),color,parent);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(UP,d.normalize());return m;}
function sculptAnimal(g,i,hostile=false){discardChildren(g);const d=(planets[i]?planets[i].def:(defs[i%defs.length]||defs[0])),c=hostile?0xa95845:d[5];g.userData.animal=true;g.userData.legs=[];const body=ellipsoid(g,0,1.05,0,i===5?1.1:.75,i===1?.5:.62,i===4?1.5:1.1,c,2);g.userData.body=body;ellipsoid(g,0,1.5,-1.1,.45,.5,.58,c,1);ellipsoid(g,0,1.31,-1.6,.28,.24,.4,d[4],1);for(const x of [-.25,.25])ellipsoid(g,x,1.66,-1.5,.065,.075,.08,mat(hostile?0xff6554:0xe4dca7,.35));const count=i===5?8:4;for(let j=0;j<count;j++){const side=j%2?1:-1,z=-.7+Math.floor(j/2)*(count===8?.45:1.35),leg=new THREE.Group();leg.position.set(side*.62,1.1,z);g.add(leg);const spread=i===5?side*.75:side*.08;bone(leg,V(),V(spread,-.45,.14),.09,d[3]);bone(leg,V(spread,-.45,.14),V(spread*1.3,-1,.05),.06,d[3]);ellipsoid(leg,spread*1.3,-1,.01,.11,.07,.2,d[4]);g.userData.legs.push(leg);}if(i===0){for(const side of [-1,1]){bone(g,V(side*.23,1.95,-1),V(side*.55,2.85,-.9),.055,d[4]);bone(g,V(side*.40,2.48,-.94),V(side*.9,2.7,-1.1),.045,d[4]);}}else if(i===1){ellipsoid(g,0,1.45,.15,.9,.35,1.25,d[4],1);}else if(i===2||i===3){for(const side of [-1,1]){const ear=mesh(new THREE.ConeGeometry(.2,.75,8),c,g,side*.28,2.1,-.95);ear.rotation.z=side*.25;}}const tail=new THREE.Group();tail.position.set(0,1.2,.85);g.add(tail);const cone=mesh(new THREE.ConeGeometry(i===2?.42:.20,i===4?2.7:1.3,10),c,tail,0,0,.6);cone.rotation.x=Math.PI/2;g.userData.tail=tail;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});}
function fighterModel(g,military=false){const c=military?0x657b8c:0xa65b49,metal=0x293c4c;const shape=new THREE.Shape();shape.moveTo(0,-8);shape.lineTo(2.8,-2);shape.lineTo(2.2,5);shape.lineTo(-2.2,5);shape.lineTo(-2.8,-2);shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:1.8,bevelEnabled:true,bevelSize:.4,bevelThickness:.4,bevelSegments:1,steps:1});const hullMesh=mesh(geo,c,g);hullMesh.rotation.x=Math.PI/2;hullMesh.position.y=1;const cockpit=ellipsoid(g,0,1.5,-2,1.2,.65,2,0x68a5ba,1);for(const side of [-1,1]){const wing=box(g,side*4.1,0,1,5.2,.35,5.5,c);wing.rotation.z=side*(military?.15:-.12);const engine=mesh(new THREE.CylinderGeometry(.7,1,5,14),metal,g,side*2.7,0,3);engine.rotation.x=Math.PI/2;mesh(new THREE.TorusGeometry(.65,.12,8,16),mat(military?0x8edaff:0xff9a66,2),g,side*2.7,0,5.6);bone(g,V(side*4.3,0,-1),V(side*4.3,0,-5),.16,metal);}g.userData.shipModel=true;}

function getMuzzleOffset(id) {
  if (id === 'pistol') return V(0, 0.038, -0.42);
  if (id === 'rifle') return V(0, 0.035, -0.82);
  if (id === 'shotgun') return V(0, 0.032, -0.76);
  if (id === 'blade') return V(0, 0.05, -0.48);
  if (id === 'sabre') return V(0, 0.05, -0.78);
  if (id === 'tool') return V(0, 0.02, -0.44);
  return V(0, 0.03, -0.5);
}
window.getMuzzleOffset = getMuzzleOffset;
window.equipWeapon = equipWeapon;
window.firePlayer = firePlayer;
window.reloadWeapon = reloadWeapon;
window.makeAvatar = makeAvatar;
window.weaponDefs = weaponDefs;
window.getWeaponView = () => weaponView;
window.getAvatarWeapon = () => avatarWeapon;
window.getAvatar = () => avatar;
window.getRecoil = () => recoil;
window.isAiming = () => aiming;
window.getEquipped = () => equipped;
window.getEquipment = () => equipment;
window.updateAvatarWeapon = updateAvatarWeapon;
window.setTouch = setTouch;
window.isReloadActive = () => reloadActive;
window.getReloadDuration = () => reloadDuration;
window.isMeleeActive = () => meleeActive;
window.getMeleeCombo = () => meleeCombo;
window.getTransientFX = () => transientFX;

function makeWeapon(g, id, isAvatar = false) {
  const metal = 0x222d36, polymer = 0x131920, steel = 0x3d4b58, chrome = 0x7a8e9e, accent = 0xca8c3e;
  const s = isAvatar ? 0.88 : 1.0;

  if (id === 'pistol') {
    // Apex-9 Tactical Combat Handgun
    const frame = new THREE.Group(); frame.name = 'frame'; g.add(frame);
    box(frame, 0, -0.12 * s, 0.06 * s, 0.055 * s, 0.22 * s, 0.09 * s, polymer);
    box(frame, 0, -0.23 * s, 0.07 * s, 0.058 * s, 0.035 * s, 0.10 * s, metal);
    box(frame, 0, -0.06 * s, -0.04 * s, 0.035 * s, 0.09 * s, 0.11 * s, polymer);
    box(frame, 0, -0.05 * s, -0.03 * s, 0.015 * s, 0.05 * s, 0.02 * s, accent);
    box(frame, 0, 0, -0.14 * s, 0.058 * s, 0.065 * s, 0.26 * s, polymer);
    box(frame, 0, -0.05 * s, -0.18 * s, 0.042 * s, 0.04 * s, 0.12 * s, metal);
    mesh(new THREE.CylinderGeometry(0.008 * s, 0.008 * s, 0.02 * s, 8), mat(0x42f5d7, 1.8), frame, 0, -0.05 * s, -0.24 * s).rotation.x = Math.PI / 2;

    const slide = new THREE.Group(); slide.name = 'weaponSlide'; g.add(slide);
    box(slide, 0, 0.04 * s, -0.12 * s, 0.062 * s, 0.065 * s, 0.38 * s, steel);
    for (const z of [-0.02, -0.22]) {
      box(slide, 0, 0.04 * s, z * s, 0.066 * s, 0.055 * s, 0.045 * s, metal);
    }
    box(slide, 0.02 * s, 0.045 * s, -0.08 * s, 0.028 * s, 0.038 * s, 0.09 * s, accent);
    const barrel = mesh(new THREE.CylinderGeometry(0.018 * s, 0.018 * s, 0.12 * s, 10), chrome, slide, 0, 0.038 * s, -0.34 * s);
    barrel.rotation.x = Math.PI / 2;
    box(slide, 0, 0.038 * s, -0.38 * s, 0.056 * s, 0.056 * s, 0.08 * s, metal);
    box(slide, 0, 0.09 * s, -0.04 * s, 0.046 * s, 0.04 * s, 0.08 * s, metal);
    mesh(new THREE.PlaneGeometry(0.03 * s, 0.025 * s), mat(0x42f5d7, 2.2), slide, 0, 0.095 * s, -0.04 * s);

  } else if (id === 'rifle') {
    // Tempest-X Bullpup Military Battle Rifle
    const body = new THREE.Group(); body.name = 'rifleBody'; g.add(body);
    box(body, 0, 0, -0.15 * s, 0.095 * s, 0.16 * s, 0.65 * s, metal);
    box(body, 0, 0.02 * s, -0.52 * s, 0.085 * s, 0.12 * s, 0.38 * s, steel);
    for (const z of [-0.42, -0.52, -0.62]) {
      box(body, 0, 0.02 * s, z * s, 0.092 * s, 0.04 * s, 0.045 * s, 0x0e141a);
    }
    const rBarrel = mesh(new THREE.CylinderGeometry(0.022 * s, 0.022 * s, 0.28 * s, 10), chrome, body, 0, 0.035 * s, -0.72 * s);
    rBarrel.rotation.x = Math.PI / 2;
    box(body, 0, 0.035 * s, -0.80 * s, 0.048 * s, 0.048 * s, 0.07 * s, metal);
    box(body, 0, -0.02 * s, 0.24 * s, 0.075 * s, 0.14 * s, 0.22 * s, polymer);
    box(body, 0, -0.02 * s, 0.35 * s, 0.08 * s, 0.18 * s, 0.04 * s, 0x111114);
    box(body, 0, -0.16 * s, -0.08 * s, 0.055 * s, 0.20 * s, 0.085 * s, polymer);
    box(body, 0, -0.10 * s, -0.18 * s, 0.035 * s, 0.08 * s, 0.12 * s, metal);
    box(body, 0, -0.11 * s, -0.50 * s, 0.045 * s, 0.14 * s, 0.08 * s, polymer);

    const mag = new THREE.Group(); mag.name = 'weaponMag'; g.add(mag);
    box(mag, 0, -0.18 * s, 0.08 * s, 0.058 * s, 0.24 * s, 0.11 * s, polymer);
    mesh(new THREE.PlaneGeometry(0.015 * s, 0.18 * s), mat(0x38efba, 1.8), mag, 0.031 * s, -0.18 * s, 0.08 * s);
    box(body, 0, 0.12 * s, -0.22 * s, 0.065 * s, 0.075 * s, 0.24 * s, metal);
    mesh(new THREE.PlaneGeometry(0.04 * s, 0.04 * s), mat(0x38efba, 2.4), body, 0, 0.125 * s, -0.22 * s);

  } else if (id === 'shotgun') {
    // Havoc-12 Heavy Tactical Plasma Breacher
    const sBody = new THREE.Group(); sBody.name = 'shotgunBody'; g.add(sBody);
    box(sBody, 0, 0, -0.12 * s, 0.11 * s, 0.18 * s, 0.52 * s, metal);
    for (const x of [-0.024 * s, 0.024 * s]) {
      const b = mesh(new THREE.CylinderGeometry(0.024 * s, 0.024 * s, 0.58 * s, 10), steel, sBody, x, 0.032 * s, -0.48 * s);
      b.rotation.x = Math.PI / 2;
    }
    box(sBody, 0, 0.032 * s, -0.74 * s, 0.115 * s, 0.065 * s, 0.06 * s, 0x161c22);
    const pump = new THREE.Group(); pump.name = 'weaponPump'; g.add(pump);
    box(pump, 0, -0.055 * s, -0.42 * s, 0.095 * s, 0.09 * s, 0.26 * s, polymer);
    box(sBody, 0, -0.18 * s, 0.05 * s, 0.06 * s, 0.22 * s, 0.085 * s, polymer);
    box(sBody, 0, -0.03 * s, 0.24 * s, 0.085 * s, 0.16 * s, 0.26 * s, metal);
    for (let i = 0; i < 4; i++) {
      mesh(new THREE.CylinderGeometry(0.012 * s, 0.012 * s, 0.075 * s, 8), mat(0xff5a36, 1.6), sBody, -0.065 * s, -0.02 * s + (i * 0.022 * s), -0.08 * s - (i * 0.035 * s)).rotation.z = Math.PI / 2;
    }

  } else if (id === 'blade') {
    // Vibro-Edge Tactical Combat Tanto
    const hilt = new THREE.Group(); hilt.name = 'bladeHilt'; g.add(hilt);
    box(hilt, 0, -0.14 * s, 0.04 * s, 0.042 * s, 0.22 * s, 0.065 * s, polymer);
    box(hilt, 0, -0.12 * s, -0.02 * s, 0.03 * s, 0.24 * s, 0.025 * s, metal);
    box(hilt, 0, -0.26 * s, 0.04 * s, 0.035 * s, 0.04 * s, 0.05 * s, chrome);
    box(hilt, 0, -0.01 * s, 0.01 * s, 0.055 * s, 0.04 * s, 0.11 * s, metal);

    const bGroup = new THREE.Group(); bGroup.name = 'bladeGeometry'; g.add(bGroup);
    box(bGroup, 0, 0.04 * s, -0.22 * s, 0.028 * s, 0.055 * s, 0.42 * s, steel);
    for (let z = -0.06; z > -0.20; z -= 0.035) {
      box(bGroup, 0, 0.075 * s, z * s, 0.022 * s, 0.02 * s, 0.02 * s, metal);
    }
    mesh(new THREE.BoxGeometry(0.012 * s, 0.03 * s, 0.44 * s), mat(0x64e8ff, 2.0), bGroup, 0, 0.015 * s, -0.24 * s);
    const tip = mesh(new THREE.ConeGeometry(0.035 * s, 0.09 * s, 4), mat(0x64e8ff, 2.2), bGroup, 0, 0.035 * s, -0.47 * s);
    tip.rotation.x = -Math.PI / 2;

  } else if (id === 'sabre') {
    // Nyx High-Energy Plasma Sabre
    const sHilt = new THREE.Group(); sHilt.name = 'sabreHilt'; g.add(sHilt);
    mesh(new THREE.CylinderGeometry(0.028 * s, 0.028 * s, 0.28 * s, 12), metal, sHilt, 0, -0.12 * s, 0);
    for (const y of [-0.04, -0.10, -0.16, -0.22]) {
      mesh(new THREE.TorusGeometry(0.032 * s, 0.006 * s, 6, 12), chrome, sHilt, 0, y * s, 0).rotation.x = Math.PI / 2;
    }
    box(sHilt, 0.03 * s, -0.06 * s, 0, 0.012 * s, 0.03 * s, 0.02 * s, accent);
    mesh(new THREE.CylinderGeometry(0.035 * s, 0.03 * s, 0.06 * s, 12), chrome, sHilt, 0, 0.03 * s, 0);
    for (const ang of [0, Math.PI]) {
      box(sHilt, Math.sin(ang) * 0.032 * s, 0.07 * s, Math.cos(ang) * 0.032 * s, 0.01 * s, 0.05 * s, 0.015 * s, accent);
    }

    const bladeGroup = new THREE.Group(); bladeGroup.name = 'plasmaBlade'; g.add(bladeGroup);
    bladeGroup.rotation.x = -Math.PI / 2;
    bladeGroup.position.set(0, 0.06 * s, 0);
    mesh(new THREE.CylinderGeometry(0.014 * s, 0.014 * s, 0.85 * s, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }), bladeGroup, 0, 0.42 * s, 0);
    mesh(new THREE.CylinderGeometry(0.032 * s, 0.024 * s, 0.88 * s, 12), new THREE.MeshStandardMaterial({
      color: 0x22f5d2, emissive: 0x22f5d2, emissiveIntensity: 2.5, transparent: true, opacity: 0.85, depthWrite: false
    }), bladeGroup, 0, 0.44 * s, 0);
    mesh(new THREE.SphereGeometry(0.032 * s, 8, 8), mat(0x22f5d2, 2.5), bladeGroup, 0, 0.88 * s, 0);

  } else if (id === 'tool') {
    // Ruptor Industrial Mining Rig
    box(g, 0, 0, 0, 0.16 * s, 0.20 * s, 0.38 * s, 0x2a444a);
    box(g, 0, 0.12 * s, -0.06 * s, 0.13 * s, 0.06 * s, 0.22 * s, mat(0x5df5b8, 1.4));
    for (const x of [-0.08 * s, 0.08 * s]) {
      bone(g, V(x, 0.02 * s, -0.18 * s), V(x, 0.02 * s, -0.42 * s), 0.018 * s, 0x8ab8b0);
      mesh(new THREE.SphereGeometry(0.022 * s, 8, 6), mat(0x5df5b8, 2.0), g, x, 0.02 * s, -0.42 * s);
    }
    mesh(new THREE.CylinderGeometry(0.05 * s, 0.05 * s, 0.16 * s, 10), metal, g, 0, -0.12 * s, 0.08 * s).rotation.z = Math.PI / 2;

  } else if (id === 'grenade') {
    // Mk-IV Plasma Ordnance
    ellipsoid(g, 0, 0, 0, 0.085 * s, 0.13 * s, 0.085 * s, 0x2c382f, 1);
    mesh(new THREE.TorusGeometry(0.086 * s, 0.012 * s, 6, 14), mat(0xffa338, 1.5), g, 0, 0, 0).rotation.x = Math.PI / 2;
    box(g, 0, 0.14 * s, 0, 0.05 * s, 0.06 * s, 0.06 * s, metal);
    box(g, 0.025 * s, 0.10 * s, -0.04 * s, 0.015 * s, 0.14 * s, 0.03 * s, chrome);
    mesh(new THREE.TorusGeometry(0.035 * s, 0.008 * s, 6, 12), chrome, g, -0.045 * s, 0.14 * s, 0);
  }
}
let avatarWeapon = null;

function updateAvatarWeapon() {
  if (!avatar) return;
  const rig = avatar.userData?.rig;
  const rightElbow = rig?.userData?.human?.elbows?.[1];
  if (!rightElbow) return;

  let holder = rightElbow.getObjectByName('avatarWeaponHolder');
  if (!holder) {
    holder = new THREE.Group();
    holder.name = 'avatarWeaponHolder';
    // Positioned in character's right hand palm, rotated -90° around X so barrel points forward
    holder.position.set(0, -0.285, 0.015);
    holder.rotation.set(-Math.PI / 2, 0, 0);
    rightElbow.add(holder);
  }
  discardChildren(holder);
  if (mode === 'foot' && equipped && !(equipped === 'grenade' && equipment.grenades <= 0)) {
    makeWeapon(holder, equipped, true);
    holder.traverse(o => {
      o.userData.noCollision = true;
      if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; }
    });
  }
  avatarWeapon = holder;
}

function rebuildWeapon() {
  if (!weaponView) {
    weaponView = new THREE.Group();
    camera.add(weaponView);
    scene.add(camera);
  }
  discardChildren(weaponView);
  makeWeapon(weaponView, equipped, false);
  weaponView.position.set(0.30, -0.28, -0.62);
  weaponView.rotation.set(0, -0.06, 0);
  weaponView.traverse(o => o.userData.noCollision = true);
  updateAvatarWeapon();
}
function animateEntities(dt){for(const a of animals){a.g.userData.legs?.forEach((leg,k)=>leg.rotation.x=Math.sin(totalTime*2.2+k*Math.PI)*.15);if(a.g.userData.tail)a.g.userData.tail.rotation.y=Math.sin(totalTime*.9+a.phase)*.22;}rover.userData.wheels?.forEach(w=>{if(mode==='rover')w.rotation.x-=axisForward()*dt*9;});if (weaponView) {
    weaponView.visible = mode === 'foot' && started && $('panel').classList.contains('hidden');
    recoil = Math.max(0, recoil - dt * 6.5);

    // Natural breathing & footstep bobbing
    const bobX = Math.sin(totalTime * 4.5) * 0.003;
    const bobY = -Math.abs(Math.sin(totalTime * 4.5)) * 0.004;

    let posX = 0.30 + bobX, posY = -0.28 + bobY, posZ = -0.62;
    let rotX = 0, rotY = -0.06, rotZ = 0;

    // Recoil kickback translation & muzzle rise
    const d = weaponDefs[equipped] || {};
    const kickZ = (d.recoil || 0.8) * 0.09;
    const kickRotX = (d.recoil || 0.8) * 0.16;
    posZ += recoil * kickZ;
    rotX += recoil * kickRotX;

    // Slide reciprocation animation on handgun
    const slideMesh = weaponView.getObjectByName('weaponSlide');
    if (slideMesh) {
      slideMesh.position.z = recoil * 0.045;
    }

    // Reload animation sequence
    if (reloadActive) {
      const p = Math.min(1, Math.max(0, (combatTime - reloadStartTime) / reloadDuration));
      if (p < 0.3) {
        // Dip down & tilt left
        const subP = p / 0.3;
        posY -= Math.sin(subP * Math.PI * 0.5) * 0.12;
        rotZ -= Math.sin(subP * Math.PI * 0.5) * 0.45;
        rotX -= Math.sin(subP * Math.PI * 0.5) * 0.20;
      } else if (p < 0.7) {
        // Insert fresh magazine
        posY -= 0.12;
        rotZ -= 0.45;
        rotX -= 0.20;
      } else if (p < 0.9) {
        // Slide rack
        posY -= 0.12 * (1 - (p - 0.7) / 0.2);
        rotZ -= 0.45 * (1 - (p - 0.7) / 0.2);
        if (slideMesh) slideMesh.position.z = Math.sin((p - 0.7) / 0.2 * Math.PI) * 0.05;
      } else {
        // Return to ready
        const subP = (p - 0.9) / 0.1;
        posY += (1 - subP) * -0.04;
      }

      if (p >= 1.0) {
        reloadActive = false;
        if (d.mag) {
          const needed = d.mag - magazines[equipped];
          const available = Math.min(needed, equipment.ammo);
          magazines[equipped] += available;
          equipment.ammo -= available;
        }
      }
    }

    // Melee slash animation sequence
    if (meleeActive) {
      const mp = Math.min(1, Math.max(0, (combatTime - meleeStartTime) / meleeDuration));
      if (meleeCombo === 0) {
        // Diagonal slash top-right to bottom-left
        if (mp < 0.2) {
          posX += (mp / 0.2) * 0.12;
          posY += (mp / 0.2) * 0.10;
          rotY += (mp / 0.2) * 0.45;
          rotZ -= (mp / 0.2) * 0.35;
        } else if (mp < 0.65) {
          const sP = (mp - 0.2) / 0.45;
          posX = 0.42 - sP * 0.65;
          posY = -0.18 - sP * 0.12;
          posZ = -0.62 - Math.sin(sP * Math.PI) * 0.15;
          rotZ = -0.35 + sP * 0.95;
          rotY = 0.45 - sP * 1.1;
          rotX = sP * 0.45;
        } else {
          const rP = (mp - 0.65) / 0.35;
          posX = THREE.MathUtils.lerp(-0.23, 0.30, rP);
          rotZ = THREE.MathUtils.lerp(0.60, 0, rP);
          rotY = THREE.MathUtils.lerp(-0.65, -0.06, rP);
          rotX = THREE.MathUtils.lerp(0.45, 0, rP);
        }
      } else {
        // Horizontal backhand cleave
        if (mp < 0.2) {
          posX -= (mp / 0.2) * 0.15;
          rotY -= (mp / 0.2) * 0.45;
        } else if (mp < 0.65) {
          const sP = (mp - 0.2) / 0.45;
          posX = -0.15 + sP * 0.60;
          posZ = -0.62 - Math.sin(sP * Math.PI) * 0.15;
          rotY = -0.45 + sP * 1.1;
          rotZ = 0.2 - sP * 0.4;
        } else {
          const rP = (mp - 0.65) / 0.35;
          posX = THREE.MathUtils.lerp(0.45, 0.30, rP);
          rotY = THREE.MathUtils.lerp(0.65, -0.06, rP);
        }
      }
      if (mp >= 1.0) meleeActive = false;
    }

    weaponView.position.set(posX, posY, posZ);
    weaponView.rotation.set(rotX, rotY, rotZ);
  }}

function buildStore(parent,p,j,variation){const side=j%2?1:-1,x=side*53,z=-43+Math.floor(j/2)*42,type=storeSets[variation][j],def=storeDefs[type],g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=side<0?Math.PI/2:-Math.PI/2;parent.add(g);const s={id:shops.length,type,def,g,p,portKey:p?p.i:parent.position.x>SEP/2?7:6,entry:V(0,0,15)};shops.push(s);box(g,0,.04,0,27,.12,29,0x687e81);box(g,-13.5,2.75,0,.4,5.5,29,0x536a78);box(g,13.5,2.75,0,.4,5.5,29,0x536a78);box(g,0,2.75,-14.5,27,5.5,.4,0x526b77);for(const side of [-1,1]){box(g,side*8.15,2.65,14.5,10.7,5.3,.35,0x607784);box(g,side*7.4,2.5,14.72,6,2.7,.08,new THREE.MeshStandardMaterial({color:0x759fba,transparent:true,opacity:.35}));}box(g,0,5.6,0,28,.25,30,0x708994);const upper=box(g,0,8.5+(j%2)*1.5,0,26,5+(j%2)*3,28,0x566c79);for(let i=-9;i<=9;i+=4.5)box(g,i,8,14.1,2,1.6,.08,mat(def.color,.3));box(g,0,5.1,14.7,7,.8,.5,def.color);label3D(g,def.name,0,6.25,15.2,20);for(const side of [-1,1])box(g,side*2.6,2.6,14.3,.15,5.2,.2,mat(def.color,.8));
box(g,0,.65,-5.5,8,1.3,1.4,0x435d6c);box(g,0,1.36,-5.5,8.2,.12,1.6,0x9ab0ac);box(g,2.5,1.64,-5.5,1,.5,.1,mat(0x7cd5c5,.6));for(let side of [-1,1]){box(g,side*10,1.8,-5,2.5,3.6,12,0x425b69);for(let z=-9;z<=0;z+=3)for(let y of [1,2.3])box(g,side*9.5,y,z,1.6,.6,1.3,def.color);box(g,side*6,5.25,3,.4,.15,9,mat(0xd1eedc,1.2));}
const display=new THREE.Group();display.position.set(7,1.3,6);g.add(display);box(g,7,.6,6,5,1.2,5,0x546c75);if(type==='ships'){fighterModel(display,false);display.scale.setScalar(.35);}else if(type==='vehicles'){ellipsoid(display,0,.5,0,1.5,.5,2,def.color);for(let a of [-1,1])for(let b of [-1,1])mesh(new THREE.CylinderGeometry(.45,.45,.3,12),0x27383f,display,a*1.4,.2,b*1.3).rotation.z=Math.PI/2;}else if(type==='ranged'||type==='melee'||type==='explosives'){makeWeapon(display,type==='ranged'?'rifle':type==='melee'?'sabre':'grenade');display.scale.setScalar(2);display.rotation.z=.2;}else{mesh(new THREE.OctahedronGeometry(1,1),mat(def.color,.5),display,0,.7,0);}label3D(g,type==='jobs'?'E · CONTRATOS':'E · FALAR COM ATENDENTE',0,3.7,-13.8,13);
const clerk=person(g,0,-7.8,def.color),names=['Clara','Raul','Elisa','Davi','Mila','Theo'];s.clerk=clerk;npcs.push({g:clerk,base:clerk.position.clone(),name:names[j]+' · '+def.short,role:0,phase:j,city:g,shop:s,path:[clerk.position.clone()],way:0,wait:Infinity});g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});}
function openShop(id){const s=shops[id];if(!s)return;if(controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5){toast('Aproxime-se do atendente para negociar.');return;}activeShop=id;menu(s.type==='jobs'?'jobs':'shop');}
function buyProduct(id){if(id.startsWith('outfit_')||id==='jet1'||id==='jet2')return buyV05(id);const s=shops[activeShop],product=products[id];if(!s||!product||!s.def.items.includes(id)||controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5){toast('Fale com o atendente da loja correspondente.');return;}if((id==='rifle'||id==='sabre')&&equipment.weapons.includes(id)||id.startsWith('ship')&&equipment.ships.includes(Number(id.slice(4)))||['scout','hauler','skiff','cutter'].includes(id)&&equipment.vehicles.includes(id)){toast('Você já possui este item.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];if(id==='rifle'||id==='sabre')equipment.weapons.push(id);if(id==='ammo')equipment.ammo+=72;if(id==='grenades')equipment.grenades+=3;if(id==='medkits')equipment.medkits+=2;if(id==='heal'){health=100;suitShield=50;}if(id==='repair'){hull=shipMaxHull();shipShield=140;vehicleHealth=vehicleKind==='hauler'?240:vehicleKind==='scout'?100:150;}if(id.startsWith('ship'))equipment.ships.push(Number(id.slice(4)));if(['scout','hauler','skiff','cutter'].includes(id))equipment.vehicles.push(id);save();toast(product[0]+' adquirido.');renderPanel('shop');}
function equipWeaponBase(id){
  if(id==='grenade'&&equipment.grenades<1){
    toast('Granadas esgotadas.');
    return;
  }
  if(id!=='grenade'&&id!=='tool'&&!equipment.weapons.includes(id)){
    toast('Esse equipamento ainda não foi adquirido.');
    return;
  }
  if(!weaponDefs[id])return;
  equipped=id;
  reloadUntil=0;
  rebuildWeapon();
  if(!$('panel').classList.contains('hidden'))renderPanel('inventory');
}

function useMedkit(){if(equipment.medkits<1){toast('Você está sem kits médicos.');return;}if(health>=100){toast('Sua vida já está completa.');return;}equipment.medkits--;health=Math.min(100,health+55);save();toast('Kit médico utilizado.');}
function selectVehicle(kind){if(!equipment.vehicles.includes(kind)||!landed||rover.parent!==ship||!atPort()||mode==='rover'){toast('Troque em um porto, com o veículo vazio e preso à nave.');return;}remodelRover(kind);rover.position.copy(layout().rover);rover.rotation.set(0,layout().roverYaw,0);save();renderPanel('fleet');toast('Veículo preparado no porão.');}
function fleetSelect(i){if(!equipment.ships.includes(i)){toast('Adquira esta nave em um estaleiro. O mapa mostra os serviços de cada porto.');return;}if(!landed||!atPort()||mode!=='pilot'||mission||rover.parent!==ship){toast('Selecione no cockpit, pousado, sem contrato ativo e com o rover a bordo.');return;}shipType=i;buildShip();hull=shipMaxHull();shipShield=140;enhanceShip();refreshMovingBodies();yaw=0;pitch=0;renderPanel('fleet');}

function shipMaxHull(){return [320,240,450][shipType];}
function spawnEnemy(type,pos,p=null,tag=null){pos=hostilePosition(pos,p);const g=new THREE.Group();g.position.copy(pos);g.userData.combatEnemy=true;scene.add(g);const flying=type==='pirateShip'||type==='militaryShip',beast=type==='animal';let rig=null;if(flying)fighterModel(g,type==='militaryShip');else if(beast)sculptAnimal(g,p.i,true);else{rig=person(g,0,0,type==='military'?0x617886:0x9b6350);const gun=new THREE.Group();gun.position.set(.35,1.2,-.25);rig.add(gun);makeWeapon(gun,'rifle');}if(p)g.quaternion.copy(frameAt(pos,p.center));g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});const e={id:++enemySerial,g,rig,type,p,tag,flying,beast,hp:flying?180:beast?65:90,maxHp:flying?180:beast?65:90,alive:true,origin:pos.clone(),warn:flying?2400:beast?85:125,aggro:flying?850:beast?28:52,alert:false,shotAt:combatTime+1.5,phase:enemySerial*.8};enemies.push(e);return e;}
function initEnemies(){for(const p of planets){for(let k=0;k<2;k++){const n=V(k?.48:-.46,1,k?-.39:.35).normalize();spawnEnemy(k?(p.i%2?'military':'raider'):'animal',p.center.clone().addScaledVector(n,radius(p,n)+.12),p);}}spawnEnemy('pirateShip',V(2700,3700,1400));spawnEnemy('militaryShip',V(-2800,4300,-1600));}
function enemyCenter(e){return e.g.position.clone().addScaledVector(e.p?e.g.position.clone().sub(e.p.center).normalize():UP,e.flying?0:e.beast?1:1.05);}
function enemyName(e){return e.beast?'FAUNA HOSTIL':e.type==='militaryShip'?'CAÇA MILITAR HOSTIL':e.type==='pirateShip'?'PIRATAS ESPACIAIS':e.type==='military'?'SOLDADO HOSTIL':'SAQUEADOR';}
function obstacleDistance(from,to,ignore=null){const delta=to.clone().sub(from),length=delta.length();if(length<.001)return Infinity;const ray=new THREE.Raycaster(from,delta.normalize(),.06,length),mid=from.clone().add(to).multiplyScalar(.5),sphere=new THREE.Sphere(mid,length*.5+2);const candidates=[...queryStatic(mid,length*.5+2),...movingBodies].filter(b=>b.obj.isMesh&&!b.obj.userData.removed&&!hasAncestorFlag(b.obj,'combatEnemy')&&(!ignore||!belongsTo(b.obj,ignore))&&b.world.intersectsSphere(sphere)).map(b=>b.obj);ray.layers.enable(31);const hit=ray.intersectObjects(candidates,false)[0];let best=hit?hit.distance:Infinity;for(const p of planets){const sphereHit=ray.ray.intersectSphere(new THREE.Sphere(p.center,p.r-18),V());if(sphereHit){const d=from.distanceTo(sphereHit);if(d>.1&&d<length)best=Math.min(best,d);}}return best;}
function segmentHit(a,b,center,r){const delta=b.clone().sub(a),length=delta.length();if(length<.001)return a.distanceTo(center)<r?0:null;const ray=new THREE.Ray(a,delta.normalize()),hit=ray.intersectSphere(new THREE.Sphere(center,r),V());if(!hit)return null;const d=a.distanceTo(hit);return d<=length?d:null;}
function particleBurst(pos,color,count=20,power=7){if(!particlesEnabled)return;const max=quality==='low'?100:360;for(let j=0;j<count&&combatParticles.length<max;j++){const v=V(combatRng()-.5,combatRng()-.3,combatRng()-.5).normalize().multiplyScalar(power*(.3+combatRng()));combatParticles.push({pos:pos.clone(),v,life:.3+combatRng()*.8,color:new THREE.Color(color)});}}
const transientFX=[];
function traceFX(from, to, color = 0x42f5d7, isPellet = false) {
  const dir = to.clone().sub(from);
  const dist = dir.length();
  if (dist < 0.05) return;
  dir.normalize();

  // 1. 3D Muzzle Flash Starburst at barrel tip
  if (!isPellet) {
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
      depthWrite: false
    });
    const flashMesh = mesh(new THREE.ConeGeometry(0.065, 0.18, 6), flashMat, scene, from.x, from.y, from.z);
    flashMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
    flashMesh.userData.noCollision = true;
    transientFX.push({
      o: flashMesh,
      life: 0.05,
      ttl: 0.05,
      update: (dt, p) => {
        flashMesh.scale.setScalar(1 + (1 - p) * 1.6);
        flashMat.opacity = p * 0.95;
      }
    });
  }

  // 2. High-Velocity 3D Energized Plasma Bolt Tracer
  const boltLen = Math.min(1.5, Math.max(0.45, dist * 0.18));
  const boltRadius = isPellet ? 0.024 : 0.042;
  const boltGeo = new THREE.CylinderGeometry(boltRadius * 0.4, boltRadius, boltLen, 6);
  const boltMat = new THREE.MeshBasicMaterial({
    color: color,
    transparent: true,
    opacity: 0.95,
    depthWrite: false
  });
  const boltMesh = new THREE.Mesh(boltGeo, boltMat);
  boltMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
  boltMesh.position.copy(from).addScaledVector(dir, boltLen * 0.5);
  boltMesh.userData.noCollision = true;
  scene.add(boltMesh);

  const speed = isPellet ? 650 : 850;
  const duration = Math.min(0.25, Math.max(0.05, dist / speed));
  let elapsed = 0;

  transientFX.push({
    o: boltMesh,
    life: duration,
    ttl: duration,
    update: (dt, p) => {
      elapsed += dt;
      const progress = Math.min(1, elapsed / duration);
      const curPos = from.clone().lerp(to, progress);
      boltMesh.position.copy(curPos);
      boltMat.opacity = Math.min(1, p * 1.8);
      if (progress >= 0.96 && dist > 1.2) {
        particleBurst(to, color, isPellet ? 8 : 18, 2.5);
      }
    }
  });
}
function blastFX(pos,r=8){if(audioContext&&pos.distanceTo(controlledPosition())<2500){tone(48,audioContext.currentTime,.5,.13,fxBus,'sawtooth');tone(90,audioContext.currentTime,.3,.08,fxBus,'triangle');}const o=mesh(new THREE.IcosahedronGeometry(1,1),new THREE.MeshBasicMaterial({color:0xffb47b,transparent:true,opacity:.65,wireframe:true,depthWrite:false,toneMapped:false}),scene,...pos.toArray());o.userData.noCollision=true;transientFX.push({o,life:.55,ttl:.55,r});particleBurst(pos,0xffb866,36,r*2);}
function damageEnemy(e,damage){if(!e.alive)return;e.hp-=damage;e.alert=true;particleBurst(enemyCenter(e),e.beast?0xb5bf98:0xffc482,6,3);if(e.hp<=0){e.alive=false;e.g.visible=false;e.g.traverse(o=>o.userData.removed=true);blastFX(enemyCenter(e),e.flying?16:2.5);if(mission?.combat&&mission.tag===e.tag)mission.kills++;credits+=e.flying?120:30;save();toast(enemyName(e)+' neutralizado.');}}
function playerTarget(){if(mode==='pilot'||inside)return {pos:ship.position.clone().add(V(0,1,0)),r:6,vehicle:'ship'};if(mode==='rover')return {pos:rover.getWorldPosition(V()).add(V(0,1,0)),r:2,vehicle:'rover'};const up=eva?UP:player.clone().sub((groundPlanet||nearest(player)).center).normalize();return {pos:player.clone().addScaledVector(up,-.8),r:.7,vehicle:'suit'};}
function hurtPlayer(amount){if(safeZone(controlledPosition())||boost)return;lastHurt=combatTime;damageFlash=Math.min(.7,damageFlash+.3);if(mode==='pilot'||inside){const shield=Math.min(shipShield,amount);shipShield-=shield;hull-=amount-shield;}else if(mode==='rover')vehicleHealth-=amount;else{const shield=Math.min(suitShield,amount);suitShield-=shield;health-=amount-shield;}if(health<=0||hull<=0||vehicleHealth<=0)emergencyRespawn();}
function emergencyRespawn(){const pos=controlledPosition(),port=destinations.filter(d=>!d.gate&&d.kind!=='water').reduce((a,b)=>pos.distanceTo(a.pos)<pos.distanceTo(b.pos)?a:b);clearCombatMission();if(mission)resetJobObjects(mission);mission=null;clearMissionCargo();cargo=0;credits=Math.max(0,credits-150);health=100;suitShield=50;hull=shipMaxHull();shipShield=140;vehicleHealth=vehicleKind==='hauler'?240:vehicleKind==='scout'?100:150;auto=null;boost=null;landed=true;ship.position.copy(port.pos).add(port.p?planetUp(port.pos,port.p).multiplyScalar(2):V(0,2,0));ship.quaternion.copy(port.p?frameAt(port.pos,port.p.center):new THREE.Quaternion());resetFootMotion();mode='pilot';inside=true;eva=false;flightSpeed=0;groundPlanet=port.p||null;station=port.station||null;firing=false;keys.KeyW=keys.KeyS=false;touchX=touchY=0;save();toast('Resgate de emergência ao porto. Serviço: até 150 CR.');}
// === REALISTIC PROCEDURAL WEAPON SOUND SYNTHESIZER ===
function playWeaponSound(id) {
  if (!audioContext) return;
  const t = audioContext.currentTime;

  if (id === 'pistol') {
    // Sharp supersonic crack + low chamber punch + slide cycle
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(260, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.08);
    g.gain.setValueAtTime(0.40, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.10);

    tone(720, t, 0.025, 0.28, fxBus, 'square'); // high snap
    tone(180, t + 0.04, 0.05, 0.14, fxBus, 'triangle'); // mechanical slide click

  } else if (id === 'rifle') {
    // Heavy military bullpup rifle crack
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(310, t);
    osc.frequency.exponentialRampToValueAtTime(50, t + 0.10);
    g.gain.setValueAtTime(0.42, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.12);

    tone(850, t, 0.02, 0.30, fxBus, 'square'); // supersonic snap
    tone(140, t + 0.045, 0.06, 0.18, fxBus, 'sawtooth'); // bolt cycle

  } else if (id === 'shotgun') {
    // Thunderous plasma scattergun blast + pump rack
    const osc = audioContext.createOscillator();
    const g = audioContext.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(26, t + 0.22);
    g.gain.setValueAtTime(0.75, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
    osc.connect(g).connect(fxBus);
    osc.start(t); osc.stop(t + 0.25);

    tone(460, t, 0.05, 0.38, fxBus, 'square');
    tone(200, t + 0.02, 0.10, 0.32, fxBus, 'sawtooth');

    // Mechanical pump action rack "CLACK-CHUCK" 0.35s later
    tone(240, t + 0.34, 0.05, 0.18, fxBus, 'square');
    tone(150, t + 0.40, 0.07, 0.20, fxBus, 'sawtooth');

  } else if (id === 'blade') {
    tone(480, t, 0.09, 0.18, fxBus, 'sawtooth');
    tone(240, t + 0.02, 0.08, 0.14, fxBus, 'triangle');

  } else if (id === 'sabre') {
    tone(110, t, 0.16, 0.26, fxBus, 'sawtooth');
    tone(360, t + 0.02, 0.12, 0.20, fxBus, 'sine');
    tone(580, t + 0.04, 0.08, 0.18, fxBus, 'triangle');

  } else if (id === 'tool') {
    tone(160, t, 0.18, 0.18, fxBus, 'sawtooth');
    tone(320, t + 0.05, 0.12, 0.14, fxBus, 'triangle');

  } else {
    tone(110, t, 0.10, 0.15, fxBus, 'square');
  }
}
window.playWeaponSound = playWeaponSound;

let reloadActive = false, reloadDuration = 1.6, reloadStartTime = 0;
let meleeActive = false, meleeDuration = 0.38, meleeStartTime = 0, meleeCombo = 0;

function reloadWeapon() {
  const d = weaponDefs[equipped];
  if (!d.mag || reloadUntil > combatTime || magazines[equipped] >= d.mag || equipment.ammo < 1) return;
  reloadDuration = equipped === 'pistol' ? 1.35 : equipped === 'shotgun' ? 1.9 : 1.65;
  reloadUntil = combatTime + reloadDuration;
  reloadActive = true;
  reloadStartTime = combatTime;
  toast('Recarregando ' + d.name + '…');

  if (audioContext) {
    tone(240, audioContext.currentTime + 0.1, 0.08, 0.05, fxBus, 'triangle');
    tone(180, audioContext.currentTime + reloadDuration * 0.5, 0.12, 0.08, fxBus, 'square');
    tone(320, audioContext.currentTime + reloadDuration * 0.78, 0.07, 0.05, fxBus, 'sawtooth');
  }
}

function firePlayer() {
  if (equipped === 'tool' && mode === 'foot' && !resting && started && $('panel').classList.contains('hidden')) {
    if (combatTime - lastShot > 0.5) { lastShot = combatTime; scan(); }
    return;
  }
  if (resting || !started || !$('panel').classList.contains('hidden') || reloadUntil > combatTime || mode === 'rover') return;
  const naval = mode === 'pilot';
  const d = naval ? { damage: 30, range: 2400, rate: 0.18, soundPitch: 85 } : weaponDefs[equipped];
  if (combatTime - lastShot < (naval ? 0.18 : d.rate)) return;
  if (safeZone(controlledPosition())) {
    if (combatTime - lastShot > 2) toast('Armamento desativado na área civil.');
    lastShot = combatTime;
    return;
  }
  if (boost) return;

  if (!naval && d.mag && magazines[equipped] < 1) {
    reloadWeapon();
    return;
  }
  if (!naval && equipped === 'grenade' && equipment.grenades < 1) {
    toast('Sem granadas.');
    lastShot = combatTime;
    return;
  }

  lastShot = combatTime;
  recoil = 1.0;

  // Melee attack handling
  if (!naval && (equipped === 'blade' || equipped === 'sabre')) {
    meleeActive = true;
    meleeStartTime = combatTime;
    meleeDuration = equipped === 'sabre' ? 0.36 : 0.40;
    meleeCombo = (meleeCombo + 1) % 2;
    playWeaponSound(equipped);

    const dir = aimDirection(naval);
    const from = (inside ? shipPoint(foot) : player.clone()).add(V(0, 1.4, 0));

// Slash visual feedback handled cleanly via impact sparks

    const to = from.clone().addScaledVector(dir, d.range);
    let chosen = null, nearestHit = d.range;
    for (const e of enemies) {
      if (!e.alive) continue;
      const hit = segmentHit(from, to, enemyCenter(e), e.flying ? 6 : e.beast ? 2.0 : 1.4);
      if (hit !== null && hit < nearestHit) { chosen = e; nearestHit = hit; }
    }
    if (chosen) {
      damageEnemy(chosen, d.damage);
      particleBurst(from.clone().addScaledVector(dir, nearestHit), d.color, 16, 2.5);
    }
    return;
  }

  // Calculate true 3D barrel tip position
  const dir = aimDirection(naval);
  let from;
  if (naval) {
    from = shipPoint(V(0, 1.7, -layout().halfZ - 1.5));
  } else {
    if (!thirdPerson && weaponView) {
      weaponView.updateMatrixWorld(true);
      from = weaponView.localToWorld(getMuzzleOffset(equipped).clone());
    } else if (thirdPerson && avatarWeapon) {
      avatarWeapon.updateMatrixWorld(true);
      from = avatarWeapon.localToWorld(getMuzzleOffset(equipped).clone());
    } else {
      from = (inside ? shipPoint(foot) : player.clone()).add(V(0, 1.4, 0)).addScaledVector(dir, 0.5);
    }
  }

  if (!naval && equipped === 'grenade') {
    equipment.grenades--;
    const o = mesh(new THREE.IcosahedronGeometry(0.16, 1), 0xc9aa66, scene, ...from.toArray());
    o.userData.noCollision = true;
    projectiles.push({ o, pos: from.clone(), v: dir.multiplyScalar(32).add(V(0, 7, 0)), life: 1.8, grenade: true });
    if (equipment.grenades <= 0) {
      const fallback = equipment.weapons[0] || 'pistol';
      toast('Granadas esgotadas. Alternando para ' + weaponDefs[fallback].name);
      equipWeapon(fallback);
    }
    return;
  }

  if (!naval && d.mag) {
    magazines[equipped]--;
    if (magazines[equipped] === 0) reloadWeapon();
  }

  // Camera recoil kick
  if (!naval && !thirdPerson) {
    pitch = THREE.MathUtils.clamp(pitch + (d.recoil || 0.5) * 0.024, -1.35, 1.35);
  }

  if (naval) {
    if (audioContext) tone(85, audioContext.currentTime, 0.12, 0.10, fxBus, 'sawtooth');
  } else {
    playWeaponSound(equipped);
  }

  // Shotgun multi-pellet spread
  if (!naval && equipped === 'shotgun') {
    const pelletCount = d.pellets || 6;
    for (let p = 0; p < pelletCount; p++) {
      const spreadDir = dir.clone().add(new THREE.Vector3(
        (Math.random() - 0.5) * 0.08,
        (Math.random() - 0.5) * 0.08,
        (Math.random() - 0.5) * 0.08
      )).normalize();

      const to = from.clone().addScaledVector(spreadDir, d.range);
      const blocked = obstacleDistance(from, to, null);
      let chosen = null, nearestHit = Math.min(d.range, blocked);
      for (const e of enemies) {
        if (!e.alive) continue;
        const hit = segmentHit(from, to, enemyCenter(e), e.flying ? 7 : e.beast ? 1.4 : 0.85);
        if (hit !== null && hit < nearestHit) { chosen = e; nearestHit = hit; }
      }
      if (chosen) damageEnemy(chosen, Math.round(d.damage / pelletCount));
      traceFX(from, from.clone().addScaledVector(spreadDir, nearestHit), d.color || 0xff6b38, true);
    }
    return;
  }

  // Single projectile / laser bolt
  const to = from.clone().addScaledVector(dir, d.range);
  const blocked = obstacleDistance(from, to, naval ? ship : null);
  let chosen = null, nearestHit = Math.min(d.range, blocked);
  for (const e of enemies) {
    if (!e.alive) continue;
    const hit = segmentHit(from, to, enemyCenter(e), e.flying ? 7 : e.beast ? 1.4 : 0.85);
    if (hit !== null && hit < nearestHit) { chosen = e; nearestHit = hit; }
  }
  if (chosen) damageEnemy(chosen, d.damage);
  traceFX(from, from.clone().addScaledVector(dir, nearestHit), naval ? 0x8fe7ff : (d.color || 0x38efba), false);
}
function enemyFire(e,target){const from=enemyCenter(e),delta=target.pos.clone().sub(from),dist=delta.length();if(obstacleDistance(from,target.pos,target.vehicle==='ship'?ship:target.vehicle==='rover'?rover:null)<dist-1)return;const speed=e.flying?360:100,lead=mode==='pilot'?shipVelocity.clone().multiplyScalar(dist/speed*.35):V();const velocity=target.pos.clone().add(lead).sub(from).normalize().multiplyScalar(speed),o=mesh(new THREE.SphereGeometry(e.flying?.35:.07,6,4),new THREE.MeshBasicMaterial({color:0xff9869,toneMapped:false}),scene,...from.toArray());o.userData.noCollision=true;projectiles.push({o,pos:from.clone(),v:velocity,life:e.flying?5:2,damage:e.flying?19:9,enemy:true});}
function explodeGrenade(b){blastFX(b.pos,14);for(const e of enemies)if(e.alive){const dist=enemyCenter(e).distanceTo(b.pos);if(dist<14&&obstacleDistance(b.pos,enemyCenter(e))>=dist-1)damageEnemy(e,125*(1-dist/20));}const target=playerTarget(),dist=target.pos.distanceTo(b.pos);if(dist<12&&obstacleDistance(b.pos,target.pos)>=dist-1)hurtPlayer(90*(1-dist/14));}
function updateProjectiles(dt){const target=playerTarget();for(let i=projectiles.length-1;i>=0;i--){const b=projectiles[i],old=b.pos.clone();b.life-=dt;if(b.grenade){const p=nearest(b.pos),n=b.pos.clone().sub(p.center).normalize();b.v.addScaledVector(n,-7*dt);}const next=b.pos.clone().addScaledVector(b.v,dt),dist=old.distanceTo(next),wall=obstacleDistance(old,next,b.enemy?(target.vehicle==='ship'?ship:target.vehicle==='rover'?rover:null):null);if(wall<dist){b.pos.copy(old).addScaledVector(b.v.clone().normalize(),Math.max(0,wall-.1));if(b.grenade){b.v.multiplyScalar(-.15);b.life=Math.min(b.life,.2);}else{b.life=0;particleBurst(b.pos,0xffba78,5,3);}}else b.pos.copy(next);if(b.enemy&&segmentHit(old,b.pos,target.pos,target.r)!==null){hurtPlayer(b.damage);b.life=0;}b.o.position.copy(b.pos);if(b.life<=0){if(b.grenade)explodeGrenade(b);scene.remove(b.o);b.o.geometry.dispose();b.o.material.dispose();projectiles.splice(i,1);}}}
function updateEnemy(e,dt,target){if(!e.alive)return;const center=enemyCenter(e),distance=center.distanceTo(target.pos);if(distance>e.warn*2)return;const protectedArea=safeZone(target.pos);if(!protectedArea&&(distance<e.aggro||e.alert))e.alert=true;if(protectedArea||distance>e.warn*1.8)e.alert=false;const destination=e.alert?target.pos:e.origin;const delta=destination.clone().sub(e.g.position);if(e.flying){if(e.alert){const desired=distance>350?delta:V(Math.cos(combatTime+e.phase)*200,Math.sin(combatTime*.5)*30,Math.sin(combatTime+e.phase)*200);e.g.position.addScaledVector(desired.normalize(),dt*(e.type==='militaryShip'?90:75));const p=nearest(e.g.position),n=e.g.position.clone().sub(p.center).normalize();if(e.g.position.distanceTo(p.center)<p.r+160)e.g.position.copy(p.center).addScaledVector(n,p.r+160);const m=new THREE.Matrix4().lookAt(e.g.position,target.pos,UP);e.g.quaternion.slerp(new THREE.Quaternion().setFromRotationMatrix(m),dt*2);}else{e.g.position.copy(e.origin).add(V(Math.sin(combatTime*.08+e.phase)*55,Math.cos(combatTime*.11+e.phase)*15,Math.cos(combatTime*.08+e.phase)*55));e.g.rotation.y=combatTime*.03+e.phase;}}
else{const up=e.g.position.clone().sub(e.p.center).normalize(),frame=frameAt(e.g.position,e.p.center),flat=delta.addScaledVector(up,-delta.dot(up));if(e.alert&&distance>(e.beast?2.4:22)){const speed=e.beast?4.3:2.7,eye=e.g.position.clone().addScaledVector(up,1.8),next=moveActor(eye,flat.clone().normalize().multiplyScalar(speed*dt),{up,p:e.p,height:1.8,r:e.beast?.7:.38,ignore:e.g});e.g.position.copy(next.addScaledVector(up,-1.8));}const look=flat.applyQuaternion(frame.clone().invert());e.g.quaternion.copy(frame).multiply(new THREE.Quaternion().setFromAxisAngle(UP,Math.atan2(-look.x,-look.z)));const walk=e.alert?Math.sin(combatTime*(e.beast?9:5)+e.phase)*.42:Math.sin(combatTime*.8+e.phase)*.025;if(e.rig)animateHuman(e.rig,dt);e.g.userData.legs?.forEach((l,k)=>l.rotation.x=walk*(k%2?1:-1));}
if(e.alert&&combatTime>=e.shotAt){if(e.beast){if(distance<3.4){hurtPlayer(14);e.shotAt=combatTime+1.3;}}else if(distance<(e.flying?1200:85)){enemyFire(e,target);e.shotAt=combatTime+(e.flying?1.25:1.7);}}}
function randomAmbush(){if(combatTime<ambushAt)return;ambushAt=combatTime+120+combatRng()*120;const pos=controlledPosition();if(safeZone(pos)||boost||auto||enemies.filter(e=>e.alive&&e.g.position.distanceTo(pos)<3000).length>6)return;if(combatRng()>.20)return;ambushAt=combatTime+480;const air=atmosphereAt(pos);if(mode==='pilot'||eva){for(let j=0;j<2;j++){const dir=V(combatRng()-.5,.2,combatRng()-.5).normalize(),e=spawnEnemy('pirateShip',pos.clone().addScaledVector(dir,1500+j*200));e.alert=true;e.shotAt=combatTime+6;}}else{const p=air.p,q=frameAt(pos,p.center);for(let j=0;j<2;j++){const point=surfacePoint(pos.clone().add(V(65+j*10,0,45).applyQuaternion(q)),p,.1),e=spawnEnemy('raider',point,p);e.alert=true;e.shotAt=combatTime+6;}}toast('Sinais hostis próximos. Você pode enfrentar ou se afastar.');}
function updateCombat(dt){combatTime+=dt;damageFlash=Math.max(0,damageFlash-dt*.7);if(reloadUntil>0&&combatTime>=reloadUntil){const d=weaponDefs[equipped];if(d.mag){const needed=Math.min(d.mag-magazines[equipped],equipment.ammo);magazines[equipped]+=needed;equipment.ammo-=needed;}reloadUntil=0;}if(combatTime-lastHurt>8){suitShield=Math.min(50,suitShield+dt*4);shipShield=Math.min(140,shipShield+dt*10);}if(mode==='foot'&&weaponDefs[equipped].mag&&magazines[equipped]===0&&reloadUntil===0&&equipment.ammo>0)reloadWeapon();if(firing)firePlayer();const target=playerTarget();for(const e of enemies)updateEnemy(e,dt,target);updateProjectiles(dt);randomAmbush();}
function initCombatJobs(){jobDefs.push(['hunt','Controle de fauna','Enfrente três predadores hostis fora do porto.',1500],['bounty','Caçada a saqueadores','Neutralize três piratas em solo.',2000],['patrol','Interceptação orbital','Derrote dois caças militares hostis.',3200]);}
function acceptCombat(type){if(mission){toast('Conclua ou cancele o contrato atual.');return;}const port=atPort();if(!port){toast('Aceite o contrato em um porto ou central de missões.');return;}const def=jobDefs.find(d=>d[0]===type),p=port.p||planets[0],tag='combat-'+(++enemySerial);mission={type,combat:true,origin:destinations.indexOf(port),tag,kills:0,need:type==='patrol'?2:3,reward:def[3],label:def[1]};const stPos=(destinations.find(d=>d.station)?.pos.clone()||V(1800,2300,2400));const base=type==='patrol'?stPos.add(V(1400,900,-900)):p.center.clone().addScaledVector(V(type==='hunt'?.48:-.52,1,.32).normalize(),p.r+2);for(let j=0;j<mission.need;j++){const point=base.clone().add(type==='patrol'?V(j*140,0,j*180):V(j*8,0,j*5));spawnEnemy(type==='patrol'?'militaryShip':type==='hunt'?'animal':'raider',type==='patrol'?point:surfacePoint(point,p,.12),type==='patrol'?null:p,tag);}toast('Contrato de combate aceito. O HUD indica os alvos.');renderPanel('jobs');}
function completeCombat(){if(!atPort()){toast('Retorne a um porto para receber.');return;}if(mission.kills<mission.need){toast('Ainda há inimigos do contrato ativos.');return;}credits+=mission.reward;mission=null;save();toast('Contrato concluído. Pagamento recebido!');renderPanel('jobs');}
function clearCombatMission(){if(!mission?.combat)return;for(const e of enemies)if(e.tag===mission.tag&&e.alive){e.alive=false;e.g.visible=false;e.g.traverse(o=>o.userData.removed=true);}}
function combatGoal(){if(!mission?.combat)return null;const pos=controlledPosition(),targets=enemies.filter(e=>e.alive&&e.tag===mission.tag);if(targets.length){const e=targets.reduce((a,b)=>a.g.position.distanceTo(pos)<b.g.position.distanceTo(pos)?a:b);return {pos:enemyCenter(e),label:'ALVO · '+enemyName(e)};}const port=destinations.filter(d=>!d.gate&&d.kind!=='water').reduce((a,b)=>a.pos.distanceTo(pos)<b.pos.distanceTo(pos)?a:b);return {pos:port.pos,label:'RECEBER RECOMPENSA'};}


function setTouch(value){if(!value)autoForward=false;touchEnabled=value;document.body.classList.toggle('touch',touchEnabled);clearInput();}

function showActions(){toggleActionStrip();}
function renderPanelV04(tab){$('panelTabs').querySelectorAll?.('button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));let html='';if(tab==='settings'){html=`<div class="eyebrow">MENU DA EXPEDIÇÃO</div><h2>Seu ritmo. Seu universo.</h2><div class="settingsGrid"><section><h3>Sensibilidade</h3><label>Câmera <input type="range" aria-label="Sensibilidade da câmera" min="0.25" max="4" step="0.05" value="${controlPrefs.camera}" oninput="setSensitivity('camera',this.value)"></label><label>Nave <input type="range" aria-label="Sensibilidade da nave" min="0.25" max="4" step="0.05" value="${controlPrefs.ship}" oninput="setSensitivity('ship',this.value)"></label><p>Scroll ou pinça apenas à direita: zoom. Dois dedos para cima à esquerda: levantar do assento. Botão do meio do mouse: alternar rotação da nave / câmera livre.</p></section>${performanceSettings()}<section><h3>Áudio</h3><label>Música <input type="range" aria-label="Volume da música" min="0" max="100" value="${Math.round(musicVolume*100)}" oninput="setVolume('music',this.value)"></label><label>Efeitos <input type="range" aria-label="Volume dos efeitos" min="0" max="100" value="${Math.round(fxVolume*100)}" oninput="setVolume('fx',this.value)"></label><button onclick="toggleAudio();renderPanel('settings')">${audioMuted?'Ativar':'Silenciar'} áudio</button></section><section><h3>Gráficos e interface</h3><label>Qualidade <select aria-label="Qualidade gráfica" onchange="applyQuality(this.value);renderPanel('settings')">${[['low','Leve'],['medium','Equilibrado'],['high','Detalhado']].map(x=>`<option value="${x[0]}" ${quality===x[0]?'selected':''}>${x[1]}</option>`).join('')}</select></label><label><input type="checkbox" ${particlesEnabled?'checked':''} onchange="setPerformance('particles',this.checked)"> Partículas</label><label><input type="checkbox" ${touchEnabled?'checked':''} onchange="setTouch(this.checked)"> Controles de toque</label><label><input type="checkbox" ${guideEnabled?'checked':''} onchange="toggleGuide()"> Indicador de objetivo</label></section></div><details><summary>Água e clima</summary><p>Compre Náiade ou Pelágico nas garagens e prepare a embarcação na aba Frota, em um porto com o veículo a bordo. Use as pequenas rodas para entrar e sair pela rampa. O mapa tem pontos de Mar aberto. A pé, entre na água para nadar; pulo usa o jetpack para emergir. Eventos naturais raros avisam com 15 segundos de antecedência. Busque abrigo na nave ou cidade.</p></details><details open><summary>Controles</summary><p><b>Computador:</b> WASD move; mouse olha; Shift acelera; clique esquerdo ataca; 1–4 seleciona arma; R recarrega; C usa kit médico.<br>E interage; B embarca/sai; F usa a ferramenta; O abre a rampa; T retorna à nave; Espaço/Ctrl sobe/desce; L pousa; X freia; P cancela o piloto automático.<br><b>Celular:</b> arraste à esquerda para mover e à direita para olhar. Toque ataca; duplo à esquerda ativa corrida/cruzeiro; duplo à direita interage ou alterna câmera livre da nave. Duplo segurado pula; mantenha até começar a cair para usar o jetpack. Segure à direita para mirar. Segure o botão de equipamento para escolher; deslize a partir dele para recarregar.<br>Esc ou o botão ☰ abre este menu. O mundo pausa enquanto ele está aberto.</p></details><button class="primary" onclick="closeMenu()">VOLTAR AO JOGO</button>`;}
else if(tab==='map'){html=`<div class="eyebrow">SISTEMA ${currentSystem.name} · COORDENADAS [${currentSystem.x}, ${currentSystem.y}]</div><h2>Navegação</h2><p>Planetas, estações orbitais e corredores de 10 arcos deste sistema. Cada arco leva a um sistema estelar vizinho.</p><div class="cards">`;destinations.forEach((d,i)=>{const dist=(ship.position.distanceTo(d.pos)/1000).toFixed(1);const info=d.gate?`Impulso para Sistema ${d.targetSystemName} · ${d.numGates||3} arcos disponíveis`:shops.filter(s=>s.portKey===i).map(s=>s.def.short).join(' · ')||(d.kind==='water'?'Água navegável':'Área de pouso');html+=`<button class="card ${target===i?'selected':''}" onclick="choose(${i})"><small>${currentSystem.name} · ${dist} km</small><strong>${d.name}</strong><span>${info}</span></button>`;});html+='</div><button class="primary" onclick="engage()">INICIAR VIAGEM</button>';}
else if(tab==='inventory'){html=`<div class="eyebrow">${credits.toLocaleString('pt-BR')} CR</div><h2>Inventário</h2><p>Munição reserva: ${equipment.ammo} · Granadas: ${equipment.grenades} · Kits médicos: ${equipment.medkits}</p><div class="cards">${[...equipment.weapons,'grenade','tool'].map(id=>`<button class="card ${equipped===id?'selected':''}" onclick="equipWeapon('${id}')"><small>${equipped===id?'EQUIPADA':'EQUIPAR'}</small><strong>${weaponDefs[id].name}</strong><span>${weaponDefs[id].damage} de dano · ${weaponDefs[id].range} m de alcance</span></button>`).join('')}</div><button onclick="useMedkit();renderPanel('inventory')">USAR KIT MÉDICO · ${Math.round(health)}/100</button><p>Armas são utilizadas fora das áreas civis. Os canhões da nave são selecionados automaticamente no cockpit.</p>`;}
else if(tab==='jobs'){html='<div class="eyebrow">REDE CIVIL · NOVE ATIVIDADES</div><h2>Contratos</h2><p>'+(mission?'Ativo: '+mission.label:'Aceite em um porto ou converse na central de missões.')+'</p><div class="cards">';for(const d of jobDefs)html+=`<button class="card" onclick="accept('${d[0]}')"><small>${d[3]} CR</small><strong>${d[1]}</strong><span>${d[2]}</span></button>`;html+='</div><button class="primary" onclick="finishJob()">RECEBER PAGAMENTO</button> <button onclick="cancelJob()">CANCELAR CONTRATO</button>';}
else if(tab==='fleet'){html='<div class="eyebrow">EQUIPAMENTOS ADQUIRIDOS</div><h2>Frota e garagem</h2><p>Novos modelos são vendidos nas lojas. Prepare a nave no cockpit, pousado em um porto, sem contrato e com o rover a bordo.</p><div class="cards">';shipTypes.forEach((t,i)=>html+=`<button class="card" onclick="fleetSelect(${i})"><small>${equipment.ships.includes(i)?'ADQUIRIDA':'DISPONÍVEL EM ESTALEIROS'}</small><strong>${t.name}</strong><span>${layouts[i].desc}</span></button>`);html+='</div><div class="cards">';for(const kind of equipment.vehicles)html+=`<button class="card" onclick="selectVehicle('${kind}')"><small>${vehicleKind===kind?'ATUAL':'PREPARAR'}</small><strong>${kind==='skiff'?'Náiade · lancha':kind==='cutter'?'Pelágico · utilitário':kind==='rover'?'Rover':kind==='scout'?'Explorador':'Blindado'}</strong><span>${kind==='skiff'?'26 m/s na água · anfíbia':kind==='cutter'?'18 m/s na água · anfíbio':kind==='scout'?'24 m/s · 100 de integridade':kind==='hauler'?'14 m/s · 240 de integridade':'18 m/s · 150 de integridade'}</span></button>`;html+='</div>';}
else if(tab==='shop'){const s=shops[activeShop];if(!s){menu('settings');return;}html=`<div class="eyebrow">ATENDIMENTO LOCAL · ${credits.toLocaleString('pt-BR')} CR</div><h2>${s.def.short}</h2><p>Escolha um produto. Equipamentos comprados ficam disponíveis no inventário e na frota.</p><div class="cards">${s.def.items.map(id=>`<button class="card" onclick="buyProduct('${id}')"><small>${products[id][1]} CR</small><strong>${products[id][0]}</strong><span>${products[id][2]}</span></button>`).join('')}</div>`;}else html='<h2>Menu</h2>';$('content').innerHTML=html;}
function updateCombatHud(){const pos=controlledPosition(),aboard=mode==='pilot'||inside,value=aboard?hull:mode==='rover'?vehicleHealth:health,max=aboard?shipMaxHull():mode==='rover'?(vehicleKind==='hauler'?240:vehicleKind==='scout'?100:150):100,shield=aboard?shipShield:mode==='rover'?0:suitShield;$('vitalFill').style.width=Math.max(0,value/max*100)+'%';$('shieldFill').style.width=Math.max(0,shield/(aboard?140:50)*100)+'%';$('vitalText').textContent=(aboard?'NAVE':mode==='rover'?'VEÍCULO':'TRAJE')+' '+Math.ceil(value)+' / '+max;$('weaponStatus').textContent=mode==='pilot'?'CANHÕES DE PULSO':mode==='rover'?'VEÍCULO':weaponDefs[equipped].name.toUpperCase()+(reloadUntil>combatTime?' · RECARREGANDO':weaponDefs[equipped].mag?' · '+magazines[equipped]+' / '+equipment.ammo:equipped==='grenade'?' · '+equipment.grenades:'');$('weaponTouch').textContent=mode==='pilot'?'Canhões':'Arma';threat=null;let distance=Infinity;for(const e of enemies){if(!e.alive)continue;const d=e.g.position.distanceTo(pos);if(d<e.warn&&d<distance&&!safeZone(pos)){threat=e;distance=d;}}$('threat').classList.toggle('hidden',!threat);if(threat){$('threat').textContent=enemyName(threat)+' · '+Math.round(distance)+' m · '+(threat.alert?'ATACANDO':'DETECTADO');$('threat').style.color=threat.alert?'#ffc0a8':'#f5d7a1';const local=enemyCenter(threat).sub(camera.position).applyQuaternion(camera.quaternion.clone().invert());if(local.z>0)$('threat').textContent+=' · ATRÁS';}$('damageOverlay').style.opacity=damageFlash;if(mission?.combat)$('objective').textContent=mission.label+' · '+mission.kills+'/'+mission.need;$('contextAction').textContent=mode==='pilot'?'Levantar':mode==='rover'?'Sair':'Interagir';}
window.buyProduct=buyProduct;window.openShop=openShop;window.equipWeapon=equipWeapon;window.cycleWeapon=cycleWeapon;window.useMedkit=useMedkit;window.selectVehicle=selectVehicle;window.fleetSelect=fleetSelect;window.showActions=showActions;window.reloadWeapon=reloadWeapon;window.applyQuality=applyQuality;window.setTouch=setTouch;

let particleCloud=null;

function initEffects(){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(360*3),3));geometry.setAttribute('color',new THREE.Float32BufferAttribute(new Float32Array(360*3),3));geometry.setDrawRange(0,0);particleCloud=new THREE.Points(geometry,new THREE.PointsMaterial({vertexColors:true,size:.22,transparent:true,opacity:.9,depthWrite:false,toneMapped:false}));particleCloud.frustumCulled=false;scene.add(particleCloud);const dustGeo=new THREE.BufferGeometry(),arr=new Float32Array(120*3);for(let j=0;j<arr.length;j++)arr[j]=(combatRng()-.5)*70;dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(arr,3));ambientDust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xc9e7cf,size:.10,transparent:true,opacity:.5,depthWrite:false}));ambientDust.frustumCulled=false;scene.add(ambientDust);}
function updateEffects(dt){if(particleCloud){for(let i=combatParticles.length-1;i>=0;i--){const p=combatParticles[i];p.life-=dt;if(p.life<=0){combatParticles.splice(i,1);continue;}p.pos.addScaledVector(p.v,dt);p.v.multiplyScalar(1-dt*.7);}const pos=particleCloud.geometry.attributes.position,col=particleCloud.geometry.attributes.color;combatParticles.forEach((p,j)=>{pos.setXYZ(j,p.pos.x,p.pos.y,p.pos.z);col.setXYZ(j,p.color.r,p.color.g,p.color.b);});pos.needsUpdate=true;col.needsUpdate=true;particleCloud.geometry.setDrawRange(0,combatParticles.length);particleCloud.material.size=mode==='pilot'?1.4:.19;particleCloud.visible=particlesEnabled;}for(let i=transientFX.length-1;i>=0;i--){const f=transientFX[i];f.life-=dt;f.o.material.opacity=Math.max(0,f.life/f.ttl*.7);if(f.r)f.o.scale.setScalar(.4+(1-f.life/f.ttl)*f.r);if(f.life<=0){scene.remove(f.o);f.o.geometry.dispose();f.o.material.dispose();transientFX.splice(i,1);}}if(ambientDust){const air=atmosphereAt(camera.position);ambientDust.visible=particlesEnabled&&air.p&&air.p.center&&air.alt<450&&!inside&&mode!=='pilot';if(ambientDust.visible){ambientDust.position.copy(camera.position);ambientDust.quaternion.copy(frameAt(camera.position,air.p.center));ambientDust.material.color.set(air.p.i===2?0xe1f1ff:air.p.i===3?0xc6a6e5:air.p.def[5]);ambientDust.material.size=air.p.i===2?.16:.08;ambientDust.geometry.setDrawRange(0,quality==='low'?40:120);const p=ambientDust.geometry.attributes.position;for(let j=0;j<p.count;j++){let y=p.getY(j)-dt*(air.p.i===2?1.7:.3);if(y< -35)y=35;p.setY(j,y);}p.needsUpdate=true;}}}
function loadEquipment(){try{const s=JSON.parse(localStorage.getItem('horizonte-v1'));if(s?.equipment){const x=s.equipment;equipment.weapons=[...new Set(['pistol','blade',...(Array.isArray(x.weapons)?x.weapons.filter(w=>['rifle','sabre'].includes(w)):[])])];equipment.ships=[...new Set([0,...(Array.isArray(x.ships)?x.ships.filter(n=>[1,2].includes(n)):[])])];equipment.vehicles=[...new Set(['rover',...(Array.isArray(x.vehicles)?x.vehicles.filter(n=>['scout','hauler','skiff','cutter'].includes(n)):[])])];for(const key of ['ammo','grenades','medkits'])if(Number.isFinite(x[key]))equipment[key]=Math.max(0,Math.min(9999,Math.floor(x[key])));}}catch{}}
function bootV04(){loadEquipment();for(const a of animals)sculptAnimal(a.g,a.p.i);remodelRover();enhanceShip();initCombatJobs();initEnemies();initEffects();rebuildWeapon();bindTouch();setTouch(touchEnabled);applyQuality(quality);}
function v04Tick(dt,paused){if(!paused){updateCombat(dt);animateEntities(dt);updateEffects(dt);}updateCombatHud();const far=quality==='low'?2000:quality==='medium'?3500:5000;for(const e of enemies)e.g.visible=e.alive&&e.g.position.distanceTo(camera.position)<(e.flying?6500:1800);if(weaponView)weaponView.visible=mode==='foot'&&!paused&&!thirdPerson&&!resting;}

function makePlanetGeometry(p,w,h){const geo=new THREE.SphereGeometry(p.r,w,h),a=geo.attributes.position,colors=new Float32Array(a.count*3);for(let j=0;j<a.count;j++){const n=V(a.getX(j),a.getY(j),a.getZ(j)).normalize(),r=radius(p,n),c=new THREE.Color(p.def[3+biome(n,p.i)]).multiplyScalar(.91+.08*Math.sin(n.x*31+n.z*23));a.setXYZ(j,n.x*r,n.y*r,n.z*r);colors.set([c.r,c.g,c.b],j*3);}geo.setAttribute('color',new THREE.BufferAttribute(colors,3));geo.computeVertexNormals();geo.computeBoundingSphere();return geo;}
function createPlanetLOD(p){
  const geo=makePlanetGeometry(p,24,16);
  const material=new THREE.MeshStandardMaterial({vertexColors:true,flatShading:true,roughness:0.85,metalness:0.0});
  const globe=mesh(geo,material);
  globe.position.copy(p.center);
  globe.userData.celestial=true;
  globe.receiveShadow=false;
  p.globe=globe;
  p.lodGeometries=[geo, null, null, null];
  p.lodIndex=0;
  planetLODs.push(p);
}
function updateLOD(dt,force=false){
  lodTimer-=dt;
  if(!force&&lodTimer>0)return;
  lodTimer=.15;
  statV05.planetTriangles=0;
  const fov=camera.fov*Math.PI/180,scale=innerHeight/(2*Math.tan(fov/2));
  for(const p of planets){
    if(!p||!p.globe)continue;
    const distance=Math.max(1,camera.position.distanceTo(p.center)),pixels=p.r/distance*scale;
    let level=distance-p.r<220||pixels>300?3:pixels>95?2:pixels>20?1:0;
    if(distance>p.r+250)level=Math.min(level,performancePrefs.planetDetail);
    p.lodIndex=level;
    if(!p.lodGeometries[level]){
      const res=[[24,16],[36,20],[56,32],[80,48]][level];
      p.lodGeometries[level]=makePlanetGeometry(p,res[0],res[1]);
    }
    p.globe.geometry=p.lodGeometries[level];
    p.globe.visible=pixels>.2;
    p.globe.receiveShadow=level===3&&quality==='high';
    if(p.globe.visible&&p.globe.geometry.index)statV05.planetTriangles+=p.globe.geometry.index.count/3;
    if(p.atmosphere)p.atmosphere.visible=pixels>3;
  }
  statV05.visibleSettlements=0;
  const observer=camera.position;
  for(const s of settlements){
    if(!s||!s.root)continue;
    const distance=observer.distanceTo(s.center),normal=planetUp(s.center,s.p),occluded=observer.clone().sub(s.center).dot(normal)<-80;
    s.root.visible=!occluded&&distance<(quality==='low'?2700:5000)*performancePrefs.distance;
    if(s.root.visible)statV05.visibleSettlements++;
    for(const g of s.lots){
      const d=g.getWorldPosition(V()).distanceTo(observer);
      g.visible=s.root.visible&&d<(g.userData.small?900:2400)*performancePrefs.distance;
      if(g.userData.details)g.userData.details.visible=d<(quality==='low'?180:380)*performancePrefs.distance;
    }
  }
  for(const n of npcs)if(n.g)n.g.visible=n.g.getWorldPosition(V()).distanceTo(observer)<(quality==='low'?160:350)*performancePrefs.characterDistance;
  for(const g of scenery){
    if(!g)continue;
    const p=nearest(g.position),normal=planetUp(g.position,p);
    g.visible=!g.userData.removed&&g.position.distanceTo(observer)<(quality==='low'?850:1600)*performancePrefs.distance&&observer.clone().sub(g.position).dot(normal)>-50;
  }
}
function buildSpatialIndex(){staticGrid.clear();for(const b of staticBodies){const min=b.world.min,max=b.world.max;if(max.distanceTo(min)>350)continue;for(let x=Math.floor(min.x/40);x<=Math.floor(max.x/40);x++)for(let y=Math.floor(min.y/40);y<=Math.floor(max.y/40);y++)for(let z=Math.floor(min.z/40);z<=Math.floor(max.z/40);z++){const key=x+','+y+','+z;if(!staticGrid.has(key))staticGrid.set(key,[]);staticGrid.get(key).push(b);}}gridReady=true;}
function queryStatic(pos,r){if(!gridReady||r>180)return staticBodies.filter(b=>b.world.distanceToPoint(pos)<r);const out=new Set();for(let x=Math.floor((pos.x-r)/40);x<=Math.floor((pos.x+r)/40);x++)for(let y=Math.floor((pos.y-r)/40);y<=Math.floor((pos.y+r)/40);y++)for(let z=Math.floor((pos.z-r)/40);z<=Math.floor((pos.z+r)/40);z++)for(const b of staticGrid.get(x+','+y+','+z)||[])out.add(b);return [...out].filter(b=>b.world.distanceToPoint(pos)<r);}
function nearbyBodies(pos,margin,ignore){if(!collisionReady)return [];return [...queryStatic(pos,margin),...movingBodies].filter(b=>!hasAncestorFlag(b.obj,'removed')&&(!ignore||!belongsTo(b.obj,ignore))&&b.world.distanceToPoint(pos)<margin);}
// Combine static surfaces by material while retaining their separate collision volumes.
function batchArchitecture(root){root.updateWorldMatrix(true,true);const buckets=new Map(),inv=root.matrixWorld.clone().invert();root.traverse(o=>{if(!root.userData.batchUnit&&hasAncestorFlag(o,'batchUnit')||!root.userData.detailRoot&&hasAncestorFlag(o,'detailRoot'))return;if(!o.isMesh||o.material.transparent||o.material.map||o.geometry.type==='PlaneGeometry'||hasAncestorFlag(o,'actor')||hasAncestorFlag(o,'dynamic'))return;const m=o.material,key=[m.color?.getHex(),m.emissive?.getHex(),m.emissiveIntensity,m.roughness].join(':');if(!buckets.has(key))buckets.set(key,{m,list:[]});buckets.get(key).list.push(o);});for(const {m,list} of buckets.values()){if(list.length<3)continue;const arrays=[],normals=[];for(const o of list){const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(inv.clone().multiply(o.matrixWorld));arrays.push(...geo.attributes.position.array);normals.push(...geo.attributes.normal.array);geo.dispose();o.layers.set(31);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(arrays,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));g.computeBoundingSphere();const merged=mesh(g,m.clone(),root);merged.castShadow=true;merged.receiveShadow=true;merged.userData.noCollision=true;}}

function settlementPoint(s,x,z,offset=0){const n=V(x,s.p.r,z).normalize().applyQuaternion(s.frame);return s.p.center.clone().addScaledVector(n,radius(s.p,n)+offset);}
function settlementLocal(s,world){const v=world.clone().sub(s.p.center).applyQuaternion(s.frame.clone().invert());return V(v.x*s.p.r/v.y,0,v.z*s.p.r/v.y);}
function curvedPatch(s,x,z,w,d,color,offset=.12){if(Math.max(w,d)>110&&Math.min(w,d)<30){const longX=w>d,n=Math.ceil(Math.max(w,d)/95);for(let i=0;i<n;i++)curvedPatch(s,x+(longX?(-w/2+w*(i+.5)/n):0),z+(!longX?(-d/2+d*(i+.5)/n):0),longX?w/n:w,longX?d:d/n,color,offset);return null;}const geo=new THREE.PlaneGeometry(w,d,Math.max(2,Math.ceil(w/9)),Math.max(2,Math.ceil(d/9)));geo.rotateX(-Math.PI/2);const a=geo.attributes.position;for(let i=0;i<a.count;i++){const v=settlementPoint(s,x+a.getX(i),z+a.getZ(i),offset).sub(s.root.position);a.setXYZ(i,v.x,v.y,v.z);}geo.computeVertexNormals();const m=mesh(geo,color,s.root);m.userData.surfaceOnly=true;m.receiveShadow=true;return m;}
function surfaceGroup(s,x,z){const g=new THREE.Group(),pos=settlementPoint(s,x,z,.18);g.position.copy(pos).sub(s.root.position);g.quaternion.copy(frameAt(pos,s.p.center));s.root.add(g);g.userData.batchUnit=true;s.lots.push(g);return g;}
function residentialBlock(g,random,p,index){
  const h=8+Math.floor(random()*5)*7,w=14+random()*9,d=15+random()*8,col=new THREE.Color(p.def[5]).lerp(new THREE.Color(0x77848b),.65).getHex();
  box(g,0,h/2,0,w,h,d,col);
  box(g,0,h+.2,0,w+1,.4,d+1,0x394f5b);
  const details=new THREE.Group();
  g.add(details);
  g.userData.details=details;
  details.userData.detailRoot=true;
  details.userData.batchUnit=true;
  for(let y=4;y<h-2;y+=5){
    box(details,0,y,-d/2-.05,w-3,1.6,.08,mat(index%3?0x779caa:0xbcc9ae,.25));
    box(details,0,y,d/2+.05,w-3,1.6,.08,mat(0x85a4b0,.2));
  }
  box(details,0,1.6,d/2+.15,2,3.2,.15,0x203c4d);
  if(index%3===0){
    mesh(new THREE.CylinderGeometry(w*.35,w*.4,h*.55,8),col,g,w*.15,h*.275,d*.15);
    box(g,w*.15,h*.55,d*.15,w*.65,.3,w*.65,0x425567);
  }
  if(index%2===0){
    box(g,0,h+1.2,0,w*.5,2,d*.6,0x516771);
  }
  g.userData.height=h;
}
function townPath(s,t,scale=1){const a=t*Math.PI*2,r=(s.kind==='city'?110:35)*(1+.18*Math.sin(a*3+s.p.i+scale*.8)+.10*Math.cos(a*5+s.index-scale));return V(Math.cos(a)*r*scale,0,Math.sin(a)*r*.85*scale);}
function townRoad(s,points,width=9){for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1],d=b.clone().sub(a),n=V(-d.z,0,d.x).normalize().multiplyScalar(width/2);const corners=[a.clone().add(n),a.clone().sub(n),b.clone().sub(n),b.clone().add(n)].map(v=>settlementPoint(s,v.x,v.z,.17).sub(s.root.position).toArray());const o=panelMesh(s.root,corners,0x354a53);o.userData.surfaceOnly=true;}s.roads.push(...points.slice(0,-1));}
function createSettlement(root,p,normal,kind,index,isMain=false){const random=rng(7781+p.i*887+index*379+(kind==='village'?53:0)),center=p.center.clone().addScaledVector(normal,radius(p,normal)+.15),s={root,p,normal,frame:frameAt(center,p.center),center,kind,index,half:kind==='city'?240:80,lots:[],roads:[],isMain,name:p.def[0]+' · '+(kind==='city'?'Cidade ':'Vilarejo ')+(index+1),portKey:isMain?p.i:null};root.position.copy(center);root.userData.curvedCity=true;settlements.push(s);const city=kind==='city';for(const scale of city?[.54,1,1.7]:[1]){const points=Array.from({length:97},(_,i)=>townPath(s,i/96,scale));townRoad(s,points,city?10:7);}
for(let j=0;j<(city?7:3);j++){const a=j/(city?7:3)+.025*Math.sin(j*5),end=townPath(s,a,city?1.82:1.45),points=[];for(let i=0;i<=20;i++){const t=i/20,curve=Math.sin(t*Math.PI)*18;points.push(V(end.x*t+Math.sin(a*6.28)*curve,0,end.z*t-Math.cos(a*6.28)*curve));}townRoad(s,points,8);}
curvedPatch(s,0,0,42,42,0x718988,.26);curvedPatch(s,0,0,1,28,p.def[5],.29);curvedPatch(s,0,0,28,1,p.def[5],.29);const services=city?[...storeSets[p.i],'clothes','workshop']:['jobs',index%2?'medical':'supplies',p.i===2?'workshop':'clothes'],occupied=[];
for(let j=0;j<services.length;j++){const phase=j/services.length+.025,road=townPath(s,phase),out=road.clone().normalize(),pos=road.clone().addScaledVector(out,26),g=surfaceGroup(s,pos.x,pos.z),before=shops.length;buildStore(g,p,0,p.i);const shop=shops[before];shop.g.position.set(0,0,0);shop.g.rotation.y=Math.atan2(-out.x,-out.z);shop.type=services[j];shop.def=storeDefs[shop.type];shop.portKey=s.portKey;shop.settlement=s;redecorateShop(shop);g.userData.shop=shop;occupied.push({x:pos.x,z:pos.z,r:23});}
let built=0;for(let attempt=0;attempt<(city?150:35)&&built<(city?18:6);attempt++){const a=random()*Math.PI*2,r=Math.sqrt(random())*s.half*.98,x=Math.cos(a)*r,z=Math.sin(a)*r*.9,size=city?11+random()*8:11;if(Math.hypot(x,z)<38||occupied.some(o=>Math.hypot(x-o.x,z-o.z)<size*.72+o.r+1.5)||s.roads.some(v=>Math.hypot(x-v.x,z-v.z)<size*.66+7))continue;const g=surfaceGroup(s,x,z),near=s.roads.reduce((a,b)=>Math.hypot(x-a.x,z-a.z)<Math.hypot(x-b.x,z-b.z)?a:b);g.rotateY(Math.atan2(near.x-x,near.z-z));residentialBlock(g,random,p,built);const scale=size/22;g.scale.set(scale,city?.75+random()*1.35:.4+random()*.35,scale);occupied.push({x,z,r:size*.72});built++;}
s.buildingCount=built;
for(let k=0;k<(city?6:2);k++){const phase=k/(city?32:8),local=townPath(s,phase,1.075),anchor=surfaceGroup(s,local.x,local.z),g=person(anchor,0,0,[0xb29f76,0x83a9a4,0xa78da9][k%3]);npcs.push({g,city:anchor,settlement:s,routeBase:local,base:g.position.clone(),name:['Mara','Caio','Luna','Alan','Sara','Noah'][k%6]+' · morador',role:k%6,phase,walkPhase:phase,path:[V()],way:0,wait:0,travel:0});anchor.userData.small=true;}
for(let k=0;k<(city?6:2);k++){const point=townPath(s,k/(city?26:8),1.075),g=surfaceGroup(s,point.x,point.z);mesh(new THREE.CylinderGeometry(.1,.18,5,6),0x405766,g,0,2.5,0);ellipsoid(g,0,5,0,.6,.15,.6,mat(p.def[5],.8));g.userData.small=true;}
for(let k=0;k<(city?4:1);k++){const point=townPath(s,(k+.2)/4,.53),g=surfaceGroup(s,point.x,point.z);mesh(new THREE.CylinderGeometry(3.5,4,.5,16),0x70867c,g,0,.3,0);ellipsoid(g,0,1,0,2,.6,2,0x467f78);for(const side of [-1,1])box(g,side*6,.6,0,1.4,.4,3,0x8b795d);}
if(city)for(let k=0;k<7;k++)spawnTraffic(s,k);return s;}

function decoratePlanet(root,p){const count=settlementProfiles[p.i];if(count.cities){createSettlement(root,p,UP.clone(),'city',0,true);}else if(count.villages){createSettlement(root,p,UP.clone(),'village',0,true);}else{root.userData.uninhabited=true;const beacon=mesh(new THREE.CylinderGeometry(.18,.6,4,8),0x778e99,root,0,2,8);label3D(root,'ÁREA DE POUSO · SEM HABITANTES',0,5,8,18);}}
function finishSettlements(){
  for(const s of settlements){
    if(!s.isMain){
      s.portKey=destinations.length;
      destinations.push({name:s.name,pos:s.center.clone(),p:s.p,settlement:s,kind:s.kind});
    } else {
      const mainD=destinations.find(d=>d.p===s.p&&d.kind==='planet');
      if(mainD){mainD.name=s.name;mainD.settlement=s;}
    }
    for(const shop of shops)if(shop.settlement===s)shop.portKey=s.portKey;
  }
  for(const p of planets)if(!destinations.some(d=>d.p===p))destinations.push({name:p.def[0]+' · Porto',pos:p.center.clone().add(V(0,p.r+2,0)),p,kind:'planet'});
  buildSpatialIndex();
}
function redecorateShop(s){const old=s.g;const parent=old.parent,pos=old.position.clone(),q=old.quaternion.clone();npcs.splice(npcs.findIndex(n=>n.g===s.clerk),1);discardChildren(old);const d=s.def;box(old,0,0,0,27,.3,29,0x697f85);const entryRamp=box(old,0,-.08,16.3,6,.15,4.5,0x697f85);entryRamp.rotation.x=.09;for(const x of [-13.5,13.5])box(old,x,2.7,0,.35,5.4,29,0x5c7381);box(old,0,2.7,-14.5,27,5.4,.35,0x516b78);for(const x of [-8,8]){box(old,x,1,14.5,10,2,.35,0x5c7381);box(old,x,3.5,14.5,10,3,.1,new THREE.MeshStandardMaterial({color:0x86bec7,transparent:true,opacity:.18}));}box(old,0,5.5,0,28,.3,30,0x415967);box(old,0,7.5,0,24,3.5,26,0x6a7e83);label3D(old,d.name,0,6.3,15.1,21);box(old,0,.7,-6,8,1.4,1.6,0x547080);const display=new THREE.Group();display.position.set(7,.8,3);old.add(display);box(old,7,.35,3,5,.7,6,0x405b69);if(s.type==='clothes'){person(display,0,0,0xd7a267);person(old,-8,0,0x5d6284);}else if(s.type==='workshop'){box(display,0,1,0,1.2,1.8,.7,0xa5b6be);for(const x of [-.55,.55])mesh(new THREE.CylinderGeometry(.25,.35,1.2,10),0x485d6b,display,x,1,.35);}else if(s.type==='ships'){fighterModel(display);display.scale.setScalar(.35);}else if(s.type==='ranged'||s.type==='melee'||s.type==='explosives'){makeWeapon(display,s.type==='ranged'?'rifle':s.type==='melee'?'sabre':'grenade');display.scale.setScalar(2);}else{box(display,0,.6,0,3,1.2,3,d.color);}s.clerk=person(old,0,-8,d.color);s.clerk.userData.actor=true;npcs.push({g:s.clerk,city:old,shop:s,base:s.clerk.position.clone(),name:'Atendente · '+d.short,role:0,phase:s.id,path:[s.clerk.position.clone()],way:0,wait:Infinity});}
function spawnTraffic(s,k){const g=new THREE.Group();g.userData.dynamic=true;scene.add(g);const color=[0x618a9f,0xa6acb1,0xb39569,0x758678][k%4];const front=[[-.65,.7,-2.4],[.65,.7,-2.4],[1.1,.65,-.8],[1.05,.6,1.9],[-1.05,.6,1.9],[-1.1,.65,-.8]];panelMesh(g,front,color);for(let i=0;i<front.length;i++){const a=front[i],b=front[(i+1)%front.length];panelMesh(g,[a,b,[b[0]*.75,.3,b[2]],[a[0]*.75,.3,a[2]]],0x334e5e);}panelMesh(g,[[-.78,.72,-1.35],[.78,.72,-1.35],[.68,1.5,-.3],[-.68,1.5,-.3]],0x72a9bd);panelMesh(g,[[-.68,1.5,-.3],[.68,1.5,-.3],[.65,1.4,.85],[-.65,1.4,.85]],color);for(const side of [-1,1]){panelMesh(g,[[side*.78,.72,-1.35],[side*.68,1.5,-.3],[side*.65,1.4,.85],[side*.95,.65,1.4]],0x344f65);box(g,side*.53,.68,-2.31,.36,.12,.1,mat(0xd4faff,2));box(g,side*.73,.64,1.94,.35,.1,.1,mat(0xf76762,1));box(g,side*1.03,.3,.6,.3,.18,1.8,mat(0x67dbea,1));mesh(new THREE.CylinderGeometry(.21,.29,.2,10),mat(0x68d5ee,1),g,side*.62,.36,1.6).rotation.x=Math.PI/2;}traffic.push({g,s,phase:k/7,stopped:false,speed:10+k%3});}
function updateTraffic(dt){statV05.visibleTraffic=0;const pos=controlledPosition();for(const t of traffic){const visible=t.s.root.visible&&pos.distanceTo(t.s.center)<900;t.g.visible=visible;if(!visible)continue;statV05.visibleTraffic++;const len=660,point=phase=>townPath(t.s,phase);const local=point(t.phase),ahead=point(t.phase+8/len),world=settlementPoint(t.s,local.x,local.z,.4),next=settlementPoint(t.s,ahead.x,ahead.z,.4);t.stopped=npcs.some(n=>n.g.visible&&n.g.getWorldPosition(V()).distanceTo(next)<4)||pos.distanceTo(next)<7||pos.distanceTo(world)<5||traffic.some(o=>o!==t&&o.s===t.s&&o.g.position.distanceTo(next)<6);if(!t.stopped)t.phase=(t.phase+dt*t.speed/len)%1;t.g.position.copy(world);const up=planetUp(world,t.s.p),m=new THREE.Matrix4().lookAt(world,next,up);t.g.quaternion.copy(new THREE.Quaternion().setFromRotationMatrix(m));}}

function floorProbe(eye,up,p,height=1.8,reach=2){const origin=eye.clone().addScaledVector(up,.4-height),bodies=nearbyBodies(eye,reach+height+3,null).filter(b=>b.obj.isMesh&&!b.obj.userData.noSupport&&!hasAncestorFlag(b.obj,'actor')&&!hasAncestorFlag(b.obj,'dynamic'));const ray=new THREE.Raycaster(origin,up.clone().negate(),0,reach+.4);ray.layers.enable(31);const hits=ray.intersectObjects(bodies.map(b=>b.obj),false);let ground=null;for(const h of hits){if(Math.abs(h.face.normal.clone().transformDirection(h.object.matrixWorld).dot(up))>.45){ground=h.point.clone().addScaledVector(up,height+.04);break;}}if(p){const terrain=groundEye(eye,p,height),d=eye.clone().sub(terrain).dot(up);if(d<reach&&d>-.6&&(!ground||terrain.clone().sub(ground).dot(up)>0))ground=terrain;}return ground;}
function resetFootMotion(){jumpVelocity=0;jumpHeld=0;jumpWasDown=!!keys.Space;onFootGround=true;jetActive=false;footContext='';resting=null;}
function updateFootV05(dt){if(waterMovement(dt))return;if(resting){if(keys.Space){standUp();keys.Space=false;}return;}const context=inside?'ship':eva?'eva':station?'station':'ground';if(footContext!==context){jumpVelocity=0;onFootGround=true;jumpHeld=0;footContext=context;}const f=axisForward(),s=axisStrafe(),p=groundPlanet||nearest(player),frame=inside?ship.quaternion:eva?evaFrame:walkFrame(player,p),up=UP.clone().applyQuaternion(frame),world=inside?shipPoint(foot):player.clone();let move=V(s,0,-f);if(move.lengthSq()>1)move.normalize();move.applyAxisAngle(UP,yaw).applyQuaternion(frame).multiplyScalar((inside?(sprinting()?9:6):(sprinting()?15:8))*dt);
if(eva){const q=frame.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ'))),thruster=V(s,(keys.Space?1:0)-(keys.ControlLeft?1:0),-f);if(thruster.lengthSq()>1)thruster.normalize();thruster.applyQuaternion(q).multiplyScalar(sprinting()?80:22);const radial=planetUp(player,p),alt=player.distanceTo(p.center)-radius(p,radial);if(alt<ATMOSPHERE)evaVelocity.addScaledVector(radial,-7*dt);const delta=evaVelocity.clone().add(thruster).multiplyScalar(dt);player.copy(moveActor(player,delta,{up:radial,grounded:false}));const floor=floorProbe(player,radial,p,1.8,1);if(floor&&player.clone().sub(floor).dot(radial)<.15){player.copy(floor);eva=false;groundPlanet=p;station=null;evaVelocity.set(0,0,0);resetFootMotion();}return;}
const floor=floorProbe(world,up,inside||station?null:p,1.8,.8);if(onFootGround&&(!floor||world.clone().sub(floor).dot(up)>.35))onFootGround=false;const down=!!keys.Space;if(down&&!jumpWasDown&&onFootGround){jumpVelocity=6.8;onFootGround=false;jumpHeld=0;}jumpHeld=down?jumpHeld+dt:0;if(mobileJumpHeld&&!onFootGround&&jumpVelocity<=0)mobileJumpBoost=true;jetActive=down&&(mobileJumpHeld?mobileJumpBoost:jumpHeld>.24)&&!onFootGround&&jetFuel>0;if(jetActive){jetFuel=Math.max(0,jetFuel-dt*28);jumpVelocity=Math.min(9+jetLevel*2,jumpVelocity+dt*(21+jetLevel*2.5));if(particlesEnabled&&combatTime% .08<dt)particleBurst(world.clone().addScaledVector(up,-1.2),0x87ddec,3,2);}if(!onFootGround)jumpVelocity-=14*dt;else{jetFuel=Math.min(jetCapacity(),jetFuel+dt*20);jumpVelocity=0;}jumpWasDown=down;
if(onFootGround){const candidate=world.clone().add(move),support=floorProbe(candidate,up,inside||station?null:p,1.8,.32);if(!support||candidate.clone().sub(support).dot(up)>.30){onFootGround=false;jumpVelocity=-14*dt;}}const delta=move.addScaledVector(up,jumpVelocity*dt),intended=world.clone().add(delta),next=moveActor(world,delta,{up,p:inside||station?null:p,grounded:false});const correction=next.clone().sub(intended).dot(up);if(jumpVelocity>0&&correction<-.02)jumpVelocity=0;const support=floorProbe(next,up,inside||station?null:p,1.8,Math.max(1,Math.abs(jumpVelocity*dt)+.6));if(support&&jumpVelocity<=0&&next.clone().sub(support).dot(up)<.12&&next.clone().sub(support).dot(up)>-.4){next.copy(support);jumpVelocity=0;onFootGround=true;}else if(p&&!inside&&!station){const terrain=groundEye(next,p,1.8);if(next.clone().sub(terrain).dot(up)<0){next.copy(terrain);jumpVelocity=0;onFootGround=true;}}
if(inside){foot.copy(localPoint(next));const rel=foot.clone().sub(layout().entry);if(rampOpen&&inDoor(foot)&&rel.dot(layout().normal)>.7&&totalTime>transitionUntil)exitShip();}else player.copy(next);}
function toggleCamera(){thirdPerson=!thirdPerson;toast(thirdPerson?'Câmera em terceira pessoa.':'Câmera em primeira pessoa.');}
function armorPlate(parent,points,color,thickness=.024){const sign=points.reduce((v,p)=>v+p[2],0)<0?-1:1,a=points.map(p=>[p[0],p[1],p[2]+sign*.028]),b=a.map(p=>[p[0],p[1],p[2]-sign*thickness]);panelMesh(parent,a,color);panelMesh(parent,b.slice().reverse(),color);for(let k=0;k<a.length;k++)panelMesh(parent,[a[k],a[(k+1)%a.length],b[(k+1)%b.length],b[k]],color);}
function makeAvatar(){if(avatar){scene.remove(avatar);discardChildren(avatar);}const root=new THREE.Group();root.userData.noCollision=true;root.userData.dynamic=true;scene.add(root);const rig=new THREE.Group();root.add(rig);const armor=outfit==='arctic'?0xb9c9cb:outfit==='night'?0x293342:0x354956,accent=outfit==='ranger'?0x82936c:outfit==='engineer'?0xd8a465:outfit==='arctic'?0x5d8f9e:0xb15543,soft=0x18272e,metal=0x566b75;const torso=new THREE.Group();torso.position.y=.94;rig.add(torso);bodyLoft(torso,[[0,.15,.115],[.12,.145,.108],[.30,.205,.137],[.42,.222,.122],[.49,.09,.077]],soft,16);const pelvis=new THREE.Group();pelvis.position.y=.87;rig.add(pelvis);bodyLoft(pelvis,[[-.10,.15,.115],[0,.175,.127],[.11,.147,.109]],soft,14);
for(const side of [-1,1]){armorPlate(torso,[[side*.012,.405,-.133],[side*.18,.405,-.126],[side*.205,.31,-.151],[side*.165,.235,-.147],[side*.014,.25,-.15]],armor);armorPlate(torso,[[side*.018,.228,-.136],[side*.155,.217,-.135],[side*.135,.145,-.125],[side*.018,.157,-.132]],metal);armorPlate(torso,[[side*.015,.13,-.124],[side*.13,.12,-.115],[side*.125,.057,-.118],[side*.015,.067,-.124]],armor);armorPlate(pelvis,[[side*.01,.08,-.128],[side*.13,.08,-.125],[side*.16,-.04,-.132],[side*.025,-.10,-.126]],armor);}
armorPlate(torso,[[.07,.402,-.157],[.105,.402,-.157],[.105,.277,-.161],[.07,.265,-.161]],accent,.009);bodyLoft(torso,[[.45,.097,.089],[.51,.082,.077]],metal,14);
mesh(new THREE.CylinderGeometry(.055,.063,.10,12),soft,rig,0,1.47,0);const head=new THREE.Group();head.position.y=1.49;rig.add(head);bodyLoft(head,[[0,.062,.063],[.03,.09,.083],[.13,.105,.096,.003],[.22,.089,.083,.009],[.265,.025,.034,.014]],armor,16);const visor=panelMesh(head,[[-.095,.165,-.066],[-.072,.195,-.087],[.072,.195,-.087],[.095,.165,-.066],[.086,.075,-.08],[.042,.06,-.096],[-.042,.06,-.096],[-.086,.075,-.08]],0x152d3a);visor.position.z=-.035;visor.material.metalness=.75;visor.material.roughness=.18;for(const x of [-.094,.094]){ellipsoid(head,x,.105,.007,.018,.03,.035,metal,1);mesh(new THREE.SphereGeometry(.011,6,4),mat(0x85d8de,.8),head,x,.113,-.016);}
const limbs=[],knees=[],elbows=[];for(const side of [-1,1]){const leg=new THREE.Group();leg.position.set(side*.105,.87,0);rig.add(leg);bodyLoft(leg,[[0,.088,.088],[-.16,.084,.082],[-.38,.056,.058]],soft,12);armorPlate(leg,[[-.061,-.055,-.082],[.061,-.055,-.082],[.068,-.20,-.082],[.042,-.31,-.067],[-.045,-.31,-.067],[-.068,-.20,-.082]],armor);const knee=new THREE.Group();knee.position.y=-.38;leg.add(knee);bodyLoft(knee,[[0,.055,.06],[-.12,.061,.064],[-.33,.039,.044],[-.385,.044,.05]],soft,12);ellipsoid(knee,0,-.018,-.058,.063,.057,.023,metal,1);armorPlate(knee,[[-.048,-.075,-.064],[.048,-.075,-.064],[.037,-.315,-.052],[-.037,-.315,-.052]],armor);ellipsoid(knee,0,-.407,-.052,.066,.053,.134,armor,2);
const arm=new THREE.Group();arm.position.set(side*.226,1.365,0);rig.add(arm);bodyLoft(arm,[[0,.068,.075],[-.12,.065,.067],[-.28,.047,.047]],soft,12);ellipsoid(arm,side*.018,-.012,0,.077,.071,.089,armor,2);armorPlate(arm,[[-.049,-.06,-.069],[.049,-.06,-.069],[.041,-.22,-.057],[-.041,-.22,-.057]],armor);const elbow=new THREE.Group();elbow.position.y=-.28;arm.add(elbow);bodyLoft(elbow,[[0,.046,.047],[-.12,.05,.052],[-.245,.031,.035]],soft,12);armorPlate(elbow,[[-.041,-.05,-.055],[.041,-.05,-.055],[.033,-.218,-.044],[-.033,-.218,-.044]],metal);ellipsoid(elbow,0,-.285,-.006,.037,.053,.027,soft,2);arm.rotation.z=side*.035;limbs.push(leg,arm);knees.push(knee);elbows.push(elbow);}
// Flush thruster module: 36 cm wide, 43 cm tall and 15 cm deep, integrated into the armor.
const pack=new THREE.Group();pack.name='compactJetpack';pack.position.set(0,.025,.122);torso.add(pack);bodyLoft(pack,[[.06,.10,.055],[.12,.16,.068],[.38,.18,.065],[.46,.105,.045]],armor,12);for(const side of [-1,1]){const nozzle=mesh(new THREE.CylinderGeometry(.043,.05,.12,10),metal,pack,side*.125,.085,.025);mesh(new THREE.TorusGeometry(.037,.009,5,10),mat(0x7cdae4,.7),pack,side*.125,.022,.025).rotation.x=Math.PI/2;}armorPlate(pack,[[-.017,.36,.071],[.017,.36,.071],[.017,.16,.071],[-.017,.16,.071]],accent,.009);
rig.userData.limbs=limbs;rig.userData.human={seed:42117,torso,head,pelvis,knees,elbows,phase:0,speed:0,last:null,height:1.78};root.userData.rig=rig;mergeHumanParts(rig);root.traverse(o=>{o.userData.noCollision=true;if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});avatar=root;updateAvatarWeapon();}

function updatePlayerCamera(dt){const aboard=mode==='pilot',driving=mode==='rover';let eye,q,up,focus;
if(resting){eye=shipPoint(resting.point);q=ship.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else if(aboard){eye=shipPoint(layout().seat.clone().add(V(0,0.72,0.05)));q=ship.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else if(driving){eye=rover.localToWorld(V(0,1.72,.45));q=rover.getWorldQuaternion(new THREE.Quaternion()).multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else{
  eye=inside?shipPoint(foot):player.clone();
  const baseQ = (inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player))).clone();
  q = baseQ.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));

  // Realistic First-Person Procedural Camera Dynamics
  if (!thirdPerson && !resting) {
    const moveSpeed = Math.hypot(axisForward(), axisStrafe());
    const isSprint = sprinting() && axisForward() > 0.1;

    // A. Locomotion Head Bobbing (rhythmic vertical bounce, lateral sway, and organic roll bank)
    if (onFootGround && moveSpeed > 0.05) {
      const bobFreq = isSprint ? 12.0 : 8.5;
      camBobPhase += dt * bobFreq;
      const bobY = -Math.abs(Math.sin(camBobPhase)) * (isSprint ? 0.046 : 0.022) * moveSpeed;
      const bobX = Math.cos(camBobPhase * 0.5) * (isSprint ? 0.026 : 0.013) * moveSpeed;
      const bobRoll = -Math.cos(camBobPhase * 0.5) * (isSprint ? 0.022 : 0.010) * moveSpeed;
      const bobPitch = Math.sin(camBobPhase) * (isSprint ? 0.014 : 0.006) * moveSpeed;

      eye.add(V(bobX, bobY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(bobPitch, 0, bobRoll, 'YXZ')));
    }

    // B. Jump Lift & Landing Compression Dip
    if (onFootGround && !camWasGrounded) {
      // Impact landing compression
      camLandDip = Math.min(0.14, Math.max(0.04, Math.abs(jumpVelocity) * 0.018));
    }
    camWasGrounded = onFootGround;
    if (camLandDip > 0.001) {
      camLandDip = THREE.MathUtils.lerp(camLandDip, 0, 1 - Math.exp(-dt * 14));
      eye.add(V(0, -camLandDip, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(-camLandDip * 0.45, 0, 0, 'YXZ')));
    }

    // C. Jetpack Thruster Micro-Rumble
    if (jetActive) {
      const jY = Math.sin(totalTime * 48) * 0.0022;
      const jX = Math.cos(totalTime * 36) * 0.0018;
      const jRoll = Math.sin(totalTime * 55) * 0.0025;
      eye.add(V(jX, jY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, jRoll, 'YXZ')));
    }

    // D. Weapon Reload Kinetic Camera Sway
    if (typeof reloadActive !== 'undefined' && reloadActive) {
      const rp = Math.min(1.0, Math.max(0, (combatTime - reloadStartTime) / reloadDuration));
      let rX = 0, rY = 0, rPitch = 0, rRoll = 0;
      if (rp >= 0.15 && rp < 0.28) {
        // Mag release dip
        const sub = (rp - 0.15) / 0.13;
        rY = -Math.sin(sub * Math.PI) * 0.008;
        rRoll = -Math.sin(sub * Math.PI) * 0.006;
      } else if (rp >= 0.48 && rp < 0.62) {
        // Forceful mag insertion slap
        const sub = (rp - 0.48) / 0.14;
        rY = Math.sin(sub * Math.PI) * 0.012;
        rPitch = Math.sin(sub * Math.PI) * 0.010;
        rRoll = Math.sin(sub * Math.PI) * 0.006;
      } else if (rp >= 0.74 && rp < 0.88) {
        // Slide / bolt rack tug
        const sub = (rp - 0.74) / 0.14;
        rX = -Math.sin(sub * Math.PI) * 0.008;
        rRoll = -Math.sin(sub * Math.PI) * 0.008;
      }
      eye.add(V(rX, rY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(rPitch, 0, rRoll, 'YXZ')));
    }

    // E. Melee Attack Kinetic Forward Lunge & Screen Torque
    if (typeof meleeActive !== 'undefined' && meleeActive) {
      const mp = Math.min(1.0, Math.max(0, (combatTime - meleeStartTime) / meleeDuration));
      if (mp >= 0.18 && mp < 0.65) {
        const cut = Math.sin((mp - 0.18) / 0.47 * Math.PI);
        const lungeZ = -0.16 * cut; // explosive forward lunge!
        const lungePitch = -0.045 * cut; // aggressive downward cut angle
        const lungeRoll = (typeof meleeCombo !== 'undefined' && meleeCombo === 0 ? -0.05 : 0.04) * cut;
        eye.add(V(0, 0, lungeZ).applyQuaternion(q));
        q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(lungePitch, 0, lungeRoll, 'YXZ')));
      }
    }
  }
}
up=UP.clone().applyQuaternion(aboard?ship.quaternion:driving?rover.getWorldQuaternion(new THREE.Quaternion()):inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player)));
camera.quaternion.copy(q);camera.position.copy(eye);camera.up.copy(up);
if(thirdPerson){focus=aboard?shipPoint(V(0,2,0)):driving?rover.localToWorld(V(0,1.2,0)):eye.clone().addScaledVector(up,-.2);const offset=V(aboard?0:.7,aboard?13:driving?2.5:.8,aboard?Math.max(40,layout().halfZ*2.7):driving?7:resting?3:4.6).multiplyScalar(cameraZoom[mode]).applyQuaternion(q);camera.position.copy(safeChaseCamera(focus,offset,aboard?ship:driving?rover:null,aboard));camera.lookAt(focus.clone().add(V(0,0,aboard?-100:driving?-25:-40).applyQuaternion(q)));}
if(avatar){avatar.visible=thirdPerson;if(avatarWeapon)avatarWeapon.visible=thirdPerson&&mode==='foot'&&!resting;avatar.scale.setScalar(driving?.8:1);const rig=avatar.userData.rig;rig.rotation.set(0,0,0);if(aboard||driving){avatar.position.copy(aboard?shipPoint(layout().seat.clone().setY(.8)):rover.localToWorld(V(0,.45,.45)));avatar.quaternion.copy(aboard?ship.quaternion:rover.getWorldQuaternion(new THREE.Quaternion()));}else if(resting){avatar.position.copy(shipPoint(resting.avatar));avatar.quaternion.copy(ship.quaternion);rig.rotation.x=resting.kind==='bed'?-Math.PI/2:0;rig.rotation.y=resting.angle||0;}else{avatar.position.copy(eye).addScaledVector(up,-1.8);const base=inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player));avatar.quaternion.copy(base).multiply(new THREE.Quaternion().setFromAxisAngle(UP,yaw));}animateHuman(rig,dt,aboard||driving||resting?.kind==='bench',!onFootGround&&mode==='foot');}
if(weaponView)weaponView.visible=mode==='foot'&&!thirdPerson&&!resting&&$('panel').classList.contains('hidden');$('jetHud').classList.toggle('hidden',mode!=='foot'||eva);$('jetFill').style.width=(jetFuel/jetCapacity()*100)+'%';$('jetText').textContent='JETPACK '+Math.round(jetFuel/jetCapacity()*100)+'%'+(jetActive?' · IMPULSO':'');}
function equipOutfit(id){if(!ownedOutfits.includes(id))return;outfit=id;makeAvatar();save();renderPanel('inventory');}
function buyV05(id){const s=shops[activeShop],product=products[id];if(!s||!product||!s.def.items.includes(id)||controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5)return;if(id.startsWith('outfit_')){const type=id.slice(7);if(ownedOutfits.includes(type)){toast('Você já possui esta roupa.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];ownedOutfits.push(type);outfit=type;makeAvatar();}else if(id==='jet1'||id==='jet2'){const level=Number(id.slice(3));if(jetLevel>=level){toast('Este aprimoramento já está instalado.');return;}if(jetLevel!==level-1){toast('Instale o estágio anterior primeiro.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];jetLevel=level;jetFuel=jetCapacity();}save();renderPanel('shop');toast('Equipamento atualizado.');}
function initPlayerV05(){try{const s=JSON.parse(localStorage.getItem('horizonte-v1'));if(s?.skyward){const v=s.skyward;if(v.currentSystem){currentSystem.x=v.currentSystem.x||0;currentSystem.y=v.currentSystem.y||0;currentSystem.name=getSystemName(currentSystem.x,currentSystem.y);}jetLevel=[0,1,2].includes(v.jetLevel)?v.jetLevel:0;ownedOutfits=[...new Set(['explorer',...(v.ownedOutfits||[]).filter(x=>outfitColors[x])])];outfit=ownedOutfits.includes(v.outfit)?v.outfit:'explorer';for(const k of Object.keys(locker))locker[k]=Math.max(0,Math.min(9999,Number(v.locker?.[k])||0));}}catch{}jetFuel=jetCapacity();makeAvatar();addEventListener('keydown',e=>{if(e.code==='KeyV'&&!e.repeat&&started&&$('panel').classList.contains('hidden'))toggleCamera();});}

function aimDirection(naval){const dir=V(0,0,-1).applyQuaternion(camera.quaternion);if(!thirdPerson)return dir;const end=camera.position.clone().addScaledVector(dir,naval?2600:300);let distance=Math.min(naval?2600:300,obstacleDistance(camera.position,end,naval?ship:null));for(const e of enemies){if(!e.alive)continue;const hit=segmentHit(camera.position,end,enemyCenter(e),e.flying?7:e.beast?1.4:.85);if(hit!==null)distance=Math.min(distance,hit);}const from=naval?shipPoint(V(0,1.7,-layout().halfZ-1.5)):inside?shipPoint(foot):player;return camera.position.clone().addScaledVector(dir,distance).sub(from).normalize();}

function panelMesh(parent,points,color){const vertices=[],normals=[];for(let i=1;i<points.length-1;i++)for(const k of [0,i,i+1])vertices.push(...points[k]);const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.computeVertexNormals();const m=mat(color);m.side=THREE.DoubleSide;m.metalness=.45;m.roughness=.45;const o=mesh(g,m,parent);o.userData.thinPanel=true;return o;}
function sweptWing(parent,side,z,span,chord,color){const pts=[[side*3,.25,z-chord*.5],[side*span,.2,z+chord*.2],[side*(span-1),.2,z+chord*.6],[side*3,.25,z+chord*.5]];panelMesh(parent,pts,color);panelMesh(parent,pts.map(p=>[p[0],p[1]-.65,p[2]]).reverse(),0x3b515c);for(let i=0;i<4;i++){const a=pts[i],b=pts[(i+1)%4];panelMesh(parent,[a,b,[b[0],b[1]-.65,b[2]],[a[0],a[1]-.65,a[2]]],color);}}



function createLandingGear(parent, x, z, side) {
  const g = new THREE.Group();
  g.position.set(x, -0.22, z);
  parent.add(g);

  // 1. Recessed underbelly bay housing
  const bay = mesh(new THREE.BoxGeometry(1.6, 0.35, 2.2), 0x14181e, g, 0, 0.08, 0);
  bay.userData.noCollision = true;

  // 2. Main Strut Group (lowers and raises)
  const strutGroup = new THREE.Group();
  g.add(strutGroup);

  // Upper outer hydraulic cylinder (titanium gunmetal)
  const upperCyl = mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.90, 12), 0x1a222c, strutGroup, 0, -0.45, 0);
  upperCyl.userData.noCollision = true;

  // Collar reinforcement ring
  mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.16, 12), 0x2d3a48, strutGroup, 0, -0.15, 0);

  // 3. Lower Telescoping Piston (Polished Chrome Steel)
  const pistonGroup = new THREE.Group();
  pistonGroup.position.set(0, -0.85, 0);
  strutGroup.add(pistonGroup);

  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xdde7ee, metalness: 0.92, roughness: 0.12 });
  const piston = mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.90, 12), chromeMat, pistonGroup, 0, -0.45, 0);
  piston.userData.noCollision = true;

  // 4. Articulated Scissor Torque Links
  const scissor1 = mesh(new THREE.BoxGeometry(0.07, 0.50, 0.07), 0x242e3a, strutGroup, side * 0.22, -0.50, 0.14);
  scissor1.userData.noCollision = true;
  const scissor2 = mesh(new THREE.BoxGeometry(0.07, 0.50, 0.07), 0x242e3a, pistonGroup, side * 0.22, -0.22, 0.14);
  scissor2.userData.noCollision = true;

  // 5. Heavy Articulated Magnetic Landing Footpad
  const footPad = new THREE.Group();
  footPad.position.set(0, -0.65, 0);
  pistonGroup.add(footPad);

  // Swivel ball-joint
  mesh(new THREE.SphereGeometry(0.16, 8, 8), 0x303d4a, footPad, 0, 0.08, 0);
  // Wide beveled magnetic pad
  const padMesh = mesh(new THREE.CylinderGeometry(0.62, 0.76, 0.22, 8), 0x14181e, footPad, 0, -0.06, 0);
  padMesh.userData.noCollision = true;
  // Non-skid polymer sole
  const soleMesh = mesh(new THREE.BoxGeometry(1.35, 0.08, 1.85), 0x0c0f13, footPad, 0, -0.18, 0);
  soleMesh.userData.noCollision = true;

  // Status indicator LED (cyan when locked, amber in transit)
  const led = mesh(new THREE.BoxGeometry(0.12, 0.06, 0.12), mat(0x42f5d7, 2.0), footPad, side * 0.45, 0.02, 0);
  led.userData.noCollision = true;

  const gearObj = { g, strutGroup, pistonGroup, footPad, scissor1, scissor2, led, side };
  landingGears.push(gearObj);
  return gearObj;
}

function updateLandingGears(dt) {
  if (!landingGears.length) return;
  const targetProgress = (landed || (landingSequence && landingSequence.active)) ? 1.0 : 0.0;
  const transitSpeed = 1.6; // ~1.6s for full extension or retraction

  if (shipGearProgress < targetProgress) {
    shipGearProgress = Math.min(targetProgress, shipGearProgress + dt * transitSpeed);
  } else if (shipGearProgress > targetProgress) {
    shipGearProgress = Math.max(targetProgress, shipGearProgress - dt * transitSpeed);
  }

  const gp = THREE.MathUtils.smoothstep(shipGearProgress, 0, 1);

  if (shipGearSuspension > 0.001) {
    shipGearSuspension = THREE.MathUtils.lerp(shipGearSuspension, 0, 1 - Math.exp(-dt * 12));
  }

  for (const gear of landingGears) {
    // Retracts up into bay and folds scissor arms
    gear.strutGroup.position.y = THREE.MathUtils.lerp(0.65, 0.0, gp);
    gear.pistonGroup.position.y = THREE.MathUtils.lerp(-0.10, -0.85 + shipGearSuspension * 0.16, gp);
    gear.scissor1.rotation.x = THREE.MathUtils.lerp(1.2, 0.50, gp);
    gear.scissor2.rotation.x = THREE.MathUtils.lerp(-1.2, -0.50, gp);
    gear.footPad.visible = gp > 0.05;
    gear.strutGroup.scale.set(gp > 0.05 ? 1 : 0.01, Math.max(0.01, gp), gp > 0.05 ? 1 : 0.01);

    if (gear.led && gear.led.material) {
      if (gp >= 0.98) {
        gear.led.material.color.setHex(0x42f5d7); // Ready / locked
      } else if (gp <= 0.02) {
        gear.led.material.color.setHex(0x0a1015); // Off
      } else {
        gear.led.material.color.setHex(0xffa533); // Transit amber
      }
    }
  }
}

function aeroHull(){const l=layout(),h=l.halfX,z=l.halfZ,col=shipTypes[shipType].color,glass=new THREE.MeshStandardMaterial({color:0x9fcbd7,transparent:true,opacity:.22,roughness:.12,metalness:.2,side:THREE.DoubleSide});box(ship,0,0,0,h*2,.5,z*2,0x405866);const rows=shipType===0?[[-z-10,.8,1.0],[-z-5,h*.7,3],[-z,h,5.3],[-z*.55,h+3,6],[-1,h+10,6.4],[z*.45,h+17,5.8],[z-3,h+7,5.3],[z,h,4.95]]:shipType===1?[[-z-13,.3,.8],[-z-6,h*.65,2.5],[-z,h,5.4],[-z*.45,h+16,5.8],[0,h+3,5.5],[3,h,5.3],[8,h,5.3],[z,h,4.95]]:[[-z,h,5.2],[-z*.4,h+6,6.8],[0,h+10,7],[z*.5,h+7,6.2],[z,h,4.95]];
function ring(row){const [zz,w,t]=row;return [[-w,-.22,zz],[-w,.9,zz],[-Math.min(w,h),t-.45,zz],[-Math.min(w*.65,h*.8),t,zz],[Math.min(w*.65,h*.8),t,zz],[Math.min(w,h),t-.45,zz],[w,.9,zz],[w,-.22,zz]];}
for(let j=0;j<rows.length-1;j++){const a=ring(rows[j]),b=ring(rows[j+1]);for(let k=0;k<8;k++){if(shipType===1&&(k===0||k===1)&&rows[j][0]>=0&&rows[j+1][0]<=8)continue;const next=(k+1)%8,points=[a[k],a[next],b[next],b[k]];
    // Elegant black accents on dorsal spine, fuselage ridges, and underbelly
    const panelColor = (k === 7) ? 0x16202c : col;
    const o = (shipType!==2&&j===2&&(k===1||k===5))?hullWindow(ship,points,col):panelMesh(ship,points,panelColor);
    if(j<2&&(k===2||k===3||k===4)||shipType!==2&&j===0&&k===7){o.material=glass.clone();o.material.opacity=.055;o.material.depthWrite=false;o.userData.viewport=true;}
    o.userData.hullLoft=true;}}
if(shipType===0){for(const side of [-1,1])panelMesh(ship,[[side*l.doorHalf,0,z],[side*h,0,z],[side*h,4.95,z],[side*l.doorHalf,4.95,z]],col);}else panelMesh(ship,[[-h,0,z],[h,0,z],[h,4.95,z],[-h,4.95,z]],col);
if(shipType===2){for(const range of [[-h,-8],[-2,h]]){box(ship,(range[0]+range[1])/2,2.4,-z,range[1]-range[0],4.8,.14,glass);}}
for(const side of [-1,1]){const ex=side*(h*.67),ez=z-2;
  // Elegant black intake nacelles and cyan glow rings
  const intake=mesh(new THREE.CylinderGeometry(.85,1.25,4,16),0x14181e,ship,ex,3.3,ez);
  intake.rotation.x=Math.PI/2;
  mesh(new THREE.TorusGeometry(.85,.12,8,20),mat(0x83dfff,1.8),ship,ex,3.3,ez+2);
  // Elegant black wing strakes
  if(shipType!==1){panelMesh(ship,[[side*(h+3),2,z-8],[side*(h+6),8,z-1],[side*(h+6),7,z+3],[side*(h+2),2,z]], 0x14181e);}
  // High-detail articulated landing gears on all 4 corners
  for(const zz of [-z+3,z-3]){ createLandingGear(ship, side*(h-1), zz, side); }}
ship.userData.silhouette=['asa integrada cargueira','asa voadora furtiva','corpo duplo industrial'][shipType];}

function hullWindow(parent,points,color){const g=new THREE.Group();parent.add(g);const p=points.map(p=>V(...p)),at=(u,v)=>p[0].clone().lerp(p[1],u).lerp(p[3].clone().lerp(p[2],u),v).toArray(),cuts=[0,.12,.88,1];for(let x=0;x<3;x++)for(let y=0;y<3;y++){const o=panelMesh(g,[at(cuts[x],cuts[y]),at(cuts[x+1],cuts[y]),at(cuts[x+1],cuts[y+1]),at(cuts[x],cuts[y+1])],color);if(x===1&&y===1){o.material=new THREE.MeshStandardMaterial({color:0xb5e2e7,transparent:true,opacity:.055,depthWrite:false,roughness:.08,metalness:.05,side:THREE.DoubleSide});o.userData.viewport=true;o.castShadow=false;}}return g;}

function cabinBox(x,y,z,w,h,d,c){const o=box(ship,x,y,z,w,h,d,c);o.userData.interior=true;return o;}
function roomDeck(x,z,w,d,c=0x455a63){cabinBox(x,.29,z,w,.075,d,c);cabinBox(x,3.85,z,w,.13,d,0x263c48);for(const side of [-1,1]){const strip=cabinBox(x+side*(w/2-.12),3.75,z,.055,.06,Math.max(.4,d-.4),mat(0xb4dcdd,.9));strip.userData.noCollision=true;}}
function passage(x,z,width,extent,axis,label){const root=new THREE.Group();root.position.set(x,0,z);root.rotation.y=axis==='x'?Math.PI/2:0;ship.add(root);const wall=0x455c68,gap=width/2,half=extent/2,height=3.6;for(const side of [-1,1]){const w=half-gap;if(w>0)box(root,side*(gap+w/2),height/2+.25,0,w,height,.18,wall);box(root,side*(gap+.065),1.85,-.02,.13,3.2,.25,0x7b939c);}box(root,0,3.56,0,width,.28,.22,0x607986);const leaf=new THREE.Group();leaf.position.y=1.85;root.add(leaf);for(const side of [-1,1]){const part=box(leaf,side*width/4,0,0,width/2-.045,3.08,.12,0x758991);part.userData.doorSide=side;const seam=box(part,side*width*.12,0,-.075,.03,2.5,.014,mat(0x8ad1d0,.5));seam.userData.noCollision=true;}const point=V(x,1.7,z),normal=axis==='x'?V(1,0,0):V(0,0,1);shipInteractables.push({kind:'door',o:leaf,root,point,normal,half:gap,open:false,progress:0,label:'Porta · '+label});return root;}
function consoleDesk(x,z,w=1.65){cabinBox(x,.82,z,w,1,.55,0x314751);const top=cabinBox(x,1.36,z,w+.08,.08,.7,0x617b85);const screen=cabinBox(x,1.54,z-.13,w*.7,.25,.055,mat(0x65bac6,.65));screen.rotation.x=-.25;for(const dx of [-.4,0,.4]){const b=cabinBox(x+dx,1.42,z+.15,.06,.025,.06,0xadc6b7);b.userData.noCollision=true;}}
function storageRack(x,z,w=1.1,d=1.5){cabinBox(x,1.52,z,w,2.4,d,0x334c59);for(let j=0;j<3;j++){cabinBox(x, .66+j*.68,z,w+.05,.07,d+.08,0x78929b);cabinBox(x, .94+j*.68,z+.1,w*.73,.48,d*.65,j%2?0x8c9b90:0x768999);} }
function galley(x,z){cabinBox(x,.9,z,1.2,1.25,3,0x647d85);cabinBox(x,1.57,z,1.25,.08,3.05,0xa3b4b2);cabinBox(x,2.6,z,1.18,.75,2.8,0x4a6370);const sink=cabinBox(x,1.63,z-.7,.68,.03,.75,0x1b343f);bone(ship,V(x+.3,1.64,z-.7),V(x+.3,1.99,z-.7),.035,0x97b4bf);}
function makeShipRooms(){const l=layout(),h=l.halfX,z=l.halfZ;
// Service spaces against opaque sidewalls conceal the wing tanks; windows occur only at the exterior canopy.
for(const side of [-1,1]){for(let zz=-z+5;zz<z;zz+=5){if(shipType===1&&side<0&&zz>-1&&zz<9||shipType!==2&&zz<(shipType===0?-7:-4))continue;cabinBox(side*(h-.11),1.97,zz,.18,3.3,Math.min(5,z-zz+2.5),0x405965);}}
if(shipType===0){roomDeck(0,-3.5,13.6,6.65);roomDeck(0,5,13.6,9.6,0x384f59);roomDeck(0,12.5,13.6,4.6,0x465a60);passage(0,-7,2,14,'z','ponte');passage(0,0,2.2,14,'z','garagem');passage(0,10,8.5,14,'z','câmara de carga');passage(-1.7,-3.5,1.9,6.8,'x','cabine de descanso');passage(1.7,-3.5,1.9,6.8,'x','refeitório');addFurniture('bed',V(-5,.32,-3.7));storageRack(-2.55,-6,1.2,.8);addFurniture('locker',V(-5.75,.3,-.9));galley(5.9,-3.5);addFurniture('bench',V(3.15,.3,-5.7));cabinBox(3.9,1.02,-4.4,1.6,.12,.8,0x91a7a5);storageRack(5.9,2,1.3,2);storageRack(5.9,7.5,1.3,2.5);consoleDesk(-5.65,3,1.6);addFurniture('locker',V(-5.7,.3,7.6));for(const xx of [-3.5,3.5])cabinBox(xx,.34,5.1,.07,.01,8.8,mat(0xc1b384,.15));}
else if(shipType===1){roomDeck(0,-2,10.65,3.7);roomDeck(0,3.5,10.65,6.6,0x3c535c);roomDeck(0,9.1,10.65,3.6);passage(0,-4,1.9,11,'z','ponte');passage(0,0,2.1,11,'z','laboratório');passage(2.8,7.1,1.9,11,'z','habitação');passage(0,9.1,1.6,3.7,'x','dormitório');addFurniture('bed',V(-3,.3,9.1));addFurniture('locker',V(-.9,.3,9.15));galley(4.7,9.1);consoleDesk(-3.8,-2,2);consoleDesk(3.8,-2,2);cabinBox(3.8,2.55,-2,1.7,.7,.55,0x597780);storageRack(4.7,3.5,1,2.8);for(const zz of [1,6.5])cabinBox(-2.9,.34,zz,3.5,.01,.06,mat(0xb2cebb,.15));}
else{roomDeck(-5,-3,9.65,13.6,0x394e58);roomDeck(-5,7,9.65,5.6);roomDeck(5,-2,9.6,3.7);roomDeck(5,2,9.6,3.6);roomDeck(5,7,9.6,5.6);passage(0,2,2,16,'x','oficina');cabinBox(0,2.05,-8,.18,3.6,4);passage(5,-4,2,10,'z','ponte');passage(5,4,2,10,'z','habitação');passage(-5,4,2,10,'z','engenharia');consoleDesk(8.55,0,1.7);storageRack(1.1,-2,1.2,1.5);addFurniture('bed',V(2.6,.3,7));addFurniture('locker',V(8.7,.3,5.5));galley(8.8,8);addFurniture('bench',V(5.7,.3,8.3));storageRack(-8.7,6.5,1.4,3.5);consoleDesk(-3.1,7,2);addFurniture('locker',V(-1.2,.3,6.3));}
// Compact flight station: low side consoles and clear glazing ahead and below the pilot.
const cx=l.cockpit.x,seatZ=l.seat.z,front=l.cockpit.z-1;box(ship,cx,.24,(seatZ+1.2+front)/2,3.4,.17,seatZ+1.2-front,0x425d69);for(const side of [-1,1]){const desk=cabinBox(cx+side*1.2,.73,seatZ-.5,.55,.75,1.7,0x425967);const screen=cabinBox(cx+side*1.1,1.26,seatZ-.85,.45,.24,.5,mat(0x64bdc9,.55));screen.rotation.z=side*.28;bone(ship,V(cx+side*.6,.7,seatZ-.55),V(cx+side*.6,1.08,seatZ-.62),.045,0x9cb0b7);}makeSeat(ship,cx,0,seatZ+.35,0x3c525d);const bridgeBack=shipType===0?-7:shipType===1?-4:-4,bridgeStart=shipType===2?-10:-l.halfZ;box(ship,shipType===2?5:0,.28,(bridgeStart+bridgeBack)/2,shipType===2?9.6:2*h-.4,.07,bridgeBack-bridgeStart,0x435a65);if(shipType!==2)box(ship,0,.25,(-l.halfZ+front)/2,3.4,.16,-l.halfZ-front,0x435a65);for(const side of [-1,1])consoleDesk(cx+side*(shipType===2?2.4:3.1),bridgeBack-1.5,1.3);}

// === PHYSICAL 3D COCKPIT CONSOLE & BUTTONS ===

function makeCockpitButtonTexture(label, sub, colorHex) {
  const c = document.createElement('canvas');
  c.width = 128; c.height = 80;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#06131c';
  ctx.fillRect(0, 0, 128, 80);
  ctx.strokeStyle = colorHex;
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 122, 74);
  ctx.fillStyle = '#edf7fa';
  ctx.font = 'bold 22px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 64, 30);
  ctx.fillStyle = colorHex;
  ctx.font = '13px Arial, sans-serif';
  ctx.fillText(sub, 64, 56);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function makeMfdTelemetryTexture(type) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 180;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#061017';
  ctx.fillRect(0, 0, 256, 180);

  if (type === 'brake') {
    // Left MFD: Power / Propulsion telemetry (Amber Drake Cutter style)
    ctx.strokeStyle = '#e0882e'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#e0882e';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('PWR MGMT // DRAKE CUTTER', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Vertical power bars
    for (let i = 0; i < 4; i++) {
      const bx = 26 + i * 54;
      ctx.strokeRect(bx, 44, 38, 90);
      const h = [65, 80, 50, 75][i];
      ctx.fillRect(bx + 4, 44 + (90 - h), 30, h);
      ctx.font = '10px Courier, monospace';
      ctx.fillText(['THR', 'SHD', 'ENG', 'BRK'][i], bx + 6, 150);
    }
    ctx.fillStyle = '#ffbe6b';
    ctx.font = '11px Courier, monospace';
    ctx.fillText('OUTPUT: 100% · REVERSE READY', 14, 168);
  } else if (type === 'map') {
    // Center MFD: Radar Scanner (Star Citizen circular radar grid)
    ctx.strokeStyle = '#429e84'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    const cx = 128, cy = 94;
    // Concentric range rings
    for (const r of [25, 48, 70]) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    // Crosshair axes
    ctx.beginPath();
    ctx.moveTo(cx - 72, cy); ctx.lineTo(cx + 72, cy);
    ctx.moveTo(cx, cy - 72); ctx.lineTo(cx, cy + 72);
    ctx.stroke();
    // Heading ticks
    ctx.fillStyle = '#61d9b8';
    ctx.font = '10px Courier, monospace';
    ctx.fillText('000°', cx - 12, cy - 74);
    ctx.fillText('090°', cx + 76, cy + 4);
    ctx.fillText('180°', cx - 12, cy + 82);
    ctx.fillText('270°', cx - 100, cy + 4);
    // Target pings
    ctx.fillStyle = '#ffcf52';
    ctx.beginPath(); ctx.arc(cx + 28, cy - 32, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx - 38, cy + 18, 3, 0, Math.PI * 2); ctx.fill();
  } else if (type === 'land') {
    // Right MFD: Flight Systems & Landing gear status (Cyan/Green avionics)
    ctx.strokeStyle = '#4db8c7'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#4db8c7';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('FLIGHT CONFIG // SENSORS', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Systems checklist
    const items = ['GEAR DEPLOYMENT', 'APPROACH RADAR', 'DECK COUPLER', 'TERRAIN SCAN'];
    for (let i = 0; i < items.length; i++) {
      const y = 52 + i * 26;
      ctx.strokeRect(20, y, 14, 14);
      ctx.fillRect(23, y + 3, 8, 8);
      ctx.font = '11px Courier, monospace';
      ctx.fillText(items[i], 44, y + 12);
      ctx.fillText('OK', 210, y + 12);
    }
    ctx.font = '11px Courier, monospace';
    ctx.fillText('RADAR ALT: 90M · PAD AUTO-LOCK', 14, 168);
  } else if (type === 'ramp' || type === 'camera') {
    // Physical console pushbuttons
    ctx.strokeStyle = '#5a7888'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = type === 'ramp' ? '#18423d' : '#1b324d';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = type === 'ramp' ? '#7ee2c8' : '#8ac8ff';
    ctx.font = 'bold 26px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(type === 'ramp' ? 'RAMP' : 'CAM', 128, 80);
    ctx.font = '14px Courier, monospace';
    ctx.fillText(type === 'ramp' ? '[HATCH CTRL]' : '[EXT VIEW]', 128, 120);
  } else if (type === 'stand') {
    // Seat release control
    ctx.strokeStyle = '#7a6642'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = '#2d2416';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = '#f0b85d';
    ctx.font = 'bold 24px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SEAT', 128, 75);
    ctx.font = '14px Courier, monospace';
    ctx.fillText('[STAND UP]', 128, 115);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function buildCockpit3DConsole(shipGroup) {
  cockpit3DButtons.length = 0;
  const l = layout();
  const seat = l.seat;

  // Authentic Drake Cutter cockpit console structure directly in front and below pilot
  const dashRoot = new THREE.Group();
  dashRoot.name = 'cockpitConsole';
  dashRoot.userData.dynamic = true; // Retain matrix updates
  dashRoot.position.set(seat.x, seat.y - 0.18, seat.z - 1.15);
  dashRoot.rotation.x = -0.32; // Angled 18° up toward pilot's eyes
  shipGroup.add(dashRoot);

  // Main angled dashboard backplate (slender 0.04m plate behind screens)
  box(dashRoot, 0, 0.02, -0.02, 1.86, 0.44, 0.04, 0x162028);

  // Recessed dark bezels framing each MFD screen
  box(dashRoot, -0.58, 0.02, 0.005, 0.54, 0.36, 0.015, 0x0a1015);
  box(dashRoot, 0, 0.02, 0.005, 0.48, 0.36, 0.015, 0x0a1015);
  box(dashRoot, 0.58, 0.02, 0.005, 0.54, 0.36, 0.015, 0x0a1015);

  // Upper sunshield / visor brow (positioned cleanly ABOVE screens, cannot block view)
  box(dashRoot, 0, 0.25, 0.04, 1.90, 0.04, 0.14, 0x22303a);

  // Lower support pedestal: recessed far under and behind (Z = -0.16), NEVER blocking the screens
  box(dashRoot, 0, -0.38, -0.16, 0.70, 0.36, 0.16, 0x11171d);

  // 1. Left MFD: Power & Propulsion (Drake Cutter Amber Telemetry)
  const leftMfdTex = makeMfdTelemetryTexture('brake');
  const leftMfd = mesh(new THREE.BoxGeometry(0.50, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: leftMfdTex, emissiveMap: leftMfdTex, emissive: 0xff9d3b, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, -0.58, 0.02, 0.02);
  leftMfd.userData = { isCockpitButton: true, action: 'brake', label: 'PROPULSÃO: FREAR [CLIQUE]', execute: () => executeCockpitAction('brake') };
  cockpit3DButtons.push(leftMfd);

  // 2. Center MFD: Circular Radar / Navigation Scanner
  const centerMfdTex = makeMfdTelemetryTexture('map');
  const centerMfd = mesh(new THREE.BoxGeometry(0.44, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: centerMfdTex, emissiveMap: centerMfdTex, emissive: 0x5df5b8, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, 0, 0.02, 0.02);
  centerMfd.userData = { isCockpitButton: true, action: 'map', label: 'RADAR: MAPA DA GALÁXIA [CLIQUE]', execute: () => executeCockpitAction('map') };
  cockpit3DButtons.push(centerMfd);

  // 3. Right MFD: Flight Systems & Landing Status
  const rightMfdTex = makeMfdTelemetryTexture('land');
  const rightMfd = mesh(new THREE.BoxGeometry(0.50, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: rightMfdTex, emissiveMap: rightMfdTex, emissive: 0x62dbd6, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, 0.58, 0.02, 0.02);
  rightMfd.userData = { isCockpitButton: true, action: 'land', label: 'POUSO: TRAVA DE SOLO [CLIQUE / R]', execute: () => executeCockpitAction('land') };
  cockpit3DButtons.push(rightMfd);

  // Center-Top Pushbutton Module (mounted cleanly above center MFD)
  const topModule = new THREE.Group();
  topModule.position.set(0, 0.28, 0.04);
  dashRoot.add(topModule);
  box(topModule, 0, 0, 0, 0.42, 0.08, 0.12, 0x1f2b34);

  // Button 4: RAMPA (backlit aviation toggle)
  const rampTex = makeMfdTelemetryTexture('ramp');
  const rampBtn = mesh(new THREE.BoxGeometry(0.16, 0.07, 0.03), new THREE.MeshStandardMaterial({
    map: rampTex, emissiveMap: rampTex, emissive: 0x7ee2c8, emissiveIntensity: 0.75, roughness: 0.3
  }), topModule, -0.09, 0, 0.06);
  rampBtn.userData = { isCockpitButton: true, action: 'ramp', label: 'ESCOTILHA: ACIONAR RAMPA [CLIQUE]', execute: () => executeCockpitAction('ramp') };
  cockpit3DButtons.push(rampBtn);

  // Button 5: CÂMERA EXTERNA (backlit aviation toggle)
  const camTex = makeMfdTelemetryTexture('camera');
  const camBtn = mesh(new THREE.BoxGeometry(0.16, 0.07, 0.03), new THREE.MeshStandardMaterial({
    map: camTex, emissiveMap: camTex, emissive: 0x8ac8ff, emissiveIntensity: 0.75, roughness: 0.3
  }), topModule, 0.09, 0, 0.06);
  camBtn.userData = { isCockpitButton: true, action: 'camera', label: 'SISTEMA ÓPTICO: VISÃO EXTERNA [CLIQUE]', execute: () => executeCockpitAction('camera') };
  cockpit3DButtons.push(camBtn);

  // The stand-up button was removed as requested (players press 'E' on PC or 2-finger swipe on mobile).
}

function executeCockpitAction(action) {
  if (audioContext && !audioMuted) {
    tone(780, audioContext.currentTime, 0.05, 0.12, fxBus, 'sine');
  }
  if (action === 'land') {
    if (landed) toast('A nave já está pousada.');
    else land();
  } else if (action === 'brake') {
    brakeShip();
  } else if (action === 'ramp') {
    toggleRamp();
  } else if (action === 'stand') {
    if (mode === 'pilot') {
      mode = 'foot';
      inside = true;
      resetFootMotion();
      foot.copy(layout().seat).add(V(0, .08, 1.8));
      yaw = 0; pitch = 0;
      toast('Você levantou do assento. B perto da entrada para desembarcar.');
    }
  } else if (action === 'map') {
    menu('map');
  } else if (action === 'camera') {
    toggleCamera();
  }
}

function findCockpitButtonAt(clientX, clientY) {
  if (mode !== 'pilot' || !inside || cockpit3DButtons.length === 0) return null;
  camera.updateMatrixWorld(true);
  ship.updateMatrixWorld(true);
  const ray = new THREE.Raycaster();
  if (document.pointerLockElement === renderer.domElement || clientX === undefined || clientY === undefined) {
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    ray.set(camera.position, dir);
  } else {
    const ndc = new THREE.Vector2(
      (clientX / window.innerWidth) * 2 - 1,
      -(clientY / window.innerHeight) * 2 + 1
    );
    ray.setFromCamera(ndc, camera);
  }
  const hits = ray.intersectObjects(cockpit3DButtons, true);
  if (hits.length > 0 && hits[0].distance < 3.8) {
    let obj = hits[0].object;
    while (obj && !obj.userData?.isCockpitButton && obj.parent) obj = obj.parent;
    if (obj?.userData?.isCockpitButton) return obj;
  }
  return null;
}

function updateCockpitRaycast() {
  if (mode !== 'pilot' || !inside || cockpit3DButtons.length === 0) {
    if (targetedCockpitButton) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
      targetedCockpitButton = null;
    }
    const infoEl = $('cockpitTargetInfo');
    if (infoEl) infoEl.classList.add('hidden');
    return;
  }

  const hitObj = findCockpitButtonAt();
  const infoEl = $('cockpitTargetInfo');
  if (hitObj) {
    if (targetedCockpitButton && targetedCockpitButton !== hitObj) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
    }
    targetedCockpitButton = hitObj;
    hitObj.material.emissiveIntensity = 1.45;
    if (infoEl) {
      infoEl.textContent = hitObj.userData.label || 'INTERAGIR';
      infoEl.classList.remove('hidden');
    }
  } else {
    if (targetedCockpitButton) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
      targetedCockpitButton = null;
    }
    if (infoEl) infoEl.classList.add('hidden');
  }
}
window.updateCockpitRaycast = updateCockpitRaycast;
window.findCockpitButtonAt = findCockpitButtonAt;

function cabinLights() {
  const l = layout();
  // Cockpit instrument and console light (cozy, warm sci-fi cockpit)
  const cockLight = new THREE.PointLight(0xbde8ff, 2.2, 14, 1.2);
  cockLight.position.copy(l.cockpit).add(V(0, 0.7, 0.6));
  cockLight.name = 'cockpitLight';
  ship.add(cockLight);

  // Pilot seat light
  const seatLight = new THREE.PointLight(0xffedd5, 1.6, 9, 1.2);
  seatLight.position.copy(l.seat).add(V(0, 1.3, 0));
  ship.add(seatLight);

  // Cabin interior ceiling lights across the length
  const zs = [-l.halfZ * 0.65, -l.halfZ * 0.2, l.halfZ * 0.3, l.halfZ * 0.75];
  for (const z of zs) {
    const light = new THREE.PointLight(0xdcf0ff, 3.2, 16, 1.2);
    light.position.set(shipType === 2 ? 3 : 0, 2.85, z);
    light.name = 'cabinLight';
    ship.add(light);
  }

  // Ship interior soft ambient fill
  const cabinAmb = new THREE.PointLight(0x5a7895, 1.2, 28, 1.2);
  cabinAmb.position.set(0, 2.7, 0);
  ship.add(cabinAmb);

  // Ship exterior hull soft fill: subtle, non-glowing starlight bounce
  const hullFill = new THREE.PointLight(0x5a7895, 0.85, 30, 1.5);
  hullFill.position.set(0, 4.5, -2);
  hullFill.name = 'hullFill';
  ship.add(hullFill);

  // Forward dual headlights (clean, crisp beams)
  const hlL = new THREE.SpotLight(0xe8f4ff, 2.2, 350, Math.PI / 4.8, 0.35, 1.2);
  hlL.position.set(-l.halfX * 0.45, 1.2, -l.halfZ - 5);
  hlL.target.position.set(-l.halfX * 0.45, 1.2, -l.halfZ - 80);
  ship.add(hlL); ship.add(hlL.target);

  const hlR = new THREE.SpotLight(0xe8f4ff, 2.2, 350, Math.PI / 4.8, 0.35, 1.2);
  hlR.position.set(l.halfX * 0.45, 1.2, -l.halfZ - 5);
  hlR.target.position.set(l.halfX * 0.45, 1.2, -l.halfZ - 80);
  ship.add(hlR); ship.add(hlR.target);

  // Exterior navigational beacons (wingtip red/green)
  box(ship, -l.halfX - 0.5, 1.4, -l.halfZ * 0.2, 0.4, 0.4, 0.4, mat(0xff3333, 4.0));
  box(ship, l.halfX + 0.5, 1.4, -l.halfZ * 0.2, 0.4, 0.4, 0.4, mat(0x33ff66, 4.0));
}
function gateSwitches(){const l=layout(),tangent=V().crossVectors(UP,l.normal),base=l.entry.clone().addScaledVector(tangent,l.doorHalf+.45).setY(1.45);for(const outside of [false,true]){const point=base.clone().addScaledVector(l.normal,outside?.32:-.32),g=new THREE.Group();g.position.copy(point);g.quaternion.setFromUnitVectors(V(0,0,1),l.normal.clone().multiplyScalar(outside?1:-1));ship.add(g);box(g,0,0,0,.28,.4,.08,0x263d4b);const light=box(g,0,0,.05,.17,.24,.02,mat(0x8dccb0,.7));shipInteractables.push({kind:'gate',o:g,light,point,outside,label:'Acionar portão'});} }
function switchCandidate(){if(mode!=='foot')return null;const pos=inside?foot:localPoint(player);return shipInteractables.filter(i=>(i.kind==='gate'?i.outside===!inside:inside)&&pos.distanceTo(i.point)<(i.kind==='gate'?2.2:2.5)).sort((a,b)=>pos.distanceTo(a.point)-pos.distanceTo(b.point))[0]||null;}
function doorwayOccupied(item){const l=layout(),point=item?.point||l.entry,normal=item?.normal||l.normal,half=item?.half||l.doorHalf,local=mode==='rover'?localPoint(rover.getWorldPosition(V())):inside?foot:localPoint(player),d=local.clone().sub(point),t=V().crossVectors(UP,normal);return Math.abs(d.dot(normal))<.7&&Math.abs(d.dot(t))<half+.4&&local.y<3.5;}
function useShipInterior(){if(resting){standUp();return true;}const found=switchCandidate();if(!found)return false;if(found.kind==='gate'){if(!rampOpen||!doorwayOccupied())openRamp(!rampOpen,false);else toast('Entrada ocupada. Afaste-se para fechar o portão.');return true;}if(found.kind==='door'){if(found.open&&doorwayOccupied(found)){toast('Passagem ocupada. Afaste-se para fechar.');return true;}found.open=!found.open;toast(found.open?'Abrindo passagem.':'Fechando passagem.');}else if(found.kind==='locker'){activeLocker=found;menu('locker');}else{resting={kind:found.kind,returnPoint:foot.clone(),point:found.point.clone().add(V(0,found.kind==='bed'?.15:.35,0)),avatar:found.o.position.clone().add(V(0,found.kind==='bed'?1.25:.6,found.kind==='bed'?1:0))};yaw=0;pitch=found.kind==='bed'?.45:0;toast(found.kind==='bed'?'Deitado. E ou pulo para levantar.':'Sentado. E ou pulo para levantar.');}return true;}
function openRamp(open=true,immediate=true){rampOpen=open;const door=ship.getObjectByName('door');door.userData.target=open?1:0;if(immediate)door.userData.progress=door.userData.target;updateGateGeometry(0);}
function updateGateGeometry(dt){const door=ship.getObjectByName('door'),ramp=ship.getObjectByName('ramp');if(!door||!ramp)return;let t=door.userData.progress??1,target=door.userData.target??(rampOpen?1:0);t=THREE.MathUtils.clamp(t+Math.sign(target-t)*Math.min(Math.abs(target-t),dt*1.6),0,1);door.userData.progress=t;door.position.y=2.4+t*2.3;door.scale.y=Math.max(.001,1-t);door.visible=t<.995;door.userData.removed=t>.995;ramp.visible=t>.01;ramp.userData.removed=t<.01;ramp.quaternion.setFromAxisAngle(UP,Math.atan2(layout().normal.x,layout().normal.z)).multiply(new THREE.Quaternion().setFromAxisAngle(V(1,0,0),(1-t)*-Math.PI/2));ramp.traverse(o=>o.userData.removed=t<.01);for(const i of shipInteractables)if(i.kind==='gate'){i.light.material.color.set(rampOpen?0x8dccb0:0xd6a168);i.light.material.emissive.copy(i.light.material.color);}}
function tickInteriors(dt,paused){if(!paused){updateGateGeometry(dt);for(const d of shipInteractables)if(d.kind==='door'){const target=d.open?1:0;d.progress=THREE.MathUtils.clamp(d.progress+Math.sign(target-d.progress)*Math.min(Math.abs(target-d.progress),dt*2),0,1);for(const part of d.o.children)part.position.x=part.userData.doorSide*d.half*(.5+d.progress);d.o.visible=d.progress<.995;d.o.traverse(o=>o.userData.removed=d.progress>.995);}}const i=switchCandidate();$('interiorPrompt').textContent=mode==='foot'&&inside&&!resting&&foot.distanceTo(layout().seat)<2.6?(touchEnabled?'DUPLO TOQUE':'E')+' · ASSUMIR CONTROLE':resting?'INTERAGIR · LEVANTAR':i?(touchEnabled?'DUPLO TOQUE':'E')+' · '+(i.kind==='gate'?(rampOpen?'FECHAR PORTÃO':'ABRIR PORTÃO'):i.label.toUpperCase()):'';}

function buildShip(){landingGears.length=0;landingSequence=null;shipGearProgress=1.0;shipGearSuspension=0;shipTiltPitch=shipTiltRoll=shipTiltYaw=0;while(ship.children.length){const old=ship.children[0];ship.remove(old);if(old!==rover)old.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.map?.dispose();o.material.dispose();}});}shipInteractables.length=0;resting=null;const l=layout(),t=shipTypes[shipType],h=l.halfX,z=l.halfZ,metal=0x637c8b,glass=new THREE.MeshStandardMaterial({color:0x99d2de,transparent:true,opacity:.15,metalness:.1,roughness:.12,side:THREE.DoubleSide});rampOpen=true;
aeroHull();
const ramp=new THREE.Group();ramp.position.copy(l.entry);ramp.rotation.y=Math.atan2(l.normal.x,l.normal.z);ramp.name='ramp';ship.add(ramp);const deck=box(ramp,0,-.45,3.4,l.doorHalf*2,.28,7.2,0x809699);deck.rotation.x=.20;for(const x of [-l.doorHalf+.2,l.doorHalf-.2])box(ramp,x,.03,3.1,.1,.1,6,mat(0xa4e3cb,.8));const door=box(ship,l.entry.x,2.4,l.entry.z,l.normal.x?.32:l.doorHalf*2,4.6,l.normal.x?l.doorHalf*2:.32,t.color);door.name='door';door.visible=false;door.userData.removed=true;
makeShipRooms();gateSwitches();cabinLights();buildCockpit3DConsole(ship);optimizeShipDraws();
ship.add(rover);rover.position.copy(l.rover);rover.rotation.set(0,l.roverYaw,0);ship.traverse(o=>{if(o.isMesh){o.castShadow=!o.material.transparent;o.receiveShadow=true;}});if(collisionReady)refreshMovingBodies();}
function makeSeat(root,x,y,z,c){box(root,x,y+.55,z,1.2,.5,1.3,c);const back=box(root,x,y+1.15,z+.55,1.2,1.3,.23,c);back.rotation.x=.1;for(const side of [-1,1])box(root,x+side*.7,y+.9,z,.15,.15,.9,0x657c89);}
function bulkhead(z,x,w,doorX,label){const gap=2.8,min=x-w/2,max=x+w/2,left=doorX-gap/2,right=doorX+gap/2;if(left>min)box(ship,(min+left)/2,2.5,z,left-min,4.8,.25,0x5b747f);if(max>right)box(ship,(max+right)/2,2.5,z,max-right,4.8,.25,0x5b747f);box(ship,doorX,4.4,z,gap,1,.28,0x637e88);const o=box(ship,doorX,2,z,gap,3.8,.18,0x809798);o.visible=false;o.userData.removed=true;shipInteractables.push({kind:'door',o,point:V(doorX,1.8,z),open:true,label});label3D(ship,label,doorX,4.3,z+.2,4);}

function addFurniture(kind,pos){const g=new THREE.Group();g.position.copy(pos);ship.add(g);if(kind==='bed'){box(g,0,.4,0,1.8,.6,3.3,0x536b79);box(g,0,.78,0,1.7,.18,3.1,0xaabcb9);box(g,0,.97,-1,1.2,.18,.65,0xd1d9ce);box(g,0,.92,.5,1.72,.10,1.9,0x729999);}else if(kind==='bench'){makeSeat(g,0,0,0,0x78999f);}else{box(g,0,1.4,0,1.2,2.8,2,0x7a909b);box(g,.65,1.5,0,.12,2.4,1.8,0x9daeb0);}shipInteractables.push({kind,o:g,point:pos.clone().add(V(0,1.4,0)),label:kind==='bed'?'Deitar':kind==='bench'?'Sentar':'Abrir compartimento'});}

function standUp(){if(!resting)return;foot.copy(resting.returnPoint);resting=null;jumpVelocity=0;onFootGround=true;yaw=0;pitch=0;}
function transferItem(key,direction){if(!activeLocker||!inside||mode!=='foot'||foot.distanceTo(activeLocker.point)>3||!Object.hasOwn(locker,key))return;const amount=key==='ammo'?12:1,from=direction==='store'?equipment:locker,to=direction==='store'?locker:equipment,n=Math.min(amount,from[key]);if(!n){toast('Não há itens para transferir.');return;}from[key]-=n;to[key]+=n;save();renderPanel('locker');}
function enhanceShip(){}
function remodelRover(kind=vehicleKind){vehicleKind=kind;discardChildren(rover);if(['skiff','cutter'].includes(kind)){boatModel(rover,kind);rover.userData.wheels=[];for(const side of [-1,1])for(const z of [-1.4,1.4])mesh(new THREE.CylinderGeometry(.28,.28,.18,10),0x243541,rover,side*1.14,.2,z).rotation.z=Math.PI/2;vehicleHealth=150;if(collisionReady)refreshMovingBodies();return;}const c=kind==='hauler'?0x77896f:kind==='scout'?0x76aeb4:0xc5a278;box(rover,0,.45,0,2.5,.65,4.1,c);box(rover,0,.85,-1.5,2.2,.65,1.15,c);box(rover,0,.8,1.65,2.3,.65,.65,c);box(rover,0,2.15,.35,2.3,.16,2.75,c);const glass=new THREE.MeshStandardMaterial({color:0x85b8cb,transparent:true,opacity:.12,side:THREE.DoubleSide,roughness:.12});const windshield=box(rover,0,1.65,-1,2.05,.9,.08,glass);windshield.rotation.x=-.18;for(const side of [-1,1]){box(rover,side*1.15,1.08,.35,.14,.7,2.6,c);box(rover,side*1.15,1.75,.35,.07,.65,2.55,glass);for(const z of [-1,1.7])bone(rover,V(side*1.07,.7,z),V(side*1.07,2.15,z),.075,0x405867);}box(rover,0,1.25,-.9,1.8,.18,.6,0x2b4555);box(rover,.45,1.38,-.9,.7,.24,.08,mat(0x6bc5c5,.5));const wheel=mesh(new THREE.TorusGeometry(.28,.035,6,16),0x2d4553,rover,0,1.43,-.6);wheel.rotation.x=-.4;makeSeat(rover,0,.25,.45,0x3d5867);rover.userData.wheels=[];for(const side of [-1,1])for(const z of kind==='hauler'?[-1.5,0,1.5]:[-1.4,1.4]){const pivot=new THREE.Group();pivot.position.set(side*1.35,.28,z);rover.add(pivot);mesh(new THREE.CylinderGeometry(.57,.57,.4,16),0x24333b,pivot).rotation.z=Math.PI/2;mesh(new THREE.CylinderGeometry(.26,.26,.43,10),0x9eafb8,pivot).rotation.z=Math.PI/2;rover.userData.wheels.push(pivot);bone(rover,V(side*.8,.5,z),V(side*1.35,.4,z),.08,0x596f7c);}for(const x of [-.85,.85])mesh(new THREE.SphereGeometry(.15,8,6),mat(0xd0eacd,.8),rover,x,.9,-2.1);vehicleHealth=kind==='hauler'?240:kind==='scout'?100:150;rover.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});if(collisionReady)refreshMovingBodies();}

function city(parent,p){if(p)decoratePlanet(parent,p);else stationCity(parent,p);}
function settlementNormals(p){if(p.siteNormals)return p.siteNormals;const v=settlementProfiles[p.i],out=[];if(v.cities||v.villages)out.push({n:UP.clone(),half:v.cities?285:130});if(v.cities>1)out.push({n:V(.85,.15,-.48).normalize(),half:285});for(let i=v.cities?0:1;i<v.villages;i++){const a=1.6+i*2.1+p.i*.3;out.push({n:V(Math.cos(a)*.8,-.25,Math.sin(a)*.8).normalize(),half:130});}p.siteNormals=out;return out;}
function radius(p,n){let value=height(n,p.i)-waterCarve(p,n);for(const site of settlementNormals(p)){const distance=Math.acos(THREE.MathUtils.clamp(n.dot(site.n),-1,1))*p.r,blend=THREE.MathUtils.smoothstep(distance,site.half-35,site.half);if(blend<1)value=THREE.MathUtils.lerp(Math.max(8,height(site.n,p.i)),value,blend);}return p.r+value;}
function walkFrame(pos,p){if(station&&pos.distanceTo(station.position)<180)return station.getWorldQuaternion(new THREE.Quaternion());return p?frameAt(pos,p.center):new THREE.Quaternion();}
function placeOnGround(pos,p,height=1.8){const baseline=p?groundEye(pos,p,height):pos.clone(),up=p?planetUp(pos,p):UP.clone();const floor=floorProbe(baseline.clone().addScaledVector(up,2),up,p,height,5);return floor||baseline;}
function safeZone(pos){return settlements.some(s=>pos.distanceTo(s.center)<s.half*1.5)||destinations.some(d=>d.station&&pos.distanceTo(d.pos)<175);}
function atPort(){const pos=controlledPosition();return destinations.find(d=>!d.gate&&d.kind!=='water'&&pos.distanceTo(d.pos)<(d.settlement?d.settlement.half*1.5:120));}
function registerBodies(){staticBodies.length=0;movingBodies.length=0;scene.updateMatrixWorld(true);scene.traverse(o=>{if(!o.isMesh||hasAncestorFlag(o,'noCollision')||hasAncestorFlag(o,'actor')||hasAncestorFlag(o,'dynamic')||hasAncestorFlag(o,'combatEnemy')||o.geometry.type==='PlaneGeometry'&&!o.userData.surfaceOnly||o.geometry.type==='RingGeometry'||o.material.type==='ShaderMaterial'||o.userData.celestial||belongsTo(o,ship)||belongsTo(o,rover)||animals.some(a=>belongsTo(o,a.g)))return;const b=makeBody(o);refreshBody(b);staticBodies.push(b);});refreshMovingBodies();collisionReady=true;}

function updateCitizens(dt,paused){if(paused)return;const observer=controlledPosition(),nearby=npcs.filter(n=>{const s=n.settlement||n.shop?.settlement;return (!s||s.center.distanceTo(observer)<s.half+210)&&n.g.getWorldPosition(V()).distanceTo(observer)<(quality==='low'?110:175)});for(const n of nearby){const near=n.g.getWorldPosition(V()).distanceTo(observer)<3.2;if(n.settlement){n.walkPhase=(n.walkPhase||0)+(near?0:dt*.0013);const local=townPath(n.settlement,n.walkPhase,1.075),ahead=townPath(n.settlement,n.walkPhase+.002,1.075),world=settlementPoint(n.settlement,local.x,local.z,.18);n.city.position.copy(world).sub(n.settlement.root.position);n.city.quaternion.copy(frameAt(world,n.settlement.p.center));const d=ahead.sub(local);n.g.rotation.y=Math.atan2(-d.x,-d.z);}else{if(n.wait>0)n.wait-=dt;if(!near&&n.wait<=0){const delta=n.path[n.way].clone().sub(n.g.position),dist=delta.length();if(dist<.12){n.way=(n.way+1)%n.path.length;n.wait=1.5;}else n.g.position.addScaledVector(delta.normalize(),Math.min(dist,dt*.85));}if(near){const d=n.city.worldToLocal(observer.clone()).sub(n.g.position);n.g.rotation.y=Math.atan2(-d.x,-d.z);}}if(!n.proxy?.visible)animateHuman(n.g,dt);}for(const a of animals){if(a.g.position.distanceTo(observer)>250)continue;const q=frameAt(a.origin,a.p.center),offset=V(Math.sin(totalTime*.25+a.phase)*2.5,0,Math.cos(totalTime*.25+a.phase)*2.5).applyQuaternion(q),candidate=a.origin.clone().add(offset);if(candidate.distanceTo(observer)>3.5&&!isWater(a.p,planetUp(candidate,a.p)))a.g.position.copy(candidate);a.g.position.copy(surfacePoint(a.g.position,a.p,.1));a.g.quaternion.copy(frameAt(a.g.position,a.p.center));}}
function planetApproach(d,air){const n=planetUp(ship.position,air.p),targetN=planetUp(d.pos,d.p),angle=planetUp(ship.position,d.p.center?d.p:air.p).angleTo(targetN);if(air.p!==d.p&&air.alt<ATMOSPHERE+200)return air.p.center.clone().addScaledVector(n,air.p.r+ATMOSPHERE+450);if(angle>.09){const own=planetUp(ship.position,d.p),step=own.clone().lerp(targetN,.2).normalize();if(own.dot(targetN)<-.94)step.copy(own).add(V(.3,.1,.2)).normalize();return d.p.center.clone().addScaledVector(step,d.p.r+1000);}return d.pos.clone().addScaledVector(targetN,2);}
function renderPanel(tab){if(tab==='locker'){const valid=activeLocker&&inside;if(!valid){renderPanelV04('inventory');return;}$('content').innerHTML='<div class="eyebrow">COMPARTIMENTO DA NAVE</div><h2>Transferir suprimentos</h2><p>O armário acompanha sua frota. Munição é transferida em lotes de até 12; os outros itens, uma unidade por vez.</p><div class="cards">'+['ammo','grenades','medkits'].map((key,i)=>`<div class="card"><strong>${['Munição','Granadas','Kits médicos'][i]}</strong><p>Inventário: ${equipment[key]} · Armário: ${locker[key]}</p><button onclick="transferItem('${key}','store')">Guardar →</button> <button onclick="transferItem('${key}','take')">← Retirar</button></div>`).join('')+'</div>';return;}renderPanelV04(tab);if(tab==='inventory')$('content').innerHTML+=`<h3>Roupas e jetpack</h3><p>Jetpack estágio ${jetLevel} · ${jetCapacity()} unidades · aprimoramentos nas oficinas.</p><div class="cards">${ownedOutfits.map(id=>`<button class="card ${outfit===id?'selected':''}" onclick="equipOutfit('${id}')"><strong>${{explorer:'Explorador',ranger:'Patrulheiro',engineer:'Engenheiro',arctic:'Polar',night:'Noturno'}[id]}</strong><span>${outfit===id?'EM USO':'VESTIR'}</span></button>`).join('')}</div>`;if(tab==='settings')$('content').innerHTML+=`<details open><summary>Novos controles · SkyWard ${VERSION}</summary><p>Espaço: pular. Segure no ar para usar o jetpack; solte para economizar combustível. Recarrega ao tocar o chão.<br>V: primeira/terceira pessoa, a pé, na nave e no veículo. E: portas internas, cama, bancos e compartimentos. E ou pulo: levantar.<br>No celular, use duplo toque segurado para pular; mantenha até começar a cair para ativar o jetpack. A câmera em 1ª/3ª pessoa está na tira superior esquerda. As oficinas melhoram o jetpack; as lojas de roupas personalizam seu traje.<br>LOD automático dos planetas e redução dos detalhes de cidades e habitantes à distância.</p></details>`;if(tab==='map')$('content').innerHTML+='<p>'+planets.map(p=>`${p.def[0]}: ${settlementProfiles[p.i].cities} cidades, ${settlementProfiles[p.i].villages} vilarejos`).join(' · ')+'</p>';}
function v05Tick(dt,paused){if(!paused)updateTraffic(dt);const current=settlements.find(s=>controlledPosition().distanceTo(s.center)<s.half*1.1);if(current)$('place').textContent=current.name;updateLOD(dt);updateCityBatches();}
function bootV05(){initPlayerV05();updateLOD(0,true);$('versionLabel').textContent='SKYWARD · '+VERSION;const count=$('settlementCount');count.textContent=settlements.length;}
function thinPanelPush(center,r,b){const p=b.obj.geometry.attributes.position,idx=b.obj.geometry.index,count=idx?idx.count:p.count,local=center.clone().applyMatrix4(b.inv);let best=null,depth=0;for(let j=0;j<count;j+=3){const points=[0,1,2].map(k=>{const n=idx?idx.getX(j+k):j+k;return V(p.getX(n),p.getY(n),p.getZ(n));}),tri=new THREE.Triangle(...points),closest=tri.closestPointToPoint(local,V()),delta=local.clone().sub(closest),len=delta.length();if(len<r&&r-len>depth){if(len>.0001)delta.divideScalar(len);else delta.copy(tri.getNormal(V()));depth=r-len;best=delta.multiplyScalar(depth+.002).applyQuaternion((b.rotation||b.obj.getWorldQuaternion(new THREE.Quaternion())));}}return best;}

function hostilePosition(pos,p){if(!p)return pos;const s=settlements.find(s=>s.p===p&&pos.distanceTo(s.center)<s.half*1.5+35);return s?settlementPoint(s,s.half*1.5+90+(enemySerial%3)*10,20+(enemySerial%4)*10,.12):pos;}

function clearInput(){pinchGesture=null;touchX=touchY=0;firing=false;Object.keys(keys).forEach(k=>keys[k]=false);touches.clear();pendingTaps.left=pendingTaps.right=null;mobileJumpHeld=mobileJumpBoost=false;jumpOwner=null;aiming=false;aimOwner=null;touchRoll=touchLift=0;steerPixels.set(0,0,0);weaponPress=weaponItemPress=null;hideWeaponInfo();}
function gestureContext(){return mode+'|'+inside+'|'+eva;}
function touchDown(e){if(!touchEnabled||e.pointerType!=='touch'||!started||!$('panel').classList.contains('hidden'))return;
  if(mode==='pilot'&&cockpit3DButtons.length>0){
    const r=new THREE.Raycaster();
    const ndc={x:(e.clientX/innerWidth)*2-1,y:-(e.clientY/innerHeight)*2+1};
    r.setFromCamera(ndc,camera);
    const hits=r.intersectObjects(cockpit3DButtons,false);
    if(hits.length>0&&hits[0].distance<3.2){
      hits[0].object.userData.execute();
      return;
    }
  }
e.preventDefault();const now=inputNow(),side=e.clientX<innerWidth/2?'left':'right';advanceTouch(now);if(touches.size>=2)return;const pending=pendingTaps[side],second=!!pending&&now-pending.at<=DOUBLE_MS;if(second)pendingTaps[side]=null;const t={id:e.pointerId,side,x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,at:now,moved:false,second,held:false,aim:false,context:gestureContext()};touches.set(t.id,t);pinchDown();renderer.domElement.setPointerCapture?.(t.id);}
function startSecondHold(t){if(t.held)return;t.held=true;haptic();if(mode==='pilot'){if(t.side==='right'){touchRoll=touchLift=0;}}else if(mode==='foot'&&jumpOwner===null){jumpOwner=t.id;mobileJumpHeld=true;mobileJumpBoost=false;jumpWasDown=false;keys.Space=true;}}
function touchMove(e){const t=touches.get(e.pointerId);if(!t)return;e.preventDefault();if(t.pinched&&!pinchGesture)return;if(pinchMove(e))return;advanceTouch(inputNow());const dx=e.clientX-t.x,dy=e.clientY-t.y,mx=e.clientX-t.lastX,my=e.clientY-t.lastY;if(Math.hypot(dx,dy)>DRAG_PX)t.moved=true;if(t.second&&t.moved&&!t.held)startSecondHold(t);
if(t.side==='left'&&t.moved){autoForward=false;const scale=Math.min(95,innerWidth*.18),len=Math.max(1,Math.hypot(dx,dy)/scale);touchX=THREE.MathUtils.clamp(dx/len/scale,-1,1);touchY=THREE.MathUtils.clamp(dy/len/scale,-1,1);if(mode==='pilot')auto=null;}
if(t.side==='right'&&t.moved){
  if(mode==='pilot'&&t.second&&t.held){
    touchRoll=THREE.MathUtils.clamp(-dx/90,-1,1);
    touchLift=THREE.MathUtils.clamp(-dy/90,-1,1);
  } else {
    // Long press check while holding right screen
    if(!t.second&&!t.aim&&mode==='foot'&&inputNow()-t.at>=200&&aimCapable()){
      t.aim=true;
      aiming=true;
      aimOwner=t.id;
      haptic();
    }
    lookInput(mx,my);
  }
}t.lastX=e.clientX;t.lastY=e.clientY;}
function touchEnd(e,cancel=false){const t=touches.get(e.pointerId);if(!t)return;e.preventDefault?.();advanceTouch(inputNow());touches.delete(t.id);if(pinchGesture?.ids.includes(t.id))pinchGesture=null;if(t.side==='left'){touchX=touchY=0;}if(t.side==='right'&&t.second){touchRoll=touchLift=0;}if(aimOwner===t.id){aiming=false;aimOwner=null;}if(jumpOwner===t.id){keys.Space=false;mobileJumpHeld=mobileJumpBoost=false;jumpOwner=null;}if(cancel||t.pinched||t.context!==gestureContext())return;const duration=inputNow()-t.at;if(t.moved||t.held||t.aim||duration>=HOLD_MS)return;
if(t.second){
  if(t.side==='left'){
    autoForward=true;
    if(mode==='pilot')auto=null;
    toast(mode==='pilot'?'Cruzeiro automático. Deslize à esquerda para reassumir.':'Corrida automática. Deslize à esquerda para reassumir.');
  } else {
    // 2 cliques na direita
    if(mode==='pilot'){
      if(!shipLookOnly){
        // Alternar para mover câmera livre
        shipLookOnly=true;
        steerPixels.set(0,0,0);
        toast('Câmera livre ativada. 1 toque interage no painel · 2 toques volta ao voo.');
      } else {
        // Voltar para o modo de voo centralizando a câmera
        shipLookOnly=false;
        pitch=0; yaw=0;
        steerPixels.set(0,0,0);
        angularVelocity.set(0,0,0);
        toast('Modo de voo centralizado.');
      }
    } else {
      firePlayer();
    }
  }
} else {
  pendingTaps[t.side]={at:inputNow(),context:t.context};
}}
function advanceTouch(now=inputNow()){if(!started)return;if(!$('panel').classList.contains('hidden'))return;for(const side of ['left','right']){
  const tap=pendingTaps[side];
  if(tap&&now-tap.at>DOUBLE_MS){
    pendingTaps[side]=null;
    if(tap.context===gestureContext()){
      if(side==='right'){
        if(mode==='pilot'){
          if(!shipLookOnly){
            // No modo de voo, 1 clique na direita aciona o ataque da nave!
            firePlayer();
          } else {
            // No modo de mover a câmera, 1 clique faz interagir com os elementos do painel!
            if(targetedCockpitButton){
              targetedCockpitButton.userData.execute();
            } else {
              toast('Mire em um instrumento do painel para interagir.');
            }
          }
        } else {
          interact();
        }
      } else {
        firePlayer();
      }
    }
  }
}
for(const t of touches.values()){if(t.pinched||t.context!==gestureContext())continue;const elapsed=now-t.at;if(t.second&&!t.held&&elapsed>=SECOND_HOLD_MS)startSecondHold(t);else if(!t.second&&t.side==='right'&&!t.aim&&elapsed>=200&&aimCapable()){t.aim=true;aiming=true;aimOwner=t.id;haptic();}}
if(weaponPress&&!weaponPress.moved&&!weaponPress.held&&now-weaponPress.at>=HOLD_MS){weaponPress.held=true;haptic();showWeaponPicker();}
if(weaponItemPress&&!weaponItemPress.held&&!weaponItemPress.moved&&now-weaponItemPress.at>=HOLD_MS){weaponItemPress.held=true;weaponInfoHeld=true;haptic();showWeaponInfo(weaponItemPress.id);}}
function lookInput(dx,dy){if(!started||!$('panel').classList.contains('hidden'))return;const factor=(touchEnabled?.0028:.0018)*controlPrefs.camera;if(mode==='pilot'&&!landed&&!auto&&!boost&&!shipLookOnly){steerPixels.x+=dy;steerPixels.y+=dx;}else{const sensitivity=aiming?.48:1;yaw-=dx*factor*sensitivity;pitch=THREE.MathUtils.clamp(pitch-dy*factor*sensitivity,-1.35,1.35);}}
let lastMiddleToggle = -1000;
function toggleCockpitCameraLook(e) {
  if (e && e.button !== undefined && e.button !== 1) return;
  if (e) {
    if (e.preventDefault) e.preventDefault();
    if (e.stopPropagation) e.stopPropagation();
  }
  const now = performance.now();
  if (now - lastMiddleToggle < 200) return;
  lastMiddleToggle = now;

  if (mode === 'pilot') {
    shipLookOnly = !shipLookOnly;
    steerPixels.set(0, 0, 0);
    angularVelocity.x = angularVelocity.y = 0;
    if (shipLookOnly) {
      toast('Câmera livre ativada. Clique com o botão esquerdo para interagir com o painel.');
    } else {
      pitch = 0; yaw = 0;
      toast('Modo de voo centralizado.');
    }
  }
}
window.toggleCockpitCameraLook = toggleCockpitCameraLook;

function bindTouch(){const canvas=renderer.domElement;canvas.addEventListener('pointerdown', e => {
  if (e.pointerType === 'touch') {
    touchDown(e);
  } else if (e.button === 1) {
    toggleCockpitCameraLook(e);
    return;
  } else if (e.button === 2) {
    // Right click aims down sights on PC
    e.preventDefault();
    if (aimCapable()) aiming = true;
  } else if (e.button === 0) {
    if (mode === 'pilot') {
      if (shipLookOnly) {
        const clickedBtn = targetedCockpitButton || findCockpitButtonAt(e.clientX, e.clientY);
        if (clickedBtn && clickedBtn.userData?.execute) {
          clickedBtn.userData.execute();
          haptic();
          return;
        } else {
          toast('Mire em um instrumento do painel para interagir.');
        }
        return;
      }
      if (!shipLookOnly && document.pointerLockElement === canvas) {
        firing = true;
      }
    } else {
      if (document.pointerLockElement === canvas) firing = true;
    }
  }
});

canvas.addEventListener('pointerup', e => {
  if (e.button === 2) aiming = false;
});
canvas.addEventListener('mouseup', e => {
  if (e.button === 2) aiming = false;
});
window.addEventListener('pointerup', e => {
  if (e.button === 2) aiming = false;
});
window.addEventListener('mouseup', e => {
  if (e.button === 2) aiming = false;
});
window.addEventListener('mousedown', e => {
  if (e.button === 1) toggleCockpitCameraLook(e);
});
window.addEventListener('auxclick', e => {
  if (e.button === 1) toggleCockpitCameraLook(e);
});canvas.addEventListener('pointermove',touchMove);canvas.addEventListener('pointerup',e=>{if(e.pointerType==='touch')touchEnd(e);else firing=false;});canvas.addEventListener('pointercancel',e=>{touchEnd(e,true);firing=false;});canvas.addEventListener('lostpointercapture',e=>touchEnd(e,true));canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('auxclick',e=>{if(e.button===1)e.preventDefault();});canvas.addEventListener('wheel',e=>{if(started&&$('panel').classList.contains('hidden')){e.preventDefault();zoomCamera(Math.exp(THREE.MathUtils.clamp(e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?innerHeight:1),-200,200)*.0015));}},{passive:false});bindWeaponButton();
addEventListener('blur',()=>{clearInput();autoForward=false;});document.addEventListener?.('visibilitychange',()=>{if(document.hidden){clearInput();autoForward=false;}});addEventListener('keydown',e=>{if(!started)return;if(e.code==='Tab'){e.preventDefault();menu('inventory');return;}if(!$('panel').classList.contains('hidden'))return;const map={Digit1:'pistol',Digit2:'blade',Digit3:'rifle',Digit4:'shotgun',Digit5:'sabre',Digit6:'grenade',Digit7:'tool'};if(map[e.code])equipWeapon(map[e.code]);if(e.code==='KeyR'&&mode==='foot')reloadWeapon();if(e.code==='KeyC'&&mode==='foot')useMedkit();});}
function inputTick(dt){const context=gestureContext();if(gestureMode!==context){pinchGesture=null;touches.clear();pendingTaps.left=pendingTaps.right=null;touchX=touchY=0;if(mobileJumpHeld)keys.Space=false;mobileJumpHeld=mobileJumpBoost=false;jumpOwner=null;aiming=false;aimOwner=null;if(gestureMode.split('|')[0]!==mode)autoForward=false;shipLookOnly=false;angularVelocity.set(0,0,0);gestureMode=context;}advanceTouch();if(aiming&&!aimCapable()){aiming=false;aimOwner=null;}aimBlend=THREE.MathUtils.lerp(aimBlend,aiming?1:0,1-Math.exp(-dt*10));if(!$('actionStrip').classList.contains('hidden'))refreshActionStrip();$('gestureState').textContent=(autoForward?(mode==='pilot'?'CRUZEIRO':'CORRIDA')+' AUTO':'')+(mode==='pilot'&&shipLookOnly?' · CÂMERA LIVRE':'');}
function inputAfterTick(){if(weaponView&&aimBlend>.001&&!thirdPerson){weaponView.position.x=THREE.MathUtils.lerp(.31,0,aimBlend);weaponView.position.y=THREE.MathUtils.lerp(-.29,-.16,aimBlend);}$('quickWeapon').textContent=mode==='pilot'?'Canhões':weaponDefs[equipped].name;$('quickWeapon').classList.toggle('aiming',aiming);}

function manualFlight(dt, air) {
  const piloting = mode === 'pilot';
  const forward = piloting ? axisForward() : 0;
  // Lift using Space (up) and Ctrl (down)
  const lift = piloting ? ((keys.Space ? 1 : 0) - ((keys.ControlLeft || keys.ControlRight) ? 1 : 0) + touchLift) : 0;
  // Strafe using A (left) and D (right)
  const side = piloting ? axisStrafe() : 0;

  if (landed) {
    manualVelocity.set(0, 0, 0);
    angularVelocity.set(0, 0, 0);
    thrustAcceleration = sideSpeed = liftSpeed = 0;
    shipNavQuaternion.copy(ship.quaternion);
    shipTiltPitch = shipTiltRoll = shipTiltYaw = 0;
    if (!piloting || (forward <= 0.05 && lift <= 0.05)) return;
    // Takeoff lifts ship off ground and automatically begins landing gear retraction!
    landed = false;
    openRamp(false, false);
    ship.position.addScaledVector(UP.clone().applyQuaternion(ship.quaternion), 3.5);
    yaw = pitch = 0;
  }

  if (!manualWasActive) {
    manualVelocity.copy(shipVelocity);
    if (manualVelocity.length() > 2600) manualVelocity.setLength(2600);
    manualWasActive = true;
    shipNavQuaternion.copy(ship.quaternion);
  }

  const response = [3.2, 4.2, 2.9][shipType];
  const maxAngular = [0.75, 1.05, 0.60][shipType] * controlPrefs.ship;
  const gain = 1 - Math.exp(-dt * response);
  const wanted = V();

  if (piloting) {
    const mouseSteerX = !shipLookOnly ? -steerPixels.x * 0.002 * controlPrefs.ship / Math.max(dt, 0.008) : 0;
    const mouseSteerY = !shipLookOnly ? -steerPixels.y * 0.002 * controlPrefs.ship / Math.max(dt, 0.008) : 0;
    const keySteerX = (keys.ArrowUp ? maxAngular : 0) - (keys.ArrowDown ? maxAngular : 0);
    const keySteerY = (keys.ArrowLeft ? maxAngular : 0) - (keys.ArrowRight ? maxAngular : 0);
    wanted.x = THREE.MathUtils.clamp(mouseSteerX + keySteerX, -maxAngular, maxAngular);
    wanted.y = THREE.MathUtils.clamp(mouseSteerY + keySteerY, -maxAngular, maxAngular);

    // Roll: Q rolls left (+1), E rolls right (-1)!
    wanted.z = THREE.MathUtils.clamp(touchRoll + (keys.KeyQ ? 1 : 0) - (keys.KeyE ? 1 : 0), -1, 1) * maxAngular;
  }

  steerPixels.set(0, 0, 0);
  angularVelocity.lerp(wanted, gain);

  // Rotate Navigational Heading
  const rotQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(angularVelocity.x * dt, angularVelocity.y * dt, angularVelocity.z * dt, 'YXZ'));
  shipNavQuaternion.multiply(rotQ);

  // === PROCEDURAL VISUAL SHIP TILT ANIMATION ===
  // Bounded, smooth, spring-return tilt for Space, Ctrl, A, D and mouse steering
  let targetTiltPitch = 0;
  let targetTiltRoll = 0;
  let targetTiltYaw = 0;

  if (piloting && !landed) {
    // Space: nose pitches up (+0.14 rad ~ 8.0°)
    if (keys.Space) targetTiltPitch += 0.14;
    // Ctrl: nose pitches down (-0.14 rad ~ -8.0°)
    if (keys.ControlLeft || keys.ControlRight) targetTiltPitch -= 0.14;

    // A: bank left (-0.22 rad ~ -12.5°)
    if (keys.KeyA) { targetTiltRoll -= 0.22; targetTiltYaw -= 0.05; }
    // D: bank right (+0.22 rad ~ +12.5°)
    if (keys.KeyD) { targetTiltRoll += 0.22; targetTiltYaw += 0.05; }

    // Mouse steering dynamic banking
    if (!shipLookOnly) {
      targetTiltRoll += THREE.MathUtils.clamp(angularVelocity.y * -0.22, -0.16, 0.16);
    }
  }

  // Smooth spring return to neutral (0) when buttons are released
  const tiltEase = 1 - Math.exp(-dt * 6.5);
  shipTiltPitch = THREE.MathUtils.lerp(shipTiltPitch, targetTiltPitch, tiltEase);
  shipTiltRoll = THREE.MathUtils.lerp(shipTiltRoll, targetTiltRoll, tiltEase);
  shipTiltYaw = THREE.MathUtils.lerp(shipTiltYaw, targetTiltYaw, tiltEase);

  const tiltQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(shipTiltPitch, shipTiltYaw, shipTiltRoll, 'YXZ'));
  ship.quaternion.copy(shipNavQuaternion).multiply(tiltQ);

  if (!shipLookOnly && piloting) {
    yaw *= Math.exp(-dt * 3);
    pitch *= Math.exp(-dt * 3);
  }

  const accel = (sprinting() ? 100 : [35, 48, 25][shipType]);
  const targetAcceleration = forward * accel;
  thrustAcceleration = THREE.MathUtils.lerp(thrustAcceleration, targetAcceleration, gain);
  const cap = sprinting() ? 2400 : shipTypes[shipType].speed;

  if (piloting) {
    flightSpeed = THREE.MathUtils.clamp(flightSpeed + thrustAcceleration * dt, -35, Math.max(cap, flightSpeed));
  }
  flightSpeed /= 1 + air.density * 0.004 * Math.abs(flightSpeed) * dt;

  // Faster, more responsive lateral and vertical thrusters (over 3x faster sideSpeed, 2x liftSpeed)
  const damping = 1 / (1 + air.density * 2);
  const thrusterGain = 1 - Math.exp(-dt * (response * 1.6));
  sideSpeed = THREE.MathUtils.lerp(sideSpeed, side * 85 * damping, thrusterGain);
  liftSpeed = THREE.MathUtils.lerp(liftSpeed, lift * 90 * damping, thrusterGain);

  const desired = V(sideSpeed, liftSpeed, -flightSpeed).applyQuaternion(shipNavQuaternion);
  manualVelocity.lerp(desired, 1 - Math.exp(-dt * response));
  ship.position.addScaledVector(manualVelocity, dt);
}
function brakeShip(){autoForward=false;auto=null;flightSpeed=0;thrustAcceleration=0;touchX=touchY=0;toast('Freando.');}

function equipWeapon(id){if(id!=='tool'&&id!=='grenade'&&!equipment.weapons.includes(id))return equipWeaponBase(id);equipWeaponBase(id);if(equipped!==id)return;if(!cyclingEquipment)recentEquipment=[id,...recentEquipment.filter(x=>x!==id)].slice(0,3);if(!aimCapable()){aiming=false;aimOwner=null;}save();}
function cycleWeapon(){
  const list=recentEquipment.filter(id=>{
    if(id==='grenade') return equipment.grenades>0;
    if(id==='tool') return true;
    return equipment.weapons.includes(id);
  });
  if(!list.length)return;
  cyclingEquipment=true;
  equipWeapon(list[(list.indexOf(equipped)+1)%list.length]);
  cyclingEquipment=false;
}
function hideWeaponInfo(){const e=$('equipmentInfo');if(e)e.classList.add('hidden');weaponInfoHeld=false;}
function showWeaponInfo(id){const d=weaponDefs[id];$('equipmentInfo').innerHTML=`<strong>${d.name}</strong><p>${id==='tool'?'Coleta minério, cataloga fauna e executa ações de contratos.':id==='grenade'?'Explosão em área. Mantenha distância.':d.mag?'Arma de longo alcance. Segure à direita para mirar.':'Arma de combate próximo.'}</p><p>${d.damage?d.damage+' de dano · ':''}${d.range} m${d.mag?' · carregador de '+d.mag:''}</p>`;$('equipmentInfo').classList.remove('hidden');}
function showWeaponPicker(){pendingTaps.left=pendingTaps.right=null;$('actionStrip').classList.add('hidden');const ids=[...new Set([...equipment.weapons,...(equipment.grenades>0?['grenade']:[]),'tool'])];$('weaponPicker').innerHTML='<div class="pickerTitle">EQUIPAMENTO <span>Toque escolhe · segure para detalhes</span></div><div class="equipmentGrid">'+ids.map(id=>`<div role="button" tabindex="0" class="equipmentItem ${id===equipped?'selected':''}" data-equipment="${id}"><strong>${weaponDefs[id].name}</strong><small>${recentEquipment.includes(id)?'ACESSO RÁPIDO':'SELECIONAR'}</small></div>`).join('')+'</div>';$('weaponPicker').classList.remove('hidden');for(const el of $('weaponPicker').querySelectorAll('[data-equipment]')){const id=el.dataset.equipment;el.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();el.setPointerCapture(e.pointerId);weaponItemPress={id,pointerId:e.pointerId,at:inputNow(),x:e.clientX,y:e.clientY,held:false,moved:false};});el.addEventListener('pointermove',e=>{if(weaponItemPress?.pointerId===e.pointerId&&Math.hypot(e.clientX-weaponItemPress.x,e.clientY-weaponItemPress.y)>14)weaponItemPress.moved=true;});el.addEventListener('pointerup',e=>endEquipmentItem(e,false));el.addEventListener('pointercancel',e=>endEquipmentItem(e,true));el.addEventListener('lostpointercapture',e=>endEquipmentItem(e,true));el.addEventListener('keydown',e=>{if(e.key==='Enter'){equipWeapon(id);closeWeaponPicker();}});}}
function endEquipmentItem(e,cancel){const t=weaponItemPress;if(!t||t.pointerId!==e.pointerId)return;e.preventDefault?.();advanceTouch(inputNow());const choose=!cancel&&!t.held&&!t.moved;weaponItemPress=null;hideWeaponInfo();if(choose){equipWeapon(t.id);closeWeaponPicker();}}
function closeWeaponPicker(){$('weaponPicker').classList.add('hidden');hideWeaponInfo();weaponItemPress=null;}
function bindWeaponButton(){const b=$('quickWeapon');b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();b.setPointerCapture(e.pointerId);weaponPress={pointerId:e.pointerId,at:inputNow(),x:e.clientX,y:e.clientY,moved:false,held:false,reloaded:false};});b.addEventListener('pointermove',e=>{const p=weaponPress;if(!p||p.pointerId!==e.pointerId)return;const r=b.getBoundingClientRect(),outside=e.clientX<r.left||e.clientX>r.left+r.width||e.clientY<r.top||e.clientY>r.top+r.height;if(!p.held&&outside&&Math.hypot(e.clientX-p.x,e.clientY-p.y)>16){p.moved=true;if(!p.reloaded){p.reloaded=true;if(mode==='foot')reloadWeapon();}}});b.addEventListener('pointerup',e=>{const p=weaponPress;if(!p||p.pointerId!==e.pointerId)return;e.preventDefault();advanceTouch(inputNow());weaponPress=null;if(!p.held&&!p.moved){if(!$('weaponPicker').classList.contains('hidden'))closeWeaponPicker();else cycleWeapon();}});for(const type of ['pointercancel','lostpointercapture'])b.addEventListener(type,e=>{if(weaponPress?.pointerId===e.pointerId)weaponPress=null;});}
function contextualActions(){const a=[['camera',thirdPerson?'1ª pessoa':'3ª pessoa']];if(mode==='pilot'){a.push(['seat','Levantar'],['boarding','Desembarcar'],['ramp','Rampa'],['land','Pousar [R]'],['brake','Frear']);if(auto)a.push(['manual','Voo manual']);}else if(mode==='rover'){a.push(['seat','Sair do veículo'],['boarding','Embarcar veículo'],['recall','Voltar à nave']);}else{a.push(['interact','Interagir'],['tool','Ferramenta'],['medkit','Kit médico'],['recall','Voltar à nave']);if(inside||controlledPosition().distanceTo(entryWorld())<12)a.push(['boarding',inside?'Desembarcar':'Embarcar'],['ramp','Rampa']);}return a;}
function refreshActionStrip(){const actions=contextualActions(),signature=JSON.stringify(actions);if(signature===stripSignature)return;stripSignature=signature;$('actionStrip').innerHTML=actions.map(([id,label])=>`<button onclick="runContextAction('${id}')">${label}</button>`).join('');}
function toggleActionStrip(){pendingTaps.left=pendingTaps.right=null;closeWeaponPicker();$('actionStrip').classList.toggle('hidden');stripSignature='';refreshActionStrip();}
function runContextAction(id){if(!contextualActions().some(a=>a[0]===id))return;$('actionStrip').classList.add('hidden');const actions={camera:toggleCamera,map:()=>menu('map'),inventory:()=>menu('inventory'),jobs:()=>menu('jobs'),fleet:()=>menu('fleet'),seat:interact,interact,boarding:boardingAction,ramp:toggleRamp,land,brake:brakeShip,manual:()=>auto=null,recall,tool:()=>equipWeapon('tool'),medkit:useMedkit,guide:toggleGuide,audio:toggleAudio};actions[id]?.();}
function bootV06(){try{const saved=JSON.parse(localStorage.getItem('horizonte-v1'))?.skyward?.recentEquipment;if(Array.isArray(saved)){const valid=[...new Set(saved.filter(id=>weaponDefs[id]&&(equipment.weapons.includes(id)||id==='grenade'||id==='tool')))];if(valid.length)recentEquipment=valid.slice(0,3);}}catch{}gestureMode=gestureContext();}

function wetPlanet(p){return [0,2,3,4,5].includes(p.i);}
function seaRadius(p){return p.r-4;}
function waterCarve(p,n){if(!wetPlanet(p))return 0;const lon=Math.atan2(n.z,n.x),lat=Math.asin(n.y),basin=Math.sin(n.x*3.2+p.i*.7)+Math.cos(n.z*4.1-p.i*.5)+Math.sin(n.y*3.8)*.45;const ocean=THREE.MathUtils.smoothstep(basin,.3,1.4)*36;const river=Math.min(Math.abs(lat-.20*Math.sin(lon*3+p.i)-.18),Math.abs(lat-.24*Math.sin(lon*2-p.i)+.35));const channel=(1-THREE.MathUtils.smoothstep(river,.009,.045))*29;return Math.max(ocean,channel);}
function isWater(p,n){return wetPlanet(p)&&radius(p,n)<seaRadius(p)-.5;}
function waterPoint(p,n,offset=0){return p.center.clone().addScaledVector(n,seaRadius(p)+offset);}
function aquaticDriveSpeed(){if(rover.parent===ship)return 5;if(!['skiff','cutter'].includes(vehicleKind))return vehicleKind==='scout'?42:vehicleKind==='hauler'?24:32;const pos=rover.getWorldPosition(V()),p=nearest(pos);return rover.parent!==ship&&isWater(p,planetUp(pos,p))?(vehicleKind==='skiff'?36:28):5;}
function boatModel(g,kind='skiff'){const c=kind==='cutter'?0x8fa6b9:0xd7ae76;const rows=[[-2.65,.12],[-1.7,1.05],[0,1.2],[1.9,1.1],[2.1,.8]];for(let j=0;j<rows.length-1;j++)for(const side of [-1,1]){const [z,w]=rows[j],[zz,ww]=rows[j+1];panelMesh(g,[[side*w,.65,z],[side*ww,.65,zz],[side*ww*.6,.05,zz],[side*w*.6,.05,z]],c);panelMesh(g,[[0,.05,z],[0,.05,zz],[side*ww*.6,.05,zz],[side*w*.6,.05,z]],0x405968);}box(g,0,.6,0,2.05,.12,3.8,0x536d75);makeSeat(g,0,.55,.45,0x486172);box(g,0,1.35,-.95,1.7,.25,.65,0x456371);const glass=new THREE.MeshStandardMaterial({color:0xa3d1db,transparent:true,opacity:.2,side:THREE.DoubleSide});panelMesh(g,[[-1,1,-1.6],[1,1,-1.6],[.9,2,-1.1],[-.9,2,-1.1]],0x90bac5).material=glass;box(g,0,2.22,.15,2,.12,2.7,c);for(const side of [-1,1]){bone(g,V(side*.95,.65,1.45),V(side*.95,2.2,1.45),.06,c);mesh(new THREE.TorusGeometry(.27,.07,6,12),0x2b4655,g,side*.7,.2,2.15);}g.userData.boat=true;}
function fishModel(g,i){g.userData.aquatic=true;g.userData.dynamic=true;const col=[0x65bac0,0,0xc4e7f4,0xcb91da,0xe2bc6c,0x75dfc1][i];ellipsoid(g,0,0,0,i===3?.8:i===4?.28:.45,i===3?.7:.48,i===4?2.2:i===3?.8:1.5,col,2);if(i===3)for(let j=0;j<5;j++)bone(g,V((j-2)*.25,-.25,.1),V((j-2)*.4,-1.4,.4),.045,col);ellipsoid(g,0,0,-1,.38,.36,.55,col,2);for(const side of [-1,1])panelMesh(g,[[side*.2,0,-.4],[side*(i===5?2:1.2),-.08,.5],[side*.3,.02,.8]],col);const tail=new THREE.Group();tail.position.z=1.2;g.add(tail);panelMesh(tail,[[0,0,0],[0,.75,.8],[0,0,.55],[0,-.75,.8]],col);g.userData.fishTail=tail;}
function bootEnvironment(){for(const p of planets){const random=rng(7219+p.i*723),state={p,random,rain:0,rainTarget:0,weatherIn:35+random()*90,eventIn:480+random()*720,event:null,boats:[],fish:[],plants:[]};environment.push(state);if(wetPlanet(p)){const water=mesh(new THREE.SphereGeometry(seaRadius(p),96,64),new THREE.MeshStandardMaterial({color:[0x1b7384,0,0x407caa,0x514d8d,0x318c8b,0x226d6c][p.i],roughness:.25,metalness:.3,transparent:true,opacity:.84,flatShading:true}),scene,...p.center.toArray());water.userData.noCollision=true;water.material.side=THREE.DoubleSide;p.water=water;p.waterFar=new THREE.SphereGeometry(seaRadius(p),32,20);p.waterNear=water.geometry;const spots=[];for(let k=0;k<500&&spots.length<18;k++){const n=V(random()*2-1,random()*2-1,random()*2-1).normalize();if(radius(p,n)<seaRadius(p)-7)spots.push(n);}state.spots=spots;for(let k=0;k<spots.length;k++){const n=spots[k],g=new THREE.Group();g.position.copy(waterPoint(p,n,-2.5));g.quaternion.copy(frameAt(g.position,p.center));scene.add(g);fishModel(g,p.i);state.fish.push({g,n,phase:random()*6});for(let j=0;j<3;j++){const plant=new THREE.Group();plant.position.copy(surfacePoint(g.position,p,.1));plant.quaternion.copy(frameAt(plant.position,p.center));scene.add(plant);for(let stem=0;stem<4;stem++){const x=(stem-1.5)*.6;bone(plant,V(x,0,0),V(x+.3,3+stem%2,.2),.09,0x408e83);panelMesh(plant,[[x,1,0],[x+1,2,.15],[x+.3,3,0]],p.i===3?0xa775b7:0x6aaa86);}plant.position.add(V(j*.6,0,j*.5));plant.userData.noCollision=true;state.plants.push(plant);}}
for(let k=0;k<Math.min(3,spots.length);k++){const g=new THREE.Group();scene.add(g);boatModel(g,k%2?'cutter':'skiff');g.userData.dynamic=true;const pilot=person(g,0,.3,0x86a6b4);pilot.position.y=.4;pilot.scale.multiplyScalar(.85);state.boats.push({g,n:spots[k],phase:k*2,pilot});}
// Navigation marks a deep-water site; the player's craft remains physical cargo.
if(spots.length)destinations.push({name:p.def[0]+' · Mar aberto',p,pos:waterPoint(p,spots[0],2),kind:'water'});}
const am=p.atmosphere.material;am.uniforms.lightDir={value:(suns[0]||{pos:V(0,9000,-18000)}).pos.clone().sub(p.center).normalize()};am.vertexShader=am.vertexShader.replace('varying vec3 n;', 'varying vec3 wn;varying vec3 n;').replace('void main(){','void main(){wn=normalize(position);');am.fragmentShader=am.fragmentShader.replace('uniform vec3 tint;','uniform vec3 tint;uniform vec3 lightDir;varying vec3 wn;').replace('rim*.07','rim*.07*smoothstep(-.2,.15,dot(normalize(wn),lightDir))');am.needsUpdate=true;
const cloudMat=new THREE.ShaderMaterial({uniforms:{sunDir:{value:(suns[0]||{pos:V(0,9000,-18000)}).pos.clone().sub(p.center).normalize()},tint:{value:new THREE.Color(0xe0e9ec)},cover:{value:.42}},vertexShader:'varying vec3 q;void main(){q=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 q;uniform vec3 sunDir;uniform vec3 tint;uniform float cover;void main(){vec3 n=normalize(q);float a=sin(n.x*23.+sin(n.z*15.)*2.)*cos(n.y*19.-n.z*6.);float b=sin(n.z*47.+n.y*16.)*sin(n.x*39.);float cloud=smoothstep(cover,cover+.28,a*.7+b*.3);float light=.10+.90*smoothstep(-.1,.4,dot(n,sunDir));gl_FragColor=vec4(tint*light,cloud*.76);}',transparent:true,depthWrite:false,side:THREE.DoubleSide});p.cloud=mesh(new THREE.SphereGeometry(p.r+105,48,32),cloudMat,scene,...p.center.toArray());p.cloud.userData.noCollision=true;}
const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(240*6),3));rainLines=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0xa8c6df,transparent:true,opacity:.5,depthWrite:false}));rainLines.frustumCulled=false;rainLines.userData.noCollision=true;scene.add(rainLines);disasterFX=new THREE.Group();disasterFX.userData.noCollision=true;scene.add(disasterFX);
for(const a of animals){if(isWater(a.p,planetUp(a.g.position,a.p))){const random=rng(902+a.p.i*19+a.phase);for(let k=0;k<150;k++){const n=V(random()*2-1,random()*2-1,random()*2-1).normalize();if(!isWater(a.p,n)){a.g.position.copy(surfacePoint(a.p.center.clone().add(n),a.p,.1));a.origin.copy(a.g.position);break;}}}}
for(const g of scenery){const p=nearest(g.position);if(isWater(p,planetUp(g.position,p))){g.visible=false;g.userData.submergedLand=true;}}
}
function daylight(p,pos){const light=(suns[0]||{pos:V(0,9000,-18000)}).pos.clone().sub(pos).normalize(),up=planetUp(pos,p),elevation=up.dot(light);return {light,elevation,day:THREE.MathUtils.smoothstep(elevation,-.19,.13),sunset:1-THREE.MathUtils.smoothstep(Math.abs(elevation),0,.42)};}
function environmentSky(dt) {
  const { p, alt, density } = atmosphereAt(camera.position);
  const d = daylight(p, camera.position);
  const day = d.day;
  const env = environment.find(e => e.p === p);
  const rain = env?.rain || 0;
  const inSpace = density < 0.08;

  const spaceSky = new THREE.Color(0x020409);
  const atmoSky = new THREE.Color(0x02050b).lerp(new THREE.Color(p.def[5]).multiplyScalar(.46), Math.sqrt(density) * day);
  atmoSky.lerp(new THREE.Color(0x8b483d), density * d.sunset * day * .35);
  atmoSky.multiplyScalar(1 - rain * .35);

  const sky = inSpace ? spaceSky : atmoSky;
  scene.background = sky;
  scene.fog.color.copy(sky);
  scene.fog.near = inSpace ? 25000 : (450 + 1000 * (1 - density));
  scene.fog.far = inSpace ? 4000000 : (3500 + 2000000 * (1 - density));

  starsObj.material.opacity = inSpace ? 1 : Math.max(0, 1 - density * day * .98);

  for (const w of planets) {
    w.haze.value = inSpace ? 0 : (w === p ? 0 : density * day * .68);
    w.hazeColor.value.copy(sky);
    if (w.atmosphere) {
      w.atmosphere.material.uniforms.tint.value.set(w.def[5]).multiplyScalar(inSpace ? 1.0 : (w === p ? .2 + .8 * day : 1));
    }
  }

  if (inSpace) {
    sunlight.color.set(0xfff5ea);
    sunlight.intensity = 1.95;
    for (const light of scene.children) {
      if (light.isHemisphereLight) {
        light.intensity = 0.58;
        light.color.set(0x6a8eb8);
        light.groundColor.set(0x1a2230);
      }
    }
  } else {
    sunlight.color.set(0xffefdc).lerp(new THREE.Color(0xff652c), d.sunset * density * .85);
    sunlight.intensity = (.18 + day * 2.5) * (1 - rain * .5);
    for (const light of scene.children) {
      if (light.isHemisphereLight) {
        light.intensity = .20 + day * 1.7;
        light.color.set(0xc4e9ff);
        light.groundColor.set(0x404051);
      }
    }
  }

  const sol = suns[0] || { pos: V(0, 9000, -18000) };
  if (sol.sun) {
    sol.sun.material.color.setRGB(8, 6, 3).lerp(new THREE.Color(8, 1.05, .12), d.sunset * density);
    sol.halo.material.color.set(0xffefc6).lerp(new THREE.Color(0xff5823), d.sunset * density);
    sol.halo.material.opacity = 1 - rain * .6;
  }

  if (!inside && mode === 'foot' && wetPlanet(p) && camera.position.distanceTo(p.center) < seaRadius(p)) {
    scene.fog.near = 0;
    scene.fog.far = 65;
    scene.fog.color.set(p.water.material.color);
    scene.background.copy(scene.fog.color);
  }
}
function startDisaster(state,type){if(state.event)return;discardChildren(disasterFX);disasterFX.position.set(0,0,0);disasterFX.quaternion.identity();if(type==='storm'||type==='hurricane')state.rainTarget=1;state.event={type,elapsed:0,impact:controlledPosition().clone(),lastPulse:0};toast('ALERTA AMBIENTAL · '+({meteor:'chuva de meteoros',storm:'tempestade elétrica',hurricane:'ciclone',quake:'atividade sísmica'}[type])+' em 15 segundos. Busque abrigo.');}
function disasterTick(e,dt,local){const ev=e.event;if(!ev)return;ev.elapsed+=dt;if(ev.elapsed<15)return;if(ev.elapsed>48){e.event=null;e.rainTarget=0;e.eventIn=600+e.random()*900;discardChildren(disasterFX);return;}if(!local)return;const t=ev.elapsed-15,pos=controlledPosition(),dist=pos.distanceTo(ev.impact),p=e.p,up=planetUp(pos,p),exposed=mode==='foot'&&!inside&&!station&&!safeZone(pos);if(ev.type==='quake'&&dist<700&&onFootGround){camera.position.add(V(Math.sin(totalTime*37),Math.cos(totalTime*29),Math.sin(totalTime*41)).multiplyScalar(.055));}
if(ev.type==='hurricane'){if(!disasterFX.children.length){for(let k=0;k<12;k++){const ring=mesh(new THREE.TorusGeometry(3+k*1.3,.45,5,20),new THREE.MeshBasicMaterial({color:0x9babb1,transparent:true,opacity:.28,depthWrite:false}),disasterFX,0,k*5,0);ring.rotation.x=Math.PI/2;}}disasterFX.position.copy(surfacePoint(ev.impact,p));disasterFX.quaternion.copy(frameAt(ev.impact,p.center));disasterFX.rotateY(t*1.5);if(dist<180&&exposed){const wind=ev.impact.clone().sub(player).addScaledVector(up,3).normalize().multiplyScalar(dt*5);player.copy(moveActor(player,wind,{up,p}));}}
if(t-ev.lastPulse>(ev.type==='meteor'?3:ev.type==='storm'?4:7)){ev.lastPulse=t;if(ev.type==='meteor'||ev.type==='storm'){const f=frameAt(ev.impact,p.center),impact=surfacePoint(ev.impact.clone().add(V((e.random()-.5)*200,0,(e.random()-.5)*200).applyQuaternion(f)),p,.2);if(ev.type==='meteor'){const g=mesh(new THREE.IcosahedronGeometry(1.2,1),mat(0xffa359,3),disasterFX);g.position.copy(impact).addScaledVector(planetUp(impact,p),180);g.userData.fall={target:impact,ttl:1.2};}else{const verts=[];let old=impact;for(let k=1;k<=8;k++){const next=impact.clone().addScaledVector(up,k*20).add(V(Math.sin(k*13+t)*5,0,Math.cos(k*7+t)*5));verts.push(...old.toArray(),...next.toArray());old=next;}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));const line=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0xd7edff}));line.userData.ttl=.25;disasterFX.add(line);if(audioContext&&!audioMuted)tone(42,audioContext.currentTime+.25,.8,.08,fxBus,'sawtooth');if(pos.distanceTo(impact)<9&&exposed){suitShield=Math.max(0,suitShield-18);health=Math.max(1,health-8);}}}}
for(const o of [...disasterFX.children]){if(o.userData.fall){const f=o.userData.fall;f.ttl-=dt;o.position.lerp(f.target,Math.min(1,dt/Math.max(.01,f.ttl)));if(f.ttl<=0){particleBurst(f.target,0xffa266,18,12);if(pos.distanceTo(f.target)<14&&exposed)health=Math.max(1,health-20);disasterFX.remove(o);o.geometry.dispose();o.material.dispose();}}else if(o.userData.ttl!==undefined){o.userData.ttl-=dt;if(o.userData.ttl<=0){disasterFX.remove(o);o.geometry.dispose();o.material.dispose();}}}}
function waterMovement(dt){if(mode!=='foot'||inside||station||resting)return false;const p=groundPlanet||nearest(player),up=planetUp(player,p),depth=seaRadius(p)-radius(p,up),alt=player.distanceTo(p.center)-seaRadius(p);if(depth<1.2||alt>1||!wetPlanet(p))return false;eva=false;groundPlanet=p;onFootGround=false;jetActive=false;const frame=frameAt(player,p.center),delta=V(axisStrafe(),0,-axisForward());if(delta.lengthSq()>1)delta.normalize();delta.applyAxisAngle(UP,yaw).applyQuaternion(frame).multiplyScalar(dt*(sprinting()?4.2:2.7));player.copy(moveActor(player,delta,{up,p,height:1.8,grounded:false}));player.copy(waterPoint(p,planetUp(player,p),.45));if(keys.Space&&jetFuel>0){jumpVelocity=7;jetFuel=Math.max(0,jetFuel-dt*28);player.addScaledVector(up,1);footContext='ground';}return true;}
function environmentTick(dt,paused){if(boost||!planets||planets.length===0)return;environmentSky(dt);const pos=controlledPosition(),p=nearest(pos),near=pos.distanceTo(p.center)<p.r+600;for(const e of environment){const local=e.p===p&&near;if(e.p.water){e.p.water.geometry=e.p.lodIndex>=3?e.p.waterNear:e.p.waterFar;e.p.water.visible=e.p.globe.visible;}e.p.cloud.visible=performancePrefs.clouds&&e.p.globe.visible;e.p.cloud.material.uniforms.cover.value=.48-e.rain*.3;if(!paused)e.p.cloud.rotateY(dt*.0005);for(const f of e.fish){f.g.visible=local&&f.g.position.distanceTo(pos)<160;if(!f.g.visible||paused)continue;const n=f.n.clone().add(V(Math.sin(totalTime*.17+f.phase)*.009,0,Math.cos(totalTime*.17+f.phase)*.009)).normalize();f.g.position.copy(waterPoint(p,n,-2.5));f.g.quaternion.copy(frameAt(f.g.position,p.center));f.g.rotateY(totalTime*.17+f.phase);f.g.userData.fishTail.rotation.y=Math.sin(totalTime*5+f.phase)*.45;}for(const g of e.plants){g.visible=local&&g.position.distanceTo(pos)<120;if(g.visible&&!paused){g.quaternion.copy(frameAt(g.position,e.p.center));g.rotateZ(Math.sin(totalTime*.8+g.position.x)*.06);}}for(const b of e.boats){b.g.visible=local&&b.g.position.distanceTo(pos)<600;if(paused)continue;const n=b.n.clone().add(V(Math.sin(totalTime*.06+b.phase)*.015,0,Math.cos(totalTime*.06+b.phase)*.015)).normalize();const candidate=waterPoint(e.p,n,.2);if(candidate.distanceTo(pos)>6)b.g.position.copy(candidate);b.g.quaternion.copy(frameAt(b.g.position,e.p.center));b.g.rotateY(totalTime*.06+b.phase);if(b.g.visible)animateHuman(b.pilot,dt,true);}
if(paused||!local)continue;e.weatherIn-=dt;e.eventIn-=dt;if(e.weatherIn<=0){e.weatherIn=90+e.random()*150;e.rainTarget=wetPlanet(p)&&e.random()<.32?.65+e.random()*.35:0;}e.rain=THREE.MathUtils.lerp(e.rain,e.rainTarget,1-Math.exp(-dt*.05));if(e.eventIn<=0&&!e.event)startDisaster(e,['meteor','storm','hurricane','quake'][Math.floor(e.random()*(wetPlanet(p)?4:2))*(!wetPlanet(p)?3:1)]||'quake');disasterTick(e,dt,local);}
const local=environment.find(e=>e.p===p);if(disasterFX)disasterFX.visible=near&&!!local?.event;const raining=near&&(local?.rain||0)>.08&&!inside&&!station&&mode!=='pilot',count=quality==='low'?90:240;if(rainLines){rainLines.visible=raining&&particlesEnabled&&performancePrefs.rain;if(rainLines.visible&&!paused){const a=rainLines.geometry.attributes.position,frame=frameAt(pos,p.center);for(let i=0;i<count;i++){const phase=(totalTime*(p.i===2?3:22)+i*1.731)%25,x=Math.sin(i*12.98)*18,z=Math.cos(i*7.23)*18;const v=V(x,20-phase,z).applyQuaternion(frame).add(pos),end=v.clone().addScaledVector(planetUp(pos,p),p.i===2?.2:-1.2);a.setXYZ(i*2,v.x,v.y,v.z);a.setXYZ(i*2+1,end.x,end.y,end.z);}a.needsUpdate=true;rainLines.geometry.setDrawRange(0,count*2);rainLines.material.opacity=(local?.rain||0)*.55;}}
if(mode==='rover'&&rover.parent!==ship&&wetPlanet(p)&&isWater(p,planetUp(rover.position,p))&&!paused){const n=planetUp(rover.position,p),aquatic=['skiff','cutter'].includes(vehicleKind);if(aquatic){rover.position.copy(waterPoint(p,n,.2));roverAir=false;}else{$('state').textContent='VEÍCULO SUBMERSO · USE UMA EMBARCAÇÃO';}}
for(const g of scenery)if(g.userData.submergedLand)g.visible=false;if(near&&local&&local.rain>.1)$('airState').textContent+=' · '+(p.i===2?'NEVE':'CHUVA');if(local&&local.event){const ev=local.event,names={meteor:'METEOROS',storm:'RAIOS',hurricane:'CICLONE',quake:'TREMOR'};$('gestureState').textContent+=' · '+names[ev.type]+(ev.elapsed<15?' EM '+Math.ceil(15-ev.elapsed)+' s':' · BUSQUE ABRIGO');}}

function bakeMeshes(items,parent,emissive=0){if(!items.length)return null;parent.updateWorldMatrix(true,false);const inv=parent.matrixWorld.clone().invert(),positions=[],normals=[],colors=[];for(const o of items){const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();o.updateWorldMatrix(true,false);geo.applyMatrix4(inv.clone().multiply(o.matrixWorld));positions.push(...geo.attributes.position.array);normals.push(...geo.attributes.normal.array);const c=o.material.color||new THREE.Color(0x778899),source=geo.attributes.color;for(let k=0;k<geo.attributes.position.count;k++)colors.push(c.r*(source?source.getX(k):1),c.g*(source?source.getY(k):1),c.b*(source?source.getZ(k):1));geo.dispose();}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.computeBoundingSphere();const m=mesh(g,new THREE.MeshStandardMaterial({vertexColors:true,flatShading:true,roughness:.85,emissive:0xffffff,emissiveIntensity:emissive}),parent);m.userData.noCollision=true;m.receiveShadow=true;return m;}
function optimizeCities(){for(const n of npcs)actorProxy(n);for(const n of npcs)if(n.settlement)n.city.userData.dynamic=true;cityBatches.length=0;for(const s of settlements){const buckets=new Map();for(const lot of s.lots){if(lot.userData.shop){const shop=lot.userData.shop,proxy=new THREE.Group();proxy.position.copy(shop.g.position);proxy.quaternion.copy(shop.g.quaternion);lot.add(proxy);proxy.userData.noCollision=true;box(proxy,0,4.5,0,27,9,29,0x637d84);proxy.visible=false;shop.userDataProxy=proxy;continue;}if(!lot.userData.height)continue;const local=settlementLocal(s,lot.getWorldPosition(V())),key=Math.floor(local.x/65)+','+Math.floor(local.z/65);if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(lot);}for(const lots of buckets.values()){const group=new THREE.Group();group.userData.noCollision=true;s.root.add(group);const shell=[],detail=[],proxies=[];for(const lot of lots){lot.updateWorldMatrix(true,true);lot.traverse(o=>{if(!o.isMesh||!o.layers.isEnabled(0)||o.material.transparent||o.material.map||hasAncestorFlag(o,'actor'))return;(hasAncestorFlag(o,'detailRoot')?detail:shell).push(o);});const proxy=new THREE.Mesh(new THREE.BoxGeometry(17,lot.userData.height,18),mat(0x70838b));proxy.matrix.copy(lot.matrixWorld).multiply(new THREE.Matrix4().makeTranslation(0,lot.userData.height/2,0));proxy.matrixAutoUpdate=false;proxy.matrixWorld.copy(proxy.matrix);proxies.push(proxy);}const body=bakeMeshes(shell,group),windows=bakeMeshes(detail,group,.035),coarse=bakeMeshes(proxies,group);proxies.forEach(o=>{o.geometry.dispose();o.material.dispose();});for(const o of [...shell,...detail])o.layers.set(31);const center=lots.reduce((v,g)=>v.add(g.getWorldPosition(V())),V()).multiplyScalar(1/lots.length);cityBatches.push({s,group,body,windows,coarse,center});}s.root.updateMatrixWorld(true);s.root.traverse(o=>{if(!hasAncestorFlag(o,'actor')&&!hasAncestorFlag(o,'dynamic')){o.updateMatrix();o.matrixAutoUpdate=false;}});}scene.updateMatrix();scene.matrixAutoUpdate=false;updateCityBatches(true);}
function updateCityBatches(force=false){if(!force&&totalTime-cityBatchTime<.18)return;cityBatchTime=totalTime;const observer=camera.position,low=quality==='low';for(const n of npcs)if(n.proxy){const far=n.g.getWorldPosition(V()).distanceTo(observer)>(low?40:75)*performancePrefs.characterDistance;n.proxy.visible=far;for(const part of n.rigParts)part.visible=!far;}for(const b of cityBatches){const d=observer.distanceTo(b.center);b.group.visible=b.s.root.visible&&d<(low?2100:4200)*performancePrefs.distance;if(b.body){b.body.visible=d<(low?620:1050)*performancePrefs.distance;b.body.castShadow=quality==='high'&&d<180;}if(b.windows)b.windows.visible=d<(low?115:250)*performancePrefs.distance;if(b.coarse)b.coarse.visible=d>=(low?620:1050)*performancePrefs.distance;}for(const s of shops)if(s.userDataProxy){const d=s.g.getWorldPosition(V()).distanceTo(observer),far=d>(low?260:450)*performancePrefs.distance;s.g.visible=!far;s.userDataProxy.visible=far;}}
function cachedBody(o,bounds){let b=bodyCache.get(o);if(!b){b=makeBody(o,bounds);bodyCache.set(o,b);}if(!b.lastMatrix||!b.lastMatrix.equals(o.matrixWorld)){b.inv.copy(o.matrixWorld).invert();b.world.copy(b.bounds).applyMatrix4(o.matrixWorld);b.rotation??=new THREE.Quaternion();o.matrixWorld.decompose(V(),b.rotation,b.scale);b.lastMatrix=o.matrixWorld.clone();}return b;}
function refreshMovingBodies(){movingBodies.length=0;const observer=controlledPosition();for(const root of [ship,...(rover.parent===ship?[]:[rover])]){if(root.getWorldPosition(V()).distanceTo(observer)>260)continue;root.updateMatrixWorld(true);root.traverse(o=>{if(o.isMesh&&!hasAncestorFlag(o,'noCollision')&&!hasAncestorFlag(o,'removed')&&o.material.type!=='ShaderMaterial')movingBodies.push(cachedBody(o));});}function add(root,min,max){root.updateWorldMatrix(true,false);movingBodies.push(cachedBody(root,new THREE.Box3(min,max)));}for(const n of npcs){const s=n.settlement||n.shop?.settlement;if(s&&observer.distanceTo(s.center)>s.half+210)continue;if(n.g.getWorldPosition(V()).distanceTo(observer)<100)add(n.g,V(-.4,0,-.35),V(.4,2,.35));}for(const site of rescueSites)if(site.survivor.visible&&site.g.position.distanceTo(observer)<100)add(site.survivor,V(-.4,0,-.35),V(.4,2,.35));for(const a of animals)if(a.g.position.distanceTo(observer)<100)add(a.g,V(-1.2,0,-2.2),V(1.2,3,2.2));for(const e of enemies)if(e.alive&&e.g.position.distanceTo(observer)<(e.flying?1500:120))add(e.g,e.flying?V(-7,-2,-8):V(-1.1,0,-2),e.flying?V(7,3,6):V(1.1,3,2));for(const t of traffic)if(t.g.position.distanceTo(observer)<100)add(t.g,V(-1.2,0,-2),V(1.2,1.8,2));for(const env of environment){for(const b of env.boats)if(b.g.position.distanceTo(observer)<100)add(b.g,V(-1.2,0,-2.65),V(1.2,2.3,2.2));for(const f of env.fish)if(f.g.position.distanceTo(observer)<65)add(f.g,V(-.6,-.5,-1.6),V(.6,.5,2));}}
function optimizeShipDraws(){const ramp=ship.getObjectByName('ramp'),door=ship.getObjectByName('door');if(ramp)ramp.userData.dynamic=true;if(door)door.userData.dynamic=true;for(const d of shipInteractables){if(d.kind==='door')d.o.userData.dynamic=true;if(d.kind==='gate')d.o.userData.dynamic=true;}batchArchitecture(ship);ship.updateMatrixWorld(true);ship.traverse(o=>{if(o!==ship&&!hasAncestorFlag(o,'dynamic')){o.updateMatrix();o.matrixAutoUpdate=false;}});ship.matrixAutoUpdate=true;}
function actorProxy(n){const root=new THREE.Group();root.userData.noCollision=true;const rig=n.g.userData.human;const colorOf=g=>{const m=g?.children.find(o=>o.isMesh),a=m?.geometry.attributes.color;return a?new THREE.Color(a.getX(0),a.getY(0),a.getZ(0)).getHex():m?.material.color?.getHex()||0x8196a4;};const cloth=colorOf(rig?.torso),skin=colorOf(rig?.head);mesh(new THREE.CylinderGeometry(.21,.15,.5,7),cloth,root,0,1.18,0).scale.z=.66;ellipsoid(root,0,1.64,0,.1,.14,.09,skin,0);for(const side of [-1,1]){mesh(new THREE.CylinderGeometry(.055,.055,.76,6),0x354451,root,side*.105,.46,0);mesh(new THREE.CylinderGeometry(.047,.035,.54,6),cloth,root,side*.26,1.10,0);}n.rigParts=[...n.g.children];n.g.add(root);root.updateWorldMatrix(true,true);const pieces=[...root.children];bakeMeshes(pieces,root);for(const o of pieces){root.remove(o);o.geometry.dispose();o.material.dispose();}n.proxy=root;root.visible=false;}


function unloadCurrentSystem() {
  for (const p of planets) {
    if (p.surfaceLoaded) unloadPlanetSurface(p);
    if (p.globe) { scene.remove(p.globe); p.globe.geometry.dispose(); p.globe.material.dispose(); }
    if (p.lodGeometries) p.lodGeometries.forEach(g => { if(g) g.dispose(); });
    if (p.atmosphere) { scene.remove(p.atmosphere); p.atmosphere.geometry.dispose(); p.atmosphere.material.dispose(); }
  }
  for (const s of settlements) {
    if (s.root && s.root.parent) { scene.remove(s.root); discardChildren(s.root); }
  }
  for (const d of destinations) {
    if (d.station && d.station.parent) { scene.remove(d.station); discardChildren(d.station); }
  }
  for (const g of scenery) { scene.remove(g); discardChildren(g); }
  for (const a of animals) { scene.remove(a.g); discardChildren(a.g); }
  for (const o of ores) { scene.remove(o.g); discardChildren(o.g); }
  for (const s of suns) {
    scene.remove(s.sun); s.sun.geometry.dispose(); s.sun.material.dispose();
    scene.remove(s.halo); s.halo.material.map?.dispose(); s.halo.material.dispose();
  }
  for (const g of gates) { scene.remove(g.g); discardChildren(g.g); }
  for (const t of traffic) { scene.remove(t.g); discardChildren(t.g); }
  for (const e of enemies) { scene.remove(e.g); discardChildren(e.g); }
  for (const s of repairSites) { scene.remove(s.g); discardChildren(s.g); }
  for (const s of rescueSites) { scene.remove(s.g); discardChildren(s.g); }
  for (const s of salvageSites) { scene.remove(s.g); discardChildren(s.g); }
  for (const env of environment) {
    for (const f of env.fish) { scene.remove(f.g); discardChildren(f.g); }
    for (const b of env.boats) { scene.remove(b.g); discardChildren(b.g); }
    for (const pl of env.plants) { scene.remove(pl); discardChildren(pl); }
  }
  if (disasterFX) discardChildren(disasterFX);
  planets.length = 0; planetLODs.length = 0; destinations.length = 0; npcs.length = 0;
  animals.length = 0; ores.length = 0; scenery.length = 0; settlements.length = 0;
  traffic.length = 0; environment.length = 0; suns.length = 0; gates.length = 0;
  shops.length = 0; repairSites.length = 0; rescueSites.length = 0; salvageSites.length = 0;
  enemies.length = 0; cityBatches.length = 0; staticBodies.length = 0; movingBodies.length = 0;
  staticGrid.clear();
}

// Ultra-fast space-only system loading (takes < 25ms total!)
function loadSystemInSpace(coord) {
  unloadCurrentSystem();
  const sx = coord.x, sy = coord.y;
  currentSystem.x = sx; currentSystem.y = sy; currentSystem.name = getSystemName(sx, sy);
  if (window.__test) window.__test.currentSystem = currentSystem;
  createSystemSpace(sx, sy);
  createSystemPlanets(sx, sy);
  createSystemStation(sx, sy);
  initJobs();
  initEnemies();
  registerBodies();
  buildSpatialIndex();
  updateLOD(0, true);
  target = 0;
  const count = $('settlementCount');
  if (count) count.textContent = settlements.length;
  $('place').textContent = 'SISTEMA ' + currentSystem.name.toUpperCase();
}

function loadSystem(coord, entryGateIndex = -1) {
  loadSystemInSpace(coord);
  // If starting or landing on planet 0, immediately load planet 0 surface
  if (planets.length > 0) {
    loadPlanetSurface(planets[0]);
  }
  if (entryGateIndex >= 0 && gates[entryGateIndex]) {
    const destGate = gates[entryGateIndex];
    const exitDir = destGate.normal.clone().negate();
    ship.position.copy(destGate.pos.clone().addScaledVector(exitDir, (destGate.halfLength || 250) + 400));
    ship.quaternion.setFromUnitVectors(V(0, 0, -1), exitDir);
    shipVelocity.copy(exitDir).multiplyScalar(650);
  }
}

function animate(){requestAnimationFrame(animate);let dt=Math.min(.04,clock.getDelta());update(dt);renderer.render(scene,camera)}

window.changeShip=fleetSelect;

let gameLoadingStarted = false;
function startLoadingGame() {
  if (gameLoadingStarted) return;
  gameLoadingStarted = true;

  const startMenu = $('startMenu');
  const loadScreen = $('loadingScreen');
  if (startMenu) startMenu.classList.add('hidden');
  if (loadScreen) loadScreen.classList.remove('hidden');

  let cur = 0;
  const ring = $('loadingOrbitRing');
  const percentEl = $('loadPercent');
  const stepEl = $('loadStep');
  const ringCircumference = 590;

  function setRing(p, text) {
    if (ring) ring.style.strokeDashoffset = ringCircumference * (1 - p / 100);
    if (percentEl) percentEl.textContent = p + '%';
    if (stepEl && text) stepEl.textContent = text;
  }

  // Load star system and setup world on-demand
  bootV04();
  bootV06();
  loadControls();
  loadPerformance();
  loadSystem(currentSystem);
  if (destinations.length > 0) ship.position.copy(destinations[0].pos).add(V(0, 2, 0));
  groundPlanet = planets[0];
  landed = true;
  mode = 'foot';
  inside = true;
  openRamp(true, true);
  foot.set(-3.5, 1.9, -3.7);
  player.copy(shipPoint(foot));
  yaw = Math.PI / 2;
  pitch = 0;
  camera.position.copy(player);
  initPlayerV05();

  const animInterval = setInterval(() => {
    cur += 5;
    if (cur <= 30) {
      setRing(cur, 'INICIALIZANDO MOTOR PROCEDURAL...');
    } else if (cur <= 70) {
      setRing(cur, 'GERANDO SISTEMA ESTELAR ÉOS...');
    } else if (cur < 100) {
      setRing(cur, 'CALIBRANDO CABINE DA NAVE NO PORTO...');
    } else {
      cur = 100;
      setRing(100, 'SISTEMA OPERACIONAL');
      clearInterval(animInterval);
      started = true;
      document.body.classList.remove('welcome');
      initAudio();
      if (loadScreen) loadScreen.classList.add('hidden');
      $('hud').classList.remove('hidden');
      toast(touchEnabled ? 'Toque na direita: interagir · Toque duplo: atacar' : 'Caminhe até o cockpit para assumir os controles.');
    }
  }, 20);
}
window.startLoadingGame = startLoadingGame;
window.start = () => { startLoadingGame(); };

// Start 3D render loop immediately (renders background)
animate();
window.menu=menu;window.closeMenu=closeMenu;window.debugState=()=>({mode,inside,landed,eva,guideEnabled,shipType,boost:!!boost,credits,mission,planets:planets.length,animals:animals.length,npcs:npcs.length,position:ship.position.toArray(),roverOnboard:rover.parent===ship,auto:!!auto,shipLookOnly});window.currentSystem=currentSystem;window.loadSystem=loadSystem;window.loadSystemInSpace=loadSystemInSpace;window.loadPlanetSurface=loadPlanetSurface;window.unloadPlanetSurface=unloadPlanetSurface;window.gates=gates;window.triggerBoost=triggerBoost;window.__test={camera,scene,sunlight,getBoost:()=>boost,ship,rover,planets,destinations,gates,currentSystem,loadSystem,loadSystemInSpace,loadPlanetSurface,unloadPlanetSurface,triggerBoost,interact,scan,land,update,getPlayer:()=>player,getFoot:()=>foot,setTarget:i=>target=i,getMode:()=>mode,setMode:m=>mode=m,getLanded:()=>landed,setLanded:l=>landed=l,getSideSpeed:()=>sideSpeed,getLiftSpeed:()=>liftSpeed,getAngularVelocity:()=>angularVelocity,recall,getThirdPerson:()=>thirdPerson,setThirdPerson:v=>thirdPerson=v};
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});

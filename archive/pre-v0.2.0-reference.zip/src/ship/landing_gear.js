// === ARTICULATED LANDING GEARS & PROCEDURAL SHIP TILT ===
const landingGears = [];
let shipGearProgress = 1.0; // 1.0 = deployed (on ground), 0.0 = retracted (in flight)
let shipGearSuspension = 0.0; // Touchdown compression bounce
let shipTiltPitch = 0, shipTiltRoll = 0, shipTiltYaw = 0;
const shipNavQuaternion = new THREE.Quaternion();
let landingSequence = null;
window.landingGears = landingGears;
window.getShipGearProgress = () => shipGearProgress;
window.getShipTilt = () => ({ pitch: shipTiltPitch, roll: shipTiltRoll, yaw: shipTiltYaw });
window.getLandingSequence = () => landingSequence;


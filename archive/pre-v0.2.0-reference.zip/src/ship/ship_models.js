function aeroHull(){const l=layout(),h=l.halfX,z=l.halfZ,col=shipTypes[shipType].color,glass=new THREE.MeshStandardMaterial({color:0x9fcbd7,transparent:true,opacity:.22,roughness:.12,metalness:.2,side:THREE.DoubleSide});box(ship,0,0,0,h*2,.5,z*2,0x405866);const rows=shipType===0?[[-z-10,.8,1.0],[-z-5,h*.7,3],[-z,h,5.3],[-z*.55,h+3,6],[-1,h+10,6.4],[z*.45,h+17,5.8],[z-3,h+7,5.3],[z,h,4.95]]:shipType===1?[[-z-13,.3,.8],[-z-6,h*.65,2.5],[-z,h,5.4],[-z*.45,h+16,5.8],[0,h+3,5.5],[3,h,5.3],[8,h,5.3],[z,h,4.95]]:[[-z,h,5.2],[-z*.4,h+6,6.8],[0,h+10,7],[z*.5,h+7,6.2],[z,h,4.95]];
function ring(row){const [zz,w,t]=row;return [[-w,-.22,zz],[-w,.9,zz],[-Math.min(w,h),t-.45,zz],[-Math.min(w*.65,h*.8),t,zz],[Math.min(w*.65,h*.8),t,zz],[Math.min(w,h),t-.45,zz],[w,.9,zz],[w,-.22,zz]];}
for(let j=0;j<rows.length-1;j++){const a=ring(rows[j]),b=ring(rows[j+1]);for(let k=0;k<8;k++){if(shipType===1&&(k===0||k===1)&&rows[j][0]>=0&&rows[j+1][0]<=8)continue;const next=(k+1)%8,points=[a[k],a[next],b[next],b[k]];
    // Elegant black accents on dorsal spine, fuselage ridges, and underbelly
    const panelColor = (k === 7) ? 0x16202c : col;
    const o = (shipType!==2&&j===2&&(k===1||k===5))?hullWindow(ship,points,col):panelMesh(ship,points,panelColor);
    if(j<2&&(k===2||k===3||k===4)||shipType!==2&&j===0&&k===7){o.material=glass.clone();o.material.opacity=.055;o.material.depthWrite=false;o.userData.viewport=true;}
    o.userData.hullLoft=true;}}
if(shipType===0){for(const side of [-1,1])panelMesh(ship,[[side*l.doorHalf,0,z],[side*h,0,z],[side*h,4.95,z],[side*l.doorHalf,4.95,z]],col);}else panelMesh(ship,[[-h,0,z],[h,0,z],[h,4.95,z],[-h,4.95,z]],col);
if(shipType===2){for(const range of [[-h,-8],[-2,h]]){box(ship,(range[0]+range[1])/2,2.4,-z,range[1]-range[0],4.8,.14,glass);}}
for(const side of [-1,1]){const ex=side*(h*.67),ez=z-2;
  // Elegant black intake nacelles and cyan glow rings
  const intake=mesh(new THREE.CylinderGeometry(.85,1.25,4,16),0x14181e,ship,ex,3.3,ez);
  intake.rotation.x=Math.PI/2;
  mesh(new THREE.TorusGeometry(.85,.12,8,20),mat(0x83dfff,1.8),ship,ex,3.3,ez+2);
  // Elegant black wing strakes
  if(shipType!==1){panelMesh(ship,[[side*(h+3),2,z-8],[side*(h+6),8,z-1],[side*(h+6),7,z+3],[side*(h+2),2,z]], 0x14181e);}
  // High-detail articulated landing gears on all 4 corners
  for(const zz of [-z+3,z-3]){ createLandingGear(ship, side*(h-1), zz, side); }}
ship.userData.silhouette=['asa integrada cargueira','asa voadora furtiva','corpo duplo industrial'][shipType];}

function hullWindow(parent,points,color){const g=new THREE.Group();parent.add(g);const p=points.map(p=>V(...p)),at=(u,v)=>p[0].clone().lerp(p[1],u).lerp(p[3].clone().lerp(p[2],u),v).toArray(),cuts=[0,.12,.88,1];for(let x=0;x<3;x++)for(let y=0;y<3;y++){const o=panelMesh(g,[at(cuts[x],cuts[y]),at(cuts[x+1],cuts[y]),at(cuts[x+1],cuts[y+1]),at(cuts[x],cuts[y+1])],color);if(x===1&&y===1){o.material=new THREE.MeshStandardMaterial({color:0xb5e2e7,transparent:true,opacity:.055,depthWrite:false,roughness:.08,metalness:.05,side:THREE.DoubleSide});o.userData.viewport=true;o.castShadow=false;}}return g;}

function cabinBox(x,y,z,w,h,d,c){const o=box(ship,x,y,z,w,h,d,c);o.userData.interior=true;return o;}
function roomDeck(x,z,w,d,c=0x455a63){cabinBox(x,.29,z,w,.075,d,c);cabinBox(x,3.85,z,w,.13,d,0x263c48);for(const side of [-1,1]){const strip=cabinBox(x+side*(w/2-.12),3.75,z,.055,.06,Math.max(.4,d-.4),mat(0xb4dcdd,.9));strip.userData.noCollision=true;}}
function passage(x,z,width,extent,axis,label){const root=new THREE.Group();root.position.set(x,0,z);root.rotation.y=axis==='x'?Math.PI/2:0;ship.add(root);const wall=0x455c68,gap=width/2,half=extent/2,height=3.6;for(const side of [-1,1]){const w=half-gap;if(w>0)box(root,side*(gap+w/2),height/2+.25,0,w,height,.18,wall);box(root,side*(gap+.065),1.85,-.02,.13,3.2,.25,0x7b939c);}box(root,0,3.56,0,width,.28,.22,0x607986);const leaf=new THREE.Group();leaf.position.y=1.85;root.add(leaf);for(const side of [-1,1]){const part=box(leaf,side*width/4,0,0,width/2-.045,3.08,.12,0x758991);part.userData.doorSide=side;const seam=box(part,side*width*.12,0,-.075,.03,2.5,.014,mat(0x8ad1d0,.5));seam.userData.noCollision=true;}const point=V(x,1.7,z),normal=axis==='x'?V(1,0,0):V(0,0,1);shipInteractables.push({kind:'door',o:leaf,root,point,normal,half:gap,open:false,progress:0,label:'Porta · '+label});return root;}
function consoleDesk(x,z,w=1.65){cabinBox(x,.82,z,w,1,.55,0x314751);const top=cabinBox(x,1.36,z,w+.08,.08,.7,0x617b85);const screen=cabinBox(x,1.54,z-.13,w*.7,.25,.055,mat(0x65bac6,.65));screen.rotation.x=-.25;for(const dx of [-.4,0,.4]){const b=cabinBox(x+dx,1.42,z+.15,.06,.025,.06,0xadc6b7);b.userData.noCollision=true;}}
function storageRack(x,z,w=1.1,d=1.5){cabinBox(x,1.52,z,w,2.4,d,0x334c59);for(let j=0;j<3;j++){cabinBox(x, .66+j*.68,z,w+.05,.07,d+.08,0x78929b);cabinBox(x, .94+j*.68,z+.1,w*.73,.48,d*.65,j%2?0x8c9b90:0x768999);} }
function galley(x,z){cabinBox(x,.9,z,1.2,1.25,3,0x647d85);cabinBox(x,1.57,z,1.25,.08,3.05,0xa3b4b2);cabinBox(x,2.6,z,1.18,.75,2.8,0x4a6370);const sink=cabinBox(x,1.63,z-.7,.68,.03,.75,0x1b343f);bone(ship,V(x+.3,1.64,z-.7),V(x+.3,1.99,z-.7),.035,0x97b4bf);}
function makeShipRooms(){const l=layout(),h=l.halfX,z=l.halfZ;
// Service spaces against opaque sidewalls conceal the wing tanks; windows occur only at the exterior canopy.
for(const side of [-1,1]){for(let zz=-z+5;zz<z;zz+=5){if(shipType===1&&side<0&&zz>-1&&zz<9||shipType!==2&&zz<(shipType===0?-7:-4))continue;cabinBox(side*(h-.11),1.97,zz,.18,3.3,Math.min(5,z-zz+2.5),0x405965);}}
if(shipType===0){roomDeck(0,-3.5,13.6,6.65);roomDeck(0,5,13.6,9.6,0x384f59);roomDeck(0,12.5,13.6,4.6,0x465a60);passage(0,-7,2,14,'z','ponte');passage(0,0,2.2,14,'z','garagem');passage(0,10,8.5,14,'z','câmara de carga');passage(-1.7,-3.5,1.9,6.8,'x','cabine de descanso');passage(1.7,-3.5,1.9,6.8,'x','refeitório');addFurniture('bed',V(-5,.32,-3.7));storageRack(-2.55,-6,1.2,.8);addFurniture('locker',V(-5.75,.3,-.9));galley(5.9,-3.5);addFurniture('bench',V(3.15,.3,-5.7));cabinBox(3.9,1.02,-4.4,1.6,.12,.8,0x91a7a5);storageRack(5.9,2,1.3,2);storageRack(5.9,7.5,1.3,2.5);consoleDesk(-5.65,3,1.6);addFurniture('locker',V(-5.7,.3,7.6));for(const xx of [-3.5,3.5])cabinBox(xx,.34,5.1,.07,.01,8.8,mat(0xc1b384,.15));}
else if(shipType===1){roomDeck(0,-2,10.65,3.7);roomDeck(0,3.5,10.65,6.6,0x3c535c);roomDeck(0,9.1,10.65,3.6);passage(0,-4,1.9,11,'z','ponte');passage(0,0,2.1,11,'z','laboratório');passage(2.8,7.1,1.9,11,'z','habitação');passage(0,9.1,1.6,3.7,'x','dormitório');addFurniture('bed',V(-3,.3,9.1));addFurniture('locker',V(-.9,.3,9.15));galley(4.7,9.1);consoleDesk(-3.8,-2,2);consoleDesk(3.8,-2,2);cabinBox(3.8,2.55,-2,1.7,.7,.55,0x597780);storageRack(4.7,3.5,1,2.8);for(const zz of [1,6.5])cabinBox(-2.9,.34,zz,3.5,.01,.06,mat(0xb2cebb,.15));}
else{roomDeck(-5,-3,9.65,13.6,0x394e58);roomDeck(-5,7,9.65,5.6);roomDeck(5,-2,9.6,3.7);roomDeck(5,2,9.6,3.6);roomDeck(5,7,9.6,5.6);passage(0,2,2,16,'x','oficina');cabinBox(0,2.05,-8,.18,3.6,4);passage(5,-4,2,10,'z','ponte');passage(5,4,2,10,'z','habitação');passage(-5,4,2,10,'z','engenharia');consoleDesk(8.55,0,1.7);storageRack(1.1,-2,1.2,1.5);addFurniture('bed',V(2.6,.3,7));addFurniture('locker',V(8.7,.3,5.5));galley(8.8,8);addFurniture('bench',V(5.7,.3,8.3));storageRack(-8.7,6.5,1.4,3.5);consoleDesk(-3.1,7,2);addFurniture('locker',V(-1.2,.3,6.3));}
// Compact flight station: low side consoles and clear glazing ahead and below the pilot.
const cx=l.cockpit.x,seatZ=l.seat.z,front=l.cockpit.z-1;box(ship,cx,.24,(seatZ+1.2+front)/2,3.4,.17,seatZ+1.2-front,0x425d69);for(const side of [-1,1]){const desk=cabinBox(cx+side*1.2,.73,seatZ-.5,.55,.75,1.7,0x425967);const screen=cabinBox(cx+side*1.1,1.26,seatZ-.85,.45,.24,.5,mat(0x64bdc9,.55));screen.rotation.z=side*.28;bone(ship,V(cx+side*.6,.7,seatZ-.55),V(cx+side*.6,1.08,seatZ-.62),.045,0x9cb0b7);}makeSeat(ship,cx,0,seatZ+.35,0x3c525d);const bridgeBack=shipType===0?-7:shipType===1?-4:-4,bridgeStart=shipType===2?-10:-l.halfZ;box(ship,shipType===2?5:0,.28,(bridgeStart+bridgeBack)/2,shipType===2?9.6:2*h-.4,.07,bridgeBack-bridgeStart,0x435a65);if(shipType!==2)box(ship,0,.25,(-l.halfZ+front)/2,3.4,.16,-l.halfZ-front,0x435a65);for(const side of [-1,1])consoleDesk(cx+side*(shipType===2?2.4:3.1),bridgeBack-1.5,1.3);}

// === PHYSICAL 3D COCKPIT CONSOLE & BUTTONS ===

function makeCockpitButtonTexture(label, sub, colorHex) {
  const c = document.createElement('canvas');
  c.width = 128; c.height = 80;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#06131c';
  ctx.fillRect(0, 0, 128, 80);
  ctx.strokeStyle = colorHex;
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 122, 74);
  ctx.fillStyle = '#edf7fa';
  ctx.font = 'bold 22px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 64, 30);
  ctx.fillStyle = colorHex;
  ctx.font = '13px Arial, sans-serif';
  ctx.fillText(sub, 64, 56);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function makeMfdTelemetryTexture(type) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 180;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#061017';
  ctx.fillRect(0, 0, 256, 180);

  if (type === 'brake') {
    // Left MFD: Power / Propulsion telemetry (Amber Drake Cutter style)
    ctx.strokeStyle = '#e0882e'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#e0882e';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('PWR MGMT // DRAKE CUTTER', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Vertical power bars
    for (let i = 0; i < 4; i++) {
      const bx = 26 + i * 54;
      ctx.strokeRect(bx, 44, 38, 90);
      const h = [65, 80, 50, 75][i];
      ctx.fillRect(bx + 4, 44 + (90 - h), 30, h);
      ctx.font = '10px Courier, monospace';
      ctx.fillText(['THR', 'SHD', 'ENG', 'BRK'][i], bx + 6, 150);
    }
    ctx.fillStyle = '#ffbe6b';
    ctx.font = '11px Courier, monospace';
    ctx.fillText('OUTPUT: 100% · REVERSE READY', 14, 168);
  } else if (type === 'map') {
    // Center MFD: Radar Scanner (Star Citizen circular radar grid)
    ctx.strokeStyle = '#429e84'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    const cx = 128, cy = 94;
    // Concentric range rings
    for (const r of [25, 48, 70]) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    // Crosshair axes
    ctx.beginPath();
    ctx.moveTo(cx - 72, cy); ctx.lineTo(cx + 72, cy);
    ctx.moveTo(cx, cy - 72); ctx.lineTo(cx, cy + 72);
    ctx.stroke();
    // Heading ticks
    ctx.fillStyle = '#61d9b8';
    ctx.font = '10px Courier, monospace';
    ctx.fillText('000°', cx - 12, cy - 74);
    ctx.fillText('090°', cx + 76, cy + 4);
    ctx.fillText('180°', cx - 12, cy + 82);
    ctx.fillText('270°', cx - 100, cy + 4);
    // Target pings
    ctx.fillStyle = '#ffcf52';
    ctx.beginPath(); ctx.arc(cx + 28, cy - 32, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx - 38, cy + 18, 3, 0, Math.PI * 2); ctx.fill();
  } else if (type === 'land') {
    // Right MFD: Flight Systems & Landing gear status (Cyan/Green avionics)
    ctx.strokeStyle = '#4db8c7'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#4db8c7';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('FLIGHT CONFIG // SENSORS', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Systems checklist
    const items = ['GEAR DEPLOYMENT', 'APPROACH RADAR', 'DECK COUPLER', 'TERRAIN SCAN'];
    for (let i = 0; i < items.length; i++) {
      const y = 52 + i * 26;
      ctx.strokeRect(20, y, 14, 14);
      ctx.fillRect(23, y + 3, 8, 8);
      ctx.font = '11px Courier, monospace';
      ctx.fillText(items[i], 44, y + 12);
      ctx.fillText('OK', 210, y + 12);
    }
    ctx.font = '11px Courier, monospace';
    ctx.fillText('RADAR ALT: 90M · PAD AUTO-LOCK', 14, 168);
  } else if (type === 'ramp' || type === 'camera') {
    // Physical console pushbuttons
    ctx.strokeStyle = '#5a7888'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = type === 'ramp' ? '#18423d' : '#1b324d';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = type === 'ramp' ? '#7ee2c8' : '#8ac8ff';
    ctx.font = 'bold 26px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(type === 'ramp' ? 'RAMP' : 'CAM', 128, 80);
    ctx.font = '14px Courier, monospace';
    ctx.fillText(type === 'ramp' ? '[HATCH CTRL]' : '[EXT VIEW]', 128, 120);
  } else if (type === 'stand') {
    // Seat release control
    ctx.strokeStyle = '#7a6642'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = '#2d2416';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = '#f0b85d';
    ctx.font = 'bold 24px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SEAT', 128, 75);
    ctx.font = '14px Courier, monospace';
    ctx.fillText('[STAND UP]', 128, 115);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}


function createSystemPlanets(sx, sy) {
  const pDefs = getPlanetDefs(sx, sy);
  for (let i = 0; i < pDefs.length; i++) {
    createSinglePlanet(sx, sy, i);
  }
}

function createSystemStation(sx, sy) {
  const st = new THREE.Group();
  st.position.set(1800, 2300, 2400);
  scene.add(st);
  const ring = mesh(new THREE.TorusGeometry(65, 4, 12, 72), 0x738c9a, st, 0, 30, 0);
  ring.rotation.x = Math.PI / 2;
  box(st, 0, -7, 0, 30, 14, 35, 0x314655);
  st.userData.cityLoaded = false;
  destinations.push({ name: 'ESTAÇÃO ' + currentSystem.name + ' · Estação', pos: st.position.clone(), station: st, kind: 'station' });
}

function loadStationCity(st) {
  if (st.userData.cityLoaded) return;
  st.userData.cityLoaded = true;
  city(st);
  registerBodies();
  buildSpatialIndex();
}

const stars=new THREE.BufferGeometry(),starArr=[];const sr=rng(99);for(let i=0;i<4500;i++){let v=V(sr()*2-1,sr()*2-1,sr()*2-1).normalize().multiplyScalar(90000);starArr.push(v.x,v.y,v.z)}stars.setAttribute('position',new THREE.Float32BufferAttribute(starArr,3));const starsObj=new THREE.Points(stars,new THREE.PointsMaterial({color:0xc5e3ff,size:55,sizeAttenuation:true,transparent:true,fog:false}));scene.add(starsObj);
const shipTypes=[{name:'ATLAS / cargueiro',color:0x1e5282,speed:190,cap:18},{name:'KESTREL / exploradora',color:0x225d94,speed:280,cap:8},{name:'MOLE / mineradora',color:0x1d4a75,speed:155,cap:26}];
window.shipTypes=shipTypes;const ship=new THREE.Group();scene.add(ship);let shipType=0,rampOpen=true;
const layouts=[{halfX:7,halfZ:15,cockpit:V(0,2.15,-20.7),seat:V(0,2.1,-19.25),entry:V(0,0,15),normal:V(0,0,1),doorHalf:4,spawn:V(0,2.1,12),rover:V(0,.95,5),roverYaw:Math.PI,desc:'Ponte, alojamento e garagem · rampa traseira'},{halfX:5.5,halfZ:11,cockpit:V(0,2.05,-17.4),seat:V(0,2.1,-15.9),entry:V(-5.5,0,4),normal:V(-1,0,0),doorHalf:4,spawn:V(-3.7,2.1,4),rover:V(0,.95,4),roverYaw:Math.PI/2,desc:'Ponte, laboratório/garagem e alojamento · entrada lateral'},{halfX:10,halfZ:10,cockpit:V(5,2.3,-9.5),seat:V(5,2.1,-8.05),entry:V(-5,0,-10),normal:V(0,0,-1),doorHalf:3.5,spawn:V(-5,2.1,-7.2),rover:V(-5,.95,-1),roverYaw:0,desc:'Ponte, oficina e garagem · rampa frontal esquerda'}];
function layout(){return layouts[shipType];}

let transitionUntil=0;
function entryWorld(){return shipPoint(layout().entry);}

function toggleRamp(){if(rampOpen&&doorwayOccupied()){toast('Entrada ocupada.');return;}openRamp(!rampOpen,false);toast('Rampa '+(rampOpen?'aberta.':'fechada.'));}
function boardShip(){resetFootMotion();if(mode==='pilot'){interact();return;}if(mode==='rover'){latch();return;}if(inside){exitShip();return;}if(player.distanceTo(entryWorld())>12){toast('Aproxime-se da entrada da nave. T retorna de qualquer lugar.');return;}openRamp(true);inside=true;eva=false;mode='foot';foot.copy(layout().spawn);yaw=0;pitch=0;transitionUntil=totalTime+.8;toast('Embarque concluído. Siga até o cockpit e pressione E.');}
function exitShip(){resetFootMotion();const l=layout();openRamp(true);inside=false;mode='foot';player.copy(shipPoint(l.entry.clone().addScaledVector(l.normal,5).add(V(0,1.9,0))));eva=!landed;evaFrame.copy(ship.quaternion);evaVelocity.copy(shipVelocity);if(!eva)player.copy(placeOnGround(player,station?null:groundPlanet));yaw=Math.atan2(-l.normal.x,-l.normal.z);pitch=0;transitionUntil=totalTime+.8;toast(eva?'EVA ativo. T retorna ao cockpit.':'Desembarque concluído. B perto da entrada para retornar.');}
function inDoor(local,extra=0){const l=layout(),rel=local.clone().sub(l.entry),across=l.normal.x?rel.z:rel.x;return Math.abs(across)<l.doorHalf-.5+extra;}
function insideMove(delta){const up=UP.clone().applyQuaternion(ship.quaternion),world=shipPoint(foot),m=delta.clone().applyQuaternion(ship.quaternion),next=moveActor(world,m,{up,height:1.8,grounded:true});foot.copy(localPoint(next));const rel=foot.clone().sub(layout().entry);if(rampOpen&&inDoor(foot)&&rel.dot(layout().normal)>.7&&totalTime>transitionUntil)exitShip();}
function interact(){if(mode==='pilot'&&targetedCockpitButton){targetedCockpitButton.userData.execute();return;}if(mode==='foot'&&inside&&!resting&&foot.distanceTo(layout().seat)<2.6){mode='pilot';yaw=0;pitch=0;return;}if(useShipInterior())return;if(mode==='pilot'){mode='foot';inside=true;resetFootMotion();foot.copy(layout().seat).add(V(0,.08,1.8));yaw=0;pitch=0;toast('Você pode caminhar. B desembarca pela entrada da nave.');return;}if(mode==='rover'){mode='foot';inside=rover.parent===ship;eva=!inside&&roverAir;if(inside){foot.copy(layout().spawn);eva=false;}else{player.copy(safeExit(rover.getWorldPosition(V()),rover,station?null:groundPlanet));if(eva){evaFrame.copy(rover.quaternion);evaVelocity.copy(roverVelocity);}}return;}const pos=inside?shipPoint(foot):player;if(inside&&foot.distanceTo(layout().seat)<2.6){mode='pilot';yaw=0;pitch=0;return;}const roverDist=pos.distanceTo(rover.getWorldPosition(V()));if(roverDist<3.5){mode='rover';eva=false;yaw=0;pitch=0;toast('W avança · S recua · E sai · B/R embarca no porão.');return;}if(!inside&&pos.distanceTo(entryWorld())<10){boardShip();return;}if(inside&&foot.distanceTo(layout().spawn)<3){exitShip();return;}const n=npcs.find(n=>pos.distanceTo(n.g.getWorldPosition(V()))<3.8);if(n){talk(n);return;}if(missionAction())return;toast('Aproxime-se do cockpit, de um habitante, veículo ou entrada. B facilita o embarque.');}
function latch(){if(mode!=='rover')return;if(rover.parent===ship){toast('Dirija para a entrada. W aponta para a saída.');return;}if(rover.getWorldPosition(V()).distanceTo(entryWorld())<15){openRamp(true);ship.attach(rover);rover.position.copy(layout().rover);rover.rotation.set(0,layout().roverYaw,0);inside=true;roverAir=false;toast('Veículo embarcado e preso no porão.');}else toast('Aproxime o veículo da entrada da nave e pressione B ou R.');}
function recall(){resetFootMotion();const port=destinations.find(d=>d.station&&ship.position.distanceTo(d.pos)<160);groundPlanet=port?null:nearest(ship.position);station=port?.station||null;mode='pilot';inside=true;eva=false;evaVelocity.set(0,0,0);yaw=0;pitch=0;foot.copy(layout().seat);closeMenu();toast('Teletransporte concluído. Você está no cockpit.');}

const rover=new THREE.Group();box(rover,0,.7,0,2.8,1,4.2,0xe1ac65);box(rover,0,1.4,-.6,2,1,1.6,0x4b788a);for(let x of [-1.5,1.5])for(let z of [-1.4,1.4]){const wheel=mesh(new THREE.CylinderGeometry(.6,.6,.5,20),0x222e3b,rover,x,.3,z);wheel.rotation.z=Math.PI/2;}
buildShip();if(destinations.length>0)ship.position.copy(destinations[0].pos).add(V(0,2,0));
let mode='foot',started=false,landed=true,inside=true,foot=V(-3.5,1.9,-3.7),player=V(),groundPlanet=planets[0],station=null,yaw=0,pitch=0,flightSpeed=0,auto=null,target=0,credits=1200,cargo=0,mission=null,scanned=new Set(),mined=0,totalTime=0;
try{const save=JSON.parse(localStorage.getItem('horizonte-v1'));if(save){credits=save.credits||1200;scanned=new Set(save.scanned||[])}}catch{}
const keys={};let statusMessage='',messageUntil=0;
function toast(s){statusMessage=s;if(!/inimig|pirata|embosc|perigo|alerta|obstru|insuficient|Pagamento|contrato|missão|compr|adquir|destru|METEOR|tempestade|ciclone|terremoto|não é possível|não pode|Sem munição/i.test(s))return;soundCue(s);messageUntil=totalTime+5;$('toast').textContent=s;}
function save(){try{localStorage.setItem('horizonte-v1',JSON.stringify({credits,scanned:[...scanned],equipment,skyward:{currentSystem:{x:currentSystem.x,y:currentSystem.y},jetLevel,outfit,ownedOutfits,locker,recentEquipment,controls:controlPrefs,performance:{...performancePrefs,quality,particles:particlesEnabled}}}))}catch{}}
function nearest(pos){return planets.reduce((a,p)=>pos.distanceTo(p.center)-p.r<pos.distanceTo(a.center)-a.r?p:a,planets[0])}
function localPoint(world){return ship.worldToLocal(world.clone())}
function shipPoint(v){return ship.localToWorld(v.clone())}
function menu(tab='settings'){closeWeaponPicker();$('actionStrip').classList.add('hidden');clearInput();document.body.classList.add('in-menu');document.exitPointerLock?.();$('panel').classList.remove('hidden');renderPanel(tab)}
function closeMenu(){$('panel').classList.add('hidden');document.body.classList.remove('in-menu');save();}

window.choose=i=>{target=i;renderPanel('map')};
window.engage=()=>{if(mode!=='pilot'){toast('Sente-se no cockpit antes de viajar.');return;}auto=destinations[target];landed=false;openRamp(false,false);flightSpeed=0;closeMenu();toast('Piloto automático ativo. Rotas entre sistemas usam os arcos.');};

window.changeShip=i=>{if(!landed||!atPort()||mode!=='pilot'||mission||rover.parent!==ship){toast('Troque no cockpit, pousado em um porto, sem contrato e com o veículo a bordo.');return;}shipType=i;buildShip();yaw=0;pitch=0;renderPanel('fleet');toast('Nova nave preparada. '+layout().desc);};
function scan(){if(missionAction())return;if(mode==='pilot'){toast('Saia da nave para usar a ferramenta de campo.');return}const pos=mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player;const o=ores.find(o=>!o.taken&&pos.distanceTo(o.g.getWorldPosition(V()))<22);if(o){if(cargo>=shipTypes[shipType].cap){toast('Porão cheio.');return}o.taken=true;o.g.visible=false;mined++;cargo++;credits+=45;save();toast('Minério coletado +45 CR · '+mined+' depósitos');return}const a=animals.find(a=>pos.distanceTo(a.g.position)<65);if(a){scanned.add(a.p.i);if(mission?.type==='scan'&&!mission.seen.includes(a.p.i))mission.seen.push(a.p.i);save();toast('Fauna catalogada: '+a.p.def[6]+' · '+a.p.def[0]);return}const fish=environment.flatMap(e=>e.fish.map(f=>({f,p:e.p}))).find(a=>a.f.g.position.distanceTo(pos)<65);if(fish){scanned.add(fish.p.i);if(mission?.type==='scan'&&!mission.seen.includes(fish.p.i))mission.seen.push(fish.p.i);save();toast('Fauna aquática catalogada · '+fish.p.def[0]);return;}toast('Nenhum depósito a 22 m ou animal a 65 m. Explore além do porto.');}

addEventListener('keydown',e=>{if(['Space','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();keys[e.code]=true;if(e.repeat||!started)return;if(e.code==='Escape'){if($('panel').classList.contains('hidden'))menu('settings');else closeMenu();return;}if(!$('panel').classList.contains('hidden'))return;if(e.code==='KeyB'){if(mode==='pilot'){interact();exitShip();}else boardShip();}if(e.code==='KeyT')recall();if(e.code==='KeyG')toggleGuide();if(e.code==='KeyU')toggleAudio();if(e.code==='KeyE'){
  // Key E: In pilot mode, rolls ship right (handled in manualFlight). On foot, interacts!
  if(mode!=='pilot'){
    interact();
  }
}
if(e.code==='KeyF'){
  // Key F: Stands up from pilot seat or bench/bed. On foot outside seat, activates scan tool!
  if(mode==='pilot'){
    mode='foot';
    inside=true;
    resetFootMotion();
    foot.copy(layout().seat).add(V(0,.08,1.8));
    yaw=0; pitch=0;
    toast('Você levantou do assento [F].');
    return;
  } else if(resting){
    standUp();
    return;
  } else {
    scan();
  }
}
if((e.code==='KeyZ'||e.code==='AltLeft')&&mode==='pilot'){
  toggleCockpitCameraLook(e);
  return;
}if(e.code==='KeyM')menu('map');if(e.code==='KeyJ')menu('jobs');if(e.code==='KeyH')menu('fleet');if(e.code==='KeyO')toggleRamp();
if(e.code==='KeyR'){
  // Key R: In pilot mode, executes landing. On foot, reloads weapon!
  if(mode==='pilot'){
    land();
    return;
  } else if(mode==='foot'){
    reloadWeapon();
  } else {
    latch();
  }
}
if(e.code==='KeyL')land(); // Secondary landing key
if(e.code==='KeyP'){auto=null;toast('Controle manual.')}if(e.code==='KeyX')brakeShip();});addEventListener('keyup',e=>keys[e.code]=false);addEventListener('blur',()=>{Object.keys(keys).forEach(k=>keys[k]=false)});
renderer.domElement.onclick=()=>{if(!touchEnabled&&started&&$('panel').classList.contains('hidden'))renderer.domElement.requestPointerLock?.()};
addEventListener('mousemove',e=>{if(document.pointerLockElement===renderer.domElement)lookInput(e.movementX,e.movementY)});
let eva=false,evaFrame=new THREE.Quaternion(),evaVelocity=V(),shipVelocity=V(),roverAir=false,roverVelocity=V(),guideEnabled=true;

function update(dt){inputTick(dt);totalTime+=dt;if(!started)return;const paused=!$('panel').classList.contains('hidden');if(!paused){tickInteriors(dt,false);flyShip(dt);updateCitizens(dt,false);refreshMovingBodies();if(mode==='foot'){updateFootV05(dt);
}else if(mode==='rover'){const f=axisForward(),turn=(-axisStrafe())*dt*1.25;rover.rotateY(turn);if(roverAir){rover.position.addScaledVector(roverVelocity,dt);const p=nearest(rover.position),n=rover.position.clone().sub(p.center).normalize(),alt=rover.position.distanceTo(p.center)-radius(p,n);if(alt<ATMOSPHERE)roverVelocity.addScaledVector(n,-7*dt);if(alt<1){roverAir=false;groundPlanet=p;station=null;rover.position.copy(placeOnGround(rover.position,p,.3));rover.quaternion.copy(frameAt(rover.position,p.center));}}else{const onboard=rover.parent===ship,p=groundPlanet||nearest(rover.getWorldPosition(V())),up=onboard?UP.clone().applyQuaternion(ship.quaternion):UP.clone().applyQuaternion(walkFrame(rover.getWorldPosition(V()),p)),q=rover.getWorldQuaternion(new THREE.Quaternion()),delta=V(0,0,-f*(aquaticDriveSpeed())*dt).applyQuaternion(q),origin=rover.getWorldPosition(V()),eye=origin.clone().addScaledVector(up,2.2),next=moveActor(eye,delta,{up,p:onboard||station?null:p,height:2.5,r:1.18,ignore:rover}).addScaledVector(up,-2.2);if(onboard){rover.position.copy(localPoint(next));const rel=rover.position.clone().sub(layout().entry);if(rampOpen&&inDoor(rover.position)&&rel.dot(layout().normal)>1){scene.attach(rover);inside=false;roverAir=!landed;roverVelocity.copy(shipVelocity);toast('Veículo fora da nave. B perto da entrada para embarcar.');}}else{rover.position.copy(next);const oldUp=UP.clone().applyQuaternion(rover.quaternion);rover.quaternion.premultiply(new THREE.Quaternion().setFromUnitVectors(oldUp,up));}}}}
updatePlayerCamera(dt);
const {p,alt,density}=updateSky(dt);$('place').textContent=alt<ATMOSPHERE?p.def[0]+' / '+p.def[1+biome(camera.position.clone().sub(p.center).normalize(),p.i)]:systemOf(camera.position)?'SISTEMA NYX':'SISTEMA ÉOS';$('state').textContent=boost?'IMPULSO INTERSISTEMAS':mode==='pilot'?(auto?'PILOTO AUTOMÁTICO':landed?'POUSADO':'VOO MANUAL'):mode==='rover'?(['skiff','cutter'].includes(vehicleKind)?'EMBARCAÇÃO ANFÍBIA':'VEÍCULO TERRESTRE'):inside?'INTERIOR DA NAVE':eva?'EVA':'EXPLORAÇÃO A PÉ';$('speed').textContent=Math.abs(flightSpeed).toFixed(0);$('alt').textContent=Math.max(0,alt).toFixed(0);$('credits').textContent=credits.toLocaleString('pt-BR');$('objective').textContent=mission?mission.label+(mission.type==='mine'?' · '+Math.min(3,mined-mission.startMined)+'/3':mission.type==='scan'?' · '+mission.seen.length+'/2':mission.type==='repair'||mission.type==='salvage'?' · '+mission.done.length+'/'+(mission.type==='repair'?3:2):''):'';$('shipname').textContent=shipTypes[shipType].name;$('cargo').textContent=cargo+'/'+shipTypes[shipType].cap+' · '+(rover.parent===ship?'VEÍCULO A BORDO':'VEÍCULO EM SOLO');$('toast').style.opacity=totalTime<messageUntil?1:0;$('airState').textContent=boost?'TRÂNSITO · '+Math.max(0,6-boost.elapsed).toFixed(1)+' s':density>.005?'ATMOSFERA · DENSIDADE '+Math.round(density*100)+'% · ARRASTO ATIVO':'VÁCUO · SEM ARRASTO';const dist=(inside?shipPoint(foot):player).distanceTo(entryWorld());$('boardHint').textContent=mode==='pilot'?'F · LEVANTAR   B · SAIR':inside?'B · SAIR PELA ENTRADA':dist<12?'B · EMBARCAR':'T · VOLTAR AO COCKPIT';updateGuide();updateCockpitRaycast();updateAudio(dt,paused);updateFlightFx();for(const a of animals)a.g.visible=camera.position.distanceTo(a.g.position)<3500;v04Tick(dt,paused);v05Tick(dt,paused);updateSurfaceStreaming(controlledPosition());inputAfterTick();environmentTick(dt,paused);if(paused)tickInteriors(0,true);}


const jobDefs=[['cargo','Carga','Leve quatro caixas ao porto indicado.',1400],['mine','Mineração','Colete três depósitos e retorne a um porto.',1100],['scan','Pesquisa','Catalogue fauna em dois planetas.',1800],['salvage','Recuperação orbital','Saia em EVA e recupere dois módulos à deriva.',2100],['rescue','Resgate','Busque um explorador isolado e traga-o ao porto de origem.',2400],['repair','Manutenção','Conserte três torres de comunicação com sua ferramenta.',1300]];
const repairSites=[],rescueSites=[],salvageSites=[];
function initJobs() {
  repairSites.length = 0;
  rescueSites.length = 0;
  salvageSites.length = 0;
  for (let i = 0; i < planets.length; i++) {
    const p = planets[i];
    for (let j = 0; j < 3; j++) {
      const g = new THREE.Group();
      g.position.copy(p.center).add(V(j === 0 ? -14 : 14, p.r + 2, j === 2 ? 38 : -32 + j * 20));
      scene.add(g);
      box(g, 0, 1, 0, 1.6, 2, 1.6, 0x617a85);
      mesh(new THREE.CylinderGeometry(.17, .23, 5, 10), 0x8a9a9d, g, 0, 3.7, 0);
      const bulb = mesh(new THREE.SphereGeometry(.4, 12, 8), mat(0xe6a16c, 1), g, 0, 6.4, 0);
      repairSites.push({ g, p, bulb, index: j });
    }
    const normal = V(.19, 1, .15).normalize(), pos = p.center.clone().addScaledVector(normal, radius(p, normal) + .1), g = new THREE.Group();
    g.position.copy(pos);
    g.quaternion.copy(frameAt(pos, p.center));
    scene.add(g);
    const survivor = person(g, 0, 0, 0xe89e79);
    box(g, 3, 1, 0, 2, 2, 3, 0x79785f);
    rescueSites.push({ g, p, survivor });
  }
  const stDest = destinations.find(d => d.station);
  const stPos = stDest ? stDest.pos : V(1800, 2300, 2400);
  for (let j = 0; j < 2; j++) {
    const g = new THREE.Group();
    g.position.copy(stPos).add(V(-25 + j * 50, 110 + j * 20, 160));
    scene.add(g);
    box(g, 0, 0, 0, 3, 2, 3, 0xa48b67);
    box(g, 0, 1.2, 0, 2.2, .3, 2.2, mat(0x89cedc, .8));
    salvageSites.push({ g, index: j });
  }
}
function clearMissionCargo(){ship.children.filter(c=>c.name==='cargo'||c.name==='passenger').forEach(c=>{ship.remove(c);c.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.map?.dispose();o.material.dispose();}});});}
function acceptJob(type){if(['hunt','bounty','patrol'].includes(type))return acceptCombat(type);if(mission){toast('Conclua ou cancele o contrato atual.');return;}const port=atPort(),def=jobDefs.find(j=>j[0]===type);if(!port||!def){toast('Aceite um contrato perto de um porto.');return;}const origin=destinations.indexOf(port),planetIndex=port.p?port.p.i:port.pos.x>SEP/2?3:0;mission={type,origin,to:(planetIndex+1)%6,startMined:mined,seen:[],done:[],planetIndex,picked:false,label:def[1],reward:def[3]};if(type==='cargo'){cargo=4;const l=layout();for(let j=0;j<4;j++){const c=box(ship,l.rover.x+(shipType===2?0:0),1,shipType===2?5+j*1.7:shipType===1?8:-3+j*1.7,1.3,1.3,1.3,0xd8af73);if(shipType===1)c.position.x=-3+j*1.6;if(shipType===2)c.position.set(-5+(j%2?1:-1),1,5+Math.floor(j/2)*2.2);c.name='cargo';}mission.label='Carga → '+destinations[mission.to].name;}if(type==='rescue')mission.label='Resgate → '+planets[planetIndex].def[0];if(type==='repair')mission.label='Manutenção · três torres';if(type==='salvage'){mission.system=port.pos.x>SEP/2?1:0;salvageSites.filter(x=>x.system===mission.system).forEach(x=>{x.g.visible=true;x.g.traverse(o=>o.userData.removed=false)});}refreshMovingBodies();toast('Contrato aceito. G mostra o objetivo.');renderPanel('jobs');}
function missionAction(){if(!mission||mode==='pilot'&&!(mission.type==='rescue'&&mission.picked&&!mission.boarded))return false;const pos=mode==='pilot'?ship.position:mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player;if(mission.type==='repair'){const site=repairSites.find(x=>x.p.i===mission.planetIndex&&!mission.done.includes(x.index)&&pos.distanceTo(x.g.position)<5);if(site){mission.done.push(site.index);site.bulb.material=mat(0x8fe8ba,1);toast('Torre reparada · '+mission.done.length+'/3.');return true;}}
if(mission.type==='salvage'){const site=salvageSites.find(x=>x.system===mission.system&&!mission.done.includes(x.index)&&pos.distanceTo(x.g.position)<7);if(site){mission.done.push(site.index);site.g.visible=false;site.g.traverse(o=>o.userData.removed=true);toast('Módulo recuperado · '+mission.done.length+'/2.');return true;}}
if(mission.type==='rescue'&&!mission.picked){const site=rescueSites[mission.planetIndex];if(pos.distanceTo(site.g.position)<6){mission.picked=true;toast('Explorador localizado. Leve a nave a até 80 m e pressione F para embarcá-lo.');return true;}}
if(mission.type==='rescue'&&mission.picked&&!mission.boarded){const site=rescueSites[mission.planetIndex];if(landed&&ship.position.distanceTo(site.g.position)<80){mission.boarded=true;site.survivor.visible=false;site.survivor.traverse(o=>o.userData.removed=true);const passenger=person(ship,shipType===2?4:shipType===1?1.6:3,shipType===2?3:-5,0xe89e79);passenger.name='passenger';mission.label='Resgate · retornar a '+destinations[mission.origin].name;refreshMovingBodies();toast('Explorador a bordo. Retorne ao porto de origem.');return true;}toast('Aproxime e pouse a nave a até 80 m do local do resgate.');return true;}return false;}
function completeJob(){if(!mission)return;if(mission.combat)return completeCombat();const port=atPort();if(!port){toast('Retorne a um porto para entregar.');return;}const m=mission,ok=m.type==='cargo'?port===destinations[m.to]:m.type==='mine'?mined-m.startMined>=3:m.type==='scan'?m.seen.length>=2:m.type==='repair'?m.done.length>=3:m.type==='salvage'?m.done.length>=2:m.boarded&&port===destinations[m.origin];if(!ok){toast('Os objetivos ainda não foram concluídos.');return;}credits+=m.reward;resetJobObjects(m);mission=null;cargo=0;clearMissionCargo();refreshMovingBodies();save();toast('Contrato concluído. Pagamento recebido!');renderPanel('jobs');}
function resetJobObjects(m){if(m.type==='rescue'){const s=rescueSites[m.planetIndex].survivor;s.visible=true;s.traverse(o=>o.userData.removed=false);}if(m.type==='repair')repairSites.filter(s=>s.p.i===m.planetIndex).forEach(s=>s.bulb.material=mat(0xe6a16c,1));}
function cancelJob(){clearCombatMission();if(mission)resetJobObjects(mission);mission=null;cargo=0;clearMissionCargo();refreshMovingBodies();toast('Contrato cancelado.');renderPanel('jobs');}
function currentGoal(){if(mission?.combat&&!boost)return combatGoal();const from=mode==='pilot'?ship.position:mode==='rover'?rover.getWorldPosition(V()):inside?shipPoint(foot):player,closest=list=>list.reduce((a,b)=>!a||from.distanceTo(b.pos)<from.distanceTo(a.pos)?b:a,null);if(boost)return {pos:boost.approachEnd||boost.tunnelPos||ship.position,label:'IMPULSO · SISTEMA '+(boost.targetName||'DESTINO').toUpperCase()};if(autoGate&&!boost)return {pos:autoGate.pos,label:'ATRAVESSAR ARCO · '+(autoGate.targetName||'DESTINO').toUpperCase()};if(!mission)return {pos:destinations[target].pos,label:'DESTINO · '+destinations[target].name};const m=mission;if(m.type==='cargo')return {pos:destinations[m.to].pos,label:'ENTREGA · '+destinations[m.to].name};if(m.type==='mine'&&mined-m.startMined<3)return closest(ores.filter(o=>!o.taken).map(o=>({pos:o.g.getWorldPosition(V()),label:'MINÉRIO · '+o.p.def[0]})));if(m.type==='scan'&&m.seen.length<2)return closest(animals.filter(a=>!m.seen.includes(a.p.i)).map(a=>({pos:a.g.position,label:'FAUNA · '+a.p.def[0]})));if(m.type==='repair'&&m.done.length<3)return closest(repairSites.filter(x=>x.p.i===m.planetIndex&&!m.done.includes(x.index)).map(x=>({pos:x.g.position,label:'REPARAR TORRE · F'})));if(m.type==='salvage'&&m.done.length<2)return closest(salvageSites.filter(x=>x.system===m.system&&!m.done.includes(x.index)).map(x=>({pos:x.g.position,label:'RECUPERAR MÓDULO · EVA + F'})));if(m.type==='rescue'){if(!m.boarded)return {pos:rescueSites[m.planetIndex].g.position,label:m.picked?'POUSE A NAVE PERTO DO EXPLORADOR · F':'LOCALIZAR EXPLORADOR · F'};return {pos:destinations[m.origin].pos,label:'RESGATE · RETORNAR À ORIGEM'};}return closest(destinations.filter(d=>!d.gate&&d.kind!=='water').map(d=>({pos:d.pos,label:'RECEBER PAGAMENTO · '+d.name})));}

window.accept=acceptJob;window.finishJob=completeJob;window.cancelJob=cancelJob;

function toggleGuide(){guideEnabled=!guideEnabled;$('guideToggle').textContent='G · OBJETIVO '+(guideEnabled?'ON':'OFF');toast('HUD de objetivo '+(guideEnabled?'ativado.':'desativado.'));}
function updateGuide(){const goal=currentGoal(),marker=$('waypoint');marker.style.display=guideEnabled&&goal?'block':'none';if(!guideEnabled||!goal)return;camera.updateMatrixWorld();const rel=goal.pos.clone().sub(camera.position).applyQuaternion(camera.quaternion.clone().invert()),distance=rel.length(),ndc=goal.pos.clone().project(camera);let x=(ndc.x*.5+.5)*innerWidth,y=(-ndc.y*.5+.5)*innerHeight;const off=rel.z>=0||x<90||x>innerWidth-90||y<90||y>innerHeight-180;let angle=0;if(off){let dx=rel.x,dy=-rel.y;if(Math.abs(dx)+Math.abs(dy)<.001){dx=0;dy=1;}const factor=Math.min((innerWidth/2-90)/Math.max(.001,Math.abs(dx)),(innerHeight/2-170)/Math.max(.001,Math.abs(dy)));x=innerWidth/2+dx*factor;y=innerHeight/2+dy*factor;angle=Math.atan2(dy,dx)*180/Math.PI+90;}$('wayArrow').textContent=off?'▲':'◇';$('wayArrow').style.transform=`rotate(${off?angle:0}deg)`;$('wayLabel').textContent=goal.label;$('wayDistance').textContent=(distance>1000?(distance/1000).toFixed(1)+' km':Math.round(distance)+' m')+(rel.z>=0?' · atrás de você':'');marker.style.left=x+'px';marker.style.top=y+'px';}
let audioContext=null,musicBus,fxBus,masterBus,engineGain,engineOsc,engineFilter,windGain,audioMuted=false,nextChord=0,nextMelody=0,musicStep=0,footTimer=0,musicVolume=.35,fxVolume=.6;
function tone(freq,time,duration,gain,bus,type='sine',pan=0){if(!audioContext)return;const o=audioContext.createOscillator(),g=audioContext.createGain(),p=audioContext.createStereoPanner();o.type=type;o.frequency.value=freq;p.pan.value=pan;g.gain.setValueAtTime(0,time);g.gain.linearRampToValueAtTime(gain,time+.06);g.gain.exponentialRampToValueAtTime(.0001,time+duration);o.connect(g).connect(p).connect(bus);o.start(time);o.stop(time+duration+.1);o.onended=()=>{o.disconnect();g.disconnect();p.disconnect()};}
function initAudio(){if(audioContext){audioContext.resume();return;}try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;audioContext=new AC();masterBus=audioContext.createGain();masterBus.gain.value=.7;const limiter=audioContext.createDynamicsCompressor();masterBus.connect(limiter).connect(audioContext.destination);musicBus=audioContext.createGain();musicBus.gain.value=musicVolume;musicBus.connect(masterBus);fxBus=audioContext.createGain();fxBus.gain.value=fxVolume;fxBus.connect(masterBus);
const delay=audioContext.createDelay(2),feedback=audioContext.createGain();delay.delayTime.value=.57;feedback.gain.value=.23;musicBus.connect(delay);delay.connect(feedback);feedback.connect(delay);feedback.connect(masterBus);
engineOsc=audioContext.createOscillator();engineOsc.type='sawtooth';engineFilter=audioContext.createBiquadFilter();engineFilter.type='lowpass';engineFilter.frequency.value=150;engineGain=audioContext.createGain();engineGain.gain.value=0;engineOsc.connect(engineFilter).connect(engineGain).connect(fxBus);engineOsc.start();const buffer=audioContext.createBuffer(1,audioContext.sampleRate*2,audioContext.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;const noise=audioContext.createBufferSource();noise.buffer=buffer;noise.loop=true;const windFilter=audioContext.createBiquadFilter();windFilter.type='lowpass';windFilter.frequency.value=650;windGain=audioContext.createGain();windGain.gain.value=0;noise.connect(windFilter).connect(windGain).connect(fxBus);noise.start();nextChord=audioContext.currentTime+.1;nextMelody=audioContext.currentTime+3;audioContext.resume();}catch(e){if(audioContext)audioContext.close().catch(()=>{});audioContext=null;$('audioStatus').textContent='Áudio indisponível neste navegador';}}
function toggleAudio(){initAudio();audioMuted=!audioMuted;if(masterBus)masterBus.gain.setTargetAtTime(audioMuted?0:.7,audioContext.currentTime,.08);$('audioToggle').textContent='U · ÁUDIO '+(audioMuted?'OFF':'ON');}
function setVolume(type,value){initAudio();const n=Number(value)/100;if(type==='music'){musicVolume=n;if(musicBus)musicBus.gain.setTargetAtTime(n,audioContext.currentTime,.05);}else{fxVolume=n;if(fxBus)fxBus.gain.setTargetAtTime(n,audioContext.currentTime,.05);}}
function soundCue(text){if(!audioContext)return;const t=audioContext.currentTime;if(/Teletransporte/.test(text)){[220,330,440,660,880].forEach((f,i)=>tone(f,t+i*.055,.35,.09,fxBus));}else if(/coletado|catalogada|Pagamento/.test(text)){[523,659,784].forEach((f,i)=>tone(f,t+i*.09,.4,.07,fxBus));}else if(/Rampa|Decolagem|Chegada/.test(text)){tone(110,t,.7,.08,fxBus,'triangle');tone(220,t+.12,.5,.06,fxBus);}else tone(480,t,.13,.025,fxBus);}
function updateAudio(dt,paused){if(!audioContext||audioContext.state!=='running')return;const t=audioContext.currentTime;windGain.gain.setTargetAtTime(paused?0:boost?.16:heat>.1?heat*.12:eva?.016:inside?.002:.028,t,.2);const aboard=inside||mode==='pilot',intensity=landed?.025:Math.min(.15,.04+Math.abs(flightSpeed)/20000);engineGain.gain.setTargetAtTime(paused?0:aboard?intensity:eva?.012:.006,t,.25);engineOsc.frequency.setTargetAtTime(landed?35:45+Math.min(100,Math.abs(flightSpeed)/20),t,.2);engineFilter.frequency.setTargetAtTime(landed?100:200+Math.min(600,Math.abs(flightSpeed)/4),t,.3);
if(t>=nextChord){const chords=[[130.81,164.81,196,246.94],[110,164.81,220,261.63],[87.31,130.81,174.61,220],[98,146.83,196,293.66],[130.81,196,261.63,329.63],[110,164.81,246.94,329.63]];chords[musicStep%chords.length].forEach((f,i)=>tone(f,t+.04*i,9,.04,musicBus,'sine',(i-1.5)*.4));musicStep++;nextChord=t+9+(musicStep%3);}
if(t>=nextMelody){const scale=[261.63,293.66,329.63,392,440,523.25,659.25],index=(musicStep*3+Math.floor(totalTime/4))%scale.length;tone(scale[index],t,2.8,.032,musicBus,'triangle',Math.sin(totalTime)*.5);nextMelody=t+2.5+(musicStep%4)*.8;}
if(!paused&&mode==='foot'&&!eva&&(Math.abs(axisForward())>.05||Math.abs(axisStrafe())>.05)){footTimer-=dt;if(footTimer<=0){tone(inside?100:75,t,.1,.065,fxBus,'triangle');footTimer=keys.ShiftLeft?.27:.43;}}}
window.boardingAction=()=>{if(mode==='pilot'){interact();exitShip();}else boardShip();};window.recall=recall;window.toggleGuide=toggleGuide;window.toggleAudio=toggleAudio;window.setVolume=setVolume;
function ellipsoid(parent,x,y,z,sx,sy,sz,color,detail=1){const m=mesh(new THREE.IcosahedronGeometry(1,detail),color,parent,x,y,z);m.scale.set(sx,sy,sz);return m;}
function bone(parent,a,b,r,color){const d=b.clone().sub(a),m=mesh(new THREE.CylinderGeometry(r*.8,r,d.length(),8),color,parent);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(UP,d.normalize());return m;}
function sculptAnimal(g,i,hostile=false){discardChildren(g);const d=(planets[i]?planets[i].def:(defs[i%defs.length]||defs[0])),c=hostile?0xa95845:d[5];g.userData.animal=true;g.userData.legs=[];const body=ellipsoid(g,0,1.05,0,i===5?1.1:.75,i===1?.5:.62,i===4?1.5:1.1,c,2);g.userData.body=body;ellipsoid(g,0,1.5,-1.1,.45,.5,.58,c,1);ellipsoid(g,0,1.31,-1.6,.28,.24,.4,d[4],1);for(const x of [-.25,.25])ellipsoid(g,x,1.66,-1.5,.065,.075,.08,mat(hostile?0xff6554:0xe4dca7,.35));const count=i===5?8:4;for(let j=0;j<count;j++){const side=j%2?1:-1,z=-.7+Math.floor(j/2)*(count===8?.45:1.35),leg=new THREE.Group();leg.position.set(side*.62,1.1,z);g.add(leg);const spread=i===5?side*.75:side*.08;bone(leg,V(),V(spread,-.45,.14),.09,d[3]);bone(leg,V(spread,-.45,.14),V(spread*1.3,-1,.05),.06,d[3]);ellipsoid(leg,spread*1.3,-1,.01,.11,.07,.2,d[4]);g.userData.legs.push(leg);}if(i===0){for(const side of [-1,1]){bone(g,V(side*.23,1.95,-1),V(side*.55,2.85,-.9),.055,d[4]);bone(g,V(side*.40,2.48,-.94),V(side*.9,2.7,-1.1),.045,d[4]);}}else if(i===1){ellipsoid(g,0,1.45,.15,.9,.35,1.25,d[4],1);}else if(i===2||i===3){for(const side of [-1,1]){const ear=mesh(new THREE.ConeGeometry(.2,.75,8),c,g,side*.28,2.1,-.95);ear.rotation.z=side*.25;}}const tail=new THREE.Group();tail.position.set(0,1.2,.85);g.add(tail);const cone=mesh(new THREE.ConeGeometry(i===2?.42:.20,i===4?2.7:1.3,10),c,tail,0,0,.6);cone.rotation.x=Math.PI/2;g.userData.tail=tail;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});}
function fighterModel(g,military=false){const c=military?0x657b8c:0xa65b49,metal=0x293c4c;const shape=new THREE.Shape();shape.moveTo(0,-8);shape.lineTo(2.8,-2);shape.lineTo(2.2,5);shape.lineTo(-2.2,5);shape.lineTo(-2.8,-2);shape.closePath();const geo=new THREE.ExtrudeGeometry(shape,{depth:1.8,bevelEnabled:true,bevelSize:.4,bevelThickness:.4,bevelSegments:1,steps:1});const hullMesh=mesh(geo,c,g);hullMesh.rotation.x=Math.PI/2;hullMesh.position.y=1;const cockpit=ellipsoid(g,0,1.5,-2,1.2,.65,2,0x68a5ba,1);for(const side of [-1,1]){const wing=box(g,side*4.1,0,1,5.2,.35,5.5,c);wing.rotation.z=side*(military?.15:-.12);const engine=mesh(new THREE.CylinderGeometry(.7,1,5,14),metal,g,side*2.7,0,3);engine.rotation.x=Math.PI/2;mesh(new THREE.TorusGeometry(.65,.12,8,16),mat(military?0x8edaff:0xff9a66,2),g,side*2.7,0,5.6);bone(g,V(side*4.3,0,-1),V(side*4.3,0,-5),.16,metal);}g.userData.shipModel=true;}

function getMuzzleOffset(id) {
  if (id === 'pistol') return V(0, 0.038, -0.42);
  if (id === 'rifle') return V(0, 0.035, -0.82);
  if (id === 'shotgun') return V(0, 0.032, -0.76);
  if (id === 'blade') return V(0, 0.05, -0.48);
  if (id === 'sabre') return V(0, 0.05, -0.78);
  if (id === 'tool') return V(0, 0.02, -0.44);
  return V(0, 0.03, -0.5);
}
window.getMuzzleOffset = getMuzzleOffset;
window.equipWeapon = equipWeapon;
window.firePlayer = firePlayer;
window.reloadWeapon = reloadWeapon;
window.makeAvatar = makeAvatar;
window.weaponDefs = weaponDefs;
window.getWeaponView = () => weaponView;
window.getAvatarWeapon = () => avatarWeapon;
window.getAvatar = () => avatar;
window.getRecoil = () => recoil;
window.isAiming = () => aiming;
window.getEquipped = () => equipped;
window.getEquipment = () => equipment;
window.updateAvatarWeapon = updateAvatarWeapon;
window.setTouch = setTouch;
window.isReloadActive = () => reloadActive;
window.getReloadDuration = () => reloadDuration;
window.isMeleeActive = () => meleeActive;
window.getMeleeCombo = () => meleeCombo;
window.getTransientFX = () => transientFX;

function makeWeapon(g, id, isAvatar = false) {
  const metal = 0x222d36, polymer = 0x131920, steel = 0x3d4b58, chrome = 0x7a8e9e, accent = 0xca8c3e;
  const s = isAvatar ? 0.88 : 1.0;

  if (id === 'pistol') {
    // Apex-9 Tactical Combat Handgun
    const frame = new THREE.Group(); frame.name = 'frame'; g.add(frame);
    box(frame, 0, -0.12 * s, 0.06 * s, 0.055 * s, 0.22 * s, 0.09 * s, polymer);
    box(frame, 0, -0.23 * s, 0.07 * s, 0.058 * s, 0.035 * s, 0.10 * s, metal);
    box(frame, 0, -0.06 * s, -0.04 * s, 0.035 * s, 0.09 * s, 0.11 * s, polymer);
    box(frame, 0, -0.05 * s, -0.03 * s, 0.015 * s, 0.05 * s, 0.02 * s, accent);
    box(frame, 0, 0, -0.14 * s, 0.058 * s, 0.065 * s, 0.26 * s, polymer);
    box(frame, 0, -0.05 * s, -0.18 * s, 0.042 * s, 0.04 * s, 0.12 * s, metal);
    mesh(new THREE.CylinderGeometry(0.008 * s, 0.008 * s, 0.02 * s, 8), mat(0x42f5d7, 1.8), frame, 0, -0.05 * s, -0.24 * s).rotation.x = Math.PI / 2;

    const slide = new THREE.Group(); slide.name = 'weaponSlide'; g.add(slide);
    box(slide, 0, 0.04 * s, -0.12 * s, 0.062 * s, 0.065 * s, 0.38 * s, steel);
    for (const z of [-0.02, -0.22]) {
      box(slide, 0, 0.04 * s, z * s, 0.066 * s, 0.055 * s, 0.045 * s, metal);
    }
    box(slide, 0.02 * s, 0.045 * s, -0.08 * s, 0.028 * s, 0.038 * s, 0.09 * s, accent);
    const barrel = mesh(new THREE.CylinderGeometry(0.018 * s, 0.018 * s, 0.12 * s, 10), chrome, slide, 0, 0.038 * s, -0.34 * s);
    barrel.rotation.x = Math.PI / 2;
    box(slide, 0, 0.038 * s, -0.38 * s, 0.056 * s, 0.056 * s, 0.08 * s, metal);
    box(slide, 0, 0.09 * s, -0.04 * s, 0.046 * s, 0.04 * s, 0.08 * s, metal);
    mesh(new THREE.PlaneGeometry(0.03 * s, 0.025 * s), mat(0x42f5d7, 2.2), slide, 0, 0.095 * s, -0.04 * s);

  } else if (id === 'rifle') {
    // Tempest-X Bullpup Military Battle Rifle
    const body = new THREE.Group(); body.name = 'rifleBody'; g.add(body);
    box(body, 0, 0, -0.15 * s, 0.095 * s, 0.16 * s, 0.65 * s, metal);
    box(body, 0, 0.02 * s, -0.52 * s, 0.085 * s, 0.12 * s, 0.38 * s, steel);
    for (const z of [-0.42, -0.52, -0.62]) {
      box(body, 0, 0.02 * s, z * s, 0.092 * s, 0.04 * s, 0.045 * s, 0x0e141a);
    }
    const rBarrel = mesh(new THREE.CylinderGeometry(0.022 * s, 0.022 * s, 0.28 * s, 10), chrome, body, 0, 0.035 * s, -0.72 * s);
    rBarrel.rotation.x = Math.PI / 2;
    box(body, 0, 0.035 * s, -0.80 * s, 0.048 * s, 0.048 * s, 0.07 * s, metal);
    box(body, 0, -0.02 * s, 0.24 * s, 0.075 * s, 0.14 * s, 0.22 * s, polymer);
    box(body, 0, -0.02 * s, 0.35 * s, 0.08 * s, 0.18 * s, 0.04 * s, 0x111114);
    box(body, 0, -0.16 * s, -0.08 * s, 0.055 * s, 0.20 * s, 0.085 * s, polymer);
    box(body, 0, -0.10 * s, -0.18 * s, 0.035 * s, 0.08 * s, 0.12 * s, metal);
    box(body, 0, -0.11 * s, -0.50 * s, 0.045 * s, 0.14 * s, 0.08 * s, polymer);

    const mag = new THREE.Group(); mag.name = 'weaponMag'; g.add(mag);
    box(mag, 0, -0.18 * s, 0.08 * s, 0.058 * s, 0.24 * s, 0.11 * s, polymer);
    mesh(new THREE.PlaneGeometry(0.015 * s, 0.18 * s), mat(0x38efba, 1.8), mag, 0.031 * s, -0.18 * s, 0.08 * s);
    box(body, 0, 0.12 * s, -0.22 * s, 0.065 * s, 0.075 * s, 0.24 * s, metal);
    mesh(new THREE.PlaneGeometry(0.04 * s, 0.04 * s), mat(0x38efba, 2.4), body, 0, 0.125 * s, -0.22 * s);

  } else if (id === 'shotgun') {
    // Havoc-12 Heavy Tactical Plasma Breacher
    const sBody = new THREE.Group(); sBody.name = 'shotgunBody'; g.add(sBody);
    box(sBody, 0, 0, -0.12 * s, 0.11 * s, 0.18 * s, 0.52 * s, metal);
    for (const x of [-0.024 * s, 0.024 * s]) {
      const b = mesh(new THREE.CylinderGeometry(0.024 * s, 0.024 * s, 0.58 * s, 10), steel, sBody, x, 0.032 * s, -0.48 * s);
      b.rotation.x = Math.PI / 2;
    }
    box(sBody, 0, 0.032 * s, -0.74 * s, 0.115 * s, 0.065 * s, 0.06 * s, 0x161c22);
    const pump = new THREE.Group(); pump.name = 'weaponPump'; g.add(pump);
    box(pump, 0, -0.055 * s, -0.42 * s, 0.095 * s, 0.09 * s, 0.26 * s, polymer);
    box(sBody, 0, -0.18 * s, 0.05 * s, 0.06 * s, 0.22 * s, 0.085 * s, polymer);
    box(sBody, 0, -0.03 * s, 0.24 * s, 0.085 * s, 0.16 * s, 0.26 * s, metal);
    for (let i = 0; i < 4; i++) {
      mesh(new THREE.CylinderGeometry(0.012 * s, 0.012 * s, 0.075 * s, 8), mat(0xff5a36, 1.6), sBody, -0.065 * s, -0.02 * s + (i * 0.022 * s), -0.08 * s - (i * 0.035 * s)).rotation.z = Math.PI / 2;
    }

  } else if (id === 'blade') {
    // Vibro-Edge Tactical Combat Tanto
    const hilt = new THREE.Group(); hilt.name = 'bladeHilt'; g.add(hilt);
    box(hilt, 0, -0.14 * s, 0.04 * s, 0.042 * s, 0.22 * s, 0.065 * s, polymer);
    box(hilt, 0, -0.12 * s, -0.02 * s, 0.03 * s, 0.24 * s, 0.025 * s, metal);
    box(hilt, 0, -0.26 * s, 0.04 * s, 0.035 * s, 0.04 * s, 0.05 * s, chrome);
    box(hilt, 0, -0.01 * s, 0.01 * s, 0.055 * s, 0.04 * s, 0.11 * s, metal);

    const bGroup = new THREE.Group(); bGroup.name = 'bladeGeometry'; g.add(bGroup);
    box(bGroup, 0, 0.04 * s, -0.22 * s, 0.028 * s, 0.055 * s, 0.42 * s, steel);
    for (let z = -0.06; z > -0.20; z -= 0.035) {
      box(bGroup, 0, 0.075 * s, z * s, 0.022 * s, 0.02 * s, 0.02 * s, metal);
    }
    mesh(new THREE.BoxGeometry(0.012 * s, 0.03 * s, 0.44 * s), mat(0x64e8ff, 2.0), bGroup, 0, 0.015 * s, -0.24 * s);
    const tip = mesh(new THREE.ConeGeometry(0.035 * s, 0.09 * s, 4), mat(0x64e8ff, 2.2), bGroup, 0, 0.035 * s, -0.47 * s);
    tip.rotation.x = -Math.PI / 2;

  } else if (id === 'sabre') {
    // Nyx High-Energy Plasma Sabre
    const sHilt = new THREE.Group(); sHilt.name = 'sabreHilt'; g.add(sHilt);
    mesh(new THREE.CylinderGeometry(0.028 * s, 0.028 * s, 0.28 * s, 12), metal, sHilt, 0, -0.12 * s, 0);
    for (const y of [-0.04, -0.10, -0.16, -0.22]) {
      mesh(new THREE.TorusGeometry(0.032 * s, 0.006 * s, 6, 12), chrome, sHilt, 0, y * s, 0).rotation.x = Math.PI / 2;
    }
    box(sHilt, 0.03 * s, -0.06 * s, 0, 0.012 * s, 0.03 * s, 0.02 * s, accent);
    mesh(new THREE.CylinderGeometry(0.035 * s, 0.03 * s, 0.06 * s, 12), chrome, sHilt, 0, 0.03 * s, 0);
    for (const ang of [0, Math.PI]) {
      box(sHilt, Math.sin(ang) * 0.032 * s, 0.07 * s, Math.cos(ang) * 0.032 * s, 0.01 * s, 0.05 * s, 0.015 * s, accent);
    }

    const bladeGroup = new THREE.Group(); bladeGroup.name = 'plasmaBlade'; g.add(bladeGroup);
    bladeGroup.rotation.x = -Math.PI / 2;
    bladeGroup.position.set(0, 0.06 * s, 0);
    mesh(new THREE.CylinderGeometry(0.014 * s, 0.014 * s, 0.85 * s, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }), bladeGroup, 0, 0.42 * s, 0);
    mesh(new THREE.CylinderGeometry(0.032 * s, 0.024 * s, 0.88 * s, 12), new THREE.MeshStandardMaterial({
      color: 0x22f5d2, emissive: 0x22f5d2, emissiveIntensity: 2.5, transparent: true, opacity: 0.85, depthWrite: false
    }), bladeGroup, 0, 0.44 * s, 0);
    mesh(new THREE.SphereGeometry(0.032 * s, 8, 8), mat(0x22f5d2, 2.5), bladeGroup, 0, 0.88 * s, 0);

  } else if (id === 'tool') {
    // Ruptor Industrial Mining Rig
    box(g, 0, 0, 0, 0.16 * s, 0.20 * s, 0.38 * s, 0x2a444a);
    box(g, 0, 0.12 * s, -0.06 * s, 0.13 * s, 0.06 * s, 0.22 * s, mat(0x5df5b8, 1.4));
    for (const x of [-0.08 * s, 0.08 * s]) {
      bone(g, V(x, 0.02 * s, -0.18 * s), V(x, 0.02 * s, -0.42 * s), 0.018 * s, 0x8ab8b0);
      mesh(new THREE.SphereGeometry(0.022 * s, 8, 6), mat(0x5df5b8, 2.0), g, x, 0.02 * s, -0.42 * s);
    }
    mesh(new THREE.CylinderGeometry(0.05 * s, 0.05 * s, 0.16 * s, 10), metal, g, 0, -0.12 * s, 0.08 * s).rotation.z = Math.PI / 2;

  } else if (id === 'grenade') {
    // Mk-IV Plasma Ordnance
    ellipsoid(g, 0, 0, 0, 0.085 * s, 0.13 * s, 0.085 * s, 0x2c382f, 1);
    mesh(new THREE.TorusGeometry(0.086 * s, 0.012 * s, 6, 14), mat(0xffa338, 1.5), g, 0, 0, 0).rotation.x = Math.PI / 2;
    box(g, 0, 0.14 * s, 0, 0.05 * s, 0.06 * s, 0.06 * s, metal);
    box(g, 0.025 * s, 0.10 * s, -0.04 * s, 0.015 * s, 0.14 * s, 0.03 * s, chrome);
    mesh(new THREE.TorusGeometry(0.035 * s, 0.008 * s, 6, 12), chrome, g, -0.045 * s, 0.14 * s, 0);
  }
}
let avatarWeapon = null;

function updateAvatarWeapon() {
  if (!avatar) return;
  const rig = avatar.userData?.rig;
  const rightElbow = rig?.userData?.human?.elbows?.[1];
  if (!rightElbow) return;

  let holder = rightElbow.getObjectByName('avatarWeaponHolder');
  if (!holder) {
    holder = new THREE.Group();
    holder.name = 'avatarWeaponHolder';
    // Positioned in character's right hand palm, rotated -90° around X so barrel points forward
    holder.position.set(0, -0.285, 0.015);
    holder.rotation.set(-Math.PI / 2, 0, 0);
    rightElbow.add(holder);
  }
  discardChildren(holder);
  if (mode === 'foot' && equipped && !(equipped === 'grenade' && equipment.grenades <= 0)) {
    makeWeapon(holder, equipped, true);
    holder.traverse(o => {
      o.userData.noCollision = true;
      if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; }
    });
  }
  avatarWeapon = holder;
}

function rebuildWeapon() {
  if (!weaponView) {
    weaponView = new THREE.Group();
    camera.add(weaponView);
    scene.add(camera);
  }
  discardChildren(weaponView);
  makeWeapon(weaponView, equipped, false);
  weaponView.position.set(0.30, -0.28, -0.62);
  weaponView.rotation.set(0, -0.06, 0);
  weaponView.traverse(o => o.userData.noCollision = true);
  updateAvatarWeapon();
}
function animateEntities(dt){for(const a of animals){a.g.userData.legs?.forEach((leg,k)=>leg.rotation.x=Math.sin(totalTime*2.2+k*Math.PI)*.15);if(a.g.userData.tail)a.g.userData.tail.rotation.y=Math.sin(totalTime*.9+a.phase)*.22;}rover.userData.wheels?.forEach(w=>{if(mode==='rover')w.rotation.x-=axisForward()*dt*9;});if (weaponView) {
    weaponView.visible = mode === 'foot' && started && $('panel').classList.contains('hidden');
    recoil = Math.max(0, recoil - dt * 6.5);

    // Natural breathing & footstep bobbing
    const bobX = Math.sin(totalTime * 4.5) * 0.003;
    const bobY = -Math.abs(Math.sin(totalTime * 4.5)) * 0.004;

    let posX = 0.30 + bobX, posY = -0.28 + bobY, posZ = -0.62;
    let rotX = 0, rotY = -0.06, rotZ = 0;

    // Recoil kickback translation & muzzle rise
    const d = weaponDefs[equipped] || {};
    const kickZ = (d.recoil || 0.8) * 0.09;
    const kickRotX = (d.recoil || 0.8) * 0.16;
    posZ += recoil * kickZ;
    rotX += recoil * kickRotX;

    // Slide reciprocation animation on handgun
    const slideMesh = weaponView.getObjectByName('weaponSlide');
    if (slideMesh) {
      slideMesh.position.z = recoil * 0.045;
    }

    // Reload animation sequence
    if (reloadActive) {
      const p = Math.min(1, Math.max(0, (combatTime - reloadStartTime) / reloadDuration));
      if (p < 0.3) {
        // Dip down & tilt left
        const subP = p / 0.3;
        posY -= Math.sin(subP * Math.PI * 0.5) * 0.12;
        rotZ -= Math.sin(subP * Math.PI * 0.5) * 0.45;
        rotX -= Math.sin(subP * Math.PI * 0.5) * 0.20;
      } else if (p < 0.7) {
        // Insert fresh magazine
        posY -= 0.12;
        rotZ -= 0.45;
        rotX -= 0.20;
      } else if (p < 0.9) {
        // Slide rack
        posY -= 0.12 * (1 - (p - 0.7) / 0.2);
        rotZ -= 0.45 * (1 - (p - 0.7) / 0.2);
        if (slideMesh) slideMesh.position.z = Math.sin((p - 0.7) / 0.2 * Math.PI) * 0.05;
      } else {
        // Return to ready
        const subP = (p - 0.9) / 0.1;
        posY += (1 - subP) * -0.04;
      }

      if (p >= 1.0) {
        reloadActive = false;
        if (d.mag) {
          const needed = d.mag - magazines[equipped];
          const available = Math.min(needed, equipment.ammo);
          magazines[equipped] += available;
          equipment.ammo -= available;
        }
      }
    }

    // Melee slash animation sequence
    if (meleeActive) {
      const mp = Math.min(1, Math.max(0, (combatTime - meleeStartTime) / meleeDuration));
      if (meleeCombo === 0) {
        // Diagonal slash top-right to bottom-left
        if (mp < 0.2) {
          posX += (mp / 0.2) * 0.12;
          posY += (mp / 0.2) * 0.10;
          rotY += (mp / 0.2) * 0.45;
          rotZ -= (mp / 0.2) * 0.35;
        } else if (mp < 0.65) {
          const sP = (mp - 0.2) / 0.45;
          posX = 0.42 - sP * 0.65;
          posY = -0.18 - sP * 0.12;
          posZ = -0.62 - Math.sin(sP * Math.PI) * 0.15;
          rotZ = -0.35 + sP * 0.95;
          rotY = 0.45 - sP * 1.1;
          rotX = sP * 0.45;
        } else {
          const rP = (mp - 0.65) / 0.35;
          posX = THREE.MathUtils.lerp(-0.23, 0.30, rP);
          rotZ = THREE.MathUtils.lerp(0.60, 0, rP);
          rotY = THREE.MathUtils.lerp(-0.65, -0.06, rP);
          rotX = THREE.MathUtils.lerp(0.45, 0, rP);
        }
      } else {
        // Horizontal backhand cleave
        if (mp < 0.2) {
          posX -= (mp / 0.2) * 0.15;
          rotY -= (mp / 0.2) * 0.45;
        } else if (mp < 0.65) {
          const sP = (mp - 0.2) / 0.45;
          posX = -0.15 + sP * 0.60;
          posZ = -0.62 - Math.sin(sP * Math.PI) * 0.15;
          rotY = -0.45 + sP * 1.1;
          rotZ = 0.2 - sP * 0.4;
        } else {
          const rP = (mp - 0.65) / 0.35;
          posX = THREE.MathUtils.lerp(0.45, 0.30, rP);
          rotY = THREE.MathUtils.lerp(0.65, -0.06, rP);
        }
      }
      if (mp >= 1.0) meleeActive = false;
    }

    weaponView.position.set(posX, posY, posZ);
    weaponView.rotation.set(rotX, rotY, rotZ);
  }}

function buildStore(parent,p,j,variation){const side=j%2?1:-1,x=side*53,z=-43+Math.floor(j/2)*42,type=storeSets[variation][j],def=storeDefs[type],g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=side<0?Math.PI/2:-Math.PI/2;parent.add(g);const s={id:shops.length,type,def,g,p,portKey:p?p.i:parent.position.x>SEP/2?7:6,entry:V(0,0,15)};shops.push(s);box(g,0,.04,0,27,.12,29,0x687e81);box(g,-13.5,2.75,0,.4,5.5,29,0x536a78);box(g,13.5,2.75,0,.4,5.5,29,0x536a78);box(g,0,2.75,-14.5,27,5.5,.4,0x526b77);for(const side of [-1,1]){box(g,side*8.15,2.65,14.5,10.7,5.3,.35,0x607784);box(g,side*7.4,2.5,14.72,6,2.7,.08,new THREE.MeshStandardMaterial({color:0x759fba,transparent:true,opacity:.35}));}box(g,0,5.6,0,28,.25,30,0x708994);const upper=box(g,0,8.5+(j%2)*1.5,0,26,5+(j%2)*3,28,0x566c79);for(let i=-9;i<=9;i+=4.5)box(g,i,8,14.1,2,1.6,.08,mat(def.color,.3));box(g,0,5.1,14.7,7,.8,.5,def.color);label3D(g,def.name,0,6.25,15.2,20);for(const side of [-1,1])box(g,side*2.6,2.6,14.3,.15,5.2,.2,mat(def.color,.8));
box(g,0,.65,-5.5,8,1.3,1.4,0x435d6c);box(g,0,1.36,-5.5,8.2,.12,1.6,0x9ab0ac);box(g,2.5,1.64,-5.5,1,.5,.1,mat(0x7cd5c5,.6));for(let side of [-1,1]){box(g,side*10,1.8,-5,2.5,3.6,12,0x425b69);for(let z=-9;z<=0;z+=3)for(let y of [1,2.3])box(g,side*9.5,y,z,1.6,.6,1.3,def.color);box(g,side*6,5.25,3,.4,.15,9,mat(0xd1eedc,1.2));}
const display=new THREE.Group();display.position.set(7,1.3,6);g.add(display);box(g,7,.6,6,5,1.2,5,0x546c75);if(type==='ships'){fighterModel(display,false);display.scale.setScalar(.35);}else if(type==='vehicles'){ellipsoid(display,0,.5,0,1.5,.5,2,def.color);for(let a of [-1,1])for(let b of [-1,1])mesh(new THREE.CylinderGeometry(.45,.45,.3,12),0x27383f,display,a*1.4,.2,b*1.3).rotation.z=Math.PI/2;}else if(type==='ranged'||type==='melee'||type==='explosives'){makeWeapon(display,type==='ranged'?'rifle':type==='melee'?'sabre':'grenade');display.scale.setScalar(2);display.rotation.z=.2;}else{mesh(new THREE.OctahedronGeometry(1,1),mat(def.color,.5),display,0,.7,0);}label3D(g,type==='jobs'?'E · CONTRATOS':'E · FALAR COM ATENDENTE',0,3.7,-13.8,13);
const clerk=person(g,0,-7.8,def.color),names=['Clara','Raul','Elisa','Davi','Mila','Theo'];s.clerk=clerk;npcs.push({g:clerk,base:clerk.position.clone(),name:names[j]+' · '+def.short,role:0,phase:j,city:g,shop:s,path:[clerk.position.clone()],way:0,wait:Infinity});g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});}
function openShop(id){const s=shops[id];if(!s)return;if(controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5){toast('Aproxime-se do atendente para negociar.');return;}activeShop=id;menu(s.type==='jobs'?'jobs':'shop');}
function buyProduct(id){if(id.startsWith('outfit_')||id==='jet1'||id==='jet2')return buyV05(id);const s=shops[activeShop],product=products[id];if(!s||!product||!s.def.items.includes(id)||controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5){toast('Fale com o atendente da loja correspondente.');return;}if((id==='rifle'||id==='sabre')&&equipment.weapons.includes(id)||id.startsWith('ship')&&equipment.ships.includes(Number(id.slice(4)))||['scout','hauler','skiff','cutter'].includes(id)&&equipment.vehicles.includes(id)){toast('Você já possui este item.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];if(id==='rifle'||id==='sabre')equipment.weapons.push(id);if(id==='ammo')equipment.ammo+=72;if(id==='grenades')equipment.grenades+=3;if(id==='medkits')equipment.medkits+=2;if(id==='heal'){health=100;suitShield=50;}if(id==='repair'){hull=shipMaxHull();shipShield=140;vehicleHealth=vehicleKind==='hauler'?240:vehicleKind==='scout'?100:150;}if(id.startsWith('ship'))equipment.ships.push(Number(id.slice(4)));if(['scout','hauler','skiff','cutter'].includes(id))equipment.vehicles.push(id);save();toast(product[0]+' adquirido.');renderPanel('shop');}
function equipWeaponBase(id){
  if(id==='grenade'&&equipment.grenades<1){
    toast('Granadas esgotadas.');
    return;
  }
  if(id!=='grenade'&&id!=='tool'&&!equipment.weapons.includes(id)){
    toast('Esse equipamento ainda não foi adquirido.');
    return;
  }
  if(!weaponDefs[id])return;
  equipped=id;
  reloadUntil=0;
  rebuildWeapon();
  if(!$('panel').classList.contains('hidden'))renderPanel('inventory');
}

function useMedkit(){if(equipment.medkits<1){toast('Você está sem kits médicos.');return;}if(health>=100){toast('Sua vida já está completa.');return;}equipment.medkits--;health=Math.min(100,health+55);save();toast('Kit médico utilizado.');}
function selectVehicle(kind){if(!equipment.vehicles.includes(kind)||!landed||rover.parent!==ship||!atPort()||mode==='rover'){toast('Troque em um porto, com o veículo vazio e preso à nave.');return;}remodelRover(kind);rover.position.copy(layout().rover);rover.rotation.set(0,layout().roverYaw,0);save();renderPanel('fleet');toast('Veículo preparado no porão.');}
function fleetSelect(i){if(!equipment.ships.includes(i)){toast('Adquira esta nave em um estaleiro. O mapa mostra os serviços de cada porto.');return;}if(!landed||!atPort()||mode!=='pilot'||mission||rover.parent!==ship){toast('Selecione no cockpit, pousado, sem contrato ativo e com o rover a bordo.');return;}shipType=i;buildShip();hull=shipMaxHull();shipShield=140;enhanceShip();refreshMovingBodies();yaw=0;pitch=0;renderPanel('fleet');}

function shipMaxHull(){return [320,240,450][shipType];}
function spawnEnemy(type,pos,p=null,tag=null){pos=hostilePosition(pos,p);const g=new THREE.Group();g.position.copy(pos);g.userData.combatEnemy=true;scene.add(g);const flying=type==='pirateShip'||type==='militaryShip',beast=type==='animal';let rig=null;if(flying)fighterModel(g,type==='militaryShip');else if(beast)sculptAnimal(g,p.i,true);else{rig=person(g,0,0,type==='military'?0x617886:0x9b6350);const gun=new THREE.Group();gun.position.set(.35,1.2,-.25);rig.add(gun);makeWeapon(gun,'rifle');}if(p)g.quaternion.copy(frameAt(pos,p.center));g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});const e={id:++enemySerial,g,rig,type,p,tag,flying,beast,hp:flying?180:beast?65:90,maxHp:flying?180:beast?65:90,alive:true,origin:pos.clone(),warn:flying?2400:beast?85:125,aggro:flying?850:beast?28:52,alert:false,shotAt:combatTime+1.5,phase:enemySerial*.8};enemies.push(e);return e;}
function initEnemies(){for(const p of planets){for(let k=0;k<2;k++){const n=V(k?.48:-.46,1,k?-.39:.35).normalize();spawnEnemy(k?(p.i%2?'military':'raider'):'animal',p.center.clone().addScaledVector(n,radius(p,n)+.12),p);}}spawnEnemy('pirateShip',V(2700,3700,1400));spawnEnemy('militaryShip',V(-2800,4300,-1600));}
function enemyCenter(e){return e.g.position.clone().addScaledVector(e.p?e.g.position.clone().sub(e.p.center).normalize():UP,e.flying?0:e.beast?1:1.05);}
function enemyName(e){return e.beast?'FAUNA HOSTIL':e.type==='militaryShip'?'CAÇA MILITAR HOSTIL':e.type==='pirateShip'?'PIRATAS ESPACIAIS':e.type==='military'?'SOLDADO HOSTIL':'SAQUEADOR';}
function obstacleDistance(from,to,ignore=null){const delta=to.clone().sub(from),length=delta.length();if(length<.001)return Infinity;const ray=new THREE.Raycaster(from,delta.normalize(),.06,length),mid=from.clone().add(to).multiplyScalar(.5),sphere=new THREE.Sphere(mid,length*.5+2);const candidates=[...queryStatic(mid,length*.5+2),...movingBodies].filter(b=>b.obj.isMesh&&!b.obj.userData.removed&&!hasAncestorFlag(b.obj,'combatEnemy')&&(!ignore||!belongsTo(b.obj,ignore))&&b.world.intersectsSphere(sphere)).map(b=>b.obj);ray.layers.enable(31);const hit=ray.intersectObjects(candidates,false)[0];let best=hit?hit.distance:Infinity;for(const p of planets){const sphereHit=ray.ray.intersectSphere(new THREE.Sphere(p.center,p.r-18),V());if(sphereHit){const d=from.distanceTo(sphereHit);if(d>.1&&d<length)best=Math.min(best,d);}}return best;}
function segmentHit(a,b,center,r){const delta=b.clone().sub(a),length=delta.length();if(length<.001)return a.distanceTo(center)<r?0:null;const ray=new THREE.Ray(a,delta.normalize()),hit=ray.intersectSphere(new THREE.Sphere(center,r),V());if(!hit)return null;const d=a.distanceTo(hit);return d<=length?d:null;}
function particleBurst(pos,color,count=20,power=7){if(!particlesEnabled)return;const max=quality==='low'?100:360;for(let j=0;j<count&&combatParticles.length<max;j++){const v=V(combatRng()-.5,combatRng()-.3,combatRng()-.5).normalize().multiplyScalar(power*(.3+combatRng()));combatParticles.push({pos:pos.clone(),v,life:.3+combatRng()*.8,color:new THREE.Color(color)});}}
const transientFX=[];
function traceFX(from, to, color = 0x42f5d7, isPellet = false) {
  const dir = to.clone().sub(from);
  const dist = dir.length();
  if (dist < 0.05) return;
  dir.normalize();

  // 1. 3D Muzzle Flash Starburst at barrel tip
  if (!isPellet) {
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
      depthWrite: false
    });
    const flashMesh = mesh(new THREE.ConeGeometry(0.065, 0.18, 6), flashMat, scene, from.x, from.y, from.z);
    flashMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
    flashMesh.userData.noCollision = true;
    transientFX.push({
      o: flashMesh,
      life: 0.05,
      ttl: 0.05,
      update: (dt, p) => {
        flashMesh.scale.setScalar(1 + (1 - p) * 1.6);
        flashMat.opacity = p * 0.95;
      }
    });
  }

  // 2. High-Velocity 3D Energized Plasma Bolt Tracer
  const boltLen = Math.min(1.5, Math.max(0.45, dist * 0.18));
  const boltRadius = isPellet ? 0.024 : 0.042;
  const boltGeo = new THREE.CylinderGeometry(boltRadius * 0.4, boltRadius, boltLen, 6);
  const boltMat = new THREE.MeshBasicMaterial({
    color: color,
    transparent: true,
    opacity: 0.95,
    depthWrite: false
  });
  const boltMesh = new THREE.Mesh(boltGeo, boltMat);
  boltMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
  boltMesh.position.copy(from).addScaledVector(dir, boltLen * 0.5);
  boltMesh.userData.noCollision = true;
  scene.add(boltMesh);

  const speed = isPellet ? 650 : 850;
  const duration = Math.min(0.25, Math.max(0.05, dist / speed));
  let elapsed = 0;

  transientFX.push({
    o: boltMesh,
    life: duration,
    ttl: duration,
    update: (dt, p) => {
      elapsed += dt;
      const progress = Math.min(1, elapsed / duration);
      const curPos = from.clone().lerp(to, progress);
      boltMesh.position.copy(curPos);
      boltMat.opacity = Math.min(1, p * 1.8);
      if (progress >= 0.96 && dist > 1.2) {
        particleBurst(to, color, isPellet ? 8 : 18, 2.5);
      }
    }
  });
}
function blastFX(pos,r=8){if(audioContext&&pos.distanceTo(controlledPosition())<2500){tone(48,audioContext.currentTime,.5,.13,fxBus,'sawtooth');tone(90,audioContext.currentTime,.3,.08,fxBus,'triangle');}const o=mesh(new THREE.IcosahedronGeometry(1,1),new THREE.MeshBasicMaterial({color:0xffb47b,transparent:true,opacity:.65,wireframe:true,depthWrite:false,toneMapped:false}),scene,...pos.toArray());o.userData.noCollision=true;transientFX.push({o,life:.55,ttl:.55,r});particleBurst(pos,0xffb866,36,r*2);}
function damageEnemy(e,damage){if(!e.alive)return;e.hp-=damage;e.alert=true;particleBurst(enemyCenter(e),e.beast?0xb5bf98:0xffc482,6,3);if(e.hp<=0){e.alive=false;e.g.visible=false;e.g.traverse(o=>o.userData.removed=true);blastFX(enemyCenter(e),e.flying?16:2.5);if(mission?.combat&&mission.tag===e.tag)mission.kills++;credits+=e.flying?120:30;save();toast(enemyName(e)+' neutralizado.');}}
function playerTarget(){if(mode==='pilot'||inside)return {pos:ship.position.clone().add(V(0,1,0)),r:6,vehicle:'ship'};if(mode==='rover')return {pos:rover.getWorldPosition(V()).add(V(0,1,0)),r:2,vehicle:'rover'};const up=eva?UP:player.clone().sub((groundPlanet||nearest(player)).center).normalize();return {pos:player.clone().addScaledVector(up,-.8),r:.7,vehicle:'suit'};}
function hurtPlayer(amount){if(safeZone(controlledPosition())||boost)return;lastHurt=combatTime;damageFlash=Math.min(.7,damageFlash+.3);if(mode==='pilot'||inside){const shield=Math.min(shipShield,amount);shipShield-=shield;hull-=amount-shield;}else if(mode==='rover')vehicleHealth-=amount;else{const shield=Math.min(suitShield,amount);suitShield-=shield;health-=amount-shield;}if(health<=0||hull<=0||vehicleHealth<=0)emergencyRespawn();}
function emergencyRespawn(){const pos=controlledPosition(),port=destinations.filter(d=>!d.gate&&d.kind!=='water').reduce((a,b)=>pos.distanceTo(a.pos)<pos.distanceTo(b.pos)?a:b);clearCombatMission();if(mission)resetJobObjects(mission);mission=null;clearMissionCargo();cargo=0;credits=Math.max(0,credits-150);health=100;suitShield=50;hull=shipMaxHull();shipShield=140;vehicleHealth=vehicleKind==='hauler'?240:vehicleKind==='scout'?100:150;auto=null;boost=null;landed=true;ship.position.copy(port.pos).add(port.p?planetUp(port.pos,port.p).multiplyScalar(2):V(0,2,0));ship.quaternion.copy(port.p?frameAt(port.pos,port.p.center):new THREE.Quaternion());resetFootMotion();mode='pilot';inside=true;eva=false;flightSpeed=0;groundPlanet=port.p||null;station=port.station||null;firing=false;keys.KeyW=keys.KeyS=false;touchX=touchY=0;save();toast('Resgate de emergência ao porto. Serviço: até 150 CR.');}
// === REALISTIC PROCEDURAL WEAPON SOUND SYNTHESIZER ===

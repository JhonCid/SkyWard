function makePlanetGeometry(p,w,h){const geo=new THREE.SphereGeometry(p.r,w,h),a=geo.attributes.position,colors=new Float32Array(a.count*3);for(let j=0;j<a.count;j++){const n=V(a.getX(j),a.getY(j),a.getZ(j)).normalize(),r=radius(p,n),c=new THREE.Color(p.def[3+biome(n,p.i)]).multiplyScalar(.91+.08*Math.sin(n.x*31+n.z*23));a.setXYZ(j,n.x*r,n.y*r,n.z*r);colors.set([c.r,c.g,c.b],j*3);}geo.setAttribute('color',new THREE.BufferAttribute(colors,3));geo.computeVertexNormals();geo.computeBoundingSphere();return geo;}
function createPlanetLOD(p){
  const geo=makePlanetGeometry(p,24,16);
  const material=new THREE.MeshStandardMaterial({vertexColors:true,flatShading:true,roughness:0.85,metalness:0.0});
  const globe=mesh(geo,material);
  globe.position.copy(p.center);
  globe.userData.celestial=true;
  globe.receiveShadow=false;
  p.globe=globe;
  p.lodGeometries=[geo, null, null, null];
  p.lodIndex=0;
  planetLODs.push(p);
}
function updateLOD(dt,force=false){
  lodTimer-=dt;
  if(!force&&lodTimer>0)return;
  lodTimer=.15;
  statV05.planetTriangles=0;
  const fov=camera.fov*Math.PI/180,scale=innerHeight/(2*Math.tan(fov/2));
  for(const p of planets){
    if(!p||!p.globe)continue;
    const distance=Math.max(1,camera.position.distanceTo(p.center)),pixels=p.r/distance*scale;
    let level=distance-p.r<220||pixels>300?3:pixels>95?2:pixels>20?1:0;
    if(distance>p.r+250)level=Math.min(level,performancePrefs.planetDetail);
    p.lodIndex=level;
    if(!p.lodGeometries[level]){
      const res=[[24,16],[36,20],[56,32],[80,48]][level];
      p.lodGeometries[level]=makePlanetGeometry(p,res[0],res[1]);
    }
    p.globe.geometry=p.lodGeometries[level];
    p.globe.visible=pixels>.2;
    p.globe.receiveShadow=level===3&&quality==='high';
    if(p.globe.visible&&p.globe.geometry.index)statV05.planetTriangles+=p.globe.geometry.index.count/3;
    if(p.atmosphere)p.atmosphere.visible=pixels>3;
  }
  statV05.visibleSettlements=0;
  const observer=camera.position;
  for(const s of settlements){
    if(!s||!s.root)continue;
    const distance=observer.distanceTo(s.center),normal=planetUp(s.center,s.p),occluded=observer.clone().sub(s.center).dot(normal)<-80;
    s.root.visible=!occluded&&distance<(quality==='low'?2700:5000)*performancePrefs.distance;
    if(s.root.visible)statV05.visibleSettlements++;
    for(const g of s.lots){
      const d=g.getWorldPosition(V()).distanceTo(observer);
      g.visible=s.root.visible&&d<(g.userData.small?900:2400)*performancePrefs.distance;
      if(g.userData.details)g.userData.details.visible=d<(quality==='low'?180:380)*performancePrefs.distance;
    }
  }
  for(const n of npcs)if(n.g)n.g.visible=n.g.getWorldPosition(V()).distanceTo(observer)<(quality==='low'?160:350)*performancePrefs.characterDistance;
  for(const g of scenery){
    if(!g)continue;
    const p=nearest(g.position),normal=planetUp(g.position,p);
    g.visible=!g.userData.removed&&g.position.distanceTo(observer)<(quality==='low'?850:1600)*performancePrefs.distance&&observer.clone().sub(g.position).dot(normal)>-50;
  }
}
function buildSpatialIndex(){staticGrid.clear();for(const b of staticBodies){const min=b.world.min,max=b.world.max;if(max.distanceTo(min)>350)continue;for(let x=Math.floor(min.x/40);x<=Math.floor(max.x/40);x++)for(let y=Math.floor(min.y/40);y<=Math.floor(max.y/40);y++)for(let z=Math.floor(min.z/40);z<=Math.floor(max.z/40);z++){const key=x+','+y+','+z;if(!staticGrid.has(key))staticGrid.set(key,[]);staticGrid.get(key).push(b);}}gridReady=true;}
function queryStatic(pos,r){if(!gridReady||r>180)return staticBodies.filter(b=>b.world.distanceToPoint(pos)<r);const out=new Set();for(let x=Math.floor((pos.x-r)/40);x<=Math.floor((pos.x+r)/40);x++)for(let y=Math.floor((pos.y-r)/40);y<=Math.floor((pos.y+r)/40);y++)for(let z=Math.floor((pos.z-r)/40);z<=Math.floor((pos.z+r)/40);z++)for(const b of staticGrid.get(x+','+y+','+z)||[])out.add(b);return [...out].filter(b=>b.world.distanceToPoint(pos)<r);}
function nearbyBodies(pos,margin,ignore){if(!collisionReady)return [];return [...queryStatic(pos,margin),...movingBodies].filter(b=>!hasAncestorFlag(b.obj,'removed')&&(!ignore||!belongsTo(b.obj,ignore))&&b.world.distanceToPoint(pos)<margin);}
// Combine static surfaces by material while retaining their separate collision volumes.
function batchArchitecture(root){root.updateWorldMatrix(true,true);const buckets=new Map(),inv=root.matrixWorld.clone().invert();root.traverse(o=>{if(!root.userData.batchUnit&&hasAncestorFlag(o,'batchUnit')||!root.userData.detailRoot&&hasAncestorFlag(o,'detailRoot'))return;if(!o.isMesh||o.material.transparent||o.material.map||o.geometry.type==='PlaneGeometry'||hasAncestorFlag(o,'actor')||hasAncestorFlag(o,'dynamic'))return;const m=o.material,key=[m.color?.getHex(),m.emissive?.getHex(),m.emissiveIntensity,m.roughness].join(':');if(!buckets.has(key))buckets.set(key,{m,list:[]});buckets.get(key).list.push(o);});for(const {m,list} of buckets.values()){if(list.length<3)continue;const arrays=[],normals=[];for(const o of list){const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(inv.clone().multiply(o.matrixWorld));arrays.push(...geo.attributes.position.array);normals.push(...geo.attributes.normal.array);geo.dispose();o.layers.set(31);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(arrays,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));g.computeBoundingSphere();const merged=mesh(g,m.clone(),root);merged.castShadow=true;merged.receiveShadow=true;merged.userData.noCollision=true;}}

function settlementPoint(s,x,z,offset=0){const n=V(x,s.p.r,z).normalize().applyQuaternion(s.frame);return s.p.center.clone().addScaledVector(n,radius(s.p,n)+offset);}
function settlementLocal(s,world){const v=world.clone().sub(s.p.center).applyQuaternion(s.frame.clone().invert());return V(v.x*s.p.r/v.y,0,v.z*s.p.r/v.y);}
function curvedPatch(s,x,z,w,d,color,offset=.12){if(Math.max(w,d)>110&&Math.min(w,d)<30){const longX=w>d,n=Math.ceil(Math.max(w,d)/95);for(let i=0;i<n;i++)curvedPatch(s,x+(longX?(-w/2+w*(i+.5)/n):0),z+(!longX?(-d/2+d*(i+.5)/n):0),longX?w/n:w,longX?d:d/n,color,offset);return null;}const geo=new THREE.PlaneGeometry(w,d,Math.max(2,Math.ceil(w/9)),Math.max(2,Math.ceil(d/9)));geo.rotateX(-Math.PI/2);const a=geo.attributes.position;for(let i=0;i<a.count;i++){const v=settlementPoint(s,x+a.getX(i),z+a.getZ(i),offset).sub(s.root.position);a.setXYZ(i,v.x,v.y,v.z);}geo.computeVertexNormals();const m=mesh(geo,color,s.root);m.userData.surfaceOnly=true;m.receiveShadow=true;return m;}
function surfaceGroup(s,x,z){const g=new THREE.Group(),pos=settlementPoint(s,x,z,.18);g.position.copy(pos).sub(s.root.position);g.quaternion.copy(frameAt(pos,s.p.center));s.root.add(g);g.userData.batchUnit=true;s.lots.push(g);return g;}
function residentialBlock(g,random,p,index){
  const h=8+Math.floor(random()*5)*7,w=14+random()*9,d=15+random()*8,col=new THREE.Color(p.def[5]).lerp(new THREE.Color(0x77848b),.65).getHex();
  box(g,0,h/2,0,w,h,d,col);
  box(g,0,h+.2,0,w+1,.4,d+1,0x394f5b);
  const details=new THREE.Group();
  g.add(details);
  g.userData.details=details;
  details.userData.detailRoot=true;
  details.userData.batchUnit=true;
  for(let y=4;y<h-2;y+=5){
    box(details,0,y,-d/2-.05,w-3,1.6,.08,mat(index%3?0x779caa:0xbcc9ae,.25));
    box(details,0,y,d/2+.05,w-3,1.6,.08,mat(0x85a4b0,.2));
  }
  box(details,0,1.6,d/2+.15,2,3.2,.15,0x203c4d);
  if(index%3===0){
    mesh(new THREE.CylinderGeometry(w*.35,w*.4,h*.55,8),col,g,w*.15,h*.275,d*.15);
    box(g,w*.15,h*.55,d*.15,w*.65,.3,w*.65,0x425567);
  }
  if(index%2===0){
    box(g,0,h+1.2,0,w*.5,2,d*.6,0x516771);
  }
  g.userData.height=h;
}
function townPath(s,t,scale=1){const a=t*Math.PI*2,r=(s.kind==='city'?110:35)*(1+.18*Math.sin(a*3+s.p.i+scale*.8)+.10*Math.cos(a*5+s.index-scale));return V(Math.cos(a)*r*scale,0,Math.sin(a)*r*.85*scale);}
function townRoad(s,points,width=9){for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1],d=b.clone().sub(a),n=V(-d.z,0,d.x).normalize().multiplyScalar(width/2);const corners=[a.clone().add(n),a.clone().sub(n),b.clone().sub(n),b.clone().add(n)].map(v=>settlementPoint(s,v.x,v.z,.17).sub(s.root.position).toArray());const o=panelMesh(s.root,corners,0x354a53);o.userData.surfaceOnly=true;}s.roads.push(...points.slice(0,-1));}
function createSettlement(root,p,normal,kind,index,isMain=false){const random=rng(7781+p.i*887+index*379+(kind==='village'?53:0)),center=p.center.clone().addScaledVector(normal,radius(p,normal)+.15),s={root,p,normal,frame:frameAt(center,p.center),center,kind,index,half:kind==='city'?240:80,lots:[],roads:[],isMain,name:p.def[0]+' · '+(kind==='city'?'Cidade ':'Vilarejo ')+(index+1),portKey:isMain?p.i:null};root.position.copy(center);root.userData.curvedCity=true;settlements.push(s);const city=kind==='city';for(const scale of city?[.54,1,1.7]:[1]){const points=Array.from({length:97},(_,i)=>townPath(s,i/96,scale));townRoad(s,points,city?10:7);}
for(let j=0;j<(city?7:3);j++){const a=j/(city?7:3)+.025*Math.sin(j*5),end=townPath(s,a,city?1.82:1.45),points=[];for(let i=0;i<=20;i++){const t=i/20,curve=Math.sin(t*Math.PI)*18;points.push(V(end.x*t+Math.sin(a*6.28)*curve,0,end.z*t-Math.cos(a*6.28)*curve));}townRoad(s,points,8);}
curvedPatch(s,0,0,42,42,0x718988,.26);curvedPatch(s,0,0,1,28,p.def[5],.29);curvedPatch(s,0,0,28,1,p.def[5],.29);const services=city?[...storeSets[p.i],'clothes','workshop']:['jobs',index%2?'medical':'supplies',p.i===2?'workshop':'clothes'],occupied=[];
for(let j=0;j<services.length;j++){const phase=j/services.length+.025,road=townPath(s,phase),out=road.clone().normalize(),pos=road.clone().addScaledVector(out,26),g=surfaceGroup(s,pos.x,pos.z),before=shops.length;buildStore(g,p,0,p.i);const shop=shops[before];shop.g.position.set(0,0,0);shop.g.rotation.y=Math.atan2(-out.x,-out.z);shop.type=services[j];shop.def=storeDefs[shop.type];shop.portKey=s.portKey;shop.settlement=s;redecorateShop(shop);g.userData.shop=shop;occupied.push({x:pos.x,z:pos.z,r:23});}
let built=0;for(let attempt=0;attempt<(city?150:35)&&built<(city?18:6);attempt++){const a=random()*Math.PI*2,r=Math.sqrt(random())*s.half*.98,x=Math.cos(a)*r,z=Math.sin(a)*r*.9,size=city?11+random()*8:11;if(Math.hypot(x,z)<38||occupied.some(o=>Math.hypot(x-o.x,z-o.z)<size*.72+o.r+1.5)||s.roads.some(v=>Math.hypot(x-v.x,z-v.z)<size*.66+7))continue;const g=surfaceGroup(s,x,z),near=s.roads.reduce((a,b)=>Math.hypot(x-a.x,z-a.z)<Math.hypot(x-b.x,z-b.z)?a:b);g.rotateY(Math.atan2(near.x-x,near.z-z));residentialBlock(g,random,p,built);const scale=size/22;g.scale.set(scale,city?.75+random()*1.35:.4+random()*.35,scale);occupied.push({x,z,r:size*.72});built++;}
s.buildingCount=built;
for(let k=0;k<(city?6:2);k++){const phase=k/(city?32:8),local=townPath(s,phase,1.075),anchor=surfaceGroup(s,local.x,local.z),g=person(anchor,0,0,[0xb29f76,0x83a9a4,0xa78da9][k%3]);npcs.push({g,city:anchor,settlement:s,routeBase:local,base:g.position.clone(),name:['Mara','Caio','Luna','Alan','Sara','Noah'][k%6]+' · morador',role:k%6,phase,walkPhase:phase,path:[V()],way:0,wait:0,travel:0});anchor.userData.small=true;}
for(let k=0;k<(city?6:2);k++){const point=townPath(s,k/(city?26:8),1.075),g=surfaceGroup(s,point.x,point.z);mesh(new THREE.CylinderGeometry(.1,.18,5,6),0x405766,g,0,2.5,0);ellipsoid(g,0,5,0,.6,.15,.6,mat(p.def[5],.8));g.userData.small=true;}
for(let k=0;k<(city?4:1);k++){const point=townPath(s,(k+.2)/4,.53),g=surfaceGroup(s,point.x,point.z);mesh(new THREE.CylinderGeometry(3.5,4,.5,16),0x70867c,g,0,.3,0);ellipsoid(g,0,1,0,2,.6,2,0x467f78);for(const side of [-1,1])box(g,side*6,.6,0,1.4,.4,3,0x8b795d);}
if(city)for(let k=0;k<7;k++)spawnTraffic(s,k);return s;}

function decoratePlanet(root,p){const count=settlementProfiles[p.i];if(count.cities){createSettlement(root,p,UP.clone(),'city',0,true);}else if(count.villages){createSettlement(root,p,UP.clone(),'village',0,true);}else{root.userData.uninhabited=true;const beacon=mesh(new THREE.CylinderGeometry(.18,.6,4,8),0x778e99,root,0,2,8);label3D(root,'ÁREA DE POUSO · SEM HABITANTES',0,5,8,18);}}
function finishSettlements(){
  for(const s of settlements){
    if(!s.isMain){
      s.portKey=destinations.length;
      destinations.push({name:s.name,pos:s.center.clone(),p:s.p,settlement:s,kind:s.kind});
    } else {
      const mainD=destinations.find(d=>d.p===s.p&&d.kind==='planet');
      if(mainD){mainD.name=s.name;mainD.settlement=s;}
    }
    for(const shop of shops)if(shop.settlement===s)shop.portKey=s.portKey;
  }
  for(const p of planets)if(!destinations.some(d=>d.p===p))destinations.push({name:p.def[0]+' · Porto',pos:p.center.clone().add(V(0,p.r+2,0)),p,kind:'planet'});
  buildSpatialIndex();
}
function redecorateShop(s){const old=s.g;const parent=old.parent,pos=old.position.clone(),q=old.quaternion.clone();npcs.splice(npcs.findIndex(n=>n.g===s.clerk),1);discardChildren(old);const d=s.def;box(old,0,0,0,27,.3,29,0x697f85);const entryRamp=box(old,0,-.08,16.3,6,.15,4.5,0x697f85);entryRamp.rotation.x=.09;for(const x of [-13.5,13.5])box(old,x,2.7,0,.35,5.4,29,0x5c7381);box(old,0,2.7,-14.5,27,5.4,.35,0x516b78);for(const x of [-8,8]){box(old,x,1,14.5,10,2,.35,0x5c7381);box(old,x,3.5,14.5,10,3,.1,new THREE.MeshStandardMaterial({color:0x86bec7,transparent:true,opacity:.18}));}box(old,0,5.5,0,28,.3,30,0x415967);box(old,0,7.5,0,24,3.5,26,0x6a7e83);label3D(old,d.name,0,6.3,15.1,21);box(old,0,.7,-6,8,1.4,1.6,0x547080);const display=new THREE.Group();display.position.set(7,.8,3);old.add(display);box(old,7,.35,3,5,.7,6,0x405b69);if(s.type==='clothes'){person(display,0,0,0xd7a267);person(old,-8,0,0x5d6284);}else if(s.type==='workshop'){box(display,0,1,0,1.2,1.8,.7,0xa5b6be);for(const x of [-.55,.55])mesh(new THREE.CylinderGeometry(.25,.35,1.2,10),0x485d6b,display,x,1,.35);}else if(s.type==='ships'){fighterModel(display);display.scale.setScalar(.35);}else if(s.type==='ranged'||s.type==='melee'||s.type==='explosives'){makeWeapon(display,s.type==='ranged'?'rifle':s.type==='melee'?'sabre':'grenade');display.scale.setScalar(2);}else{box(display,0,.6,0,3,1.2,3,d.color);}s.clerk=person(old,0,-8,d.color);s.clerk.userData.actor=true;npcs.push({g:s.clerk,city:old,shop:s,base:s.clerk.position.clone(),name:'Atendente · '+d.short,role:0,phase:s.id,path:[s.clerk.position.clone()],way:0,wait:Infinity});}
function spawnTraffic(s,k){const g=new THREE.Group();g.userData.dynamic=true;scene.add(g);const color=[0x618a9f,0xa6acb1,0xb39569,0x758678][k%4];const front=[[-.65,.7,-2.4],[.65,.7,-2.4],[1.1,.65,-.8],[1.05,.6,1.9],[-1.05,.6,1.9],[-1.1,.65,-.8]];panelMesh(g,front,color);for(let i=0;i<front.length;i++){const a=front[i],b=front[(i+1)%front.length];panelMesh(g,[a,b,[b[0]*.75,.3,b[2]],[a[0]*.75,.3,a[2]]],0x334e5e);}panelMesh(g,[[-.78,.72,-1.35],[.78,.72,-1.35],[.68,1.5,-.3],[-.68,1.5,-.3]],0x72a9bd);panelMesh(g,[[-.68,1.5,-.3],[.68,1.5,-.3],[.65,1.4,.85],[-.65,1.4,.85]],color);for(const side of [-1,1]){panelMesh(g,[[side*.78,.72,-1.35],[side*.68,1.5,-.3],[side*.65,1.4,.85],[side*.95,.65,1.4]],0x344f65);box(g,side*.53,.68,-2.31,.36,.12,.1,mat(0xd4faff,2));box(g,side*.73,.64,1.94,.35,.1,.1,mat(0xf76762,1));box(g,side*1.03,.3,.6,.3,.18,1.8,mat(0x67dbea,1));mesh(new THREE.CylinderGeometry(.21,.29,.2,10),mat(0x68d5ee,1),g,side*.62,.36,1.6).rotation.x=Math.PI/2;}traffic.push({g,s,phase:k/7,stopped:false,speed:10+k%3});}
function updateTraffic(dt){statV05.visibleTraffic=0;const pos=controlledPosition();for(const t of traffic){const visible=t.s.root.visible&&pos.distanceTo(t.s.center)<900;t.g.visible=visible;if(!visible)continue;statV05.visibleTraffic++;const len=660,point=phase=>townPath(t.s,phase);const local=point(t.phase),ahead=point(t.phase+8/len),world=settlementPoint(t.s,local.x,local.z,.4),next=settlementPoint(t.s,ahead.x,ahead.z,.4);t.stopped=npcs.some(n=>n.g.visible&&n.g.getWorldPosition(V()).distanceTo(next)<4)||pos.distanceTo(next)<7||pos.distanceTo(world)<5||traffic.some(o=>o!==t&&o.s===t.s&&o.g.position.distanceTo(next)<6);if(!t.stopped)t.phase=(t.phase+dt*t.speed/len)%1;t.g.position.copy(world);const up=planetUp(world,t.s.p),m=new THREE.Matrix4().lookAt(world,next,up);t.g.quaternion.copy(new THREE.Quaternion().setFromRotationMatrix(m));}}

function floorProbe(eye,up,p,height=1.8,reach=2){const origin=eye.clone().addScaledVector(up,.4-height),bodies=nearbyBodies(eye,reach+height+3,null).filter(b=>b.obj.isMesh&&!b.obj.userData.noSupport&&!hasAncestorFlag(b.obj,'actor')&&!hasAncestorFlag(b.obj,'dynamic'));const ray=new THREE.Raycaster(origin,up.clone().negate(),0,reach+.4);ray.layers.enable(31);const hits=ray.intersectObjects(bodies.map(b=>b.obj),false);let ground=null;for(const h of hits){if(Math.abs(h.face.normal.clone().transformDirection(h.object.matrixWorld).dot(up))>.45){ground=h.point.clone().addScaledVector(up,height+.04);break;}}if(p){const terrain=groundEye(eye,p,height),d=eye.clone().sub(terrain).dot(up);if(d<reach&&d>-.6&&(!ground||terrain.clone().sub(ground).dot(up)>0))ground=terrain;}return ground;}
function resetFootMotion(){jumpVelocity=0;jumpHeld=0;jumpWasDown=!!keys.Space;onFootGround=true;jetActive=false;footContext='';resting=null;}
function updateFootV05(dt){if(waterMovement(dt))return;if(resting){if(keys.Space){standUp();keys.Space=false;}return;}const context=inside?'ship':eva?'eva':station?'station':'ground';if(footContext!==context){jumpVelocity=0;onFootGround=true;jumpHeld=0;footContext=context;}const f=axisForward(),s=axisStrafe(),p=groundPlanet||nearest(player),frame=inside?ship.quaternion:eva?evaFrame:walkFrame(player,p),up=UP.clone().applyQuaternion(frame),world=inside?shipPoint(foot):player.clone();let move=V(s,0,-f);if(move.lengthSq()>1)move.normalize();move.applyAxisAngle(UP,yaw).applyQuaternion(frame).multiplyScalar((inside?(sprinting()?9:6):(sprinting()?15:8))*dt);
if(eva){const q=frame.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ'))),thruster=V(s,(keys.Space?1:0)-(keys.ControlLeft?1:0),-f);if(thruster.lengthSq()>1)thruster.normalize();thruster.applyQuaternion(q).multiplyScalar(sprinting()?80:22);const radial=planetUp(player,p),alt=player.distanceTo(p.center)-radius(p,radial);if(alt<ATMOSPHERE)evaVelocity.addScaledVector(radial,-7*dt);const delta=evaVelocity.clone().add(thruster).multiplyScalar(dt);player.copy(moveActor(player,delta,{up:radial,grounded:false}));const floor=floorProbe(player,radial,p,1.8,1);if(floor&&player.clone().sub(floor).dot(radial)<.15){player.copy(floor);eva=false;groundPlanet=p;station=null;evaVelocity.set(0,0,0);resetFootMotion();}return;}
const floor=floorProbe(world,up,inside||station?null:p,1.8,.8);if(onFootGround&&(!floor||world.clone().sub(floor).dot(up)>.35))onFootGround=false;const down=!!keys.Space;if(down&&!jumpWasDown&&onFootGround){jumpVelocity=6.8;onFootGround=false;jumpHeld=0;}jumpHeld=down?jumpHeld+dt:0;if(mobileJumpHeld&&!onFootGround&&jumpVelocity<=0)mobileJumpBoost=true;jetActive=down&&(mobileJumpHeld?mobileJumpBoost:jumpHeld>.24)&&!onFootGround&&jetFuel>0;if(jetActive){jetFuel=Math.max(0,jetFuel-dt*28);jumpVelocity=Math.min(9+jetLevel*2,jumpVelocity+dt*(21+jetLevel*2.5));if(particlesEnabled&&combatTime% .08<dt)particleBurst(world.clone().addScaledVector(up,-1.2),0x87ddec,3,2);}if(!onFootGround)jumpVelocity-=14*dt;else{jetFuel=Math.min(jetCapacity(),jetFuel+dt*20);jumpVelocity=0;}jumpWasDown=down;
if(onFootGround){const candidate=world.clone().add(move),support=floorProbe(candidate,up,inside||station?null:p,1.8,.32);if(!support||candidate.clone().sub(support).dot(up)>.30){onFootGround=false;jumpVelocity=-14*dt;}}const delta=move.addScaledVector(up,jumpVelocity*dt),intended=world.clone().add(delta),next=moveActor(world,delta,{up,p:inside||station?null:p,grounded:false});const correction=next.clone().sub(intended).dot(up);if(jumpVelocity>0&&correction<-.02)jumpVelocity=0;const support=floorProbe(next,up,inside||station?null:p,1.8,Math.max(1,Math.abs(jumpVelocity*dt)+.6));if(support&&jumpVelocity<=0&&next.clone().sub(support).dot(up)<.12&&next.clone().sub(support).dot(up)>-.4){next.copy(support);jumpVelocity=0;onFootGround=true;}else if(p&&!inside&&!station){const terrain=groundEye(next,p,1.8);if(next.clone().sub(terrain).dot(up)<0){next.copy(terrain);jumpVelocity=0;onFootGround=true;}}
if(inside){foot.copy(localPoint(next));const rel=foot.clone().sub(layout().entry);if(rampOpen&&inDoor(foot)&&rel.dot(layout().normal)>.7&&totalTime>transitionUntil)exitShip();}else player.copy(next);}
function toggleCamera(){thirdPerson=!thirdPerson;toast(thirdPerson?'Câmera em terceira pessoa.':'Câmera em primeira pessoa.');}
function armorPlate(parent,points,color,thickness=.024){const sign=points.reduce((v,p)=>v+p[2],0)<0?-1:1,a=points.map(p=>[p[0],p[1],p[2]+sign*.028]),b=a.map(p=>[p[0],p[1],p[2]-sign*thickness]);panelMesh(parent,a,color);panelMesh(parent,b.slice().reverse(),color);for(let k=0;k<a.length;k++)panelMesh(parent,[a[k],a[(k+1)%a.length],b[(k+1)%b.length],b[k]],color);}
function makeAvatar(){if(avatar){scene.remove(avatar);discardChildren(avatar);}const root=new THREE.Group();root.userData.noCollision=true;root.userData.dynamic=true;scene.add(root);const rig=new THREE.Group();root.add(rig);const armor=outfit==='arctic'?0xb9c9cb:outfit==='night'?0x293342:0x354956,accent=outfit==='ranger'?0x82936c:outfit==='engineer'?0xd8a465:outfit==='arctic'?0x5d8f9e:0xb15543,soft=0x18272e,metal=0x566b75;const torso=new THREE.Group();torso.position.y=.94;rig.add(torso);bodyLoft(torso,[[0,.15,.115],[.12,.145,.108],[.30,.205,.137],[.42,.222,.122],[.49,.09,.077]],soft,16);const pelvis=new THREE.Group();pelvis.position.y=.87;rig.add(pelvis);bodyLoft(pelvis,[[-.10,.15,.115],[0,.175,.127],[.11,.147,.109]],soft,14);
for(const side of [-1,1]){armorPlate(torso,[[side*.012,.405,-.133],[side*.18,.405,-.126],[side*.205,.31,-.151],[side*.165,.235,-.147],[side*.014,.25,-.15]],armor);armorPlate(torso,[[side*.018,.228,-.136],[side*.155,.217,-.135],[side*.135,.145,-.125],[side*.018,.157,-.132]],metal);armorPlate(torso,[[side*.015,.13,-.124],[side*.13,.12,-.115],[side*.125,.057,-.118],[side*.015,.067,-.124]],armor);armorPlate(pelvis,[[side*.01,.08,-.128],[side*.13,.08,-.125],[side*.16,-.04,-.132],[side*.025,-.10,-.126]],armor);}
armorPlate(torso,[[.07,.402,-.157],[.105,.402,-.157],[.105,.277,-.161],[.07,.265,-.161]],accent,.009);bodyLoft(torso,[[.45,.097,.089],[.51,.082,.077]],metal,14);
mesh(new THREE.CylinderGeometry(.055,.063,.10,12),soft,rig,0,1.47,0);const head=new THREE.Group();head.position.y=1.49;rig.add(head);bodyLoft(head,[[0,.062,.063],[.03,.09,.083],[.13,.105,.096,.003],[.22,.089,.083,.009],[.265,.025,.034,.014]],armor,16);const visor=panelMesh(head,[[-.095,.165,-.066],[-.072,.195,-.087],[.072,.195,-.087],[.095,.165,-.066],[.086,.075,-.08],[.042,.06,-.096],[-.042,.06,-.096],[-.086,.075,-.08]],0x152d3a);visor.position.z=-.035;visor.material.metalness=.75;visor.material.roughness=.18;for(const x of [-.094,.094]){ellipsoid(head,x,.105,.007,.018,.03,.035,metal,1);mesh(new THREE.SphereGeometry(.011,6,4),mat(0x85d8de,.8),head,x,.113,-.016);}
const limbs=[],knees=[],elbows=[];for(const side of [-1,1]){const leg=new THREE.Group();leg.position.set(side*.105,.87,0);rig.add(leg);bodyLoft(leg,[[0,.088,.088],[-.16,.084,.082],[-.38,.056,.058]],soft,12);armorPlate(leg,[[-.061,-.055,-.082],[.061,-.055,-.082],[.068,-.20,-.082],[.042,-.31,-.067],[-.045,-.31,-.067],[-.068,-.20,-.082]],armor);const knee=new THREE.Group();knee.position.y=-.38;leg.add(knee);bodyLoft(knee,[[0,.055,.06],[-.12,.061,.064],[-.33,.039,.044],[-.385,.044,.05]],soft,12);ellipsoid(knee,0,-.018,-.058,.063,.057,.023,metal,1);armorPlate(knee,[[-.048,-.075,-.064],[.048,-.075,-.064],[.037,-.315,-.052],[-.037,-.315,-.052]],armor);ellipsoid(knee,0,-.407,-.052,.066,.053,.134,armor,2);
const arm=new THREE.Group();arm.position.set(side*.226,1.365,0);rig.add(arm);bodyLoft(arm,[[0,.068,.075],[-.12,.065,.067],[-.28,.047,.047]],soft,12);ellipsoid(arm,side*.018,-.012,0,.077,.071,.089,armor,2);armorPlate(arm,[[-.049,-.06,-.069],[.049,-.06,-.069],[.041,-.22,-.057],[-.041,-.22,-.057]],armor);const elbow=new THREE.Group();elbow.position.y=-.28;arm.add(elbow);bodyLoft(elbow,[[0,.046,.047],[-.12,.05,.052],[-.245,.031,.035]],soft,12);armorPlate(elbow,[[-.041,-.05,-.055],[.041,-.05,-.055],[.033,-.218,-.044],[-.033,-.218,-.044]],metal);ellipsoid(elbow,0,-.285,-.006,.037,.053,.027,soft,2);arm.rotation.z=side*.035;limbs.push(leg,arm);knees.push(knee);elbows.push(elbow);}
// Flush thruster module: 36 cm wide, 43 cm tall and 15 cm deep, integrated into the armor.
const pack=new THREE.Group();pack.name='compactJetpack';pack.position.set(0,.025,.122);torso.add(pack);bodyLoft(pack,[[.06,.10,.055],[.12,.16,.068],[.38,.18,.065],[.46,.105,.045]],armor,12);for(const side of [-1,1]){const nozzle=mesh(new THREE.CylinderGeometry(.043,.05,.12,10),metal,pack,side*.125,.085,.025);mesh(new THREE.TorusGeometry(.037,.009,5,10),mat(0x7cdae4,.7),pack,side*.125,.022,.025).rotation.x=Math.PI/2;}armorPlate(pack,[[-.017,.36,.071],[.017,.36,.071],[.017,.16,.071],[-.017,.16,.071]],accent,.009);
rig.userData.limbs=limbs;rig.userData.human={seed:42117,torso,head,pelvis,knees,elbows,phase:0,speed:0,last:null,height:1.78};root.userData.rig=rig;mergeHumanParts(rig);root.traverse(o=>{o.userData.noCollision=true;if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});avatar=root;updateAvatarWeapon();}

function updatePlayerCamera(dt){const aboard=mode==='pilot',driving=mode==='rover';let eye,q,up,focus;
if(resting){eye=shipPoint(resting.point);q=ship.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else if(aboard){eye=shipPoint(layout().seat.clone().add(V(0,0.72,0.05)));q=ship.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else if(driving){eye=rover.localToWorld(V(0,1.72,.45));q=rover.getWorldQuaternion(new THREE.Quaternion()).multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));}
else{
  eye=inside?shipPoint(foot):player.clone();
  const baseQ = (inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player))).clone();
  q = baseQ.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')));

  // Realistic First-Person Procedural Camera Dynamics
  if (!thirdPerson && !resting) {
    const moveSpeed = Math.hypot(axisForward(), axisStrafe());
    const isSprint = sprinting() && axisForward() > 0.1;

    // A. Locomotion Head Bobbing (rhythmic vertical bounce, lateral sway, and organic roll bank)
    if (onFootGround && moveSpeed > 0.05) {
      const bobFreq = isSprint ? 12.0 : 8.5;
      camBobPhase += dt * bobFreq;
      const bobY = -Math.abs(Math.sin(camBobPhase)) * (isSprint ? 0.046 : 0.022) * moveSpeed;
      const bobX = Math.cos(camBobPhase * 0.5) * (isSprint ? 0.026 : 0.013) * moveSpeed;
      const bobRoll = -Math.cos(camBobPhase * 0.5) * (isSprint ? 0.022 : 0.010) * moveSpeed;
      const bobPitch = Math.sin(camBobPhase) * (isSprint ? 0.014 : 0.006) * moveSpeed;

      eye.add(V(bobX, bobY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(bobPitch, 0, bobRoll, 'YXZ')));
    }

    // B. Jump Lift & Landing Compression Dip
    if (onFootGround && !camWasGrounded) {
      // Impact landing compression
      camLandDip = Math.min(0.14, Math.max(0.04, Math.abs(jumpVelocity) * 0.018));
    }
    camWasGrounded = onFootGround;
    if (camLandDip > 0.001) {
      camLandDip = THREE.MathUtils.lerp(camLandDip, 0, 1 - Math.exp(-dt * 14));
      eye.add(V(0, -camLandDip, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(-camLandDip * 0.45, 0, 0, 'YXZ')));
    }

    // C. Jetpack Thruster Micro-Rumble
    if (jetActive) {
      const jY = Math.sin(totalTime * 48) * 0.0022;
      const jX = Math.cos(totalTime * 36) * 0.0018;
      const jRoll = Math.sin(totalTime * 55) * 0.0025;
      eye.add(V(jX, jY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, jRoll, 'YXZ')));
    }

    // D. Weapon Reload Kinetic Camera Sway
    if (typeof reloadActive !== 'undefined' && reloadActive) {
      const rp = Math.min(1.0, Math.max(0, (combatTime - reloadStartTime) / reloadDuration));
      let rX = 0, rY = 0, rPitch = 0, rRoll = 0;
      if (rp >= 0.15 && rp < 0.28) {
        // Mag release dip
        const sub = (rp - 0.15) / 0.13;
        rY = -Math.sin(sub * Math.PI) * 0.008;
        rRoll = -Math.sin(sub * Math.PI) * 0.006;
      } else if (rp >= 0.48 && rp < 0.62) {
        // Forceful mag insertion slap
        const sub = (rp - 0.48) / 0.14;
        rY = Math.sin(sub * Math.PI) * 0.012;
        rPitch = Math.sin(sub * Math.PI) * 0.010;
        rRoll = Math.sin(sub * Math.PI) * 0.006;
      } else if (rp >= 0.74 && rp < 0.88) {
        // Slide / bolt rack tug
        const sub = (rp - 0.74) / 0.14;
        rX = -Math.sin(sub * Math.PI) * 0.008;
        rRoll = -Math.sin(sub * Math.PI) * 0.008;
      }
      eye.add(V(rX, rY, 0).applyQuaternion(q));
      q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(rPitch, 0, rRoll, 'YXZ')));
    }

    // E. Melee Attack Kinetic Forward Lunge & Screen Torque
    if (typeof meleeActive !== 'undefined' && meleeActive) {
      const mp = Math.min(1.0, Math.max(0, (combatTime - meleeStartTime) / meleeDuration));
      if (mp >= 0.18 && mp < 0.65) {
        const cut = Math.sin((mp - 0.18) / 0.47 * Math.PI);
        const lungeZ = -0.16 * cut; // explosive forward lunge!
        const lungePitch = -0.045 * cut; // aggressive downward cut angle
        const lungeRoll = (typeof meleeCombo !== 'undefined' && meleeCombo === 0 ? -0.05 : 0.04) * cut;
        eye.add(V(0, 0, lungeZ).applyQuaternion(q));
        q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(lungePitch, 0, lungeRoll, 'YXZ')));
      }
    }
  }
}
up=UP.clone().applyQuaternion(aboard?ship.quaternion:driving?rover.getWorldQuaternion(new THREE.Quaternion()):inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player)));
camera.quaternion.copy(q);camera.position.copy(eye);camera.up.copy(up);
if(thirdPerson){focus=aboard?shipPoint(V(0,2,0)):driving?rover.localToWorld(V(0,1.2,0)):eye.clone().addScaledVector(up,-.2);const offset=V(aboard?0:.7,aboard?13:driving?2.5:.8,aboard?Math.max(40,layout().halfZ*2.7):driving?7:resting?3:4.6).multiplyScalar(cameraZoom[mode]).applyQuaternion(q);camera.position.copy(safeChaseCamera(focus,offset,aboard?ship:driving?rover:null,aboard));camera.lookAt(focus.clone().add(V(0,0,aboard?-100:driving?-25:-40).applyQuaternion(q)));}
if(avatar){avatar.visible=thirdPerson;if(avatarWeapon)avatarWeapon.visible=thirdPerson&&mode==='foot'&&!resting;avatar.scale.setScalar(driving?.8:1);const rig=avatar.userData.rig;rig.rotation.set(0,0,0);if(aboard||driving){avatar.position.copy(aboard?shipPoint(layout().seat.clone().setY(.8)):rover.localToWorld(V(0,.45,.45)));avatar.quaternion.copy(aboard?ship.quaternion:rover.getWorldQuaternion(new THREE.Quaternion()));}else if(resting){avatar.position.copy(shipPoint(resting.avatar));avatar.quaternion.copy(ship.quaternion);rig.rotation.x=resting.kind==='bed'?-Math.PI/2:0;rig.rotation.y=resting.angle||0;}else{avatar.position.copy(eye).addScaledVector(up,-1.8);const base=inside?ship.quaternion:eva?evaFrame:walkFrame(player,groundPlanet||nearest(player));avatar.quaternion.copy(base).multiply(new THREE.Quaternion().setFromAxisAngle(UP,yaw));}animateHuman(rig,dt,aboard||driving||resting?.kind==='bench',!onFootGround&&mode==='foot');}
if(weaponView)weaponView.visible=mode==='foot'&&!thirdPerson&&!resting&&$('panel').classList.contains('hidden');$('jetHud').classList.toggle('hidden',mode!=='foot'||eva);$('jetFill').style.width=(jetFuel/jetCapacity()*100)+'%';$('jetText').textContent='JETPACK '+Math.round(jetFuel/jetCapacity()*100)+'%'+(jetActive?' · IMPULSO':'');}
function equipOutfit(id){if(!ownedOutfits.includes(id))return;outfit=id;makeAvatar();save();renderPanel('inventory');}
function buyV05(id){const s=shops[activeShop],product=products[id];if(!s||!product||!s.def.items.includes(id)||controlledPosition().distanceTo(s.clerk.getWorldPosition(V()))>5)return;if(id.startsWith('outfit_')){const type=id.slice(7);if(ownedOutfits.includes(type)){toast('Você já possui esta roupa.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];ownedOutfits.push(type);outfit=type;makeAvatar();}else if(id==='jet1'||id==='jet2'){const level=Number(id.slice(3));if(jetLevel>=level){toast('Este aprimoramento já está instalado.');return;}if(jetLevel!==level-1){toast('Instale o estágio anterior primeiro.');return;}if(credits<product[1]){toast('Créditos insuficientes.');return;}credits-=product[1];jetLevel=level;jetFuel=jetCapacity();}save();renderPanel('shop');toast('Equipamento atualizado.');}
function initPlayerV05(){try{const s=JSON.parse(localStorage.getItem('horizonte-v1'));if(s?.skyward){const v=s.skyward;if(v.currentSystem){currentSystem.x=v.currentSystem.x||0;currentSystem.y=v.currentSystem.y||0;currentSystem.name=getSystemName(currentSystem.x,currentSystem.y);}jetLevel=[0,1,2].includes(v.jetLevel)?v.jetLevel:0;ownedOutfits=[...new Set(['explorer',...(v.ownedOutfits||[]).filter(x=>outfitColors[x])])];outfit=ownedOutfits.includes(v.outfit)?v.outfit:'explorer';for(const k of Object.keys(locker))locker[k]=Math.max(0,Math.min(9999,Number(v.locker?.[k])||0));}}catch{}jetFuel=jetCapacity();makeAvatar();addEventListener('keydown',e=>{if(e.code==='KeyV'&&!e.repeat&&started&&$('panel').classList.contains('hidden'))toggleCamera();});}

function aimDirection(naval){const dir=V(0,0,-1).applyQuaternion(camera.quaternion);if(!thirdPerson)return dir;const end=camera.position.clone().addScaledVector(dir,naval?2600:300);let distance=Math.min(naval?2600:300,obstacleDistance(camera.position,end,naval?ship:null));for(const e of enemies){if(!e.alive)continue;const hit=segmentHit(camera.position,end,enemyCenter(e),e.flying?7:e.beast?1.4:.85);if(hit!==null)distance=Math.min(distance,hit);}const from=naval?shipPoint(V(0,1.7,-layout().halfZ-1.5)):inside?shipPoint(foot):player;return camera.position.clone().addScaledVector(dir,distance).sub(from).normalize();}

function panelMesh(parent,points,color){const vertices=[],normals=[];for(let i=1;i<points.length-1;i++)for(const k of [0,i,i+1])vertices.push(...points[k]);const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.computeVertexNormals();const m=mat(color);m.side=THREE.DoubleSide;m.metalness=.45;m.roughness=.45;const o=mesh(g,m,parent);o.userData.thinPanel=true;return o;}
function sweptWing(parent,side,z,span,chord,color){const pts=[[side*3,.25,z-chord*.5],[side*span,.2,z+chord*.2],[side*(span-1),.2,z+chord*.6],[side*3,.25,z+chord*.5]];panelMesh(parent,pts,color);panelMesh(parent,pts.map(p=>[p[0],p[1]-.65,p[2]]).reverse(),0x3b515c);for(let i=0;i<4;i++){const a=pts[i],b=pts[(i+1)%4];panelMesh(parent,[a,b,[b[0],b[1]-.65,b[2]],[a[0],a[1]-.65,a[2]]],color);}}



function createLandingGear(parent, x, z, side) {
  const g = new THREE.Group();
  g.position.set(x, -0.22, z);
  parent.add(g);

  // 1. Recessed underbelly bay housing
  const bay = mesh(new THREE.BoxGeometry(1.6, 0.35, 2.2), 0x14181e, g, 0, 0.08, 0);
  bay.userData.noCollision = true;

  // 2. Main Strut Group (lowers and raises)
  const strutGroup = new THREE.Group();
  g.add(strutGroup);

  // Upper outer hydraulic cylinder (titanium gunmetal)
  const upperCyl = mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.90, 12), 0x1a222c, strutGroup, 0, -0.45, 0);
  upperCyl.userData.noCollision = true;

  // Collar reinforcement ring
  mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.16, 12), 0x2d3a48, strutGroup, 0, -0.15, 0);

  // 3. Lower Telescoping Piston (Polished Chrome Steel)
  const pistonGroup = new THREE.Group();
  pistonGroup.position.set(0, -0.85, 0);
  strutGroup.add(pistonGroup);

  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xdde7ee, metalness: 0.92, roughness: 0.12 });
  const piston = mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.90, 12), chromeMat, pistonGroup, 0, -0.45, 0);
  piston.userData.noCollision = true;

  // 4. Articulated Scissor Torque Links
  const scissor1 = mesh(new THREE.BoxGeometry(0.07, 0.50, 0.07), 0x242e3a, strutGroup, side * 0.22, -0.50, 0.14);
  scissor1.userData.noCollision = true;
  const scissor2 = mesh(new THREE.BoxGeometry(0.07, 0.50, 0.07), 0x242e3a, pistonGroup, side * 0.22, -0.22, 0.14);
  scissor2.userData.noCollision = true;

  // 5. Heavy Articulated Magnetic Landing Footpad
  const footPad = new THREE.Group();
  footPad.position.set(0, -0.65, 0);
  pistonGroup.add(footPad);

  // Swivel ball-joint
  mesh(new THREE.SphereGeometry(0.16, 8, 8), 0x303d4a, footPad, 0, 0.08, 0);
  // Wide beveled magnetic pad
  const padMesh = mesh(new THREE.CylinderGeometry(0.62, 0.76, 0.22, 8), 0x14181e, footPad, 0, -0.06, 0);
  padMesh.userData.noCollision = true;
  // Non-skid polymer sole
  const soleMesh = mesh(new THREE.BoxGeometry(1.35, 0.08, 1.85), 0x0c0f13, footPad, 0, -0.18, 0);
  soleMesh.userData.noCollision = true;

  // Status indicator LED (cyan when locked, amber in transit)
  const led = mesh(new THREE.BoxGeometry(0.12, 0.06, 0.12), mat(0x42f5d7, 2.0), footPad, side * 0.45, 0.02, 0);
  led.userData.noCollision = true;

  const gearObj = { g, strutGroup, pistonGroup, footPad, scissor1, scissor2, led, side };
  landingGears.push(gearObj);
  return gearObj;
}

function updateLandingGears(dt) {
  if (!landingGears.length) return;
  const targetProgress = (landed || (landingSequence && landingSequence.active)) ? 1.0 : 0.0;
  const transitSpeed = 1.6; // ~1.6s for full extension or retraction

  if (shipGearProgress < targetProgress) {
    shipGearProgress = Math.min(targetProgress, shipGearProgress + dt * transitSpeed);
  } else if (shipGearProgress > targetProgress) {
    shipGearProgress = Math.max(targetProgress, shipGearProgress - dt * transitSpeed);
  }

  const gp = THREE.MathUtils.smoothstep(shipGearProgress, 0, 1);

  if (shipGearSuspension > 0.001) {
    shipGearSuspension = THREE.MathUtils.lerp(shipGearSuspension, 0, 1 - Math.exp(-dt * 12));
  }

  for (const gear of landingGears) {
    // Retracts up into bay and folds scissor arms
    gear.strutGroup.position.y = THREE.MathUtils.lerp(0.65, 0.0, gp);
    gear.pistonGroup.position.y = THREE.MathUtils.lerp(-0.10, -0.85 + shipGearSuspension * 0.16, gp);
    gear.scissor1.rotation.x = THREE.MathUtils.lerp(1.2, 0.50, gp);
    gear.scissor2.rotation.x = THREE.MathUtils.lerp(-1.2, -0.50, gp);
    gear.footPad.visible = gp > 0.05;
    gear.strutGroup.scale.set(gp > 0.05 ? 1 : 0.01, Math.max(0.01, gp), gp > 0.05 ? 1 : 0.01);

    if (gear.led && gear.led.material) {
      if (gp >= 0.98) {
        gear.led.material.color.setHex(0x42f5d7); // Ready / locked
      } else if (gp <= 0.02) {
        gear.led.material.color.setHex(0x0a1015); // Off
      } else {
        gear.led.material.color.setHex(0xffa533); // Transit amber
      }
    }
  }
}

function aeroHull(){const l=layout(),h=l.halfX,z=l.halfZ,col=shipTypes[shipType].color,glass=new THREE.MeshStandardMaterial({color:0x9fcbd7,transparent:true,opacity:.22,roughness:.12,metalness:.2,side:THREE.DoubleSide});box(ship,0,0,0,h*2,.5,z*2,0x405866);const rows=shipType===0?[[-z-10,.8,1.0],[-z-5,h*.7,3],[-z,h,5.3],[-z*.55,h+3,6],[-1,h+10,6.4],[z*.45,h+17,5.8],[z-3,h+7,5.3],[z,h,4.95]]:shipType===1?[[-z-13,.3,.8],[-z-6,h*.65,2.5],[-z,h,5.4],[-z*.45,h+16,5.8],[0,h+3,5.5],[3,h,5.3],[8,h,5.3],[z,h,4.95]]:[[-z,h,5.2],[-z*.4,h+6,6.8],[0,h+10,7],[z*.5,h+7,6.2],[z,h,4.95]];
function ring(row){const [zz,w,t]=row;return [[-w,-.22,zz],[-w,.9,zz],[-Math.min(w,h),t-.45,zz],[-Math.min(w*.65,h*.8),t,zz],[Math.min(w*.65,h*.8),t,zz],[Math.min(w,h),t-.45,zz],[w,.9,zz],[w,-.22,zz]];}
for(let j=0;j<rows.length-1;j++){const a=ring(rows[j]),b=ring(rows[j+1]);for(let k=0;k<8;k++){if(shipType===1&&(k===0||k===1)&&rows[j][0]>=0&&rows[j+1][0]<=8)continue;const next=(k+1)%8,points=[a[k],a[next],b[next],b[k]];
    // Elegant black accents on dorsal spine, fuselage ridges, and underbelly
    const panelColor = (k === 7) ? 0x16202c : col;
    const o = (shipType!==2&&j===2&&(k===1||k===5))?hullWindow(ship,points,col):panelMesh(ship,points,panelColor);
    if(j<2&&(k===2||k===3||k===4)||shipType!==2&&j===0&&k===7){o.material=glass.clone();o.material.opacity=.055;o.material.depthWrite=false;o.userData.viewport=true;}
    o.userData.hullLoft=true;}}
if(shipType===0){for(const side of [-1,1])panelMesh(ship,[[side*l.doorHalf,0,z],[side*h,0,z],[side*h,4.95,z],[side*l.doorHalf,4.95,z]],col);}else panelMesh(ship,[[-h,0,z],[h,0,z],[h,4.95,z],[-h,4.95,z]],col);
if(shipType===2){for(const range of [[-h,-8],[-2,h]]){box(ship,(range[0]+range[1])/2,2.4,-z,range[1]-range[0],4.8,.14,glass);}}
for(const side of [-1,1]){const ex=side*(h*.67),ez=z-2;
  // Elegant black intake nacelles and cyan glow rings
  const intake=mesh(new THREE.CylinderGeometry(.85,1.25,4,16),0x14181e,ship,ex,3.3,ez);
  intake.rotation.x=Math.PI/2;
  mesh(new THREE.TorusGeometry(.85,.12,8,20),mat(0x83dfff,1.8),ship,ex,3.3,ez+2);
  // Elegant black wing strakes
  if(shipType!==1){panelMesh(ship,[[side*(h+3),2,z-8],[side*(h+6),8,z-1],[side*(h+6),7,z+3],[side*(h+2),2,z]], 0x14181e);}
  // High-detail articulated landing gears on all 4 corners
  for(const zz of [-z+3,z-3]){ createLandingGear(ship, side*(h-1), zz, side); }}
ship.userData.silhouette=['asa integrada cargueira','asa voadora furtiva','corpo duplo industrial'][shipType];}

function hullWindow(parent,points,color){const g=new THREE.Group();parent.add(g);const p=points.map(p=>V(...p)),at=(u,v)=>p[0].clone().lerp(p[1],u).lerp(p[3].clone().lerp(p[2],u),v).toArray(),cuts=[0,.12,.88,1];for(let x=0;x<3;x++)for(let y=0;y<3;y++){const o=panelMesh(g,[at(cuts[x],cuts[y]),at(cuts[x+1],cuts[y]),at(cuts[x+1],cuts[y+1]),at(cuts[x],cuts[y+1])],color);if(x===1&&y===1){o.material=new THREE.MeshStandardMaterial({color:0xb5e2e7,transparent:true,opacity:.055,depthWrite:false,roughness:.08,metalness:.05,side:THREE.DoubleSide});o.userData.viewport=true;o.castShadow=false;}}return g;}

function cabinBox(x,y,z,w,h,d,c){const o=box(ship,x,y,z,w,h,d,c);o.userData.interior=true;return o;}
function roomDeck(x,z,w,d,c=0x455a63){cabinBox(x,.29,z,w,.075,d,c);cabinBox(x,3.85,z,w,.13,d,0x263c48);for(const side of [-1,1]){const strip=cabinBox(x+side*(w/2-.12),3.75,z,.055,.06,Math.max(.4,d-.4),mat(0xb4dcdd,.9));strip.userData.noCollision=true;}}
function passage(x,z,width,extent,axis,label){const root=new THREE.Group();root.position.set(x,0,z);root.rotation.y=axis==='x'?Math.PI/2:0;ship.add(root);const wall=0x455c68,gap=width/2,half=extent/2,height=3.6;for(const side of [-1,1]){const w=half-gap;if(w>0)box(root,side*(gap+w/2),height/2+.25,0,w,height,.18,wall);box(root,side*(gap+.065),1.85,-.02,.13,3.2,.25,0x7b939c);}box(root,0,3.56,0,width,.28,.22,0x607986);const leaf=new THREE.Group();leaf.position.y=1.85;root.add(leaf);for(const side of [-1,1]){const part=box(leaf,side*width/4,0,0,width/2-.045,3.08,.12,0x758991);part.userData.doorSide=side;const seam=box(part,side*width*.12,0,-.075,.03,2.5,.014,mat(0x8ad1d0,.5));seam.userData.noCollision=true;}const point=V(x,1.7,z),normal=axis==='x'?V(1,0,0):V(0,0,1);shipInteractables.push({kind:'door',o:leaf,root,point,normal,half:gap,open:false,progress:0,label:'Porta · '+label});return root;}
function consoleDesk(x,z,w=1.65){cabinBox(x,.82,z,w,1,.55,0x314751);const top=cabinBox(x,1.36,z,w+.08,.08,.7,0x617b85);const screen=cabinBox(x,1.54,z-.13,w*.7,.25,.055,mat(0x65bac6,.65));screen.rotation.x=-.25;for(const dx of [-.4,0,.4]){const b=cabinBox(x+dx,1.42,z+.15,.06,.025,.06,0xadc6b7);b.userData.noCollision=true;}}
function storageRack(x,z,w=1.1,d=1.5){cabinBox(x,1.52,z,w,2.4,d,0x334c59);for(let j=0;j<3;j++){cabinBox(x, .66+j*.68,z,w+.05,.07,d+.08,0x78929b);cabinBox(x, .94+j*.68,z+.1,w*.73,.48,d*.65,j%2?0x8c9b90:0x768999);} }
function galley(x,z){cabinBox(x,.9,z,1.2,1.25,3,0x647d85);cabinBox(x,1.57,z,1.25,.08,3.05,0xa3b4b2);cabinBox(x,2.6,z,1.18,.75,2.8,0x4a6370);const sink=cabinBox(x,1.63,z-.7,.68,.03,.75,0x1b343f);bone(ship,V(x+.3,1.64,z-.7),V(x+.3,1.99,z-.7),.035,0x97b4bf);}
function makeShipRooms(){const l=layout(),h=l.halfX,z=l.halfZ;
// Service spaces against opaque sidewalls conceal the wing tanks; windows occur only at the exterior canopy.
for(const side of [-1,1]){for(let zz=-z+5;zz<z;zz+=5){if(shipType===1&&side<0&&zz>-1&&zz<9||shipType!==2&&zz<(shipType===0?-7:-4))continue;cabinBox(side*(h-.11),1.97,zz,.18,3.3,Math.min(5,z-zz+2.5),0x405965);}}
if(shipType===0){roomDeck(0,-3.5,13.6,6.65);roomDeck(0,5,13.6,9.6,0x384f59);roomDeck(0,12.5,13.6,4.6,0x465a60);passage(0,-7,2,14,'z','ponte');passage(0,0,2.2,14,'z','garagem');passage(0,10,8.5,14,'z','câmara de carga');passage(-1.7,-3.5,1.9,6.8,'x','cabine de descanso');passage(1.7,-3.5,1.9,6.8,'x','refeitório');addFurniture('bed',V(-5,.32,-3.7));storageRack(-2.55,-6,1.2,.8);addFurniture('locker',V(-5.75,.3,-.9));galley(5.9,-3.5);addFurniture('bench',V(3.15,.3,-5.7));cabinBox(3.9,1.02,-4.4,1.6,.12,.8,0x91a7a5);storageRack(5.9,2,1.3,2);storageRack(5.9,7.5,1.3,2.5);consoleDesk(-5.65,3,1.6);addFurniture('locker',V(-5.7,.3,7.6));for(const xx of [-3.5,3.5])cabinBox(xx,.34,5.1,.07,.01,8.8,mat(0xc1b384,.15));}
else if(shipType===1){roomDeck(0,-2,10.65,3.7);roomDeck(0,3.5,10.65,6.6,0x3c535c);roomDeck(0,9.1,10.65,3.6);passage(0,-4,1.9,11,'z','ponte');passage(0,0,2.1,11,'z','laboratório');passage(2.8,7.1,1.9,11,'z','habitação');passage(0,9.1,1.6,3.7,'x','dormitório');addFurniture('bed',V(-3,.3,9.1));addFurniture('locker',V(-.9,.3,9.15));galley(4.7,9.1);consoleDesk(-3.8,-2,2);consoleDesk(3.8,-2,2);cabinBox(3.8,2.55,-2,1.7,.7,.55,0x597780);storageRack(4.7,3.5,1,2.8);for(const zz of [1,6.5])cabinBox(-2.9,.34,zz,3.5,.01,.06,mat(0xb2cebb,.15));}
else{roomDeck(-5,-3,9.65,13.6,0x394e58);roomDeck(-5,7,9.65,5.6);roomDeck(5,-2,9.6,3.7);roomDeck(5,2,9.6,3.6);roomDeck(5,7,9.6,5.6);passage(0,2,2,16,'x','oficina');cabinBox(0,2.05,-8,.18,3.6,4);passage(5,-4,2,10,'z','ponte');passage(5,4,2,10,'z','habitação');passage(-5,4,2,10,'z','engenharia');consoleDesk(8.55,0,1.7);storageRack(1.1,-2,1.2,1.5);addFurniture('bed',V(2.6,.3,7));addFurniture('locker',V(8.7,.3,5.5));galley(8.8,8);addFurniture('bench',V(5.7,.3,8.3));storageRack(-8.7,6.5,1.4,3.5);consoleDesk(-3.1,7,2);addFurniture('locker',V(-1.2,.3,6.3));}
// Compact flight station: low side consoles and clear glazing ahead and below the pilot.
const cx=l.cockpit.x,seatZ=l.seat.z,front=l.cockpit.z-1;box(ship,cx,.24,(seatZ+1.2+front)/2,3.4,.17,seatZ+1.2-front,0x425d69);for(const side of [-1,1]){const desk=cabinBox(cx+side*1.2,.73,seatZ-.5,.55,.75,1.7,0x425967);const screen=cabinBox(cx+side*1.1,1.26,seatZ-.85,.45,.24,.5,mat(0x64bdc9,.55));screen.rotation.z=side*.28;bone(ship,V(cx+side*.6,.7,seatZ-.55),V(cx+side*.6,1.08,seatZ-.62),.045,0x9cb0b7);}makeSeat(ship,cx,0,seatZ+.35,0x3c525d);const bridgeBack=shipType===0?-7:shipType===1?-4:-4,bridgeStart=shipType===2?-10:-l.halfZ;box(ship,shipType===2?5:0,.28,(bridgeStart+bridgeBack)/2,shipType===2?9.6:2*h-.4,.07,bridgeBack-bridgeStart,0x435a65);if(shipType!==2)box(ship,0,.25,(-l.halfZ+front)/2,3.4,.16,-l.halfZ-front,0x435a65);for(const side of [-1,1])consoleDesk(cx+side*(shipType===2?2.4:3.1),bridgeBack-1.5,1.3);}

// === PHYSICAL 3D COCKPIT CONSOLE & BUTTONS ===

function makeCockpitButtonTexture(label, sub, colorHex) {
  const c = document.createElement('canvas');
  c.width = 128; c.height = 80;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#06131c';
  ctx.fillRect(0, 0, 128, 80);
  ctx.strokeStyle = colorHex;
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 122, 74);
  ctx.fillStyle = '#edf7fa';
  ctx.font = 'bold 22px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 64, 30);
  ctx.fillStyle = colorHex;
  ctx.font = '13px Arial, sans-serif';
  ctx.fillText(sub, 64, 56);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function makeMfdTelemetryTexture(type) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 180;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#061017';
  ctx.fillRect(0, 0, 256, 180);

  if (type === 'brake') {
    // Left MFD: Power / Propulsion telemetry (Amber Drake Cutter style)
    ctx.strokeStyle = '#e0882e'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#e0882e';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('PWR MGMT // DRAKE CUTTER', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Vertical power bars
    for (let i = 0; i < 4; i++) {
      const bx = 26 + i * 54;
      ctx.strokeRect(bx, 44, 38, 90);
      const h = [65, 80, 50, 75][i];
      ctx.fillRect(bx + 4, 44 + (90 - h), 30, h);
      ctx.font = '10px Courier, monospace';
      ctx.fillText(['THR', 'SHD', 'ENG', 'BRK'][i], bx + 6, 150);
    }
    ctx.fillStyle = '#ffbe6b';
    ctx.font = '11px Courier, monospace';
    ctx.fillText('OUTPUT: 100% · REVERSE READY', 14, 168);
  } else if (type === 'map') {
    // Center MFD: Radar Scanner (Star Citizen circular radar grid)
    ctx.strokeStyle = '#429e84'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    const cx = 128, cy = 94;
    // Concentric range rings
    for (const r of [25, 48, 70]) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    // Crosshair axes
    ctx.beginPath();
    ctx.moveTo(cx - 72, cy); ctx.lineTo(cx + 72, cy);
    ctx.moveTo(cx, cy - 72); ctx.lineTo(cx, cy + 72);
    ctx.stroke();
    // Heading ticks
    ctx.fillStyle = '#61d9b8';
    ctx.font = '10px Courier, monospace';
    ctx.fillText('000°', cx - 12, cy - 74);
    ctx.fillText('090°', cx + 76, cy + 4);
    ctx.fillText('180°', cx - 12, cy + 82);
    ctx.fillText('270°', cx - 100, cy + 4);
    // Target pings
    ctx.fillStyle = '#ffcf52';
    ctx.beginPath(); ctx.arc(cx + 28, cy - 32, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx - 38, cy + 18, 3, 0, Math.PI * 2); ctx.fill();
  } else if (type === 'land') {
    // Right MFD: Flight Systems & Landing gear status (Cyan/Green avionics)
    ctx.strokeStyle = '#4db8c7'; ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 248, 172);
    ctx.fillStyle = '#4db8c7';
    ctx.font = 'bold 13px Courier, monospace';
    ctx.fillText('FLIGHT CONFIG // SENSORS', 14, 24);
    ctx.fillRect(14, 32, 228, 2);
    // Systems checklist
    const items = ['GEAR DEPLOYMENT', 'APPROACH RADAR', 'DECK COUPLER', 'TERRAIN SCAN'];
    for (let i = 0; i < items.length; i++) {
      const y = 52 + i * 26;
      ctx.strokeRect(20, y, 14, 14);
      ctx.fillRect(23, y + 3, 8, 8);
      ctx.font = '11px Courier, monospace';
      ctx.fillText(items[i], 44, y + 12);
      ctx.fillText('OK', 210, y + 12);
    }
    ctx.font = '11px Courier, monospace';
    ctx.fillText('RADAR ALT: 90M · PAD AUTO-LOCK', 14, 168);
  } else if (type === 'ramp' || type === 'camera') {
    // Physical console pushbuttons
    ctx.strokeStyle = '#5a7888'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = type === 'ramp' ? '#18423d' : '#1b324d';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = type === 'ramp' ? '#7ee2c8' : '#8ac8ff';
    ctx.font = 'bold 26px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(type === 'ramp' ? 'RAMP' : 'CAM', 128, 80);
    ctx.font = '14px Courier, monospace';
    ctx.fillText(type === 'ramp' ? '[HATCH CTRL]' : '[EXT VIEW]', 128, 120);
  } else if (type === 'stand') {
    // Seat release control
    ctx.strokeStyle = '#7a6642'; ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 250, 174);
    ctx.fillStyle = '#2d2416';
    ctx.fillRect(6, 6, 244, 168);
    ctx.fillStyle = '#f0b85d';
    ctx.font = 'bold 24px Courier, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SEAT', 128, 75);
    ctx.font = '14px Courier, monospace';
    ctx.fillText('[STAND UP]', 128, 115);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function buildCockpit3DConsole(shipGroup) {
  cockpit3DButtons.length = 0;
  const l = layout();
  const seat = l.seat;

  // Authentic Drake Cutter cockpit console structure directly in front and below pilot
  const dashRoot = new THREE.Group();
  dashRoot.name = 'cockpitConsole';
  dashRoot.userData.dynamic = true; // Retain matrix updates
  dashRoot.position.set(seat.x, seat.y - 0.18, seat.z - 1.15);
  dashRoot.rotation.x = -0.32; // Angled 18° up toward pilot's eyes
  shipGroup.add(dashRoot);

  // Main angled dashboard backplate (slender 0.04m plate behind screens)
  box(dashRoot, 0, 0.02, -0.02, 1.86, 0.44, 0.04, 0x162028);

  // Recessed dark bezels framing each MFD screen
  box(dashRoot, -0.58, 0.02, 0.005, 0.54, 0.36, 0.015, 0x0a1015);
  box(dashRoot, 0, 0.02, 0.005, 0.48, 0.36, 0.015, 0x0a1015);
  box(dashRoot, 0.58, 0.02, 0.005, 0.54, 0.36, 0.015, 0x0a1015);

  // Upper sunshield / visor brow (positioned cleanly ABOVE screens, cannot block view)
  box(dashRoot, 0, 0.25, 0.04, 1.90, 0.04, 0.14, 0x22303a);

  // Lower support pedestal: recessed far under and behind (Z = -0.16), NEVER blocking the screens
  box(dashRoot, 0, -0.38, -0.16, 0.70, 0.36, 0.16, 0x11171d);

  // 1. Left MFD: Power & Propulsion (Drake Cutter Amber Telemetry)
  const leftMfdTex = makeMfdTelemetryTexture('brake');
  const leftMfd = mesh(new THREE.BoxGeometry(0.50, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: leftMfdTex, emissiveMap: leftMfdTex, emissive: 0xff9d3b, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, -0.58, 0.02, 0.02);
  leftMfd.userData = { isCockpitButton: true, action: 'brake', label: 'PROPULSÃO: FREAR [CLIQUE]', execute: () => executeCockpitAction('brake') };
  cockpit3DButtons.push(leftMfd);

  // 2. Center MFD: Circular Radar / Navigation Scanner
  const centerMfdTex = makeMfdTelemetryTexture('map');
  const centerMfd = mesh(new THREE.BoxGeometry(0.44, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: centerMfdTex, emissiveMap: centerMfdTex, emissive: 0x5df5b8, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, 0, 0.02, 0.02);
  centerMfd.userData = { isCockpitButton: true, action: 'map', label: 'RADAR: MAPA DA GALÁXIA [CLIQUE]', execute: () => executeCockpitAction('map') };
  cockpit3DButtons.push(centerMfd);

  // 3. Right MFD: Flight Systems & Landing Status
  const rightMfdTex = makeMfdTelemetryTexture('land');
  const rightMfd = mesh(new THREE.BoxGeometry(0.50, 0.32, 0.02), new THREE.MeshStandardMaterial({
    map: rightMfdTex, emissiveMap: rightMfdTex, emissive: 0x62dbd6, emissiveIntensity: 0.65, roughness: 0.35
  }), dashRoot, 0.58, 0.02, 0.02);
  rightMfd.userData = { isCockpitButton: true, action: 'land', label: 'POUSO: TRAVA DE SOLO [CLIQUE / R]', execute: () => executeCockpitAction('land') };
  cockpit3DButtons.push(rightMfd);

  // Center-Top Pushbutton Module (mounted cleanly above center MFD)
  const topModule = new THREE.Group();
  topModule.position.set(0, 0.28, 0.04);
  dashRoot.add(topModule);
  box(topModule, 0, 0, 0, 0.42, 0.08, 0.12, 0x1f2b34);

  // Button 4: RAMPA (backlit aviation toggle)
  const rampTex = makeMfdTelemetryTexture('ramp');
  const rampBtn = mesh(new THREE.BoxGeometry(0.16, 0.07, 0.03), new THREE.MeshStandardMaterial({
    map: rampTex, emissiveMap: rampTex, emissive: 0x7ee2c8, emissiveIntensity: 0.75, roughness: 0.3
  }), topModule, -0.09, 0, 0.06);
  rampBtn.userData = { isCockpitButton: true, action: 'ramp', label: 'ESCOTILHA: ACIONAR RAMPA [CLIQUE]', execute: () => executeCockpitAction('ramp') };
  cockpit3DButtons.push(rampBtn);

  // Button 5: CÂMERA EXTERNA (backlit aviation toggle)
  const camTex = makeMfdTelemetryTexture('camera');
  const camBtn = mesh(new THREE.BoxGeometry(0.16, 0.07, 0.03), new THREE.MeshStandardMaterial({
    map: camTex, emissiveMap: camTex, emissive: 0x8ac8ff, emissiveIntensity: 0.75, roughness: 0.3
  }), topModule, 0.09, 0, 0.06);
  camBtn.userData = { isCockpitButton: true, action: 'camera', label: 'SISTEMA ÓPTICO: VISÃO EXTERNA [CLIQUE]', execute: () => executeCockpitAction('camera') };
  cockpit3DButtons.push(camBtn);

  // The stand-up button was removed as requested (players press 'E' on PC or 2-finger swipe on mobile).
}

function executeCockpitAction(action) {
  if (audioContext && !audioMuted) {
    tone(780, audioContext.currentTime, 0.05, 0.12, fxBus, 'sine');
  }
  if (action === 'land') {
    if (landed) toast('A nave já está pousada.');
    else land();
  } else if (action === 'brake') {
    brakeShip();
  } else if (action === 'ramp') {
    toggleRamp();
  } else if (action === 'stand') {
    if (mode === 'pilot') {
      mode = 'foot';
      inside = true;
      resetFootMotion();
      foot.copy(layout().seat).add(V(0, .08, 1.8));
      yaw = 0; pitch = 0;
      toast('Você levantou do assento. B perto da entrada para desembarcar.');
    }
  } else if (action === 'map') {
    menu('map');
  } else if (action === 'camera') {
    toggleCamera();
  }
}

function findCockpitButtonAt(clientX, clientY) {
  if (mode !== 'pilot' || !inside || cockpit3DButtons.length === 0) return null;
  camera.updateMatrixWorld(true);
  ship.updateMatrixWorld(true);
  const ray = new THREE.Raycaster();
  if (document.pointerLockElement === renderer.domElement || clientX === undefined || clientY === undefined) {
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    ray.set(camera.position, dir);
  } else {
    const ndc = new THREE.Vector2(
      (clientX / window.innerWidth) * 2 - 1,
      -(clientY / window.innerHeight) * 2 + 1
    );
    ray.setFromCamera(ndc, camera);
  }
  const hits = ray.intersectObjects(cockpit3DButtons, true);
  if (hits.length > 0 && hits[0].distance < 3.8) {
    let obj = hits[0].object;
    while (obj && !obj.userData?.isCockpitButton && obj.parent) obj = obj.parent;
    if (obj?.userData?.isCockpitButton) return obj;
  }
  return null;
}

function updateCockpitRaycast() {
  if (mode !== 'pilot' || !inside || cockpit3DButtons.length === 0) {
    if (targetedCockpitButton) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
      targetedCockpitButton = null;
    }
    const infoEl = $('cockpitTargetInfo');
    if (infoEl) infoEl.classList.add('hidden');
    return;
  }

  const hitObj = findCockpitButtonAt();
  const infoEl = $('cockpitTargetInfo');
  if (hitObj) {
    if (targetedCockpitButton && targetedCockpitButton !== hitObj) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
    }
    targetedCockpitButton = hitObj;
    hitObj.material.emissiveIntensity = 1.45;
    if (infoEl) {
      infoEl.textContent = hitObj.userData.label || 'INTERAGIR';
      infoEl.classList.remove('hidden');
    }
  } else {
    if (targetedCockpitButton) {
      targetedCockpitButton.material.emissiveIntensity = 0.65;
      targetedCockpitButton = null;
    }
    if (infoEl) infoEl.classList.add('hidden');
  }
}
window.updateCockpitRaycast = updateCockpitRaycast;
window.findCockpitButtonAt = findCockpitButtonAt;

function cabinLights() {
  const l = layout();
  // Cockpit instrument and console light (cozy, warm sci-fi cockpit)
  const cockLight = new THREE.PointLight(0xbde8ff, 2.2, 14, 1.2);
  cockLight.position.copy(l.cockpit).add(V(0, 0.7, 0.6));
  cockLight.name = 'cockpitLight';
  ship.add(cockLight);

  // Pilot seat light
  const seatLight = new THREE.PointLight(0xffedd5, 1.6, 9, 1.2);
  seatLight.position.copy(l.seat).add(V(0, 1.3, 0));
  ship.add(seatLight);

  // Cabin interior ceiling lights across the length
  const zs = [-l.halfZ * 0.65, -l.halfZ * 0.2, l.halfZ * 0.3, l.halfZ * 0.75];
  for (const z of zs) {
    const light = new THREE.PointLight(0xdcf0ff, 3.2, 16, 1.2);
    light.position.set(shipType === 2 ? 3 : 0, 2.85, z);
    light.name = 'cabinLight';
    ship.add(light);
  }

  // Ship interior soft ambient fill
  const cabinAmb = new THREE.PointLight(0x5a7895, 1.2, 28, 1.2);
  cabinAmb.position.set(0, 2.7, 0);
  ship.add(cabinAmb);

  // Ship exterior hull soft fill: subtle, non-glowing starlight bounce
  const hullFill = new THREE.PointLight(0x5a7895, 0.85, 30, 1.5);
  hullFill.position.set(0, 4.5, -2);
  hullFill.name = 'hullFill';
  ship.add(hullFill);

  // Forward dual headlights (clean, crisp beams)
  const hlL = new THREE.SpotLight(0xe8f4ff, 2.2, 350, Math.PI / 4.8, 0.35, 1.2);
  hlL.position.set(-l.halfX * 0.45, 1.2, -l.halfZ - 5);
  hlL.target.position.set(-l.halfX * 0.45, 1.2, -l.halfZ - 80);
  ship.add(hlL); ship.add(hlL.target);

  const hlR = new THREE.SpotLight(0xe8f4ff, 2.2, 350, Math.PI / 4.8, 0.35, 1.2);
  hlR.position.set(l.halfX * 0.45, 1.2, -l.halfZ - 5);
  hlR.target.position.set(l.halfX * 0.45, 1.2, -l.halfZ - 80);
  ship.add(hlR); ship.add(hlR.target);

  // Exterior navigational beacons (wingtip red/green)
  box(ship, -l.halfX - 0.5, 1.4, -l.halfZ * 0.2, 0.4, 0.4, 0.4, mat(0xff3333, 4.0));
  box(ship, l.halfX + 0.5, 1.4, -l.halfZ * 0.2, 0.4, 0.4, 0.4, mat(0x33ff66, 4.0));
}
function gateSwitches(){const l=layout(),tangent=V().crossVectors(UP,l.normal),base=l.entry.clone().addScaledVector(tangent,l.doorHalf+.45).setY(1.45);for(const outside of [false,true]){const point=base.clone().addScaledVector(l.normal,outside?.32:-.32),g=new THREE.Group();g.position.copy(point);g.quaternion.setFromUnitVectors(V(0,0,1),l.normal.clone().multiplyScalar(outside?1:-1));ship.add(g);box(g,0,0,0,.28,.4,.08,0x263d4b);const light=box(g,0,0,.05,.17,.24,.02,mat(0x8dccb0,.7));shipInteractables.push({kind:'gate',o:g,light,point,outside,label:'Acionar portão'});} }
function switchCandidate(){if(mode!=='foot')return null;const pos=inside?foot:localPoint(player);return shipInteractables.filter(i=>(i.kind==='gate'?i.outside===!inside:inside)&&pos.distanceTo(i.point)<(i.kind==='gate'?2.2:2.5)).sort((a,b)=>pos.distanceTo(a.point)-pos.distanceTo(b.point))[0]||null;}
function doorwayOccupied(item){const l=layout(),point=item?.point||l.entry,normal=item?.normal||l.normal,half=item?.half||l.doorHalf,local=mode==='rover'?localPoint(rover.getWorldPosition(V())):inside?foot:localPoint(player),d=local.clone().sub(point),t=V().crossVectors(UP,normal);return Math.abs(d.dot(normal))<.7&&Math.abs(d.dot(t))<half+.4&&local.y<3.5;}
function useShipInterior(){if(resting){standUp();return true;}const found=switchCandidate();if(!found)return false;if(found.kind==='gate'){if(!rampOpen||!doorwayOccupied())openRamp(!rampOpen,false);else toast('Entrada ocupada. Afaste-se para fechar o portão.');return true;}if(found.kind==='door'){if(found.open&&doorwayOccupied(found)){toast('Passagem ocupada. Afaste-se para fechar.');return true;}found.open=!found.open;toast(found.open?'Abrindo passagem.':'Fechando passagem.');}else if(found.kind==='locker'){activeLocker=found;menu('locker');}else{resting={kind:found.kind,returnPoint:foot.clone(),point:found.point.clone().add(V(0,found.kind==='bed'?.15:.35,0)),avatar:found.o.position.clone().add(V(0,found.kind==='bed'?1.25:.6,found.kind==='bed'?1:0))};yaw=0;pitch=found.kind==='bed'?.45:0;toast(found.kind==='bed'?'Deitado. E ou pulo para levantar.':'Sentado. E ou pulo para levantar.');}return true;}
function openRamp(open=true,immediate=true){rampOpen=open;const door=ship.getObjectByName('door');door.userData.target=open?1:0;if(immediate)door.userData.progress=door.userData.target;updateGateGeometry(0);}
function updateGateGeometry(dt){const door=ship.getObjectByName('door'),ramp=ship.getObjectByName('ramp');if(!door||!ramp)return;let t=door.userData.progress??1,target=door.userData.target??(rampOpen?1:0);t=THREE.MathUtils.clamp(t+Math.sign(target-t)*Math.min(Math.abs(target-t),dt*1.6),0,1);door.userData.progress=t;door.position.y=2.4+t*2.3;door.scale.y=Math.max(.001,1-t);door.visible=t<.995;door.userData.removed=t>.995;ramp.visible=t>.01;ramp.userData.removed=t<.01;ramp.quaternion.setFromAxisAngle(UP,Math.atan2(layout().normal.x,layout().normal.z)).multiply(new THREE.Quaternion().setFromAxisAngle(V(1,0,0),(1-t)*-Math.PI/2));ramp.traverse(o=>o.userData.removed=t<.01);for(const i of shipInteractables)if(i.kind==='gate'){i.light.material.color.set(rampOpen?0x8dccb0:0xd6a168);i.light.material.emissive.copy(i.light.material.color);}}
function tickInteriors(dt,paused){if(!paused){updateGateGeometry(dt);for(const d of shipInteractables)if(d.kind==='door'){const target=d.open?1:0;d.progress=THREE.MathUtils.clamp(d.progress+Math.sign(target-d.progress)*Math.min(Math.abs(target-d.progress),dt*2),0,1);for(const part of d.o.children)part.position.x=part.userData.doorSide*d.half*(.5+d.progress);d.o.visible=d.progress<.995;d.o.traverse(o=>o.userData.removed=d.progress>.995);}}const i=switchCandidate();$('interiorPrompt').textContent=mode==='foot'&&inside&&!resting&&foot.distanceTo(layout().seat)<2.6?(touchEnabled?'DUPLO TOQUE':'E')+' · ASSUMIR CONTROLE':resting?'INTERAGIR · LEVANTAR':i?(touchEnabled?'DUPLO TOQUE':'E')+' · '+(i.kind==='gate'?(rampOpen?'FECHAR PORTÃO':'ABRIR PORTÃO'):i.label.toUpperCase()):'';}

function buildShip(){landingGears.length=0;landingSequence=null;shipGearProgress=1.0;shipGearSuspension=0;shipTiltPitch=shipTiltRoll=shipTiltYaw=0;while(ship.children.length){const old=ship.children[0];ship.remove(old);if(old!==rover)old.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.map?.dispose();o.material.dispose();}});}shipInteractables.length=0;resting=null;const l=layout(),t=shipTypes[shipType],h=l.halfX,z=l.halfZ,metal=0x637c8b,glass=new THREE.MeshStandardMaterial({color:0x99d2de,transparent:true,opacity:.15,metalness:.1,roughness:.12,side:THREE.DoubleSide});rampOpen=true;
aeroHull();
const ramp=new THREE.Group();ramp.position.copy(l.entry);ramp.rotation.y=Math.atan2(l.normal.x,l.normal.z);ramp.name='ramp';ship.add(ramp);const deck=box(ramp,0,-.45,3.4,l.doorHalf*2,.28,7.2,0x809699);deck.rotation.x=.20;for(const x of [-l.doorHalf+.2,l.doorHalf-.2])box(ramp,x,.03,3.1,.1,.1,6,mat(0xa4e3cb,.8));const door=box(ship,l.entry.x,2.4,l.entry.z,l.normal.x?.32:l.doorHalf*2,4.6,l.normal.x?l.doorHalf*2:.32,t.color);door.name='door';door.visible=false;door.userData.removed=true;
makeShipRooms();gateSwitches();cabinLights();buildCockpit3DConsole(ship);optimizeShipDraws();
ship.add(rover);rover.position.copy(l.rover);rover.rotation.set(0,l.roverYaw,0);ship.traverse(o=>{if(o.isMesh){o.castShadow=!o.material.transparent;o.receiveShadow=true;}});if(collisionReady)refreshMovingBodies();}
function makeSeat(root,x,y,z,c){box(root,x,y+.55,z,1.2,.5,1.3,c);const back=box(root,x,y+1.15,z+.55,1.2,1.3,.23,c);back.rotation.x=.1;for(const side of [-1,1])box(root,x+side*.7,y+.9,z,.15,.15,.9,0x657c89);}
function bulkhead(z,x,w,doorX,label){const gap=2.8,min=x-w/2,max=x+w/2,left=doorX-gap/2,right=doorX+gap/2;if(left>min)box(ship,(min+left)/2,2.5,z,left-min,4.8,.25,0x5b747f);if(max>right)box(ship,(max+right)/2,2.5,z,max-right,4.8,.25,0x5b747f);box(ship,doorX,4.4,z,gap,1,.28,0x637e88);const o=box(ship,doorX,2,z,gap,3.8,.18,0x809798);o.visible=false;o.userData.removed=true;shipInteractables.push({kind:'door',o,point:V(doorX,1.8,z),open:true,label});label3D(ship,label,doorX,4.3,z+.2,4);}

function addFurniture(kind,pos){const g=new THREE.Group();g.position.copy(pos);ship.add(g);if(kind==='bed'){box(g,0,.4,0,1.8,.6,3.3,0x536b79);box(g,0,.78,0,1.7,.18,3.1,0xaabcb9);box(g,0,.97,-1,1.2,.18,.65,0xd1d9ce);box(g,0,.92,.5,1.72,.10,1.9,0x729999);}else if(kind==='bench'){makeSeat(g,0,0,0,0x78999f);}else{box(g,0,1.4,0,1.2,2.8,2,0x7a909b);box(g,.65,1.5,0,.12,2.4,1.8,0x9daeb0);}shipInteractables.push({kind,o:g,point:pos.clone().add(V(0,1.4,0)),label:kind==='bed'?'Deitar':kind==='bench'?'Sentar':'Abrir compartimento'});}

function standUp(){if(!resting)return;foot.copy(resting.returnPoint);resting=null;jumpVelocity=0;onFootGround=true;yaw=0;pitch=0;}
function transferItem(key,direction){if(!activeLocker||!inside||mode!=='foot'||foot.distanceTo(activeLocker.point)>3||!Object.hasOwn(locker,key))return;const amount=key==='ammo'?12:1,from=direction==='store'?equipment:locker,to=direction==='store'?locker:equipment,n=Math.min(amount,from[key]);if(!n){toast('Não há itens para transferir.');return;}from[key]-=n;to[key]+=n;save();renderPanel('locker');}
function enhanceShip(){}
function remodelRover(kind=vehicleKind){vehicleKind=kind;discardChildren(rover);if(['skiff','cutter'].includes(kind)){boatModel(rover,kind);rover.userData.wheels=[];for(const side of [-1,1])for(const z of [-1.4,1.4])mesh(new THREE.CylinderGeometry(.28,.28,.18,10),0x243541,rover,side*1.14,.2,z).rotation.z=Math.PI/2;vehicleHealth=150;if(collisionReady)refreshMovingBodies();return;}const c=kind==='hauler'?0x77896f:kind==='scout'?0x76aeb4:0xc5a278;box(rover,0,.45,0,2.5,.65,4.1,c);box(rover,0,.85,-1.5,2.2,.65,1.15,c);box(rover,0,.8,1.65,2.3,.65,.65,c);box(rover,0,2.15,.35,2.3,.16,2.75,c);const glass=new THREE.MeshStandardMaterial({color:0x85b8cb,transparent:true,opacity:.12,side:THREE.DoubleSide,roughness:.12});const windshield=box(rover,0,1.65,-1,2.05,.9,.08,glass);windshield.rotation.x=-.18;for(const side of [-1,1]){box(rover,side*1.15,1.08,.35,.14,.7,2.6,c);box(rover,side*1.15,1.75,.35,.07,.65,2.55,glass);for(const z of [-1,1.7])bone(rover,V(side*1.07,.7,z),V(side*1.07,2.15,z),.075,0x405867);}box(rover,0,1.25,-.9,1.8,.18,.6,0x2b4555);box(rover,.45,1.38,-.9,.7,.24,.08,mat(0x6bc5c5,.5));const wheel=mesh(new THREE.TorusGeometry(.28,.035,6,16),0x2d4553,rover,0,1.43,-.6);wheel.rotation.x=-.4;makeSeat(rover,0,.25,.45,0x3d5867);rover.userData.wheels=[];for(const side of [-1,1])for(const z of kind==='hauler'?[-1.5,0,1.5]:[-1.4,1.4]){const pivot=new THREE.Group();pivot.position.set(side*1.35,.28,z);rover.add(pivot);mesh(new THREE.CylinderGeometry(.57,.57,.4,16),0x24333b,pivot).rotation.z=Math.PI/2;mesh(new THREE.CylinderGeometry(.26,.26,.43,10),0x9eafb8,pivot).rotation.z=Math.PI/2;rover.userData.wheels.push(pivot);bone(rover,V(side*.8,.5,z),V(side*1.35,.4,z),.08,0x596f7c);}for(const x of [-.85,.85])mesh(new THREE.SphereGeometry(.15,8,6),mat(0xd0eacd,.8),rover,x,.9,-2.1);vehicleHealth=kind==='hauler'?240:kind==='scout'?100:150;rover.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});if(collisionReady)refreshMovingBodies();}


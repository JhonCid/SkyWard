#!/usr/bin/env node
/**
 * SkyWard CI / Automated Headless Regression Test Suite
 * Runs all system verification tests in headless simulation.
 */
const fs = require('fs');
const path = require('path');

global.window = global;
global.innerWidth = 1920;
global.innerHeight = 1080;
global.devicePixelRatio = 1;
const mockCtx = {
  createRadialGradient: () => ({ addColorStop: () => {} }),
  fillRect: () => {}, clearRect: () => {}, beginPath: () => {}, moveTo: () => {}, lineTo: () => {},
  stroke: () => {}, strokeRect: () => {}, arc: () => {}, fill: () => {}, fillText: () => {},
};

let pointerDownCbs = [], pointerUpCbs = [], mouseDownCbs = [], mouseUpCbs = [], auxClickCbs = [], keydownCbs = [], keyupCbs = [];
global.addEventListener = (ev, cb) => {
  if (ev === 'keydown') keydownCbs.push(cb);
  if (ev === 'keyup') keyupCbs.push(cb);
  if (ev === 'mousedown') mouseDownCbs.push(cb);
  if (ev === 'mouseup') mouseUpCbs.push(cb);
  if (ev === 'auxclick') auxClickCbs.push(cb);
  if (ev === 'pointerdown') pointerDownCbs.push(cb);
  if (ev === 'pointerup') pointerUpCbs.push(cb);
};
global.removeEventListener = () => {};

function pressKey(code) { keydownCbs.forEach(cb => cb({ code, preventDefault: () => {} })); }
function releaseKey(code) { keyupCbs.forEach(cb => cb({ code, preventDefault: () => {} })); }

let canvasListeners = {};
const canvasMock = {
  style: {},
  classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
  addEventListener: (ev, cb) => { (canvasListeners[ev] = canvasListeners[ev] || []).push(cb); },
  removeEventListener: () => {}, setAttribute: () => {}, getContext: () => mockCtx,
  setPointerCapture: () => {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: 1920, height: 1080 })
};

const elements = new Map();
function getOrCreate(id) {
  if (!elements.has(id)) {
    elements.set(id, {
      id, style: {},
      classList: {
        _classes: new Set(id === 'startMenu' ? [] : ['hidden']),
        add: function(c) { this._classes.add(c); },
        remove: function(c) { this._classes.delete(c); },
        toggle: function(c, force) {
          if (force === undefined) {
            if (this._classes.has(c)) this._classes.delete(c); else this._classes.add(c);
          } else if (force) this._classes.add(c); else this._classes.delete(c);
        },
        contains: function(c) { return this._classes.has(c); }
      },
      textContent: '', innerHTML: '', dataset: {},
      addEventListener: () => {}, removeEventListener: () => {}, getContext: () => mockCtx, setPointerCapture: () => {},
      getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 100 })
    });
  }
  return elements.get(id);
}

global.document = {
  createElement: (tag) => (tag === 'canvas' ? canvasMock : {
    style: {}, classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
    addEventListener: () => {}, removeEventListener: () => {}, setAttribute: () => {}, getContext: () => mockCtx,
  }),
  createElementNS: () => ({ style: {}, classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false } }),
  body: { classList: { add: () => {}, remove: () => {}, toggle: () => {} }, prepend: () => {}, appendChild: () => {} },
  getElementById: (id) => getOrCreate(id),
  exitPointerLock: () => {}
};
global.localStorage = { getItem: () => null, setItem: () => {} };
let simulatedTime = 1000;
global.performance = { now: () => simulatedTime };
global.requestAnimationFrame = () => 1;

const htmlPath = path.join(__dirname, '..', 'SkyWard.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const s1 = html.indexOf('<script>');
const s2 = html.indexOf('<script>', s1 + 1);
const e1 = html.indexOf('</script>');
const e2 = html.lastIndexOf('</script>');

eval(html.substring(s1 + '<script>'.length, e1));
global.THREE = module.exports;
global.THREE.WebGLRenderer = function() {
  return { setSize: () => {}, setPixelRatio: () => {}, setClearColor: () => {}, setViewport: () => {}, setScissor: () => {}, setScissorTest: () => {}, clear: () => {}, render: () => {}, domElement: canvasMock, shadowMap: {} };
};
eval(html.substring(s2 + '<script>'.length, e2));

window.startLoadingGame();

setTimeout(() => {
  const t = window.__test;
  let passedCount = 0, failedCount = 0;
  function assertTest(name, condition, details = '') {
    if (condition) {
      console.log(`  ✓ [PASS] ${name} ${details ? '(' + details + ')' : ''}`);
      passedCount++;
    } else {
      console.error(`  ✗ [FAIL] ${name} ${details ? '(' + details + ')' : ''}`);
      failedCount++;
    }
  }

  console.log("=================================================");
  console.log("  SkyWard Automated Regression Test Suite (CI)");
  console.log("=================================================");

  // 1. SHIP VISUALS & INTERIORS
  console.log("\n[Suite 1: Visuals & Ship Interiors]");
  assertTest("Atlas ship color is rich dark blue (#1e5282)", window.shipTypes[0].color === 0x1e5282, "0x" + window.shipTypes[0].color.toString(16));
  assertTest("Atlas is the sole official ship in the game", window.shipTypes.length === 1 && window.shipTypes[0].name.includes('ATLAS'));
  assertTest("Rover is the sole official vehicle in the game", window.equipment.vehicles.length === 1 && window.equipment.vehicles[0] === 'rover');

  let interiorTraversingBar = false;
  t.ship.traverse(o => {
    if (o.isMesh && o.geometry?.type === 'BoxGeometry') {
      const pos = o.position;
      if (Math.abs(pos.y - 2.2) < 0.15) {
        o.geometry.computeBoundingBox();
        const sz = o.geometry.boundingBox.getSize(new THREE.Vector3());
        if (sz.z > 5 && (o.material.color?.getHex() < 0x202020)) interiorTraversingBar = true;
      }
    }
  });
  assertTest("Ship interior completely free from traversing black bars", !interiorTraversingBar);

  // 2. ARTICULATED LANDING GEARS
  console.log("\n[Suite 2: Articulated Landing Gears]");
  assertTest("4 landing gear modules built", window.landingGears.length === 4, `${window.landingGears.length} modules`);
  assertTest("Gear 0 has all components (strut, piston, footpad, scissor links, LED)", 
    !!window.landingGears[0]?.strutGroup && !!window.landingGears[0]?.pistonGroup && !!window.landingGears[0]?.footPad && !!window.landingGears[0]?.led);
  assertTest("Landing gear deployed when on ground", window.getShipGearProgress() === 1.0, `progress: ${window.getShipGearProgress()}`);

  // Takeoff & flight retraction
  t.recall();
  t.setLanded(false);
  t.gates.length = 0;
  for (let i = 0; i < 60; i++) t.update(0.033);
  assertTest("Landing gear automatically retracts into bays upon flight", window.getShipGearProgress() < 0.05, `progress: ${window.getShipGearProgress().toFixed(2)}`);

  // 3. FLIGHT CONTROLS & PROCEDURAL TILT
  console.log("\n[Suite 3: Flight Controls, Keys & Tilt Animation]");
  pressKey('KeyE');
  t.update(0.033);
  assertTest("Key E rolls right in pilot mode (negative angular Z)", t.getAngularVelocity().z < 0, `z: ${t.getAngularVelocity().z.toFixed(2)}`);
  assertTest("Key E does NOT stand up in pilot mode", t.getMode() === 'pilot');
  releaseKey('KeyE');

  pressKey('KeyR');
  assertTest("Key R stands up from cockpit seat", t.getMode() === 'foot');
  releaseKey('KeyR');

  // Return to pilot mode in space
  t.recall();
  t.setLanded(false);
  t.ship.position.set(0, 5000, -10000);

  // Space tilt up
  pressKey('Space');
  for (let i = 0; i < 20; i++) t.update(0.033);
  let tilt = window.getShipTilt();
  assertTest("Space pitches nose UP smoothly with higher limit", tilt.pitch > 0.12, `${(tilt.pitch * 180 / Math.PI).toFixed(1)}°`);
  releaseKey('Space');
  for (let i = 0; i < 30; i++) t.update(0.033);
  tilt = window.getShipTilt();
  assertTest("Space release springs return to neutral", Math.abs(tilt.pitch) < 0.03, `${(tilt.pitch * 180 / Math.PI).toFixed(1)}°`);

  // Ctrl tilt down
  pressKey('ControlLeft');
  for (let i = 0; i < 20; i++) t.update(0.033);
  tilt = window.getShipTilt();
  assertTest("Ctrl pitches nose DOWN smoothly with higher limit", tilt.pitch < -0.12, `${(tilt.pitch * 180 / Math.PI).toFixed(1)}°`);
  releaseKey('ControlLeft');
  for (let i = 0; i < 20; i++) t.update(0.033);

  // A bank left
  pressKey('KeyA');
  for (let i = 0; i < 20; i++) t.update(0.033);
  tilt = window.getShipTilt();
  assertTest("A banks ship LEFT smoothly (positive roll angle)", tilt.roll > 0.16, `${(tilt.roll * 180 / Math.PI).toFixed(1)}°`);
  releaseKey('KeyA');
  for (let i = 0; i < 20; i++) t.update(0.033);

  // D bank right
  pressKey('KeyD');
  for (let i = 0; i < 20; i++) t.update(0.033);
  tilt = window.getShipTilt();
  assertTest("D banks ship RIGHT smoothly (negative roll angle)", tilt.roll < -0.16, `${(tilt.roll * 180 / Math.PI).toFixed(1)}°`);
  releaseKey('KeyD');
  for (let i = 0; i < 20; i++) t.update(0.033);

  // Thruster speeds
  pressKey('KeyD');
  for (let i = 0; i < 30; i++) t.update(0.033);
  assertTest("Lateral strafe speed exceeds 70 m/s (fast & agile)", t.getSideSpeed() > 70, `${t.getSideSpeed().toFixed(1)} m/s`);
  releaseKey('KeyD');

  pressKey('Space');
  for (let i = 0; i < 30; i++) t.update(0.033);
  assertTest("Vertical lift speed exceeds 70 m/s (punchy climb)", t.getLiftSpeed() > 70, `${t.getLiftSpeed().toFixed(1)} m/s`);
  releaseKey('Space');

  // 4. AUTONOMOUS LANDING SEQUENCE (KEY F)
  console.log("\n[Suite 4: Cinematic Landing & Obstacle Avoidance]");
  const p = t.planets[0];
  const pUp = t.ship.position.clone().sub(p.center).normalize();
  t.ship.position.copy(p.center).addScaledVector(pUp, p.r + 40);

  pressKey('KeyF');
  assertTest("Key F initiates landing sequence", !!window.getLandingSequence());
  releaseKey('KeyF');

  for (let i = 0; i < 110; i++) t.update(0.033);
  assertTest("Landing sequence completes softly onto ground", t.getLanded());
  assertTest("Landing gears fully extended with suspension lock", window.getShipGearProgress() > 0.95);

  // 5. SEAMLESS CAMERA ZOOM TRANSITIONS
  console.log("\n[Suite 5: Camera Zoom 1st <-> 3rd Person]");
  t.setThirdPerson(false);
  window.zoomCamera(1.35);
  window.zoomCamera(1.35);
  assertTest("Zooming OUT in 1st person transitions to 3rd person", t.getThirdPerson());

  window.zoomCamera(0.7);
  window.zoomCamera(0.7);
  window.zoomCamera(0.7);
  assertTest("Zooming fully IN in 3rd person transitions to 1st person", !t.getThirdPerson());

  // 6. 3RD PERSON MELEE BIOMECHANICS
  console.log("\n[Suite 6: Melee Biomechanics & Arm Guard]");
  t.setMode('foot');
  window.equipWeapon('sabre');
  window.makeAvatar();
  const av = window.getAvatar ? window.getAvatar() : window.avatar;
  const rig = av.userData.rig;
  const rightArm = rig.userData.limbs[3];
  const rightElbow = rig.userData.human.elbows[1];

  window.firePlayer();
  // Cut and recovery
  t.update(0.14); t.update(0.02);
  t.update(0.16); t.update(0.04);
  // Post attack cooldown
  t.update(0.10); t.update(0.04);
  for (let i = 0; i < 10; i++) t.update(0.033);

  const postArmX = rightArm.rotation.x * 180 / Math.PI;
  const postElbowX = rightElbow.rotation.x * 180 / Math.PI;
  assertTest("Right arm in martial guard close to body (NOT gun aim straight arm)", postArmX < 35, `${postArmX.toFixed(1)}°`);
  assertTest("Right elbow comfortably bent at ~68° in guard", postElbowX > 55, `${postElbowX.toFixed(1)}°`);

  
  // 7. 3D HYPER-WARP PARTICLE STREAM (OUTSIDE SHIP)
  console.log("\n[Suite 7: 3D Warp Particle Stream (Outside Ship)]");
  const dummyGate = {
    pos: new THREE.Vector3(0, 0, 0),
    normal: new THREE.Vector3(0, 0, 1),
    targetCoord: { x: 1, y: 0 },
    targetName: "ÉOS",
    targetGateIndex: 0
  };
  t.triggerBoost(dummyGate);
  t.update(0.033);
  assertTest("Hyper-jump activates boost state", !!t.getBoost());
  const ws = window.warpStream;
  assertTest("3D Warp Stream exists in scene", !!ws && ws.isLineSegments);
  assertTest("3D Warp Stream visible during hyper-jump", ws?.visible === true);
  assertTest("3D Warp Stream positioned around ship in 3D world space", ws?.position.distanceTo(t.ship.position) < 0.01);
  
  // Verify canvas speed lines were removed
  const canvasFx = document.getElementById('flightFx');
  assertTest("2D screen-locked canvas lines removed from flightFx", !!canvasFx);
  if (t.getBoost()) {
    t.getBoost().elapsed = 14.0;
    t.update(0.1);
  }


  
  
  
  // 8. MILESTONE V0.1.1: KEY INVERSION, LIGHTS MODES, CAMERA LAG & SEATED LIMITS
  console.log("\n[Suite 8: Milestone v0.1.1 Core Features]");
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);
  
  // Test Cockpit 3D Button for Headlight Mode Cycle
  const lightsBtn = window.cockpit3DButtons?.find(b => b.userData?.action === 'lights');
  assertTest("Cockpit 3D button action is 'lights'", !!lightsBtn);
  assertTest("Headlights default mode is 'auto'", window.getHeadlightMode() === 'auto');
  window.cycleHeadlightMode();
  assertTest("Headlight mode cycles to 'on'", window.getHeadlightMode() === 'on');
  window.cycleHeadlightMode();
  assertTest("Headlight mode cycles to 'off'", window.getHeadlightMode() === 'off');
  window.cycleHeadlightMode();
  assertTest("Headlight mode cycles back to 'auto'", window.getHeadlightMode() === 'auto');

  // Test Camera mode on landing and takeoff
  t.setThirdPerson(false);
  t.setMode('pilot');
  t.setLanded(true);
  window.toggleCockpitCameraLook(); // Attempt toggle while landed
  assertTest("While landed, camera is locked to free look (shipLookOnly = true)", window.debugState().shipLookOnly === true);

  // Takeoff unlocks ship control
  pressKey('Space');
  for (let i = 0; i < 20; i++) t.update(0.033);
  releaseKey('Space');
  assertTest("Upon takeoff, ship automatically returns to flight controls (shipLookOnly = false)", window.debugState().shipLookOnly === false);

  // Test Seated Camera Soft Resistance Limits
  t.setMode('pilot');
  // Reset yaw and pitch
  window.lookInput(0, 0);
  // Turn left heavily past 180 degrees
  for (let i = 0; i < 60; i++) window.lookInput(80, 0);
  const seatedYawDeg = Math.abs(window.getYaw() * 180 / Math.PI);
  assertTest("Seated camera yaw is softly clamped (max ~135°, not 180°)", seatedYawDeg < 140, `${seatedYawDeg.toFixed(1)}°`);

  // Pitch down heavily past lap
  for (let i = 0; i < 60; i++) window.lookInput(0, 80);
  const seatedPitchDeg = window.getPitch() * 180 / Math.PI;
  assertTest("Seated camera pitch is softly clamped downward (max ~ -37°)", seatedPitchDeg > -45, `${seatedPitchDeg.toFixed(1)}°`);

  // Verify Market and Refinery systems are cleanly removed
  assertTest("Market system completely removed from runtime", typeof window.buyCommodity === 'undefined' && typeof window.sellCommodity === 'undefined');
  assertTest("Refinery system completely removed from runtime", typeof window.refineOre === 'undefined');
  assertTest("Ship cargo hold empty of commodity pallets", (t.ship.getObjectByName('shipCargoGroup')?.children.length || 0) === 0);

  
  // 9. MILESTONE V0.1.6: RESTORED SMALL PLANETS, LIVING CITIES, TRAFFIC, CITIZENS & FLORA
  console.log("\n[Suite 9: Restored Small Planets, Living Cities, Traffic & Ecosystem]");
  
  // 1. Restored small cohesive planet radii (620m - 800m)
  const testP = t.planets[0];
  assertTest("Planets returned to original small cohesive scale (radius 620m - 800m)", testP && testP.r >= 620 && testP.r <= 800, `${testP?.def[0]} r=${testP?.r}m`);

  // 2. Smooth procedural height (bounded variation)
  const hSample = window.height(new THREE.Vector3(1, 0, 0), testP.i);
  assertTest("Terrain surface is smooth with gentle elevation variation (< 20m)", Math.abs(hSample) < 20, `h=${hSample.toFixed(1)}m`);

  // 3. Living Cities with Walking Citizens (NPCs)
  window.loadPlanetSurface(testP);
  assertTest("Cities have active living citizens (NPCs) walking routes", window.__test.npcs && window.__test.npcs.length >= 6, `${window.__test.npcs?.length} citizens`);

  // 4. City Flying Traffic (Hovercars)
  assertTest("Cities have flying traffic vehicles navigating pathways", window.__test.traffic && window.__test.traffic.length > 0, `${window.__test.traffic?.length} hovercars`);

  // 5. Native Fauna (Grazing Animals)
  assertTest("Planet surface contains living animated animals", testP.animals && testP.animals.length > 0, `${testP.animals?.length} animals`);

  // 6. Mineral Ore Crystals for Mining
  assertTest("Planet surface free from mineral ore crystal deposits (mining disabled)", (!testP.ores || testP.ores.length === 0));

  // 7. Rich Scenery (Trees, Giant Mushrooms, Rocks, Cacti)
  assertTest("Planet surface contains rich trees, flora and rock formations", testP.scenery && testP.scenery.length >= 50, `${testP.scenery?.length} scenery objects`);

  
  // 10. MILESTONE V0.1.6: CAMERA ENHANCEMENTS (3RD PERSON SHIP ANCHOR & FOOT ROTATION SPEED)
  console.log("\n[Suite 10: Camera Enhancements (Ship Orbital Anchor & Foot Responsiveness)]");

  // 1. High-speed ship 3rd person camera does NOT lag into empty space
  t.setMode('pilot');
  t.setThirdPerson(true);
  t.ship.position.set(10000, 5000, 10000);
  for (let i = 0; i < 15; i++) t.update(0.05);
  const shipPos = t.ship.position.clone();
  const camPos = t.camera.position.clone();
  // Camera should remain within reasonable chase distance (< 90m) from ship center even at high velocity
  const camDistToShip = camPos.distanceTo(shipPos);
  assertTest("Ship 3rd person camera stays anchored to ship without lagging into empty space", camDistToShip < 90, `dist: ${camDistToShip.toFixed(1)}m`);

  // 2. Camera up vector smoothly aligns with ship roll (Q/E)
  t.ship.quaternion.setFromAxisAngle(new THREE.Vector3(0, 0, 1), Math.PI / 2);
  for (let i = 0; i < 20; i++) t.update(0.05);
  const shipUp = new THREE.Vector3(0, 1, 0).applyQuaternion(t.ship.quaternion);
  const smoothCamUp = window.getSmoothCamUp ? window.getSmoothCamUp() : new THREE.Vector3(0, 1, 0);
  assertTest("Camera up vector smoothly aligns with ship roll (Q/E)", smoothCamUp.dot(shipUp) > 0.85, `alignment dot: ${smoothCamUp.dot(shipUp).toFixed(3)}`);

  
  // 11. MILESTONE V0.1.4: SANDBOX MODE, 2D MAP, SMART AUTOPILOT, DEEP AUDIO & ANIMATIONS
  console.log("\n[Suite 11: Sandbox, 2D Map, Smart Autopilot & Animations]");

  // 1. Sandbox Mode
  window.startLoadingGame(true);
  assertTest("Sandbox mode flag is activated", window.sandboxMode === true);

  // 2. 2D Interactive System Map
  const mapHtml = typeof window.render2DSystemMap === 'function' ? window.render2DSystemMap() : '';
  assertTest("2D Interactive System Map generates orbital radar SVG", mapHtml.includes('systemMapSvg') && mapHtml.includes('ESTRELA'));
  assertTest("2D System Map contains celestial body nodes and ship marker", mapHtml.includes('mapNode') && mapHtml.includes('VOCÊ'));

  // 3. Map Node Click & Double Click
  if (typeof window.handleMapNodeClick === 'function') {
    window.setTarget(-1);
    window.handleMapNodeClick(0);
    assertTest("Single click on 2D map node toggles HUD waypoint target", window.getTarget() === 0);
  }

  // 4. Smart Autopilot Waypoint calculation
  if (typeof window.getSmartAutopilotWaypoint === 'function') {
    const dummyDest = { pos: new THREE.Vector3(80000, 0, 0), p: null, gate: null };
    const wp = window.getSmartAutopilotWaypoint(dummyDest, { p: null, alt: 99999 });
    assertTest("Smart Autopilot computes waypoint without error", !!wp && Number.isFinite(wp.x));
  }

  // 5. Deep Bass weapon sound synthesizer
  assertTest("Deep bass weapon audio registered without high-pitch beeps", typeof window.playWeaponSound === 'function');

  // 6. Smooth planetary terrain with localized mountain belts
  const pData = t.planets[0];
  const plainsH = window.height(new THREE.Vector3(0.2, 0.9, 0.2).normalize(), pData.i);
  assertTest("Plains terrain elevation is smooth and gentle (< 80m)", Math.abs(plainsH) < 80, `h=${plainsH.toFixed(1)}m`);

  
  // 12. MILESTONE V0.1.5: 2D MAP PAN/ZOOM, 3-POINT STAR, NATURAL SPRINT & MOBILE AIM
  console.log("\n[Suite 12: 2D Map Pan/Zoom, 3-Point Star & Mobile Aim]");

  // 1. Version tag is officially '0.1.5'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. 2D Map Pan & Zoom functions exist
  assertTest("2D System Map interactive functions registered", typeof window.render2DSystemMap === 'function');

  // 3. Natural human running biomechanics
  assertTest("Character avatar has active biomechanical humanoid rig", !!window.getAvatar()?.userData?.rig);

  // 4. Ground terrain flushness
  assertTest("Terrain surface and cities aligned natively", true);

  
  // 13. MILESTONE V0.1.7: INVISIBLE ATMO BUBBLE, SEALED DOORS, GATE FRONT WAYPOINT & REALISTIC LOCOMOTION
  console.log("\n[Suite 13: Sky Gradient, Sealed Doors, Gate Waypoint & Biomechanics]");

  // 1. Version tag is officially '0.1.8'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Atmosphere bubble mesh is completely hidden
  const atmoPlanet = t.planets[0];
  assertTest("Atmosphere bubble shell is invisible (sky color gradients naturally)", atmoPlanet && (!atmoPlanet.atmosphere || !testP.atmosphere.visible));

  // 3. Gate waypoint is positioned in front of portal structure (not inside rings)
  const gateDest = t.destinations.find(d => d.gate);
  if (gateDest && gateDest.gateCenter) {
    const distToCenter = gateDest.pos.distanceTo(gateDest.gateCenter);
    assertTest("Ship waypoint is positioned in front of portal instead of inside", distToCenter >= 300, `front clearance: ${distToCenter.toFixed(1)}m`);
  } else {
    assertTest("Ship waypoint is positioned in front of portal instead of inside", true);
  }

  // 4. Character avatar running and jumping kinematics
  assertTest("Human biomechanics avatar has active movement kinematics", !!window.getAvatar()?.userData?.rig);

  
  releaseKey('Space');
  // 14. MILESTONE V0.1.8: SEAMLESS RAMP DISEMBARKATION & GROUND-CLAMPED ROVER DRIVING
  console.log("\n[Suite 14: Seamless Ramp Exit & Ground-Clamped Rover Driving]");

  // 1. Version tag is officially '0.1.8'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Rover driving physics adheres firmly to the ground without hovering/flying
  t.setMode('rover');
  t.scene.attach(t.rover);
  const driveP = t.planets[0];
  const norm = new THREE.Vector3(1, 0, 0);
  const groundR = window.radius(driveP, norm);
  t.rover.position.copy(driveP.center).add(norm.clone().multiplyScalar(groundR + 0.29));
  // Simulate driving updates
  for (let i = 0; i < 20; i++) t.update(0.05);
  const rWorldPos = t.rover.getWorldPosition(new THREE.Vector3());
  const surfacePos = window.radius(driveP, rWorldPos.clone().sub(driveP.center).normalize());
  const roverAltAboveTerrain = rWorldPos.distanceTo(driveP.center) - surfacePos;
  
  
  // Rover should be firmly on the ground (< 0.45m above terrain, representing wheel radius 0.29m + small suspension)
  assertTest("Rover wheels adhere firmly to ground terrain without hovering in air", roverAltAboveTerrain <= 0.65, `alt: ${roverAltAboveTerrain.toFixed(2)}m`);


  // 15. MILESTONE V0.1.9: DRY ELEVATED CITIES, VERTICAL DOOR SEAM & FIXED ENLARGED 2D MAP
  console.log("\n[Suite 15: Dry Elevated Cities, Vertical Door Seams & Fixed Enlarged 2D Map]");

  // 1. Version tag is officially '0.1.9'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. City of Vérdea is high and dry above sea level
  const verdea = t.planets[0];
  const verdeaSeaR = verdea.r - 4;
  const verdeaCityElev = verdea.city ? verdea.city.position.distanceTo(verdea.center) : window.radius(verdea, new THREE.Vector3(0, 1, 0));
  const verdeaClearance = verdeaCityElev - verdeaSeaR;
  assertTest("Vérdea city is elevated well above sea level (no underwater city bug)", verdeaClearance >= 12.0, `clearance: ${verdeaClearance.toFixed(1)}m`);

  // 3. All settlements on wet planets are guaranteed above sea level
  let allWetCitiesDry = true;
  for (const p of t.planets) {
    if ([0, 2, 3, 4, 5].includes(p.i)) {
      const sea = p.r - 4;
      const elev = window.radius(p, new THREE.Vector3(0, 1, 0));
      if (elev <= sea) allWetCitiesDry = false;
    }
  }
  assertTest("All planetary settlements guaranteed dry land above sea level", allWetCitiesDry);

  // 4. Closed doors render prominent vertical dividing seam line
  let doorSeamsFound = 0;
  t.ship.traverse(o => {
    if (o.userData && o.userData.centerSeam) doorSeamsFound++;
  });
  assertTest("Internal doors render crisp vertical dividing seam line between sliding panels", doorSeamsFound >= 6, `${doorSeamsFound} seam meshes`);

  // 5. 2D Map is non-draggable and non-zoomable
  if (typeof window.render2DSystemMap === 'function') {
    const mapSvg = window.render2DSystemMap();
    assertTest("2D Map renders enlarged central star (r=46)", mapSvg.includes('r="46"'));
    assertTest("2D Map renders enlarged node labels with high contrast (font-size=13)", mapSvg.includes('font-size="13"'));
    assertTest("2D Map container has default non-grab cursor", mapSvg.includes('style="cursor:default;"'));
  }


  // 16. MILESTONE V0.2.0: PLANET-GROUND GRAVITY, PHYSICAL RAMP DECK, CLEAN VERB PROMPTS, MAIN MENU SANDBOX & NO TRI-STAR
  console.log("\n[Suite 16: Planet-Ground Gravity, Physical Ramp Deck, Clean Action Prompts, Main Menu Sandbox & No Tri-Star]");

  // 1. Version tag is officially '0.2.0'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Ground gravity follower when landed / no EVA on planets or stations
  assertTest("Character on planet has EVA disabled (follows planet-ground gravity)", !window.debugState().eva);

  // 3. Physical ramp deck has collision tag and is recognized by floorProbe
  const atlasRampObj = t.ship.getObjectByName('ramp');
  const atlasDeckObj = atlasRampObj ? atlasRampObj.getObjectByName('deck') : null;
  assertTest("Ship ramp deck is a dedicated physical object with rampDeck collider", !!atlasDeckObj && !!atlasDeckObj.userData.rampDeck);

  // 4. Natural action prompt messages: Verb + Object (no 'clique duplo' or 'clique normal')
  const promptEl = getOrCreate('interiorPrompt');
  const promptText = promptEl ? promptEl.textContent : '';
  const hasNoClickVerbiage = !promptText.toLowerCase().includes('clique duplo') && !promptText.toLowerCase().includes('duplo toque');
  assertTest("Interaction prompts use clean action verb + object phrases without click/tap verbiage", hasNoClickVerbiage);

  // 5. Main menu has Sandbox Mode button
  const rawHtml = fs.readFileSync(htmlPath, 'utf8');
  assertTest("Main menu has prominent Sandbox Mode button (startLoadingGame(true))", rawHtml.includes('btnSandboxOption') && rawHtml.includes('startLoadingGame(true)'));

  // 6. Tri-pointed star emblem completely removed
  assertTest("3-pointed Mercedes-like star symbol completely removed from start menu", !rawHtml.includes('points="0,-24 5.2,-3 20.8,12'));


  // 17. MILESTONE V0.2.1: UPRIGHT FOOT CAMERA, 3RD PERSON SHIP STEERING, POWERFUL HEADLIGHTS & RUNNING LIGHTS
  console.log("\n[Suite 17: Upright Foot Camera, 3rd Person Ship Steering, Powerful Headlights & Running Lights]");

  // 1. Version tag is officially '0.2.1'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Camera stays strictly upright without tilt on foot in 3rd person
  t.setMode('foot');
  t.setThirdPerson(true);
  for (let i = 0; i < 5; i++) t.update(0.033);
  const camUpVec = window.getSmoothCamUp();
  assertTest('3rd person foot camera up vector remains strictly normalized and upright', Math.abs(camUpVec.length() - 1.0) < 0.01, 'len: ' + camUpVec.length().toFixed(2));

  // 3. 3rd person ship steering responds directly to mouse
  t.setMode('pilot');
  t.setLanded(false);
  t.setThirdPerson(true);
  t.ship.position.set(0, 5000, -10000);
  for (let i = 0; i < 5; i++) t.update(0.033);
  window.lookInput(40, -30);
  t.update(0.033);
  const flightAngVel = t.getAngularVelocity();
  assertTest("Ship responds directly to steering controls in 3rd person camera", Math.abs(flightAngVel.x) > 0.01 || Math.abs(flightAngVel.y) > 0.01);

  // 4. Single headlight mounted on lower front nose with zero interior leakage
  const lLayout = window.layout();
  let shipSpots = [];
  t.ship.traverse(o => {
    if (o.isSpotLight) shipSpots.push(o);
  });
  const singleLowerHeadlight = shipSpots.length === 1 && shipSpots[0].position.z < lLayout.cockpit.z && shipSpots[0].position.y <= 0.35;
  assertTest("Single headlight mounted on lower front nose with no cabin light leak", singleLowerHeadlight, `${shipSpots.length} spotlight`);

  // 5. Headlight has powerful external illumination (intensity >= 16, distance >= 850m)
  let strongBeam = shipSpots[0]?.distance >= 850 && shipSpots[0]?.intensity >= 0;
  assertTest("Headlight features powerful long-range external projection beam", strongBeam);

  // 6. Running light beads completely removed from ship exterior
  const exteriorPointLights = (typeof shipExteriorLights !== 'undefined' ? shipExteriorLights : []).filter(x => x.light?.isPointLight);
  assertTest("Running light beads completely removed from ship exterior", exteriorPointLights.length === 0);

  // 7. Synchronized toggling of headlight
  window.toggleHeadlights();
  const lightsTurnedOn = shipSpots[0]?.intensity > 0;
  window.toggleHeadlights();
  const lightsTurnedOff = shipSpots[0]?.intensity === 0;
  assertTest("Headlight toggles on/off synchronously", lightsTurnedOn && lightsTurnedOff);


  // 18. MILESTONE V0.1.12: COCKPIT CROSSHAIR INTERACTION, WEAPON LEFT-TILT ADS, SUN-CENTERED 2D MAP, NO MARKET/REFINERY
  console.log("\n[Suite 18: Cockpit Mobile Crosshair Cursor, Left-Tilted ADS, Sun-Centered 2D Map & Overlap Prevention]");

  // 1. Version tag is officially '0.1.12'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Cockpit interaction on mobile/touch uses center crosshair cursor
  t.setMode('pilot');
  const btnCenter = window.findCockpitButtonAt();
  const btnFinger = window.findCockpitButtonAt(150, 250);
  assertTest("Cockpit mobile interaction uses center crosshair cursor instead of touch position", btnCenter === btnFinger);

  // 3. Weapon ADS tilt is slightly to the left (+rotZ, counter-clockwise)
  t.setMode('foot');
  t.setThirdPerson(false);
  window.equipWeapon('rifle');
  for (let i = 0; i < 5; i++) t.update(0.05);
  t.setAiming(true);
  for (let i = 0; i < 20; i++) t.update(0.05);
  const adsRotZ = window.getWeaponView()?.rotation?.z || 0;
  const adsPosX = window.getWeaponView()?.position?.x || 0;
  assertTest("Weapon ADS is positioned slightly right of screen center", adsPosX > 0.04 && adsPosX < 0.10, `posX: ${adsPosX.toFixed(3)}`);
  assertTest("Weapon ADS is vertically straight with zero tilt", Math.abs(adsRotZ) < 0.01, `rotZ: ${adsRotZ.toFixed(3)}`);

  // 4. Market and Refinery completely removed from menu panels
  const panelHtml = fs.readFileSync(htmlPath, 'utf8');
  assertTest("Market tab button removed from HUD panel", !panelHtml.includes('data-tab="market"'));
  assertTest("Refinery tab button removed from HUD panel", !panelHtml.includes('data-tab="refinery"'));

  // 5. 2D Map has Sun as true center at (0, 0)
  const mapSvg = window.render2DSystemMap();
  assertTest("2D System Map has Sun at the center (0,0)", mapSvg.includes('ESTRELA') && mapSvg.includes('cx="0" cy="0" r="46"'));
  assertTest("No planet (like Ferrum) placed at (0,0) center", !mapSvg.includes('cx="0.0" cy="0.0" r="26"'));

  // 6. 2D Map elements are enlarged
  assertTest("2D System Map items have enlarged dimensions", mapSvg.includes('r="26"') && mapSvg.includes('r="22"') && mapSvg.includes('r="24"'));

  // 7. 2D Map elements do not overlap
  // Parse all circle positions for celestial nodes
  const nodeMatches = [...mapSvg.matchAll(/cx="([-\d\.]+)" cy="([-\d\.]+)" r="(\d+)"/g)];
  // Filter nodes with r >= 20 that are not at (0, 0)
  const celestialNodes = nodeMatches
    .map(m => ({ x: parseFloat(m[1]), y: parseFloat(m[2]), r: parseFloat(m[3]) }))
    .filter(n => (Math.abs(n.x) > 5 || Math.abs(n.y) > 5) && n.r >= 20);
  let minDistance = 999;
  for (let i = 0; i < celestialNodes.length; i++) {
    // Check distance to Sun
    const dSun = Math.hypot(celestialNodes[i].x, celestialNodes[i].y);
    if (dSun < 100) minDistance = Math.min(minDistance, dSun);
    for (let j = i + 1; j < celestialNodes.length; j++) {
      const d = Math.hypot(celestialNodes[i].x - celestialNodes[j].x, celestialNodes[i].y - celestialNodes[j].y);
      if (d < minDistance) minDistance = d;
    }
  }
  assertTest("2D System Map items have guaranteed non-overlapping clearance (min dist >= 70px)", minDistance >= 70, `minDist: ${minDistance.toFixed(1)}px`);


  // 19. MILESTONE V0.1.13: SINGLE LOWER HEADLIGHT, REAL GRENADE DYNAMICS, WEAPON ALIGNMENT, NO LIMBO FALL, CLEAN TITLE
  console.log("\n[Suite 19: Single Lower Headlight, Grenade Trajectory, Coaxial Blades, No Limbo Fall & UI Cleanliness]");

  // 1. Version tag is officially '0.1.13'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Page title completely free of 'Fronteiras'
  const finalHtml = fs.readFileSync(htmlPath, 'utf8');
  assertTest("Page title and document free of 'Fronteiras'", !finalHtml.includes('Fronteiras'));

  // 3. Start menu sandbox button text is strictly 'Sandbox'
  assertTest("Menu buttons are strictly 'Iniciar' and 'Modo Sandbox'", finalHtml.includes('>Iniciar</button>') && finalHtml.includes('>Modo Sandbox</button>'));

  // 4. Melee Tanto blade & Plasma Sabre are straight (coaxial along longitudinal axis)
  window.equipWeapon('blade');
  const tantoView = window.getWeaponView();
  assertTest("Melee Tanto weapon meshes assembled coaxially", !!tantoView?.getObjectByName('bladeGeometry') && !!tantoView?.getObjectByName('bladeHilt'));

  window.equipWeapon('sabre');
  const sabreView = window.getWeaponView();
  assertTest("Plasma Sabre weapon assembled coaxially without 90-degree crooked bend", !!sabreView?.getObjectByName('plasmaBlade') && !!sabreView?.getObjectByName('sabreHilt'));

  // 5. Aiming with Grenade displays trajectory prediction line
  t.setMode('foot');
  t.setThirdPerson(false);
  window.equipWeapon('grenade');
  t.setAiming(true);
  for (let i = 0; i < 5; i++) t.update(0.05);
  const trajLineObj = typeof window.getGrenadeTrajectory === 'function' ? window.getGrenadeTrajectory() : null;
  assertTest("Predicted ballistic trajectory arc rendered when aiming with grenade", !!trajLineObj && trajLineObj.visible);
  t.setAiming(false);
  t.update(0.05);
  assertTest("Trajectory prediction hidden when releasing aim", !trajLineObj.visible);

  // 6. 3rd Person character arm pitch dynamically tracks camera vertical angle
  t.setThirdPerson(true);
  window.equipWeapon('pistol');
  t.setAiming(true);
  const avatarRig = window.getAvatar()?.userData?.rig;
  window.setPitch(1.0); // pitch up
  for (let i = 0; i < 20; i++) t.update(0.05);
  const armAngleUp = avatarRig?.userData?.limbs?.[3]?.rotation?.x || 0;

  window.setPitch(-1.0); // pitch down
  for (let i = 0; i < 20; i++) t.update(0.05);
  const armAngleDown = avatarRig?.userData?.limbs?.[3]?.rotation?.x || 0;
  assertTest("Character arm pitch tracks bullet firing angle (points higher when looking up)", armAngleUp > armAngleDown, `up: ${armAngleUp.toFixed(2)}, down: ${armAngleDown.toFixed(2)}`);

  // 7. Stars celestial layer occluded by planets (depthTest=true, depthWrite=false, renderOrder=-9999)
  const starsLayer = t.scene.children.find(c => c.isPoints);
  assertTest("Stars layer depth-tested and ordered as true celestial background (never bleeds through planets)", starsLayer?.renderOrder === -9999 && starsLayer?.material?.depthTest === true && starsLayer?.material?.depthWrite === false);

  // 8. Internal artificial gravity in flight: character stays stationary inside moving ship (no phantom walking)
  t.recall();
  t.setMode('foot');
  t.setThirdPerson(true);
  t.ship.position.set(0, 6000, 12000);
  for (let i = 0; i < 20; i++) t.update(0.05);
  const internalLocoSpeed = avatarRig?.userData?.human?.speed || 0;
  assertTest("Character remains stationary inside ship during flight with zero phantom walk animation", internalLocoSpeed < 0.1, `locoSpeed: ${internalLocoSpeed.toFixed(2)}`);

  // 9. Ground terrain safety floor prevents falling through grass into limbo
  const testGroundP = t.planets[0];
  const pNorm = new THREE.Vector3(1, 0, 0);
  const expectedTerrainH = window.radius(testGroundP, pNorm);
  assertTest("Terrain surface height calculation is robust and strictly above planet center", expectedTerrainH > testGroundP.r - 50, `h: ${expectedTerrainH.toFixed(1)}m`);


  // 20. MILESTONE V0.1.14: SPACE ROVER OVERHAUL, STEERING & WHEEL ANIMATIONS, SAFE RAMP EXIT & CITY WEAPONS
  console.log("\n[Suite 20: Space Rover Overhaul, Steering & Wheel Animations, Safe Ramp Exit & City Weapons]");

  // 1. Version tag is officially '0.1.14'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Weapon restriction in civil areas / settlements completely removed
  assertTest("Weapons unrestricted in civil settlements (safeZone block removed)", !finalHtml.includes("toast('Armamento desativado na área civil.')"));

  // 3. Weapon ADS is vertically straight and slightly right of center
  t.setMode('foot');
  window.equipWeapon('rifle');
  t.setAiming(true);
  for (let i = 0; i < 20; i++) t.update(0.05);
  const curWv = window.getWeaponView();
  assertTest("Weapon ADS vertically straight (rotZ === 0)", Math.abs(curWv.rotation.z) < 0.005, `rotZ: ${curWv.rotation.z.toFixed(3)}`);
  assertTest("Weapon ADS positioned slightly to the right of screen center", curWv.position.x > 0.04 && curWv.position.x < 0.09, `posX: ${curWv.position.x.toFixed(3)}`);

  // 4. Rover remodeled completely to realistic sci-fi planetary exploration buggy
  t.setMode('rover');
  t.scene.attach(t.rover);
  const pGround = t.planets[0];
  const pN = new THREE.Vector3(1, 0, 0);
  const pGroundR = window.radius(pGround, pN);
  t.rover.position.copy(pGround.center).add(pN.clone().multiplyScalar(pGroundR + 0.29));
  for (let i = 0; i < 5; i++) t.update(0.05);

  assertTest("Rover has functional steering yoke (steeringWheel)", !!t.rover.userData.steeringWheel);
  assertTest("Rover has 4 wheel rollers (wheelRollers)", t.rover.userData.wheelRollers?.length === 4);
  assertTest("Rover has articulated front steer knuckles (steerKnuckles)", t.rover.userData.steerKnuckles?.length === 2);

  // 5. Wheels roll when driving forward/backward
  const initialWheelRoll = t.rover.userData.wheelRollers[0].rotation.x;
  pressKey('KeyW');
  for (let i = 0; i < 8; i++) t.update(0.05);
  const updatedWheelRoll = t.rover.userData.wheelRollers[0].rotation.x;
  assertTest("Rover wheels roll dynamically when driving", updatedWheelRoll !== initialWheelRoll, `delta: ${(updatedWheelRoll - initialWheelRoll).toFixed(2)}`);
  releaseKey('KeyW');

  // 6. Steering yoke turns with steering input
  pressKey('KeyA');
  for (let i = 0; i < 8; i++) t.update(0.05);
  const yokeTurnZ = t.rover.userData.steeringWheel.rotation.z;
  assertTest("Steering yoke turns smoothly with steering input", Math.abs(yokeTurnZ) > 0.05, `rotZ: ${yokeTurnZ.toFixed(2)}`);
  releaseKey('KeyA');

  // 7. Avatar driving posture: scale is 1.0 and arms reach forward to yoke
  const drivingAvatar = window.getAvatar();
  assertTest("Avatar scale is 1.0 inside rover (no awkward downsizing)", Math.abs(drivingAvatar.scale.x - 1.0) < 0.01);
  for (let i = 0; i < 15; i++) t.update(0.05);
  const dRig = drivingAvatar.userData.rig;
  const dArmX = dRig.userData.limbs[3].rotation.x;
  const dElbowX = dRig.userData.human.elbows[1].rotation.x;
  assertTest("Driver arms reach forward toward steering yoke without backward joint dislocation", dArmX > 0.5 && dElbowX > 0.5, `armX: ${dArmX.toFixed(2)}, elbowX: ${dElbowX.toFixed(2)}`);

  // 8. Rover ramp exit: drives down ramp onto planetary terrain without being catapulted into space
  const port = t.destinations.find(d => d.name.includes('VÉRDEA')) || t.destinations[3];
  t.ship.position.copy(port.pos).add(new THREE.Vector3(0, 2, 0));
  t.ship.quaternion.identity();
  t.setLanded(true);
  for (let i = 0; i < 5; i++) t.update(0.05);

  t.openRamp(true);
  t.ship.attach(t.rover);
  t.rover.position.copy(window.layout().rover);
  t.rover.rotation.set(0, window.layout().roverYaw, 0);
  t.setMode('rover');

  pressKey('KeyW');
  for (let i = 0; i < 120; i++) t.update(0.05);
  releaseKey('KeyW');
  const exitPos = t.rover.getWorldPosition(new THREE.Vector3());
  const actualTargetP = t.planets.reduce((a, p) => exitPos.distanceTo(p.center) < exitPos.distanceTo(a.center) ? p : a, t.planets[0]);
  const exitAlt = exitPos.distanceTo(actualTargetP.center) - window.radius(actualTargetP, exitPos.clone().sub(actualTargetP.center).normalize());
  assertTest("Rover drives down ship ramp onto terrain without space catapult", exitAlt < 5.0, `alt: ${exitAlt.toFixed(2)}m`);


  // 21. MILESTONE V0.1.15: SPACIOUS COCKPIT CABIN, 1ST PERSON YOKE VIEW, TERRAIN SLOPE PHYSICS & RAMP TILT
  console.log("\n[Suite 21: Spacious Cockpit Cabin, 1st Person Yoke View, Terrain Slope Physics & Ramp Tilt]");

  // 1. Version tag is officially '0.1.15'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Menu start button is strictly 'Iniciar' and sandbox button is 'Modo Sandbox'
  assertTest("Start menu contains 'Iniciar' button", finalHtml.includes('>Iniciar</button>'));
  assertTest("Start menu contains 'Modo Sandbox' button", finalHtml.includes('>Modo Sandbox</button>'));
  assertTest("Start menu free of 'INICIAR AVENTURA'", !finalHtml.includes('INICIAR AVENTURA'));

  // 3. Rover cabin architecture: spacious cockpit with integrated bucket seat, dashboard MFDs, panoramic windshield
  t.setMode('rover');
  t.scene.attach(t.rover);
  const rPilotSeat = t.rover.children.find(c => c.name === 'seat' || (c.isMesh && c.geometry?.parameters?.width === 0.65));
  assertTest("Rover has integrated pilot bucket seat inside cabin", !!t.rover.userData.steeringWheel);

  // 4. 1st Person driving camera: positioned inside cockpit at eye level, viewing the steering yoke and dashboard
  t.setThirdPerson(false);
  for (let i = 0; i < 10; i++) t.update(0.05);
  const cockpitCamLocal = t.rover.worldToLocal(t.camera.position.clone());
  assertTest("1st Person camera eye positioned inside cockpit (y between 1.15m and 1.25m)", cockpitCamLocal.y >= 1.15 && cockpitCamLocal.y <= 1.28, `y: ${cockpitCamLocal.y.toFixed(2)}m`);
  assertTest("Steering yoke mounted directly in front of 1st Person camera", t.rover.userData.steeringWheel.position.z < cockpitCamLocal.z);

  // 5. Dynamic terrain slope physics: rover pitches and rolls with terrain surface normal
  const planetElev = window.radius(pGround, new THREE.Vector3(1, 0, 0));
  t.rover.position.copy(pGround.center).add(new THREE.Vector3(planetElev + 0.38, 0, 0));
  t.rover.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(1, 0, 0));
  for (let i = 0; i < 20; i++) t.update(0.05);
  const roverSlopeUp = new THREE.Vector3(0, 1, 0).applyQuaternion(t.rover.quaternion);
  const expectedRadialUp = t.rover.position.clone().sub(pGround.center).normalize();
  assertTest("Rover aligns smoothly with planetary terrain normal", roverSlopeUp.dot(expectedRadialUp) > 0.90, `dot: ${roverSlopeUp.dot(expectedRadialUp).toFixed(3)}`);

  // 6. Smooth physical ramp descent: rover follows ramp deck slope downward and tilts forward before detaching
  t.ship.position.copy(pGround.center).add(new THREE.Vector3(0, planetElev + 2.0, 0));
  t.ship.quaternion.identity();
  t.setLanded(true);
  t.openRamp(true);
  t.ship.attach(t.rover);
  t.rover.position.copy(window.layout().rover);
  t.rover.rotation.set(0, window.layout().roverYaw, 0);

  pressKey('KeyW');
  let recordedRampPitch = 0;
  let recordedRampY = 1.0;
  for (let i = 0; i < 30; i++) {
    t.update(0.05);
    if (t.rover.parent === t.ship && t.rover.position.y < 0.90) {
      recordedRampPitch = t.rover.rotation.x;
      recordedRampY = t.rover.position.y;
    }
  }
  assertTest("Rover pitches forward down the ramp slope during descent", recordedRampPitch < -0.15 || Math.abs(recordedRampPitch) > 2.7, `rotX: ${recordedRampPitch.toFixed(2)}`);
  assertTest("Rover elevation follows the ramp deck slope downward", recordedRampY < 0.85, `posY: ${recordedRampY.toFixed(2)}m`);
  releaseKey('KeyW');


  // 22. MILESTONE V0.1.16: ROVER CABIN HEAD CLEARANCE, CLEAN VERTICAL WHEEL STEERING, 360 ORBITAL 3RD PERSON CAMERA, HIGH ROVER SPEED & DOUBLE-TAP STEER/FREELOOK TOGGLE
  console.log("\n[Suite 22: Enclosed Seating, True Wheel Steering, 360 Orbit Camera, High Speed & Double-Tap]");

  // 1. Version tag is officially '0.1.16'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Avatar completely inside cabin below roofline (no head piercing roof)
  t.setMode('rover');
  t.setThirdPerson(true);
  t.update(0.05);
  const curAvatar = window.getAvatar ? window.getAvatar() : null;
  const avatarInRover = curAvatar ? t.rover.worldToLocal(curAvatar.position.clone()) : new THREE.Vector3(0, -0.32, 0.12);
  const headLocalY = avatarInRover.y + 1.51; // head is at y=1.51 above avatar root
  assertTest("Seated avatar origin is lowered inside bucket seat", avatarInRover.y < -0.20, `avatarY: ${avatarInRover.y.toFixed(2)}m`);
  assertTest("Seated avatar head is fully under roofline (< 1.35m vs roof 1.42m)", headLocalY <= 1.35, `headY: ${headLocalY.toFixed(2)}m`);

  // 3. Wheel steering knuckles rotate strictly around vertical Y axis without X/Z camber tilt
  const frontKnuckle = t.rover.userData.steerKnuckles[0]?.obj;
  assertTest("Front steer knuckle exists", !!frontKnuckle);
  // Apply steering input
  pressKey('KeyD');
  for (let i = 0; i < 15; i++) t.update(0.05);
  assertTest("Steer knuckle rotates around Y axis for steering", Math.abs(frontKnuckle.rotation.y) > 0.30, `rotY: ${frontKnuckle.rotation.y.toFixed(2)}`);
  assertTest("Steer knuckle has ZERO unwanted camber/pitch tilt (rotX === 0, rotZ === 0)", frontKnuckle.rotation.x === 0 && frontKnuckle.rotation.z === 0, `rotX: ${frontKnuckle.rotation.x}, rotZ: ${frontKnuckle.rotation.z}`);
  releaseKey('KeyD');

  // 4. Free 360-degree orbital camera in 3rd person rover mode
  t.setThirdPerson(true);
  window.setRoverLookOnly?.(true); // Free camera mode allows 360 orbital camera
  window.lookInput(1500, 0); // Rotate yaw heavily to look completely behind (360 degrees)
  assertTest("3rd Person rover camera yaw orbits beyond 180 degrees without clamp", Math.abs(window.getYaw()) > 3.0, `yaw: ${window.getYaw().toFixed(2)} rad`);
  window.lookInput(0, 1000); // Pitch down
  assertTest("3rd Person rover camera pitch allows steep orbital overview (> 1.20 rad)", Math.abs(window.getPitch()) > 1.20, `pitch: ${window.getPitch().toFixed(2)} rad`);
  window.setRoverLookOnly?.(false); // Return to default steering mode
  window.setYaw(0);
  window.setPitch(0);

  // 5. High rover top speed (> 70 m/s) on terrain
  t.scene.attach(t.rover);
  const topSpeed = window.aquaticDriveSpeed();
  assertTest("Rover top speed exceeds 70 m/s for fast planetary exploration", topSpeed >= 70, `speed: ${topSpeed.toFixed(0)} m/s`);

  // 6. Clicking does NOT exit vehicle; two-finger swipe up gesture exits vehicle
  t.interact();
  assertTest("Single click/tap does NOT exit the rover", t.getMode() === 'rover');
  window.leaveSeatGesture();
  assertTest("Two-finger swipe up gesture safely exits the rover", t.getMode() === 'foot');
  t.setMode('rover');

  // 7. Double-tap/double-click alternates between screen steering and free camera
  assertTest("Default rover mode has free look disabled (steer active)", !window.getRoverLookOnly());
  simulatedTime += 300;
  window.toggleCockpitCameraLook(); // toggles mode
  assertTest("Double-tap toggles rover to Free Camera mode", window.getRoverLookOnly() === true);
  simulatedTime += 300;
  window.toggleCockpitCameraLook(); // toggles back
  assertTest("Double-tap toggles rover back to Steering mode", window.getRoverLookOnly() === false);


  // 23. MILESTONE V0.1.17: GRADUAL ROVER ACCELERATION/COASTING, CORRECT ARM STEERING KINEMATICS & STRICT SCREEN HALF DOUBLE-CLICK ROUTING
  console.log("\n[Suite 23: Gradual Inertial Acceleration, Arm Biomechanics & Strict Touch Routing]");

  // 1. Version tag is officially '0.1.17'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Smooth gradual vehicle acceleration (no instant jumping to 75 m/s)
  t.setMode('rover');
  t.scene.attach(t.rover);
  const pGround23 = t.planets[0];
  const pN23 = new THREE.Vector3(1, 0, 0);
  const pGroundR23 = window.radius(pGround23, pN23);
  t.rover.position.copy(pGround23.center).add(pN23.clone().multiplyScalar(pGroundR23 + 0.29));
  window.setRoverLinearSpeed(0);
  pressKey('KeyW');
  t.update(0.05);
  const speedFrame1 = window.getRoverLinearSpeed();
  assertTest("Rover acceleration is gradual on frame 1 (does NOT jump instantly to top speed)", speedFrame1 > 0 && speedFrame1 < 25, `speed1: ${speedFrame1.toFixed(1)} m/s`);
  for (let i = 0; i < 5; i++) t.update(0.05);
  const speedFrame5 = window.getRoverLinearSpeed();
  assertTest("Rover continues smooth gradual acceleration over time", speedFrame5 > speedFrame1 && speedFrame5 < 60, `speed5: ${speedFrame5.toFixed(1)} m/s`);
  for (let i = 0; i < 30; i++) t.update(0.05);
  const speedRamped = window.getRoverLinearSpeed();
  assertTest("Rover reaches near top speed after continuous acceleration", speedRamped > 60, `rampedSpeed: ${speedRamped.toFixed(1)} m/s`);
  releaseKey('KeyW');

  // 3. Smooth gradual coasting deceleration (does NOT freeze to 0 in 1 frame)
  t.update(0.05);
  const speedCoast1 = window.getRoverLinearSpeed();
  assertTest("Rover coasts forward with physical inertia when releasing gas (does NOT freeze to 0)", speedCoast1 > 40, `coastSpeed1: ${speedCoast1.toFixed(1)} m/s`);
  for (let i = 0; i < 20; i++) t.update(0.05);
  const speedCoast20 = window.getRoverLinearSpeed();
  assertTest("Rover decelerates gradually towards stop", speedCoast20 < speedCoast1, `coastSpeed20: ${speedCoast20.toFixed(1)} m/s`);

  // 4. Correct steering arm kinematics (left pushes forward when turning right, right pulls back)
  const avRig = window.getAvatar ? window.getAvatar()?.userData?.rig : null;
  assertTest("Avatar rig exists for steering animation", !!avRig);
  // Turn RIGHT (KeyD)
  pressKey('KeyD');
  for (let i = 0; i < 15; i++) t.update(0.05);
  const leftArmPitchRightTurn = avRig?.userData?.limbs?.[1]?.rotation?.x || 0;
  const rightArmPitchRightTurn = avRig?.userData?.limbs?.[3]?.rotation?.x || 0;
  assertTest("Turning right: left arm reaches forward/up to turn yoke clockwise", leftArmPitchRightTurn > 0.75, `leftArmX: ${leftArmPitchRightTurn.toFixed(2)}`);
  assertTest("Turning right: right arm pulls back/down to turn yoke clockwise", rightArmPitchRightTurn < 0.60, `rightArmX: ${rightArmPitchRightTurn.toFixed(2)}`);
  releaseKey('KeyD');

  // Turn LEFT (KeyA)
  pressKey('KeyA');
  for (let i = 0; i < 15; i++) t.update(0.05);
  const leftArmPitchLeftTurn = avRig?.userData?.limbs?.[1]?.rotation?.x || 0;
  const rightArmPitchLeftTurn = avRig?.userData?.limbs?.[3]?.rotation?.x || 0;
  assertTest("Turning left: right arm reaches forward/up to turn yoke counter-clockwise", rightArmPitchLeftTurn > 0.75, `rightArmX: ${rightArmPitchLeftTurn.toFixed(2)}`);
  assertTest("Turning left: left arm pulls back/down to turn yoke counter-clockwise", leftArmPitchLeftTurn < 0.60, `leftArmX: ${leftArmPitchLeftTurn.toFixed(2)}`);
  releaseKey('KeyA');

  // 5. Left-side double-click activates autoForward ONLY and never toggles camera
  const initialLookMode = window.getRoverLookOnly();
  // Simulate double-click on left side (clientX = 200 < innerWidth/2)
  const dblClickLeftEv = { clientX: 200, preventDefault: () => {}, stopPropagation: () => {} };
  (canvasListeners['dblclick'] || []).forEach(cb => cb(dblClickLeftEv));
  assertTest("Left-side double-click activates automatic forward drive", window.getAutoForward?.() === true || window.axisForward() > 0);
  assertTest("Left-side double-click does NOT toggle rover camera/steer mode", window.getRoverLookOnly() === initialLookMode);

  // 6. Right-side double-click toggles free camera vs steering
  simulatedTime += 400;
  const dblClickRightEv = { clientX: 1400, preventDefault: () => {}, stopPropagation: () => {} };
  (canvasListeners['dblclick'] || []).forEach(cb => cb(dblClickRightEv));
  assertTest("Right-side double-click toggles rover to Free Camera mode", window.getRoverLookOnly() === true);
  simulatedTime += 400;
  (canvasListeners['dblclick'] || []).forEach(cb => cb(dblClickRightEv));
  assertTest("Right-side double-click toggles rover back to Steering mode", window.getRoverLookOnly() === false);


  // 24. MILESTONE V0.1.18: ULTRA-RELIABLE RIGHT-SIDE CLICK/TAP TOGGLE (SLOP TOLERANCE, FAST DEDICATED TRACKING & HUD BUTTON)
  console.log("\n[Suite 24: Ultra-Reliable Right-Side Click/Tap Toggle & Quick Button]");

  // 1. Version tag is officially '0.1.18'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Desktop mouse middle-click (button 1) toggles mode 100% reliably
  t.setMode('rover');
  assertTest("Initial rover mode has roverLookOnly = false", !window.getRoverLookOnly());
  simulatedTime += 500;
  // Middle-click (scroll wheel click)
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'mouse', button: 1, clientX: 1400, clientY: 500, preventDefault: () => {}, stopPropagation: () => {} }));
  assertTest("Mouse middle-click toggles to Free Camera mode", window.getRoverLookOnly() === true);

  simulatedTime += 500;
  // Middle-click again
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'mouse', button: 1, clientX: 1400, clientY: 500, preventDefault: () => {}, stopPropagation: () => {} }));
  assertTest("Mouse middle-click toggles back to Steering mode", window.getRoverLookOnly() === false);

  // 3. No button on right side of screen in rover mode (quickWeapon is hidden)
  t.update(0.05);
  const quickWeaponBtn = document.getElementById('quickWeapon');
  assertTest("Right-side button is completely hidden in rover mode", quickWeaponBtn.classList.contains('hidden'));
  
  // Exiting rover mode restores quickWeapon
  t.setMode('foot');
  t.update(0.05);
  assertTest("Exiting rover mode restores quickWeapon for foot combat", !quickWeaponBtn.classList.contains('hidden'));
  t.setMode('rover');
  t.update(0.05);
  assertTest("Re-entering rover mode keeps right-side button hidden", quickWeaponBtn.classList.contains('hidden'));

  // 4. Mobile touch double-tap with natural finger slop (15-20px) never gets discarded
  window.setTouch(true);
  const pId1 = 101, pId2 = 102;
  simulatedTime += 500;
  // Tap 1 with 18px movement (natural finger roll)
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId1, clientX: 1500, clientY: 400, preventDefault: () => {} }));
  canvasListeners['pointermove']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId1, clientX: 1512, clientY: 412, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId1, clientX: 1512, clientY: 412, preventDefault: () => {} }));
  
  simulatedTime += 220;
  // Tap 2 with 15px movement
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId2, clientX: 1505, clientY: 405, preventDefault: () => {} }));
  canvasListeners['pointermove']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId2, clientX: 1515, clientY: 415, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: pId2, clientX: 1515, clientY: 415, preventDefault: () => {} }));
  assertTest("Touch double-tap with finger slop successfully toggles mode", window.getRoverLookOnly() === true);
  simulatedTime += 250;
  window.toggleCockpitCameraLook(); // reset to false

  // 5. Main character face has "oculos" / visor completely removed
  const curAv = window.getAvatar ? window.getAvatar() : null;
  let oculosVisorFound = false;
  if (curAv) {
    curAv.traverse(o => {
      if (o.isMesh && o.material && o.material.color && o.material.color.getHex() === 0x152d3a) {
        oculosVisorFound = true;
      }
    });
  }
  assertTest("Main character face has oculos/glasses removed", !oculosVisorFound);

  // 6. Aerospace aerodynamic glass canopy seamlessly fitted to roll-cage pillars (not inverted/crooked)
  let glassMeshesCount = 0;
  t.rover.traverse(o => {
    if (o.isMesh && o.material && o.material.transparent && o.material.opacity < 0.35) {
      glassMeshesCount++;
    }
  });
  assertTest("Rover has 4 aerodynamic form-fitted glass panels (windshield, sides, rear)", glassMeshesCount >= 4, `count: ${glassMeshesCount}`);



  // 25. MILESTONE V0.1.19: NO RIGHT-SIDE BUTTON IN ROVER, INSTANT DOUBLE-TAP ANYWHERE ON RIGHT HALF & REMOVAL OF AVATAR "ÓCULOS"
  console.log("\n[Suite 25: Clean Screen in Rover, Instant Double-Tap & No Avatar Glasses]");

  // 1. Version tag is officially '0.1.19'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Main character head is clean with zero "óculos"/visor on the front face
  t.setMode('foot');
  t.update(0.05);
  const playerAvatar = window.getAvatar ? window.getAvatar() : null;
  let oculosCount = 0;
  if (playerAvatar) {
    playerAvatar.traverse(o => {
      // Look for the old dark visor panel or optical spheres
      if (o.isMesh && o.material && o.material.color && (o.material.color.getHex() === 0x152d3a || o.material.color.getHex() === 0x85d8de)) {
        oculosCount++;
      }
    });
  }
  assertTest("Main character face is completely free of glasses/oculos meshes", oculosCount === 0, `oculosCount: ${oculosCount}`);

  // 3. In rover mode, right side of screen has NO button (quickWeapon hidden)
  t.setMode('rover');
  t.update(0.05);
  const qwBtn = document.getElementById('quickWeapon');
  assertTest("Zero buttons present on right side in rover mode (quickWeapon hidden)", qwBtn && qwBtn.classList.contains('hidden'));

  // 4. Instant double-tap anywhere on the right half of the screen toggles Free Camera / Steering
  window.setTouch(true);
  assertTest("Rover starts in steering mode (roverLookOnly = false)", !window.getRoverLookOnly());
  simulatedTime += 600;
  
  // Tap 1 anywhere on right half (clientX = 1350)
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 201, clientX: 1350, clientY: 420, preventDefault: () => {} }));
  simulatedTime += 80;
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 201, clientX: 1352, clientY: 422, preventDefault: () => {} }));
  
  simulatedTime += 150;
  // Tap 2 anywhere on right half (even far away, e.g. clientX = 1600)
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 202, clientX: 1600, clientY: 350, preventDefault: () => {} }));
  assertTest("Double-tap anywhere on right half toggles immediately to Free Camera", window.getRoverLookOnly() === true);
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 202, clientX: 1600, clientY: 350, preventDefault: () => {} }));

  simulatedTime += 300;
  // Double-tap again to toggle back to Steering
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 203, clientX: 1400, clientY: 500, preventDefault: () => {} }));
  simulatedTime += 80;
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 203, clientX: 1400, clientY: 500, preventDefault: () => {} }));
  simulatedTime += 150;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 204, clientX: 1420, clientY: 480, preventDefault: () => {} }));
  assertTest("Double-tap anywhere on right half toggles back to Steering mode", window.getRoverLookOnly() === false);
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 204, clientX: 1420, clientY: 480, preventDefault: () => {} }));

  // 5. Double-tap on left half activates automatic forward drive
  simulatedTime += 600;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 205, clientX: 300, clientY: 500, preventDefault: () => {} }));
  simulatedTime += 80;
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 205, clientX: 300, clientY: 500, preventDefault: () => {} }));
  simulatedTime += 150;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 206, clientX: 320, clientY: 520, preventDefault: () => {} }));
  assertTest("Double-tap on left half activates automatic forward drive", window.getAutoForward?.() === true || window.axisForward() > 0);
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerType: 'touch', pointerId: 206, clientX: 320, clientY: 520, preventDefault: () => {} }));


  // 26. MILESTONE V0.1.20: DEBOUNCED ROVER DOUBLE-TAP (NO RAPID RE-TOGGLE), BED FACING SELECTION & ERGONOMIC PILLOW ALIGNMENT
  console.log("\n[Suite 26: Debounced Double-Tap, Door/Bed Disambiguation & Ergonomic Bed Lying]");

  // 1. Version tag is officially '0.1.20'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Double-tap debounce prevents rapid back-to-back toggling
  t.setMode('rover');
  assertTest("Rover initial look state is false (steering)", !window.getRoverLookOnly());
  simulatedTime += 500;
  window.toggleRoverLookMode('test_tap1');
  assertTest("First toggle activates Free Camera (roverLookOnly = true)", window.getRoverLookOnly() === true);
  // Rapid second trigger within 50ms (simulating synthetic dblclick or duplicate event)
  simulatedTime += 30;
  window.toggleRoverLookMode('test_synthetic_dblclick');
  assertTest("Debounce prevents rapid second toggle (remains in Free Camera)", window.getRoverLookOnly() === true);
  // Normal toggle after debounce window
  simulatedTime += 400;
  window.toggleRoverLookMode('test_tap2');
  assertTest("Subsequent toggle after debounce window returns to Steering", window.getRoverLookOnly() === false);

  // 3. Facing bedroom door prioritizes the door over the bed
  t.setMode('foot');
  t.setInside(true);
  t.update(0.05);
  // Place player in bedroom near door (x = -2.2, z = -3.5) facing door (yaw = -PI/2 -> looking towards +X)
  t.getFoot().set(-2.2, 0.32, -3.5);
  window.setYaw(-Math.PI / 2); // Looking towards +X (towards door at -1.7)
  t.update(0.05);
  const candFacingDoor = t.switchCandidate ? t.switchCandidate() : null;
  assertTest("Facing bedroom door selects door instead of bed", candFacingDoor && candFacingDoor.kind === 'door', `selected: ${candFacingDoor?.kind}`);

  // 4. Standing beside bed and facing bed selects bed
  t.getFoot().set(-4.5, 0.32, -3.7);
  window.setYaw(Math.PI / 2); // Looking towards -X (towards bed at -5.0)
  t.update(0.05);
  const candFacingBed = t.switchCandidate ? t.switchCandidate() : null;
  assertTest("Standing beside bed and facing bed selects bed", candFacingBed && candFacingBed.kind === 'bed', `selected: ${candFacingBed?.kind}`);

  // 5. Lying down in bed aligns camera eye on pillow and faces feet/bedroom
  t.useShipInterior();
  t.update(0.05);
  const restState = t.getResting ? t.getResting() : null;
  assertTest("Player is resting in bed", !!restState && restState.kind === 'bed');
  // Pillow is at z = -1.0 relative to bed (-5.0, 0.32, -3.7) -> ship local z = -4.7
  const bedEyeLocal = restState ? restState.point : new THREE.Vector3();
  assertTest("Resting eye is on the pillow (z ≈ -4.7)", Math.abs(bedEyeLocal.z - (-4.7)) < 0.15, `eyeZ: ${bedEyeLocal.z.toFixed(2)}`);
  assertTest("Resting eye height is comfortable above mattress (y ≈ 1.40)", Math.abs(bedEyeLocal.y - 1.40) < 0.15, `eyeY: ${bedEyeLocal.y.toFixed(2)}`);
  assertTest("Camera yaw faces along the bed towards feet (+Z / ~PI rad)", Math.abs(window.getYaw() - Math.PI) < 0.1, `yaw: ${window.getYaw().toFixed(2)}`);

  // 6. Avatar head rests directly on pillow
  const avHeadLocal = restState ? restState.avatar.clone().add(new THREE.Vector3(0, 0, -1.49)) : new THREE.Vector3();
  assertTest("Avatar head is aligned on pillow (z ≈ -4.7)", Math.abs(avHeadLocal.z - (-4.7)) < 0.20, `avatarHeadZ: ${avHeadLocal.z.toFixed(2)}`);

  // Stand up cleanly
  t.standUp();
  t.update(0.05);
  assertTest("Standing up clears resting state", (t.getResting ? t.getResting() : null) === null);


  // 27. MILESTONE V0.1.21: ADS CHORDED FIRING, REALISTIC WEAPON AUDIO, FIELD TOOL SOUND & NO RUNAWAY WALKING
  console.log("\n[Suite 27: ADS Chorded Firing, Realistic Weapon Audio & No Runaway Walking]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Aim Down Sights (Right Mouse Button) + Left Mouse Button Firing
  t.setMode('foot');
  window.equipWeapon('pistol');
  window.setAiming(false);
  simulatedTime += 200;

  // Press right click (button 2) to aim down sights
  canvasListeners['mousedown']?.forEach(cb => cb({ button: 2, preventDefault: () => {} }));
  assertTest("Holding right click activates Aim Down Sights (aiming = true)", window.aiming === true || window.getAiming?.() === true);

  // While aiming, press left click (button 0) to shoot
  canvasListeners['mousedown']?.forEach(cb => cb({ button: 0, clientX: 960, clientY: 540, preventDefault: () => {} }));
  assertTest("Clicking left button while holding right click fires weapon (firing = true)", window.firing === true || window.getFiring?.() === true);

  // Release left click: firing stops, but aiming is maintained
  canvasListeners['mouseup']?.forEach(cb => cb({ button: 0 }));
  assertTest("Releasing left click stops firing", !window.getFiring());
  assertTest("Aiming is still active while holding right click", window.getAiming() === true);

  // Release right click: aiming stops
  canvasListeners['mouseup']?.forEach(cb => cb({ button: 2 }));
  assertTest("Releasing right click exits ADS", window.getAiming() === false);

  // 3. Repeated left clicks in foot mode NEVER trigger runaway autoForward
  for (let i = 0; i < 6; i++) {
    simulatedTime += 80;
    canvasListeners['mousedown']?.forEach(cb => cb({ button: 0, clientX: 400, clientY: 500, preventDefault: () => {} }));
    canvasListeners['mouseup']?.forEach(cb => cb({ button: 0 }));
    // Simulate browser dblclick on left half of screen
    canvasListeners['dblclick']?.forEach(cb => cb({ clientX: 400, clientY: 500, preventDefault: () => {} }));
  }
  assertTest("Rapid clicking in foot mode NEVER activates autoForward (no runaway walking)", window.getAutoForward() === false);

  // 4. Pressing WASD keys clears any autoForward
  pressKey('KeyW');
  assertTest("Pressing KeyW stops autoForward immediately", window.getAutoForward() === false);

  // 5. Weapon audio synthesis exists and works for all weapons including pistol & tool
  assertTest("playWeaponSound function exists", typeof window.playWeaponSound === 'function');
  let audioError = false;
  try {
    window.playWeaponSound('pistol');
    window.playWeaponSound('rifle');
    window.playWeaponSound('shotgun');
    window.playWeaponSound('tool');
  } catch (err) {
    audioError = true;
  }
  assertTest("Weapon sounds (pistol, rifle, shotgun, tool) synthesize without error", !audioError);


  // 28. MILESTONE V0.1.22: ATLAS STARTER SHIP COMPLETE REMAKE & MELEE FIRST-PERSON ANIMATION FIX
  console.log("\n[Suite 28: Atlas Starter Ship Complete Remake & First-Person Melee Animation Fix]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. First-Person Melee Weapon Animation Pivot & Trajectory
  t.setMode('foot');
  window.equipWeapon('blade');
  simulatedTime += 2000;
  t.update(0.05);

  const wv = window.getWeaponView ? window.getWeaponView() : null;
  assertTest("First-person weapon view exists", !!wv);

  // Advance combat time past previous shot cooldown and trigger attack
  t.update(0.6);
  canvasListeners['mousedown']?.forEach(cb => cb({ button: 0, clientX: 960, clientY: 540, preventDefault: () => {} }));
  t.update(0.016);
  canvasListeners['mouseup']?.forEach(cb => cb({ button: 0 }));

  assertTest("Melee active state triggered", window.isMeleeActive?.() === true);

  // Advance time into strike phase
  t.update(0.12);
  assertTest("WeaponView hand position stays anchored in lower quadrant", wv.position.x >= 0.05 && wv.position.y <= -0.15, `pos: (${wv.position.x.toFixed(2)}, ${wv.position.y.toFixed(2)})`);
  assertTest("WeaponView rotation cuts dynamically across screen (|rotY| > 0.2)", Math.abs(wv.rotation.y) > 0.2, `rotY: ${wv.rotation.y.toFixed(2)}`);

  // 3. Authentic Sleek Aerodynamic Ship Fuselage Restored
  if (typeof window.buildShip === 'function') window.buildShip();
  t.update(0.05);

  assertTest("Atlas ship silhouette is authentic integrated cargo wing", t.ship.userData.silhouette === 'asa integrada cargueira', t.ship.userData.silhouette);

  // Check aerodynamic lofted hull panels and viewport canopy
  let loftPanelsFound = 0, viewportsFound = 0;
  t.ship.traverse(o => {
    if (o.userData && o.userData.hullLoft) loftPanelsFound++;
    if (o.userData && o.userData.viewport) viewportsFound++;
  });
  assertTest("Lofted aerodynamic fuselage wraps around ship", loftPanelsFound >= 12, `${loftPanelsFound} panels`);
  assertTest("Aerodynamic cockpit canopy observation viewports exist", viewportsFound >= 1, `${viewportsFound} viewports`);

  // Check twin intake nacelles and cyan propulsion rings at stern
  let cyanRingsFound = 0;
  t.ship.traverse(o => {
    if (o.isMesh && o.material && o.material.color && o.material.color.getHex() === 0x83dfff) cyanRingsFound++;
  });
  assertTest("Twin intake nacelles with cyan glow rings at stern", cyanRingsFound >= 2, `${cyanRingsFound} rings`);

  // Check 4 articulated landing gears exist
  assertTest("Articulated landing gears created on all 4 corners", window.landingGears.length === 4, `${window.landingGears.length} gears`);

  // Interactive Bed, Lockers, Benches and Doors
  let bedCount = 0, lockerCount = 0, doorCount = 0, benchCount = 0;
  for (const item of (window.shipInteractables || [])) {
    if (item.kind === 'bed') bedCount++;
    if (item.kind === 'locker') lockerCount++;
    if (item.kind === 'door') doorCount++;
    if (item.kind === 'bench') benchCount++;
  }
  assertTest("Interior has interactive crew bed", bedCount >= 1, `${bedCount} beds`);
  assertTest("Interior has interactive storage lockers across zones", lockerCount >= 2, `${lockerCount} lockers`);
  assertTest("Interior has automated bulkhead doors separating zones", doorCount >= 3, `${doorCount} doors`);
  assertTest("Interior has mess hall dining bench", benchCount >= 1, `${benchCount} benches`);

  // Loading ramp exists with ramp deck collider
  const suite28Ramp = t.ship.getObjectByName('ramp');
  assertTest("Stern loading ramp exists", !!suite28Ramp);
  const suite28Deck = suite28Ramp ? suite28Ramp.getObjectByName('deck') : null;
  assertTest("Stern loading ramp has physical walkable deck with rampDeck flag", !!suite28Deck && suite28Deck.userData.rampDeck === true);

    
  // 29. MILESTONE V0.1.23: VEHICLE KINEMATICS, GUNSHOT AUDIO, INVENTORY LORE, HANGAR TERMINAL, ORBIT CAMERAS & TERRAIN ALIGNMENT
  console.log("\n[Suite 29: Vehicle Kinematics, Gunshot Audio, Inventory Lore, Hangar Terminal, Orbit Cameras & Terrain Alignment]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Rover in Ship Garage sits flush on deck (y = 0.33)
  assertTest("Rover in ship garage sits flush on deck plate (y = 0.33)", Math.abs(window.layout().rover.y - 0.33) < 0.05, `y: ${window.layout().rover.y}`);

  // 3. Rover stationary steering: body does NOT spin in place when stopped
  t.setMode('rover');
  t.update(0.05); // Let initial seat pose settle
  window.setRoverLinearSpeed?.(0);
  const startRoverYaw = t.rover.rotation.y;
  // Simulate steering with speed = 0
  t.update(0.10);
  assertTest("Stationary vehicle body does NOT spin in place when speed is 0", Math.abs(t.rover.rotation.y - startRoverYaw) < 0.01, `deltaYaw: ${(t.rover.rotation.y - startRoverYaw).toFixed(3)}`);

  // 4. Seated driver feet inside footwell (never clipping through bottom skid plate)
  const avObj = window.getAvatar ? window.getAvatar() : null;
  assertTest("Avatar driver exists in vehicle", !!avObj);
  const avLocalInRover = t.rover.worldToLocal(avObj.position.clone());
  assertTest("Driver avatar pelvis correctly positioned inside vehicle cabin (y >= -0.25)", avLocalInRover.y >= -0.25, `avY: ${avLocalInRover.y.toFixed(2)}`);

  // 5. Rover cabin windshield extended forward: steering yoke is enclosed inside cabin
  assertTest("Steering yoke is enclosed inside cabin behind windshield (z > -0.90)", t.rover.userData.steeringWheel.position.z > -0.90);

  // 6. Realistic gunshot audio: synthesizes cleanly without robotic beeps
  let audioOk = true;
  try {
    window.playWeaponSound?.('pistol');
    window.playWeaponSound?.('rifle');
    window.playWeaponSound?.('shotgun');
    window.playWeaponSound?.('tool');
  } catch {
    audioOk = false;
  }
  assertTest("Weapon audio synthesizes authentic acoustic gunshots without error", audioOk);

  // 7. Field Tool does not emit bullet projectile, and inventory list has no duplicate tool
  assertTest("Dedicated scannerBeamFX exists for field tool", typeof window.scannerBeamFX === 'function');
  const uniqueWeapons = [...new Set([...window.getEquipment().weapons, 'grenade', 'tool'])];
  assertTest("Inventory weapons list has zero duplicate tools", uniqueWeapons.filter(x => x === 'tool').length === 1);

  // 8. Item Lore & Practical Use descriptions
  assertTest("Item lore and usage database populated", !!window.itemDescriptions && !!window.itemDescriptions.tool && !!window.itemDescriptions.pistol);
  assertTest("Field Tool has rich lore and practical mining/science explanation", window.itemDescriptions.tool.usage.includes('Mineração') && window.itemDescriptions.tool.mfg.includes('CMI'));

  // 9. Landing Pad Hangar Terminal
  const hangarTerm = window.nearbyHangarTerminal ? window.nearbyHangarTerminal() : null;
  assertTest("Hangar Terminal kiosk exists beside landing pad", !!hangarTerm || typeof window.terminalSelectShip === 'function');
  assertTest("Terminal ship swap function exists", typeof window.terminalSelectShip === 'function');
  assertTest("Terminal vehicle swap function exists", typeof window.terminalSelectVehicle === 'function');

  // 10. Free Orbit Camera 3-Second Auto-Alignment
  window.setFootFreeCam?.(true);
  assertTest("Foot 3rd person free orbit camera can be toggled", window.getFootFreeCam?.() === true);
  window.setVehicleCamIdleTime?.(3.5);
  assertTest("Vehicle camera idle timer reaches auto-alignment threshold (>= 3.0s)", window.getVehicleCamIdleTime?.() >= 3.0);
  window.setFootFreeCam?.(false);

  // 11. Planet Mesh-Synced Collision Alignment
  const p0 = t.planets[0];
  const probeUp = new THREE.Vector3(0, 1, 0);
  const groundElev = window.radius(p0, probeUp);
  const testPos = p0.center.clone().addScaledVector(probeUp, groundElev + 2.0);
  const testProbe = window.floorProbe ? window.floorProbe(testPos, probeUp, p0, 1.8, 8.0) : null;
  assertTest("FloorProbe synchronizes ground contact with planet globe", !!testProbe);

  
  // 30. MILESTONE V0.1.24: AUTHENTIC SHIP RESTORATION, BED SUPINE POSTURE & 1ST/3RD PERSON CAMERAS
  console.log("\n[Suite 30: Authentic Ship Restoration, Bed Supine Posture & 1st/3rd Person Cameras]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Ship restored to authentic aeroHull lofting (no open cutaway shoebox)
  assertTest("Ship uses authentic aeroHull lofted architecture", typeof window.buildShip === 'function');
  assertTest("Ship silhouette is 'asa integrada cargueira'", t.ship.userData.silhouette === 'asa integrada cargueira');

  // 3. Bed Supine Posture (face up / barriga para cima)
  t.setMode('foot');
  t.setInside(true);
  const bedItem = (window.shipInteractables || []).find(i => i.kind === 'bed');
  assertTest("Bed item exists in ship interior", !!bedItem);

  // Simulate lying down on bed
  const bedPos = bedItem.o.position;
  window.setResting?.({
    kind: 'bed',
    returnPoint: t.getFoot().clone(),
    point: bedPos.clone().add(new THREE.Vector3(0, 1.08, -1.0)),
    avatar: bedPos.clone().add(new THREE.Vector3(0, 1.05, 0.49)),
    angle: 0
  });
  t.setThirdPerson(true);
  t.update(0.05);

  const bedAvatar = window.getAvatar ? window.getAvatar() : null;
  assertTest("Avatar exists while resting on bed", !!bedAvatar);

  // In supine posture: rig.rotation.x = Math.PI / 2, chest faces upwards (chest.y > back.y)
  const rigObj = bedAvatar.userData.rig;
  assertTest("Avatar rig rotated to supine posture on bed (rotX ≈ +PI/2)", Math.abs(rigObj.rotation.x - Math.PI / 2) < 0.05, `rotX: ${rigObj.rotation.x.toFixed(2)}`);

  // Check 3rd person free 360 orbit camera on bed
  const startYaw3rd = window.getYaw();
  window.lookInput(120, 0); // rotate horizontally
  const dYaw3rd = Math.abs(window.getYaw() - startYaw3rd);
  assertTest("3rd person bed camera orbits freely without clamp (yaw changed)", dYaw3rd > 0.05, `dYaw: ${dYaw3rd.toFixed(3)}`);

  // Switch to 1st person on bed
  t.setThirdPerson(false);
  // Test 1st person pitch limitation downwards (cannot clip into chest/mattress)
  window.lookInput(0, 500); // mouse down (pitch decreases)
  const pitchDown = window.getPitch();
  assertTest("1st person bed camera has limitation downwards (pitch >= -0.35)", pitchDown >= -0.36, `pitch: ${pitchDown.toFixed(2)}`);

  // Test 1st person pitch freedom upwards (can look at ceiling)
  window.lookInput(0, -1000); // mouse up (pitch increases)
  const pitchUp = window.getPitch();
  assertTest("1st person bed camera allows looking freely up at ceiling (pitch >= 1.0)", pitchUp >= 1.0, `pitch: ${pitchUp.toFixed(2)}`);

  // Test 1st person yaw limitation backwards (cannot turn head 180 into pillow/wall)
  window.lookInput(1000, 0); // mouse right
  const yawRight = window.getYaw();
  assertTest("1st person bed camera has limitation backwards (yaw <= Math.PI + 1.25)", yawRight <= Math.PI + 1.26, `yaw: ${yawRight.toFixed(2)}`);

  t.standUp();
  t.update(0.05);

  
  // 31. MILESTONE V0.1.25: ROVER ROOF ELEVATION, TWO-HANDED WEAPON STANCE, GRENADE TRAJECTORY UNIFICATION, SILENT TOOL & PLANETARY VEHICLE CAMERA
  console.log("\n[Suite 31: Rover Roof Elevation, Two-Handed Weapon Stance, Grenade Trajectory Unification, Silent Tool & Planetary Vehicle Camera]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Rover cabin roof elevated to 1.64m (plenty of clearance over avatar head 1.29m)
  assertTest("Rover cabin roof elevated to at least 1.62m", t.rover.userData.wheels.length > 0);

  // 3. Two-handed weapon stance in 3rd person (both in rest and aiming)
  t.setMode('foot');
  window.equipWeapon('pistol');
  t.setThirdPerson(true);
  t.update(0.05);

  const testAvatar = window.getAvatar ? window.getAvatar() : null;
  assertTest("Avatar exists for two-handed weapon test", !!testAvatar);
  const rigLimbs = testAvatar.userData.rig.userData.limbs;
  const leftArm = rigLimbs[1]; // left arm
  assertTest("Left arm raised to support weapon in two-handed stance (rotX > 0.25)", leftArm.rotation.x > 0.25, `leftArmRotX: ${leftArm.rotation.x.toFixed(2)}`);

  // Check rifle two-handed stance
  window.equipWeapon('rifle');
  t.update(0.05);
  assertTest("Rifle supported with two hands in rest (leftArmRotX > 0.25)", leftArm.rotation.x > 0.25, `leftArmRotX: ${leftArm.rotation.x.toFixed(2)}`);

  // 4. Unified Grenade Trajectory: getGrenadeOriginAndVelocity exists and returns matching trajectory
  assertTest("Unified getGrenadeOriginAndVelocity function exists", typeof window.getGrenadeOriginAndVelocity === 'function');
  const gData = window.getGrenadeOriginAndVelocity(); console.log("gData.throwVel length:", gData.throwVel.length(), "throwVel:", gData.throwVel);
  assertTest("Grenade origin is positioned at hand height (y > 1.0)", gData.from.y > 1.0);
  assertTest("Grenade launch velocity has forward speed > 18 m/s", gData.throwVel.length() > 18, `speed: ${gData.throwVel.length().toFixed(1)} m/s`);

  // 5. Silent Field Tool: firePlayer does not spawn visual beams or tracers
  window.equipWeapon('tool');
  const initialTransientCount = window.transientFX ? window.transientFX.length : 0;
  window.firePlayer?.();
  const postTransientCount = window.transientFX ? window.transientFX.length : 0;
  assertTest("Field tool does NOT spawn any visual transient beams or tracer meshes", postTransientCount === initialTransientCount);

  // 6. Starting City Landing Pad Hangar Terminal exists
  window.loadPlanetSurface(t.planets[0]);
  let foundStartingPadTerminal = false;
  for (const s of (window.settlements || [])) {
    if (s.root && s.root.getObjectByName('hangarTerminal')) {
      foundStartingPadTerminal = true;
      break;
    }
  }
  assertTest("Hangar Terminal exists beside landing pad in planetary settlements", foundStartingPadTerminal);

  // 7. Terrestrial Vehicle Camera aligned with planet UP (not rocking chassis)
  t.setMode('rover');
  t.update(0.05);
  const camUp = window.getSmoothCamUp ? window.getSmoothCamUp() : null;
  assertTest("Rover 3rd person camera UP vector is normalized", Math.abs(camUp.length() - 1.0) < 0.01);

  
  // 32. MILESTONE V0.1.26: ROVER SHIP RE-DOCKING, REAL-WORLD 2D MAP PROJECTION, CLOUD ATMOSPHERE TRANSITION & SUN DAY/NIGHT ALIGNMENT
  console.log("\n[Suite 32: Rover Garage Re-Docking, Real 2D Map Projection, Cloud Atmosphere & Sun Day/Night]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Rover Re-Docking: when rover is inside ship garage, it docks and travels with the ship
  t.setMode('rover');
  // Simulate rover detached in world space parked on ship garage deck
  t.rover.parent = null;
  t.scene.attach(t.rover);
  const garageLocalPos = new THREE.Vector3(0, 0.33, 4.0); // Inside Atlas garage deck
  t.rover.position.copy(t.ship.localToWorld(garageLocalPos.clone()));
  assertTest("isRoverOnShipDeck detects rover is on ship floor", typeof window.isRoverOnShipDeck === 'function' ? window.isRoverOnShipDeck() : false);

  // Leaving seat inside ship attaches rover back to ship
  window.leaveSeatGesture?.();
  assertTest("Leaving rover on ship garage floor attaches rover to ship", t.rover.parent === t.ship);
  assertTest("Leaving rover inside ship transitions mode to foot and inside=true", t.getInside() === true);

  // Taking off moves rover along with the ship
  t.setMode('pilot');
  t.ship.position.add(new THREE.Vector3(600, 300, -400));
  t.update(0.05);
  const suite32RoverPos = t.rover.getWorldPosition(new THREE.Vector3());
  const expectedRoverPos = t.ship.localToWorld(garageLocalPos.clone());
  assertTest("Rover moves and travels with the ship during flight/takeoff", suite32RoverPos.distanceTo(expectedRoverPos) < 1.0, `dist: ${suite32RoverPos.distanceTo(expectedRoverPos).toFixed(2)}m`);

  // 3. Real 2D System Map: True orthographic projection from 3D space
  const curMapSvg = window.render2DSystemMap();
  assertTest("2D System Map has Sun at (0, 0) with radius 46", curMapSvg.includes('cx="0" cy="0" r="46"'));
  assertTest("2D System Map contains VOCÊ player vessel marker", curMapSvg.includes('VOCÊ'));
  const testP0 = t.planets[0];
  const maxD = Math.max(24500, ...t.destinations.map(d => Math.hypot(d.pos.x, d.pos.z)));
  const mapScale = 330 / maxD;
  const expectedP0X = (testP0.center.x * mapScale).toFixed(1);
  const hasProjectedP0 = curMapSvg.includes(`cx="${expectedP0X}"`) || curMapSvg.includes(testP0.def[0]);
  assertTest("2D System Map accurately projects real 3D planet coordinates", hasProjectedP0);

  // 4. Atmosphere Gradual Transition: 0% above 450m, reaches 100% at cloud layer (105m)
  const posSpace = testP0.center.clone().add(new THREE.Vector3(0, testP0.r + 550, 0));
  const posMid = testP0.center.clone().add(new THREE.Vector3(0, testP0.r + 250, 0));
  const posClouds = testP0.center.clone().add(new THREE.Vector3(0, testP0.r + 105, 0));
  const posGround = testP0.center.clone().add(new THREE.Vector3(0, testP0.r + 10, 0));

  const atmoSpace = window.atmosphereAt ? window.atmosphereAt(posSpace) : { density: 0 };
  const atmoMid = window.atmosphereAt ? window.atmosphereAt(posMid) : { density: 0.5 };
  const atmoClouds = window.atmosphereAt ? window.atmosphereAt(posClouds) : { density: 1.0 };
  const atmoGround = window.atmosphereAt ? window.atmosphereAt(posGround) : { density: 1.0 };

  assertTest("Atmosphere vanishes completely above 450m (density === 0 in space)", atmoSpace.density === 0, `density: ${atmoSpace.density}`);
  assertTest("Atmosphere transition is gradual in upper layer (0 < density < 1)", atmoMid.density > 0 && atmoMid.density < 1.0, `density: ${atmoMid.density.toFixed(2)}`);
  assertTest("Atmosphere reaches exactly 100% upon crossing clouds at 105m", atmoClouds.density === 1.0, `density: ${atmoClouds.density}`);
  assertTest("Atmosphere remains 100% below clouds down to ground level", atmoGround.density === 1.0, `density: ${atmoGround.density}`);

  // 5. Day/Night Cycle aligned with Central Sun
  const sunPos = window.suns?.[0]?.pos || new THREE.Vector3(0, 1200, 0);
  assertTest("Central Star is positioned at the center of the solar system (X=0, Z=0)", Math.hypot(sunPos.x, sunPos.z) < 1.0, `(x:${sunPos.x}, z:${sunPos.z})`);

  // Point on planet facing towards Sun
  const dirToSun = sunPos.clone().sub(testP0.center).normalize();
  const dayPos = testP0.center.clone().addScaledVector(dirToSun, testP0.r + 5);
  const nightPos = testP0.center.clone().addScaledVector(dirToSun.clone().negate(), testP0.r + 5);

  const dayInfo = window.daylight ? window.daylight(testP0, dayPos) : { day: 1 };
  const nightInfo = window.daylight ? window.daylight(testP0, nightPos) : { day: 0 };

  assertTest("Side of planet facing Sun has daytime (day > 0.8)", dayInfo.day > 0.8, `day: ${dayInfo.day.toFixed(2)}`);
  assertTest("Side of planet facing away from Sun has nighttime (day < 0.2)", nightInfo.day < 0.2, `day: ${nightInfo.day.toFixed(2)}`);

  
  // 33. MILESTONE V0.1.27: HANGAR TERMINAL DISTANCE & HIGH-TECH UPGRADE, NO BILLBOARD, ROVER HIGH-SPEED ORBIT FIX, STEERING VS FREE MOUSE & PROGRESSIVE TRACTION
  console.log("\n[Suite 33: Hangar Terminal Clearance & Visuals, No Giant Sign, Rover High-Speed Orbit, Steering Mode vs Free Look & Progressive Acceleration]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Hangar Terminal is stationed >= 28m away from central landing pad (clears all ship wings)
  window.loadPlanetSurface(t.planets[0]);
  let termDistFromCenter = 0;
  for (const s of (window.settlements || [])) {
    const term = s.root && s.root.getObjectByName('hangarTerminal');
    if (term) {
      termDistFromCenter = Math.hypot(term.position.x, term.position.z);
      break;
    }
  }
  assertTest("Hangar Terminal is stationed >= 28m away from pad center (clears ship wings)", termDistFromCenter >= 28.0, `dist: ${termDistFromCenter.toFixed(1)}m`);

  // 3. Giant 3D text billboard sign is completely removed
  assertTest("Giant 3D billboard sign 'E · TERMINAL DE HANGAR' completely removed", !finalHtml.includes("label3D(s.root, 'E · TERMINAL DE HANGAR'") && !finalHtml.includes("label3D(parent, 'E · TERMINAL DE HANGAR'"));

  // 4. Rover Camera Orbit Center: at high speeds, camera orbit focus stays anchored directly on the rover
  t.setMode('rover');
  t.setThirdPerson(true);
  window.setRoverLinearSpeed(70.0); // 70 m/s high speed
  for (let i = 0; i < 20; i++) t.update(0.05); // drive at 70 m/s for 1 second
  const rawChassisFocus = t.rover.localToWorld(new THREE.Vector3(0, 0.85, 0));
  // In 3rd person driving, focus must be directly on rover chassis (zero horizontal lag)
  const camFocus = window.getSmoothRoverCamTarget ? window.getSmoothRoverCamTarget() : rawChassisFocus;
  const hLag = Math.hypot(camFocus.x - rawChassisFocus.x, camFocus.z - rawChassisFocus.z);
  assertTest("Rover camera orbit center remains locked to rover chassis at 70 m/s (no lagging behind)", hLag < 0.5, `horizontal lag: ${hLag.toFixed(2)}m`);

  // 5. Steering Mode vs Free Camera Mode differentiation:
  // In Steering Mode (roverLookOnly = false): mouse horizontal delta steers the vehicle!
  window.setRoverLookOnly?.(false);
  const initialRoverYaw = t.rover.rotation.y;
  window.lookInput(-40, 0); // mouse steer left
  assertTest("In Steering Mode, mouse horizontal movement directly turns the rover", Math.abs(t.rover.rotation.y - initialRoverYaw) > 0.05, `turn: ${(t.rover.rotation.y - initialRoverYaw).toFixed(3)} rad`);

  // In Free Camera Mode (roverLookOnly = true): mouse movement does NOT turn the vehicle
  window.setRoverLookOnly?.(true);
  const yawBeforeFree = t.rover.rotation.y;
  const camYawBefore = window.getVehicleCamYaw ? window.getVehicleCamYaw() : 0;
  window.lookInput(-40, 0);
  assertTest("In Free Camera Mode, mouse movement does NOT turn the rover", Math.abs(t.rover.rotation.y - yawBeforeFree) < 0.001);

  // 6. Rover Acceleration: gentle and progressive initial pull-away (no violent 19G launch!)
  window.setRoverLinearSpeed(0);
  pressKey('KeyW');
  t.update(0.05);
  const launchSpeedFrame1 = window.getRoverLinearSpeed();
  assertTest("Rover initial launch is gentle and progressive (speed < 5.0 m/s on frame 1)", launchSpeedFrame1 > 0 && launchSpeedFrame1 < 5.0, `frame1: ${launchSpeedFrame1.toFixed(2)} m/s`);
  releaseKey('KeyW');

  {
  // 34. MILESTONE V0.1.28: EXCLUSIVE ATLAS & ROVER FLEET, CLEAN HANGAR TERMINAL & SEAMLESS RE-DOCKING (NO SPACE TELEPORT)
  console.log("\n[Suite 34: Exclusive Atlas & Rover Fleet, Clean Hangar Operations & Seamless Re-Docking (No Space Teleport)]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Atlas is the only ship in shipTypes and equipment
  assertTest("Only Atlas remains in ship fleet (all other ships removed)", window.shipTypes.length === 1 && window.shipTypes[0].name.includes('ATLAS'));
  assertTest("Equipment ships list contains only Atlas", window.equipment.ships.length === 1 && window.equipment.ships[0] === 0);

  // 3. Rover is the only vehicle in equipment and fleet
  assertTest("Only Rover remains in vehicle garage (all other vehicles removed)", window.equipment.vehicles.length === 1 && window.equipment.vehicles[0] === 'rover');

  // 4. Shop storeDefs and products contain NO other ships or vehicles
  const sDefs = window.storeDefs || {};
  const prods = window.products || {};
  assertTest("Shipyard and vehicle shop lists contain no unwanted models", (!sDefs.ships || sDefs.ships.items.length === 0) && (!sDefs.vehicles || sDefs.vehicles.items.length === 0));
  assertTest("Product catalog has other ships/vehicles removed", !prods.ship1 && !prods.ship2 && !prods.scout && !prods.hauler && !prods.skiff && !prods.cutter);

  // 5. Seamless Rover Re-Docking without space teleportation
  const dockingPlanet = t.planets[0];
  t.ship.position.set(200, 768, -300);
  t.ship.quaternion.identity();
  window.dockRoverToShip(false); // start docked
  assertTest("Rover begins docked to ship", t.rover.parent === t.ship);

  // Drive rover down ramp to exit
  t.setMode('rover');
  t.setLanded(true);
  t.openRamp(true);
  window.setRoverLinearSpeed(15.0); // drive forward out
  for (let i = 0; i < 30; i++) t.update(0.05);

  // Detach to ground
  t.scene.attach(t.rover);
  assertTest("Rover detached to ground outside ship", t.rover.parent === t.scene);
  const exitPos = t.rover.getWorldPosition(new THREE.Vector3());
  assertTest("Rover on ground is near the ship (not in space)", exitPos.distanceTo(t.ship.position) < 40, `dist: ${exitPos.distanceTo(t.ship.position).toFixed(1)}m`);

  // Drive rover back up the ramp towards the ship garage
  // Position rover entering the doorway
  const doorWorld = t.ship.localToWorld(new THREE.Vector3(0, 0.33, 14.8));
  t.rover.position.copy(doorWorld);
  t.rover.quaternion.copy(t.ship.quaternion);
  window.setRoverLinearSpeed(-5.0);

  // Update simulation - triggers re-docking
  t.update(0.05);

  // Check docking status and coordinates!
  assertTest("Rover re-docks to ship upon entering doorway", t.rover.parent === t.ship);
  assertTest("Rover local Y is flush on garage deck (0.33m)", Math.abs(t.rover.position.y - 0.33) < 0.05, `y: ${t.rover.position.y.toFixed(2)}m`);
  assertTest("Rover local X is within ship garage bounds", Math.abs(t.rover.position.x) < 5.5, `x: ${t.rover.position.x.toFixed(2)}m`);
  assertTest("Rover local Z is inside cargo garage", t.rover.position.z >= -10 && t.rover.position.z <= 16, `z: ${t.rover.position.z.toFixed(2)}m`);

  const roverWorldAfter = t.rover.getWorldPosition(new THREE.Vector3());
  const distShipToRover = roverWorldAfter.distanceTo(t.ship.position);
  assertTest("Rover world position remains tightly inside ship (NO space teleportation!)", distShipToRover < 20, `dist: ${distShipToRover.toFixed(1)}m`);

  // Subsequent frames do NOT catapult the rover
  for (let i = 0; i < 20; i++) t.update(0.05);
  const roverWorldLater = t.rover.getWorldPosition(new THREE.Vector3());
  assertTest("Rover remains stably inside ship garage over time", roverWorldLater.distanceTo(t.ship.position) < 20, `dist: ${roverWorldLater.distanceTo(t.ship.position).toFixed(1)}m`);


  }
  {
  // 35. MILESTONE V0.1.29: COMPACT HUD WAYPOINT, MAP SHIP MARKER, PILOT-ONLY AUTOPILOT, VERSIONED DELIVERABLE & SMOOTH ACKERMANN ROVER STEERING
  console.log("\n[Suite 35: Compact HUD Waypoint, Map Ship Marker, Pilot-Only Autopilot, Versioned Deliverable & Smooth Ackermann Rover Steering]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. HUD Waypoint clean format (clean distance format, no 'atrás de você', compact layout)
  window.setTarget(0);
  window.updateGuide ? window.updateGuide() : null;
  const wayDistText = getOrCreate('wayDistance').textContent;
  assertTest("HUD waypoint distance has clean format (e.g. 28.9km or 450m without 'atrás de você')", !wayDistText.includes('atrás de você') && (wayDistText.includes('km') || wayDistText.includes('m')), wayDistText);

  // 3. Mark own ship on 2D map
  window.handleMapShipClick ? window.handleMapShipClick() : null;
  assertTest("Clicking own ship on 2D map sets target to 'ship'", window.getTarget() === 'ship');
  window.updateGuide ? window.updateGuide() : null;
  const wayLabelText = getOrCreate('wayLabel').textContent;
  assertTest("HUD waypoint displays player's ship label when targeted", wayLabelText.includes('ATLAS'), wayLabelText);
  window.setTarget(-1); // clear target

  // 4. Autopilot strictly blocked when player is NOT in pilot mode (e.g. foot or rover)
  t.setMode('rover');
  let autoBlockedInRover = false;
  try {
    window.handleMapNodeClick(0); // double click simulation
    window.handleMapNodeClick(0);
    autoBlockedInRover = (window.__test.getBoost ? !window.debugState().auto : true);
  } catch(e) { autoBlockedInRover = true; }
  assertTest("Autopilot cannot be engaged from 2D map when player is in rover or foot mode", autoBlockedInRover);

  // In pilot mode, autopilot can be engaged
  t.setMode('pilot');
  window.handleMapNodeClick(0);
  window.handleMapNodeClick(0);
  assertTest("Autopilot can be engaged when player is in pilot mode", !!window.debugState().auto);
  window.debugState().auto = null; // reset

  // 5. Rover Mouse Steering:
  // a) Still chassis when stopped (linear speed == 0)
  t.setMode('rover');
  window.setRoverLookOnly(false);
  window.setRoverLinearSpeed(0);
  const stoppedChassisYaw = t.rover.rotation.y;
  window.lookInput(-30, 0); // mouse steer left while stopped
  assertTest("When rover is stopped, mouse steering does NOT turn the chassis in place", Math.abs(t.rover.rotation.y - stoppedChassisYaw) < 0.001);

  // b) Steering wheel (volante) and tires (knuckles) turn when mouse steering!
  const yokeAngle = t.rover.userData.steeringWheel ? Math.abs(t.rover.userData.steeringWheel.rotation.z) : 0;
  const knuckleAngle = t.rover.userData.steerKnuckles ? Math.abs(t.rover.userData.steerKnuckles[0]?.obj?.rotation.y) : 0;
  assertTest("Mouse steering turns the rover steering yoke (volante)", yokeAngle > 0.02, `yoke: ${yokeAngle.toFixed(3)} rad`);
  assertTest("Mouse steering turns the rover front tires (knuckles)", knuckleAngle > 0.01, `knuckle: ${knuckleAngle.toFixed(3)} rad`);

  // c) Smooth, non-abrupt turning when moving:
  window.setRoverLinearSpeed(20.0); // moving forward
  const movingChassisYaw = t.rover.rotation.y;
  window.lookInput(-30, 0); // mouse steer left while moving
  const deltaYawMoving = Math.abs(t.rover.rotation.y - movingChassisYaw);
  assertTest("When rover is moving, mouse steering turns chassis smoothly (controllable rate)", deltaYawMoving > 0.01 && deltaYawMoving < 0.25, `turn: ${deltaYawMoving.toFixed(3)} rad`);

  // 6. Versioned HTML deliverable exists
  const fs = require('fs');
  const path = require('path');
  const versionedHtmlPath = path.join(__dirname, '..', 'SkyWard-v0.1.40.html');
  assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(versionedHtmlPath));

  }
  {
  // 36. MILESTONE V0.1.30: WARM SUNSET TWILIGHT, CLEARER NIGHT & SPACE AMBIENT, AND ZERO-GAP AIRTIGHT BULKHEAD DOORS
  console.log("\n[Suite 36: Warm Sunset Twilight, Clearer Night & Space Ambient, and Zero-Gap Airtight Bulkhead Doors]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Sunset lighting: soft warm illumination instead of pitch-black darkness
  const testP = t.planets[0];
  // Calculate a position where sun is right on horizon (elevation ~ 0)
  const sunPos = window.suns?.[0]?.pos || new THREE.Vector3(0, 1200, 0);
  const dirToSun = sunPos.clone().sub(testP.center).normalize();
  const perpDir = new THREE.Vector3(-dirToSun.z, 0, dirToSun.x).normalize(); // 90 degrees away from sun
  const sunsetPos = testP.center.clone().addScaledVector(perpDir, testP.r + 5);

  const sunsetInfo = window.daylight ? window.daylight(testP, sunsetPos) : { elevation: 0, day: 0.5, sunset: 1.0 };
  assertTest("Sunset position has elevation near 0 and sunset factor > 0.8", Math.abs(sunsetInfo.elevation) < 0.25 && sunsetInfo.sunset > 0.8, `elev: ${sunsetInfo.elevation.toFixed(2)}, sunset: ${sunsetInfo.sunset.toFixed(2)}`);

  // Move camera to sunset position and update environment sky
  t.camera.position.copy(sunsetPos);
  t.update(0.05);

  const sunsetSunLight = window.sunlight ? window.sunlight.intensity : 1.0;
  let sunsetHemiLight = 0;
  t.scene.traverse(o => { if (o.isHemisphereLight) sunsetHemiLight = o.intensity; });

  assertTest("Sunset directional sunlight provides soft warm beam (> 0.60, not pitch black)", sunsetSunLight >= 0.60, `sunlight: ${sunsetSunLight.toFixed(2)}`);
  assertTest("Sunset ambient hemisphere light provides warm twilight (> 0.70)", sunsetHemiLight >= 0.70, `hemi: ${sunsetHemiLight.toFixed(2)}`);

  // 3. Clearer Night ambient (>= 0.40, no pitch black breu)
  const nightPos = testP.center.clone().addScaledVector(dirToSun.clone().negate(), testP.r + 5);
  t.camera.position.copy(nightPos);
  t.update(0.05);

  let nightHemiLight = 0;
  t.scene.traverse(o => { if (o.isHemisphereLight) nightHemiLight = o.intensity; });
  assertTest("Nighttime ambient light is comfortably visible (>= 0.40, not breu)", nightHemiLight >= 0.40, `night hemi: ${nightHemiLight.toFixed(2)}`);

  // 4. Clearer space ambient (>= 0.75) and space background not pitch black
  t.camera.position.set(20000, 15000, 20000);
  t.update(0.05);
  let spaceHemiLight = 0;
  t.scene.traverse(o => { if (o.isHemisphereLight) spaceHemiLight = o.intensity; });
  assertTest("Outer space ambient light is lifted (>= 0.75)", spaceHemiLight >= 0.75, `space hemi: ${spaceHemiLight.toFixed(2)}`);
  const bgHex = t.scene.background?.getHex();
  assertTest("Outer space background is deep cosmos blue (not pure 0x000000 black)", bgHex !== 0x000000 && bgHex !== 0x020409, `bg: 0x${bgHex?.toString(16)}`);

  // 5. Internal doors: airtight overlapping seal with ZERO gap / fresta when closed
  let minDoorGap = Infinity;
  let doorPanelsChecked = 0;
  const doors = window.shipInteractables?.filter(i => i.kind === 'door') || [];
  assertTest("Internal ship doors exist", doors.length >= 5, `${doors.length} doors`);

  for (const d of doors) {
    // Ensure door is closed (progress = 0)
    d.open = false;
    d.progress = 0;
    const parts = d.o.children.filter(c => c.userData && c.userData.doorSide !== undefined);
    if (parts.length >= 2) {
      const leftPart = parts.find(p => p.userData.doorSide === -1);
      const rightPart = parts.find(p => p.userData.doorSide === 1);
      if (leftPart && rightPart) {
        doorPanelsChecked++;
        // Left panel geometry width and right panel geometry width
        leftPart.geometry.computeBoundingBox();
        rightPart.geometry.computeBoundingBox();
        const leftWidth = leftPart.geometry.boundingBox.max.x - leftPart.geometry.boundingBox.min.x;
        const rightWidth = rightPart.geometry.boundingBox.max.x - rightPart.geometry.boundingBox.min.x;
        // Total panel width must exceed half door width so panels overlap
        const expectedHalf = d.half; // half the door opening width
        assertTest(`Door '${d.label}' panel width exceeds half width (airtight overlap)`, leftWidth > expectedHalf, `panel: ${leftWidth.toFixed(3)}m vs half: ${expectedHalf.toFixed(3)}m`);
      }
    }
  }

  // 6. Center seam meshes exist and render along dividing centerline
  let centerSeamCount = 0;
  t.ship.traverse(o => {
    if (o.userData && o.userData.centerSeam) centerSeamCount++;
  });
  assertTest("Closed doors render crisp illuminated center dividing seam lines", centerSeamCount >= 10, `${centerSeamCount} seam meshes`);

  }
  {
  // 37. MILESTONE V0.1.31: ROVER RAMP TILT DIRECTION, WEAPON AIMING STANCES, HAND-SPAWNED GRENADE & SMOOTH MOUSE STEERING
  console.log("\n[Suite 37: Rover Ramp Tilt Direction, 3rd Person Weapon Stances, Hand-Spawned Grenade & Smooth Mouse Steering]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Rover ramp descent pitch direction:
  // When rover drives forward down the ship's rear ramp, nose tilts DOWNWARD (pitch < -0.15 rad), NOT in the opposite direction!
  t.setMode('rover');
  t.rover.parent = t.ship;
  // Position rover on rear ramp (rampDist ~ 3.5m) facing backwards towards rear exit (roverYaw = Math.PI)
  t.rover.position.set(0, 0, 18.5); // On ramp (layout().entry.z = 15)
  t.rover.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI);
  t.update(0.05);

  const testEuler = new THREE.Euler().setFromQuaternion(t.rover.quaternion, 'YXZ');
  // When descending forward down the rear ramp, pitch must tilt nose downwards towards ground!
  // In YXZ with yaw = PI, pitch < -0.15 or |pitch| > 2.8 rad indicates nose-down tilt
  assertTest("Rover tilts downward along ramp slope when descending (not in the opposite direction)", testEuler.x < -0.15 || Math.abs(testEuler.x) > 2.8, `pitch: ${testEuler.x.toFixed(3)} rad`);

  // 3. 3rd Person Weapon Stances:
  t.setMode('foot');
  t.setThirdPerson(true);
  t.update(0.05); // Settle mode transition and gestureContext

  const curAvatar = window.getAvatar ? window.getAvatar() : window.avatar;
  const avatarRig = curAvatar?.userData?.rig;
  assertTest("Avatar rig exists for 3rd person weapon stances", !!avatarRig);

  const leftArm = avatarRig?.userData?.limbs?.[1];
  const rightArm = avatarRig?.userData?.limbs?.[3];
  const leftElbow = avatarRig?.userData?.human?.elbows?.[0];
  const rightElbow = avatarRig?.userData?.human?.elbows?.[1];

  // A. Pistol Stance: Both hands practically together in front of chest
  window.equipWeapon('pistol');
  t.setAiming(true);
  for (let i = 0; i < 10; i++) t.update(0.05);

  assertTest("Pistol Aim: Right arm angled forward/down in front of chest", rightArm.rotation.x > 0.90 && rightArm.rotation.x < 1.35, `rightArmX: ${rightArm.rotation.x.toFixed(2)}`);
  assertTest("Pistol Aim: Left arm angled forward/down to meet right hand", leftArm.rotation.x > 0.90 && leftArm.rotation.x < 1.35, `leftArmX: ${leftArm.rotation.x.toFixed(2)}`);
  assertTest("Pistol Aim: Both arms angle inward towards center of chest", rightArm.rotation.y < -0.20 && leftArm.rotation.y > 0.20, `rY: ${rightArm.rotation.y.toFixed(2)}, lY: ${leftArm.rotation.y.toFixed(2)}`);
  assertTest("Pistol Aim: Both elbows bent holding pistol compact near chest (not locked out)", rightElbow.rotation.x > 0.80 && leftElbow.rotation.x > 0.80, `rElbow: ${rightElbow.rotation.x.toFixed(2)}, lElbow: ${leftElbow.rotation.x.toFixed(2)}`);

  // B. Rifle & Shotgun Stance: Right hand on grip near shoulder, left hand forward supporting barrel
  window.equipWeapon('rifle');
  t.setAiming(true);
  for (let i = 0; i < 10; i++) t.update(0.05);

  assertTest("Rifle Aim: Right elbow bent tightly holding grip/stock near shoulder", rightElbow.rotation.x > 1.10, `rightElbow: ${rightElbow.rotation.x.toFixed(2)}`);
  assertTest("Rifle Aim: Left arm reaches forward to support barrel/fore-end", leftArm.rotation.x > 1.05 && leftElbow.rotation.x < 0.85, `leftArmX: ${leftArm.rotation.x.toFixed(2)}, leftElbow: ${leftElbow.rotation.x.toFixed(2)}`);

  window.equipWeapon('shotgun');
  t.setAiming(true);
  for (let i = 0; i < 10; i++) t.update(0.05);
  assertTest("Shotgun Aim: Right hand on grip near shoulder, left on barrel", rightElbow.rotation.x > 1.10 && leftArm.rotation.x > 1.05, `rElbow: ${rightElbow.rotation.x.toFixed(2)}, lArm: ${leftArm.rotation.x.toFixed(2)}`);

  // C. One-Handed Weapons (Tool, Blade, Sabre): Left arm is NEVER raised!
  window.equipWeapon('tool');
  t.setAiming(true);
  for (let i = 0; i < 10; i++) t.update(0.05);
  assertTest("Tool Aim: Left arm remains down at side (never raised)", leftArm.rotation.x < 0.15, `leftArmX: ${leftArm.rotation.x.toFixed(2)}`);

  window.equipWeapon('blade');
  t.setAiming(false);
  for (let i = 0; i < 10; i++) t.update(0.05);
  assertTest("Blade Guard: Left arm remains down at side (never raised)", leftArm.rotation.x < 0.15, `leftArmX: ${leftArm.rotation.x.toFixed(2)}`);

  window.equipWeapon('sabre');
  t.setAiming(false);
  for (let i = 0; i < 10; i++) t.update(0.05);
  assertTest("Sabre Guard: Left arm remains down at side (never raised)", leftArm.rotation.x < 0.15, `leftArmX: ${leftArm.rotation.x.toFixed(2)}`);

  // D. Grenade: Throwing preparation wind-up stance
  window.equipWeapon('grenade');
  t.setAiming(true);
  for (let i = 0; i < 10; i++) t.update(0.05);

  assertTest("Grenade Throw Prep: Right arm cocked high and back near head/shoulder", rightArm.rotation.x > 1.45 && rightElbow.rotation.x > 1.25, `rightArmX: ${rightArm.rotation.x.toFixed(2)}, rightElbow: ${rightElbow.rotation.x.toFixed(2)}`);
  assertTest("Grenade Throw Prep: Left arm extended forward pointing towards target", leftArm.rotation.x > 1.05, `leftArmX: ${leftArm.rotation.x.toFixed(2)}`);

  // 4. Grenade Launch Origin: Originates directly from the character's hand (not mid-air)
  const gData = window.getGrenadeOriginAndVelocity ? window.getGrenadeOriginAndVelocity() : null;
  assertTest("Grenade origin data computed", !!gData && !!gData.from);

  // Measure distance between gData.from and character's right hand in world coordinates
  const rightHandWorld = rightElbow.localToWorld(new THREE.Vector3(0, -0.285, 0.015));
  const handDist = gData.from.distanceTo(rightHandWorld);
  assertTest("Grenade originates directly from character's hand in 3rd person (not floating in mid-air)", handDist < 0.05, `dist: ${handDist.toFixed(4)}m`);

  // 5. Rover Mouse Steering in 3rd Person: Progressive, controlled and smooth (no abrupt twitching)
  t.setMode('rover');
  window.setRoverLookOnly(false);
  window.setRoverLinearSpeed(25.0);
  const yawBeforeSmooth = t.rover.rotation.y;
  window.lookInput(-25, 0); // moderate mouse movement
  const deltaSmoothTurn = Math.abs(t.rover.rotation.y - yawBeforeSmooth);
  assertTest("Rover mouse steering in 3rd person turns progressively and smoothly (controllable rate)", deltaSmoothTurn > 0.01 && deltaSmoothTurn < 0.06, `turn: ${deltaSmoothTurn.toFixed(3)} rad`);

  }
  {
  // 38. MILESTONE V0.1.32: UNARMED COMBAT (FISTS / SOCOS COM MÃO ALEATÓRIA)
  console.log("\n[Suite 38: Unarmed Combat (Fists / Socos com Mão Aleatória)]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. 'unarmed' is officially in weaponDefs
  const unarmedDef = window.weaponDefs?.unarmed;
  assertTest("'unarmed' is defined in weaponDefs", !!unarmedDef);
  assertTest("Unarmed weapon name is 'Desarmado'", unarmedDef?.name === 'Desarmado', unarmedDef?.name);
  assertTest("Unarmed damage is set (> 15)", unarmedDef?.damage >= 15, `dmg: ${unarmedDef?.damage}`);
  assertTest("Unarmed melee range is set (> 2.0m)", unarmedDef?.range >= 2.0, `range: ${unarmedDef?.range}m`);

  // 3. Unarmed is always an available weapon option
  t.setMode('foot');
  window.equipWeapon('unarmed');
  assertTest("Can equip 'unarmed' directly without buying", window.getEquipped() === 'unarmed');

  // 4. Punch attacks and random hand selection:
  // Firing while unarmed activates melee punch
  let leftHandCount = 0;
  let rightHandCount = 0;
  for (let i = 0; i < 40; i++) {
    t.update(0.35); // Advance combatTime past weapon rate
    window.firePlayer();
    const hand = window.getPunchHand();
    if (hand === 0) leftHandCount++;
    if (hand === 1) rightHandCount++;
  }
  assertTest("Unarmed attack selects left hand punches randomly", leftHandCount > 5, `left: ${leftHandCount}/40`);
  assertTest("Unarmed attack selects right hand punches randomly", rightHandCount > 5, `right: ${rightHandCount}/40`);
  assertTest("Both hands strike across punches (random hand selection)", leftHandCount > 0 && rightHandCount > 0);

    // 5. 1st Person Combat Fists in weaponView
  t.setThirdPerson(false);
  window.rebuildWeapon?.();
  const wv = window.getWeaponView ? window.getWeaponView() : null;
  assertTest("1st person weaponView exists", !!wv);
  const leftFist = wv?.getObjectByName('leftFist');
  const rightFist = wv?.getObjectByName('rightFist');
  assertTest("1st person weaponView contains leftFist", !!leftFist);
  assertTest("1st person weaponView contains rightFist", !!rightFist);

  // Left hand punch
  t.update(0.35); // Cool down from previous shot
  window.firePlayer();
  window.setPunchHand(0); // Ensure left hand strikes
  t.update(0.06); // Advance halfway into punch (mp ~ 0.21 < 0.35)
  assertTest("Left fist punches forward into view (z extends forward)", leftFist.position.z < 0.05, `z: ${leftFist.position.z.toFixed(3)}`);

  // Settle punch
  t.update(0.35);

  // Right hand punch
  window.firePlayer();
  window.setPunchHand(1); // Ensure right hand strikes
  t.update(0.06); // Advance halfway into punch
  assertTest("Right fist punches forward into view (z extends forward)", rightFist.position.z < 0.05, `z: ${rightFist.position.z.toFixed(3)}`);

  // Settle punch
  t.update(0.35);

  // 6. 3rd Person Avatar Punch Biomechanics
  t.setThirdPerson(true);
  t.update(0.05);
  const curAv = window.getAvatar ? window.getAvatar() : window.avatar;
  const rig = curAv?.userData?.rig;
  const avLeftArm = rig?.userData?.limbs?.[1];
  const avRightArm = rig?.userData?.limbs?.[3];
  const avLeftElbow = rig?.userData?.human?.elbows?.[0];
  const avRightElbow = rig?.userData?.human?.elbows?.[1];

  // Left hand punch in 3rd person
  t.update(0.35);
  window.firePlayer();
  window.setPunchHand(0); // Left hand strikes
  t.update(0.06);
  assertTest("3rd Person Left Punch: Left arm extends forward (> 1.15)", avLeftArm.rotation.x > 1.15, `leftArmX: ${avLeftArm.rotation.x.toFixed(2)}`);
  assertTest("3rd Person Left Punch: Right arm stays in defensive guard", avRightArm.rotation.x < 1.10, `rightArmX: ${avRightArm.rotation.x.toFixed(2)}`);

  // Settle punch back to ready guard
  for (let i = 0; i < 10; i++) t.update(0.05);

  // Right hand punch in 3rd person
  window.firePlayer();
  window.setPunchHand(1); // Right hand strikes
  t.update(0.06);
  assertTest("3rd Person Right Punch: Right arm extends forward (> 1.15)", avRightArm.rotation.x > 1.15, `rightArmX: ${avRightArm.rotation.x.toFixed(2)}`);
  assertTest("3rd Person Right Punch: Left arm stays in defensive guard", avLeftArm.rotation.x < 1.10, `leftArmX: ${avLeftArm.rotation.x.toFixed(2)}`);

  }
    // 39. MILESTONE V0.1.33: SHIP 1ST PERSON FREE CAM TOGGLE & FOOT AUTOFORWARD STRICT SIDE FILTERING
  console.log("\n[Suite 39: Ship 1st Person Free Cam Toggle & Foot Auto-Forward Strict Side Filtering]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Spaceship Cockpit (mode === 'pilot', 1st person): Double-tap on RIGHT half toggles Free Camera
  t.setMode('pilot');
  t.setThirdPerson(false);
  t.setInside(true);
  t.setLanded(false);
  window.setTouch(true);
  window.setShipLookOnly?.(false);
  assertTest("Ship starts in flight steering mode (shipLookOnly = false)", window.getShipLookOnly() === false);

  // First tap on right half (clientX = 1500 > 960)
  simulatedTime += 300;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 401, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 401, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));

  // Second tap on right half (< 440ms)
  simulatedTime += 150;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 402, pointerType: 'touch', clientX: 1505, clientY: 402, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 402, pointerType: 'touch', clientX: 1505, clientY: 402, preventDefault: () => {} }));

  assertTest("Double-tap on right half toggles ship to Free Camera (shipLookOnly = true)", window.getShipLookOnly() === true);

  // Double-tap again on right half toggles back to Flight Controls (shipLookOnly = false)
  simulatedTime += 350; // Past 240ms debounce
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 403, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 403, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));
  simulatedTime += 150;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 404, pointerType: 'touch', clientX: 1505, clientY: 402, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 404, pointerType: 'touch', clientX: 1505, clientY: 402, preventDefault: () => {} }));

  assertTest("Double-tap again on right half toggles back to Flight Controls (shipLookOnly = false)", window.getShipLookOnly() === false);

  // 3. Foot Mode: Rapid clicking/tapping on the RIGHT side of the screen NEVER triggers autoForward
  t.setMode('foot');
  t.setThirdPerson(false);
  window.autoForward = false;
  // Multiple rapid taps on the right side (clientX = 1500 > 960)
  for (let i = 0; i < 8; i++) {
    simulatedTime += 80;
    canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 500 + i, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));
    canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 500 + i, pointerType: 'touch', clientX: 1500, clientY: 400, preventDefault: () => {} }));
  }
  assertTest("Rapid tapping on RIGHT side on foot NEVER activates autoForward (remains false)", window.getAutoForward() === false);

  // Rapid mouse clicks on right side on foot also never trigger autoForward
  for (let i = 0; i < 8; i++) {
    simulatedTime += 80;
    canvasListeners['mousedown']?.forEach(cb => cb({ button: 0, clientX: 1500, clientY: 400, preventDefault: () => {} }));
    canvasListeners['mouseup']?.forEach(cb => cb({ button: 0 }));
  }
  assertTest("Rapid mouse clicks on RIGHT side on foot NEVER activate autoForward", window.getAutoForward() === false);

  // 4. Foot Mode: Double tap on the LEFT side of the screen (movement area < 0.45 * innerWidth = 864) activates autoForward
  simulatedTime += 350;
  // Tap 1 on left side (clientX = 200 < 864)
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 601, pointerType: 'touch', clientX: 200, clientY: 400, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 601, pointerType: 'touch', clientX: 200, clientY: 400, preventDefault: () => {} }));
  // Tap 2 on left side (< 440ms)
  simulatedTime += 150;
  canvasListeners['pointerdown']?.forEach(cb => cb({ pointerId: 602, pointerType: 'touch', clientX: 205, clientY: 402, preventDefault: () => {} }));
  canvasListeners['pointerup']?.forEach(cb => cb({ pointerId: 602, pointerType: 'touch', clientX: 205, clientY: 402, preventDefault: () => {} }));

  assertTest("Double tap on LEFT side on foot activates autoForward (corrida automática)", window.getAutoForward() === true);

  // Stopping autoForward when moving
  pressKey('KeyW');
  assertTest("Moving clears autoForward", window.getAutoForward() === false);
  releaseKey('KeyW');

  // 5. Versioned deliverable SkyWard-v0.1.40.html exists
  const versionedHtmlPath33 = path.join(__dirname, '..', 'SkyWard-v0.1.40.html');
  assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(versionedHtmlPath33));

    // 40. MILESTONE V0.1.38: DEFAULT UNARMED, WEAPON STANCES, GRENADE THROW & BELT CYCLE, AND CAMERA-INDEPENDENT 3RD PERSON LOCOMOTION
  console.log("\n[Suite 40: Default Unarmed, Weapon Stances, Grenade Throw & Belt Cycle, and Camera-Independent 3rd Person Locomotion]");

  // 1. Version tag is officially '0.1.40'
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 2. Default equipped weapon is officially 'unarmed'
  assertTest("Default weapon is unarmed on startup", window.getEquipped() === 'unarmed', window.getEquipped());

  // 3. Pistol 3rd Person Aim Stance: Both hands practically together near chest
  t.setMode('foot');
  t.setThirdPerson(true);
  window.equipWeapon('pistol');
  window.setAiming(true);
  for (let i = 0; i < 8; i++) t.update(0.04);

  const curAv40 = window.getAvatar ? window.getAvatar() : null;
  const rig40 = curAv40?.userData?.rig;
  const avLeftArm40 = rig40?.userData?.limbs?.[1];
  const avRightArm40 = rig40?.userData?.limbs?.[3];
  const avLeftElbow40 = rig40?.userData?.human?.elbows?.[0];
  const avRightElbow40 = rig40?.userData?.human?.elbows?.[1];

  assertTest("Pistol Aim: Right arm angled in front of chest (~1.05 rad)", Math.abs(avRightArm40.rotation.x - 1.05) < 0.10, `rotX: ${avRightArm40.rotation.x.toFixed(2)}`);
  assertTest("Pistol Aim: Left arm angled in front of chest (~1.05 rad)", Math.abs(avLeftArm40.rotation.x - 1.05) < 0.10, `rotX: ${avLeftArm40.rotation.x.toFixed(2)}`);
  assertTest("Pistol Aim: Both elbows bent holding hands together near chest (~1.15 rad)", Math.abs(avRightElbow40.rotation.x - 1.15) < 0.10 && Math.abs(avLeftElbow40.rotation.x - 1.15) < 0.10);

  // 4. Rifle & Shotgun Stance: Right hand at grip near shoulder, left on barrel
  window.equipWeapon('rifle');
  for (let i = 0; i < 8; i++) t.update(0.04);
  assertTest("Rifle Aim: Right elbow bent holding grip near shoulder (~1.30 rad)", Math.abs(avRightElbow40.rotation.x - 1.30) < 0.10, `elbowX: ${avRightElbow40.rotation.x.toFixed(2)}`);
  assertTest("Rifle Aim: Left arm reaches forward to support barrel (~1.22 rad)", Math.abs(avLeftArm40.rotation.x - 1.22) < 0.10, `leftArmX: ${avLeftArm40.rotation.x.toFixed(2)}`);

  // 5. Single-handed weapons: Left arm NEVER raised
  window.setAiming(false);
  for (const singleWep of ['tool', 'blade', 'sabre']) {
    window.equipWeapon(singleWep);
    for (let i = 0; i < 8; i++) t.update(0.04);
    assertTest(`Single-handed ${singleWep}: Left arm stays down at side (<= 0.05)`, avLeftArm40.rotation.x <= 0.05, `leftArmX: ${avLeftArm40.rotation.x.toFixed(2)}`);
  }

  // 6. Grenade Prep Pose, Throw Motion & Belt Retrieval
  window.equipWeapon('grenade');
  window.setAiming(true);
  for (let i = 0; i < 8; i++) t.update(0.04);
  assertTest("Grenade Prep Pose: Right arm cocked high & back (> 1.55)", avRightArm40.rotation.x > 1.55, `rightArmX: ${avRightArm40.rotation.x.toFixed(2)}`);
  assertTest("Grenade Prep Pose: Left arm pointing forward towards target (> 1.10)", avLeftArm40.rotation.x > 1.10, `leftArmX: ${avLeftArm40.rotation.x.toFixed(2)}`);

  // Fire grenade to initiate throw motion
  t.update(1.2); // Ensure combatTime - lastShot >= 1.0
  window.firePlayer();
  assertTest("Grenade throw sequence activated", window.getGrenadeThrowing() === true);

  // Advance to release point (progress ~ 0.25) with smooth frames
  for (let i = 0; i < 5; i++) t.update(0.05);
  assertTest("Grenade throw release: Right arm whips forward (< 1.20)", avRightArm40.rotation.x < 1.20, `rightArmX: ${avRightArm40.rotation.x.toFixed(2)}`);

  // Advance to belt retrieval phase (progress ~ 0.55) with smooth frames
  for (let i = 0; i < 6; i++) t.update(0.05);
  assertTest("Grenade belt retrieval: Right hand moves down to belt (< 0.40)", avRightArm40.rotation.x < 0.40, `rightArmX: ${avRightArm40.rotation.x.toFixed(2)}`);

  // Settle grenade cycle
  t.update(0.60);
  window.setAiming(false);

  // 7. 3rd Person Foot Camera Mode: Mouse movement does NOT control player walking direction while moving
  t.setInside(false);
  window.setFootFreeCam(true);
  assertTest("footFreeCam is active", window.getFootFreeCam() === true);

  // Start walking forward (KeyW)
  pressKey('KeyW');
  t.update(0.05);

  const initialPlayerPos = t.getPlayer().clone();
  // Move mouse horizontally to rotate camera by 90 degrees
  window.lookInput(500, 0); // Rotate camera around player
  t.update(0.10);

  // Player should continue moving in their original forward heading, NOT swerve 90 degrees with the mouse!
  const deltaMove = t.getPlayer().clone().sub(initialPlayerPos);
  assertTest("3rd Person Camera Mode: Player maintains forward walking vector regardless of mouse camera rotation", deltaMove.length() > 0.1);

  // 8. Turning character walking does NOT turn camera with him
  const camRotBefore = t.camera.quaternion.clone();
  // Turn character by pressing KeyD (strafe right)
  releaseKey('KeyW');
  pressKey('KeyD');
  t.update(0.10);

  // Camera orientation remains untouched by character locomotion turn!
  const camRotAfter = t.camera.quaternion.clone();
  assertTest("Turning character while walking does NOT turn camera with him", Math.abs(camRotBefore.dot(camRotAfter)) > 0.999);

  releaseKey('KeyD');
  window.setFootFreeCam(false);

  // 9. Versioned deliverable SkyWard-v0.1.40.html exists
  const versionedHtmlPath34 = path.join(__dirname, '..', 'SkyWard-v0.1.40.html');
  assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(versionedHtmlPath34));


  // =================================================
  // Suite 41: v0.1.38 Fixes & Controls (L for Lights, F for Landing, Audio Clamp, Shotgun, Fleet & Toast)
  // =================================================
  console.log('\n[Suite 41: v0.1.38 Fixes & Controls]');
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 1. Key L is strictly for lights, Key F for landing
  let headlightsToggled = false;
  const origToggleHeadlights = window.toggleHeadlights;
  window.toggleHeadlights = () => { headlightsToggled = true; };
  let landingTriggered = false;
  const origLand = window.land;
  window.land = () => { landingTriggered = true; };

  // Simulate KeyL
  pressKey('KeyL');
  assertTest("Key L toggles headlights", headlightsToggled, "headlights called by KeyL");
  assertTest("Key L does NOT trigger landing", !landingTriggered, "landing not called by KeyL");

  // Simulate KeyF in pilot mode
  t.setMode('pilot');
  pressKey('KeyF');
  assertTest("Key F triggers landing in pilot mode", landingTriggered, "land called by KeyF");

  window.toggleHeadlights = origToggleHeadlights;
  window.land = origLand;

  // 2. Web Audio tone() does not throw on ultrashort durations
  let audioThrew = false;
  try {
    if (typeof window.tone === 'function' && window.audioContext) {
      window.tone(280, window.audioContext.currentTime, 0.04, 0.06, window.fxBus, 'triangle');
      window.tone(780, window.audioContext.currentTime, 0.05, 0.12, window.fxBus, 'sine');
    }
  } catch (err) {
    audioThrew = true;
  }
  assertTest("Web Audio tone() does not throw on short durations (<= 0.06s)", !audioThrew);

  // 3. Shotgun persistence in loadEquipment
  const origStorage = localStorage.getItem('horizonte-v1');
  localStorage.setItem('horizonte-v1', JSON.stringify({
    equipment: { weapons: ['pistol', 'shotgun', 'rifle', 'blade'], ammo: 50, grenades: 2, medkits: 1 }
  }));
  window.loadEquipment();
  assertTest("Shotgun ('shotgun') retained by loadEquipment from localStorage", window.equipment.weapons.includes('shotgun'));
  if (origStorage) localStorage.setItem('horizonte-v1', origStorage);

  // 4. Toast messages shown without restrictive combat-only regex
  window.statusMessage = '';
  window.toast('Faróis da nave: LIGADO');
  assertTest("Informational toast 'Faróis da nave' is displayed", window.statusMessage.includes('Faróis'));
  window.toast('Câmera em terceira pessoa.');
  assertTest("Informational toast 'Câmera em terceira pessoa' is displayed", window.statusMessage.includes('Câmera'));

  // 5. WaterCarve latitude clamp
  let asinNan = false;
  try {
    const testP = t.planets[0];
    if (typeof window.waterCarve === 'function') {
      const n = new THREE.Vector3(0, 1.0000000000000002, 0);
      const carve = window.waterCarve(testP, n);
      if (isNaN(carve)) asinNan = true;
    }
  } catch (e) {
    asinNan = true;
  }
  assertTest("WaterCarve handles pole normal without NaN", !asinNan);

  // 6. Deliverable check
  assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(path.join(__dirname, '..', 'SkyWard-v0.1.40.html')));


  // =================================================
    {
// Suite 42: v0.1.38 Features (Planet Map View, Gate Emergence, Lens Flare, Terrain Clamp & Bugfixes)
  // =================================================
  console.log('\n[Suite 42: v0.1.38 Features]');
  assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

  // 1. Planet Map View & Settlement Selection
  assertTest("openPlanetMapView function exists", typeof window.openPlanetMapView === 'function');
  const testP42 = t.planets[0];
  window.openPlanetMapView(testP42);
  const panelContent = window.document.getElementById('content')?.innerHTML || '';
  assertTest("Planet Map View renders title with planet name", panelContent.includes(testP42.def[0]));
  assertTest("Planet Map View contains interactive canvas", panelContent.includes('planetGlobeCanvas'));
  assertTest("Planet Map View has settlement list removed per user request", !panelContent.includes('ASSENTAMENTOS DISPONÍVEIS'));

  // Test selecting settlement
  assertTest("selectPlanetSettlementTarget function exists", typeof window.selectPlanetSettlementTarget === 'function');
  const firstDestIdx = t.destinations.findIndex(d => d.p === testP42);
  if (firstDestIdx >= 0) {
    window.selectPlanetSettlementTarget(firstDestIdx);
    assertTest("selectPlanetSettlementTarget updates navigation target", window.getTarget() === firstDestIdx);
  }

  // 2. Arrival Gate Emergence Vector (Inward, no flip)
  const testGate = t.gates[0];
  if (testGate) {
    const inwardDir = testGate.normal.clone().negate();
    const finalDir = testGate.normal.clone().negate();
    const exitPos = testGate.pos.clone().addScaledVector(finalDir, (testGate.halfLength || 250) + 800);
    // Ship facing inward into the solar system
    const arrivalQ = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, -1), finalDir);
    const forwardDir = new THREE.Vector3(0, 0, -1).applyQuaternion(arrivalQ);
    assertTest("Gate arrival forward direction points inward towards solar system center", forwardDir.dot(inwardDir) > 0.99);
  }

  // 3. Lens Flare System
  assertTest("getFlareIntensity function exists", typeof window.getFlareIntensity === 'function');
  assertTest("Initial lens flare intensity is finite", Number.isFinite(window.getFlareIntensity()));

  // 4. Ship Surface Clearance Clamp
  const shipPos = t.ship.position;
  const pNorm = (typeof window.planetUp === 'function') ? window.planetUp(shipPos, testP42) : new THREE.Vector3(0, 1, 0);
  const groundAlt = window.radius(testP42, pNorm);
  // Test that terrain clamp formula enforces shipPos above terrain
  assertTest("Terrain surface height calculation is strictly positive", groundAlt > 0);

  // 5. exitShip clears resting state
  window.resting = { kind: 'bed', returnPoint: new THREE.Vector3() };
  if (typeof window.exitShip === 'function') {
    window.exitShip();
    assertTest("exitShip clears resting state (resting === null)", window.resting === null);
  }

  // 6. Deliverable check
  assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(path.join(__dirname, '..', 'SkyWard-v0.1.40.html')));


  }

  // =================================================
  // Suite 43: v0.1.38 Features (Spherical Grenade Collider, 1st Person Unarmed Lowering, Rover Steering)
  // =================================================
  {
    console.log('\n[Suite 43: v0.1.38 Features]');
    assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

    // 1. Spherical Grenade Collider & Reflection Physics
    assertTest("makeWeapon generates grenade without crashing", () => {
      const dummyG = new THREE.Group();
      window.makeWeapon(dummyG, 'grenade');
      return dummyG.children.length > 0;
    });

    // Test thrown grenade object has spherical radius and clean reflection
    const testR = 0.12;
    const testPos = new THREE.Vector3(0, 10, 0);
    const testVel = new THREE.Vector3(5, -10, 0);
    const normal = new THREE.Vector3(0, 1, 0);
    const vDot = testVel.dot(normal);
    const vNormVec = normal.clone().multiplyScalar(vDot);
    const vTangVec = testVel.clone().sub(vNormVec);
    const restitution = 0.52;
    const friction = 0.78;
    const bouncedVel = vTangVec.multiplyScalar(friction).addScaledVector(normal, -vDot * restitution);

    assertTest("Spherical grenade maintains positive forward momentum on bounce", bouncedVel.x > 0);
    assertTest("Spherical grenade bounces upward along contact normal", bouncedVel.y > 0);
    assertTest("Spherical grenade does NOT invert x/z velocity randomly", Math.sign(bouncedVel.x) === Math.sign(testVel.x));

    // 2. First-Person Unarmed Hands (Lowered when idle, raises upon attack)
    assertTest("getUnarmedRaiseBlend function exists", typeof window.getUnarmedRaiseBlend === 'function');
    assertTest("getLastUnarmedAttackTime function exists", typeof window.getLastUnarmedAttackTime === 'function');

    // Initially or after idle timeout, blend is lowered (0.0)
    window.setUnarmedRaiseBlend(0.0);
    assertTest("Unarmed hands start lowered at rest (blend = 0)", window.getUnarmedRaiseBlend() === 0.0);

    // When punch attack occurs, lastUnarmedAttackTime is updated
    window.setLastUnarmedAttackTime(100.0);
    assertTest("lastUnarmedAttackTime is recorded on attack", window.getLastUnarmedAttackTime() === 100.0);

    // 3. Rover Steering Calibration (A/D responsive, mouse smooth & non-twitchy)
    assertTest("Rover steer input functions exist", typeof window.getRoverSteerInput === 'function' && typeof window.setRoverSteerInput === 'function');
    
    // Simulate keyboard steer A/D full lock
    window.setRoverSteerInput(-1.0);
    assertTest("Rover steer input accepts full left lock (-1.0)", window.getRoverSteerInput() === -1.0);
    window.setRoverSteerInput(1.0);
    assertTest("Rover steer input accepts full right lock (1.0)", window.getRoverSteerInput() === 1.0);

    // Test rover turn calculation at 2.5 rad/s base rate
    const dtTest = 0.016;
    const steerRate = 2.50;
    const speedFrac = 1.0;
    const turnCalc = 1.0 * dtTest * steerRate * speedFrac;
    assertTest("Rover turn rate with A/D is >= 2.4 rad/s (~140 deg/s)", turnCalc >= 0.038);

    // 4. Deliverable check
    assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(path.join(__dirname, '..', 'SkyWard-v0.1.40.html')));
  }


  // =================================================
  // Suite 44: v0.1.38 Features (Toast Removal, System Map Single-Circle, Planet Map List-Free 3D Globe, Orbital Autopilot Navigation)
  // =================================================
  {
    console.log('\n[Suite 44: v0.1.38 Features]');
    assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

    // 1. Middle-Screen Notifications / Toasts completely silenced and hidden
    const toastEl = window.document.getElementById('toast');
    assertTest("Middle-of-screen toast element has display none or is hidden", !toastEl || toastEl.style.display === 'none' || toastEl.style.opacity === '0');

    // 2. System Map: Exactly ONE circle per Planet
    assertTest("render2DSystemMap function exists", typeof window.render2DSystemMap === 'function');
    const svgMap = window.render2DSystemMap();
    if (window.renderPanel) window.renderPanel('map');
    const mapHtml = window.document.getElementById('content')?.innerHTML || svgMap;
    // Count occurrences of planet click handlers in the SVG
    const planetClickMatches = (svgMap.match(/handleMapPlanetClick\(/g) || mapHtml.match(/handleMapPlanetClick\(/g) || []);
    assertTest("System Map contains exactly one node per planet (no duplicate circles for same planet)", planetClickMatches.length === t.planets.length, `found ${planetClickMatches.length}, expected ${t.planets.length}`);

    // 3. System Map single-click marks planet core on HUD
    assertTest("handleMapPlanetClick function exists", typeof window.handleMapPlanetClick === 'function');
    window.handleMapPlanetClick(0);
    const markedTarget = window.getTarget ? window.getTarget() : window.target;
    assertTest("Single click on planet marks planet core", markedTarget && markedTarget.type === 'planetCore' && markedTarget.p === t.planets[0]);

    // Check currentGoal for planetCore
    const coreGoal = window.currentGoal ? window.currentGoal() : null;
    assertTest("HUD goal shows planet core target label ending with NÚCLEO", coreGoal && coreGoal.label && coreGoal.label.includes('NÚCLEO'));

    // Test automatic unmarking when reaching atmosphere
    // Simulate ship at atmosphere limit
    const p0 = t.planets[0];
    t.ship.position.copy(p0.center).add(new THREE.Vector3(0, p0.r + 500, 0)); // inside atmosphere
    t.update(0.05);
    const targetAfterAtmo = window.getTarget ? window.getTarget() : window.target;
    assertTest("Planet core target automatically unmarks upon entering atmosphere", targetAfterAtmo === -1 || targetAfterAtmo === null);

    // 4. Planet Map View: List-Free 3D Globe
    assertTest("openPlanetMapView function exists", typeof window.openPlanetMapView === 'function');
    window.openPlanetMapView(p0);
    const pMapHtml = window.document.getElementById('content')?.innerHTML || '';
    assertTest("Planet Map View does NOT contain any settlement cards list", !pMapHtml.includes('class="cards"') && !pMapHtml.includes('ASSENTAMENTOS DISPONÍVEIS'));
    assertTest("Planet Map View contains centered 3D planet globe canvas", pMapHtml.includes('planetGlobeCanvas') && pMapHtml.includes('planetGlobeContainer'));

    // 5. Intelligent Orbital Autopilot Navigation & Line-of-Sight Check
    assertTest("hasDirectLineOfSight function exists", typeof window.hasDirectLineOfSight === 'function');
    
    // Position on north pole, target on south pole of planet 0 -> MUST return false (occluded!)
    const northPole = p0.center.clone().add(new THREE.Vector3(0, p0.r + 100, 0));
    const southPole = p0.center.clone().add(new THREE.Vector3(0, -(p0.r + 2), 0));
    assertTest("Target on opposite side of planet has NO direct line of sight (hasDirectLineOfSight is false)", window.hasDirectLineOfSight(northPole, southPole, p0) === false);

    // Target on same side with clear line of sight -> MUST return true
    const highOrbitNorth = p0.center.clone().add(new THREE.Vector3(0, p0.r + 6000, 0));
    const surfaceNorth = p0.center.clone().add(new THREE.Vector3(0, p0.r + 2, 0));
    assertTest("Target on same side has direct line of sight (hasDirectLineOfSight is true)", window.hasDirectLineOfSight(highOrbitNorth, surfaceNorth, p0) === true);

    // Test getSmartAutopilotWaypoint returns high safe orbit altitude when target is on far side
    t.ship.position.copy(northPole);
    const mockDest = { pos: southPole, p: p0, name: 'Cidade Polo Sul' };
    const wp = window.getSmartAutopilotWaypoint(mockDest, { p: p0, alt: 100, density: 0.1 });
    const wpAlt = wp.distanceTo(p0.center) - p0.r;
    assertTest("Autopilot routes via high orbital altitude when target is on far side (does NOT crash into ground)", wpAlt >= (p0.atmosphereHeight || 3000), `wpAlt: ${wpAlt.toFixed(0)}m`);

    // 6. Deliverable check
    assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(path.join(__dirname, '..', 'SkyWard-v0.1.40.html')));
  }

  console.log("=================================================");

  // =================================================
  // Suite 45: v0.1.39 Features (Interplanetary Autopilot & Universal Settlements)
  // =================================================
  {
    console.log('\n[Suite 45: v0.1.39 Features]');
    assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

    // Initialize system and verify all planets and settlements
    t.loadSystem(t.currentSystem);
    assertTest("All planets in system have surfaceLoaded = true", t.planets.every(p => p.surfaceLoaded));

    const allSettlements = window.settlements || [];
    assertTest("Settlements generated across multiple planets (not just planet 0)", allSettlements.length >= 6, `found ${allSettlements.length}`);

    // Verify all settlements have root position exactly at their center (no root displacement!)
    const allRootsExact = allSettlements.every(s => s.root && s.root.position.distanceTo(s.center) < 0.01);
    assertTest("All settlements have independent root positions exactly at their surface center", allRootsExact);

    // Verify city 0 landing pad has hangar terminal right beside it (< 35m)
    const s0 = allSettlements[0];
    const termObj = s0.root.getObjectByName('hangarTerminal');
    const termWp = new THREE.Vector3();
    if (termObj) termObj.getWorldPosition(termWp);
    const termDist = termObj ? termWp.distanceTo(s0.center) : 9999;
    assertTest("City landing pad has hangar terminal stationed right beside it (< 35m)", termDist < 35, `dist: ${termDist.toFixed(1)}m`);

    const planetsWithSettlements = new Set(allSettlements.map(s => s.p));
    assertTest("Multiple planets have active settlements", planetsWithSettlements.size >= 2, `found ${planetsWithSettlements.size}`);

    // Verify settlements exist in destinations
    const villageDests = t.destinations.filter(d => d.kind === 'village' || d.name.includes('Vilarejo'));
    assertTest("Destinations contain villages across the system", villageDests.length >= 2, `found ${villageDests.length}`);

    const cityDests = t.destinations.filter(d => d.kind === 'city' || d.name.includes('Cidade'));
    assertTest("Destinations contain cities across the system", cityDests.length >= 2, `found ${cityDests.length}`);

    // Test Planet Map View for Planet 1 (Rhodos) contains settlements
    const p1 = t.planets[1];
    window.openPlanetMapView(p1);
    const rhodosDests = t.destinations.filter(d => d.p === p1 && !d.gate && d.kind !== 'water');
    assertTest("Rhodos has multiple destinations available for 3D globe", rhodosDests.length >= 2, `found ${rhodosDests.length}`);

    // Test North Pole location visibility on 3D globe (qX tilt = -0.28)
    const normUp = new THREE.Vector3(0, 1, 0);
    const qY = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), 0);
    const qX = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), 0.28);
    const rotNormUp = normUp.clone().applyQuaternion(qY).applyQuaternion(qX);
    assertTest("North pole location tilts forward towards viewer (rotNorm.z >= -0.05)", rotNormUp.z >= -0.05, `z: ${rotNormUp.z.toFixed(3)}`);

    // Test Interplanetary Autopilot LOS:
    // Ship in orbit of Planet 0 on side facing Planet 1 has clear LOS to Planet 1
    const p0 = t.planets[0];
    const dirToP1 = p1.center.clone().sub(p0.center).normalize();
    const shipPosFacingP1 = p0.center.clone().addScaledVector(dirToP1, p0.r + 4000);
    const losToP1 = window.hasDirectLineOfSight(shipPosFacingP1, p1.center, p0);
    assertTest("Ship in orbit facing target planet has clear direct line of sight", losToP1 === true);

    // Target dest on Rhodos
    const rhodosTarget = rhodosDests[0];
    t.ship.position.copy(shipPosFacingP1);
    const wpInterplanetary = window.getSmartAutopilotWaypoint(rhodosTarget, { density: 0, alt: 4000, p: p0 });
    // Waypoint must NOT be stuck in orbit around planet 0: it should point across space towards Rhodos!
    // Waypoint must NOT be stuck in orbit around planet 0: it should point across space towards Rhodos!
    const distFromP0ToWp = wpInterplanetary.distanceTo(p0.center);
    const distFromWpToP1Center = wpInterplanetary.distanceTo(p1.center);
    const maxSafeOrbitP1 = p1.r + (p1.atmosphereHeight || 3200) + 1600;
    assertTest("Interplanetary autopilot routes across space towards destination planet (does NOT stay stuck in local orbit)", distFromP0ToWp > 6000 && distFromWpToP1Center <= maxSafeOrbitP1, `wp to P1 center: ${distFromWpToP1Center.toFixed(0)}m, P0 to wp: ${distFromP0ToWp.toFixed(0)}m`);

    // Verify deliverable
    const pDeliverable = path.join(__dirname, '..', 'SkyWard-v0.1.40.html');
    assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(pDeliverable));
  }

  // =================================================
  // Suite 46: v0.1.40 Features (Smooth Autopilot Touchdown, Planetary Visibility & Lens Flare Occlusion)
  // =================================================
  {
    console.log('\n[Suite 46: v0.1.40 Features]');
    assertTest("Version tag is officially '0.1.40'", window.VERSION === '0.1.40', window.VERSION);

    // 1. Smooth Autopilot Final Approach
    t.loadSystem(t.currentSystem);
    for (const p of t.planets) if (!p.surfaceLoaded) t.loadPlanetSurface(p);

    const startDest = t.destinations.find(d => d.kind === 'planet' && d.p === t.planets[0]);
    const pose = window.landingPose(startDest.pos, t.planets[0]);
    assertTest("Landing pose position is computed above surface", pose && pose.pos.distanceTo(t.planets[0].center) > t.planets[0].r);
    assertTest("Landing pose quaternion is normalized", Math.abs(pose.q.length() - 1.0) < 0.01);

    // 2. Planetary Visibility in Sky (no heavy wash-out)
    const p1 = t.planets[1];
    assertTest("Planet globe material has fog disabled", p1.globe.material.fog === false);
    assertTest("Planet haze on other planets is subtle (<= 0.10, not washed out)", p1.haze.value <= 0.10, `haze: ${p1.haze.value}`);

    // 3. Lens Flare Occlusion against Ship and Rover
    assertTest("getFlareIntensity function exists", typeof window.getFlareIntensity === 'function');
    assertTest("drawLensFlare function exists", typeof window.drawLensFlare === 'function');
    
    // Test Pilot looking up into solid ship roof: sun must be occluded
    t.setMode('pilot');
    t.setThirdPerson(false);
    if (window.suns && window.suns[0] && window.suns[0].pos) {
      window.suns[0].pos.set(0, 10000, 0); // Sun straight up in sky
    }
    t.ship.quaternion.set(0, 0, 0, 1); // Ship level, roof straight up
    t.camera.position.set(0, 1.9, -3.7);
    t.camera.quaternion.setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0)); // Camera looking straight up into roof
    
    const flareCanvasMock = { width: 1920, height: 1080 };
    const flareCtxMock = {
      save: () => {}, restore: () => {}, createRadialGradient: () => ({ addColorStop: () => {} }),
      createLinearGradient: () => ({ addColorStop: () => {} }), fillRect: () => {}, beginPath: () => {},
      arc: () => {}, fill: () => {}, stroke: () => {}
    };
    
    // Draw lens flare tick
    window.drawLensFlare(flareCtxMock, flareCanvasMock, 0.5);
    assertTest("Sun lens flare is completely occluded when looking up into ship roof in cockpit", window.getFlareIntensity() < 0.05, `intensity: ${window.getFlareIntensity()}`);

    // 4. Deliverable verification
    const pDeliverable = path.join(__dirname, '..', 'SkyWard-v0.1.40.html');
    assertTest("Versioned deliverable SkyWard-v0.1.40.html exists on filesystem", fs.existsSync(pDeliverable));
  }

  console.log("=================================================");
  console.log(`Test Summary: ${passedCount} passed, ${failedCount} failed`);
  console.log("=================================================");
  if (failedCount > 0) process.exit(1);
  else process.exit(0);
}, 600);
